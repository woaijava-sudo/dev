﻿using System.Collections;
using System.IO;
using System.Text;

namespace Front.front.lexer
{
    public class Lexer
    {
        public static int line = 1;
        char peek = ' ';
        Hashtable words = new Hashtable();
        TextReader reader = null;

        public Lexer(TextReader reader)
        {
            reserve(new Word("if", Tag.IF));
            reserve(new Word("else", Tag.ELSE));
            reserve(new Word("while", Tag.WHILE));
            reserve(new Word("do", Tag.DO));
            reserve(new Word("break", Tag.BREAK));

            reserve(Word.True); reserve(Word.False);

            reserve(symbols.Type.Int); reserve(symbols.Type.Char);
            reserve(symbols.Type.Bool); reserve(symbols.Type.Float);

            this.reader = reader;
        }

        void reserve(Word w)
        {
            words.Add(w.lexeme, w);
        }

        void readch()
        {
            peek = (char)reader.Read();
        }

        bool readch(char c)
        {
            readch();
            if (peek != c) return false;
            peek = ' ';
            return true;
        }

        public Token scan()
        {
            for (;; readch())
            {
                if (peek == ' ' || peek == '\t') continue;
                else if (peek == '\n') line = line + 1;
                else break;
            }

            switch (peek)
            {
                case '&':
                    if (readch('&')) return Word.and; else return new Token('&');
                case '|':
                    if (readch('|')) return Word.or; else return new Token('|');
                case '=':
                    if (readch('=')) return Word.eq; else return new Token('=');
                case '!':
                    if (readch('=')) return Word.ne; else return new Token('!');
                case '<':
                    if (readch('=')) return Word.le; else return new Token('<');
                case '>':
                    if (readch('=')) return Word.ge; else return new Token('>');
            }

            if (char.IsDigit(peek))
            {
                int v = 0;
                do
                {
                    v = 10 * v + System.Convert.ToInt32(peek.ToString(), 10);
                    readch();
                } while (char.IsDigit(peek));

                if (peek != '.') return new Num(v);
                float x = v; float d = 10;

                for (;;)
                {
                    readch();
                    if (!char.IsDigit(peek)) break;
                    x = x + System.Convert.ToInt32(peek.ToString(), 10) / d; d = d * 10;
                }

                return new Real(x);
            }

            if (char.IsLetter(peek))
            {
                StringBuilder b = new StringBuilder();
                do
                {
                    b.Append(peek); readch();
                } while (char.IsLetterOrDigit(peek));

                string s = b.ToString();

                Word w = words[s] as Word;
                if (w != null) return w;

                w = new Word(s, Tag.ID);
                words.Add(s, w);

                return w;
            }

            Token tok = new Token(peek); peek = ' ';
            return tok;
        }
    }
}
