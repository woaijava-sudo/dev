﻿using System;
using System.IO;

namespace Front.front.global
{
    public static class Print
    {
        public static TextWriter Out { get { return GetOutputText(); } }

        static TextWriter GetOutputText()
        {
            TextWriter writer = Form1.writer;
            if (writer == null)
            {
                throw new Exception("Output stream is empty");
            }
            return writer;
        }
    }
}
