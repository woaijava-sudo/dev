﻿using Front.front.lexer;
using Front.front.symbols;

namespace Front.front.inter
{
    public class Id : Expr
    {
        public int offset;     // relative address

        public Id(Word id, Type p, int b)
            : base(id , p)
        {
            offset = b;
        }
    }
}
