﻿using Front.front.lexer;
using Front.front.symbols;

namespace Front.front.inter
{
    /// <summary>
    /// 逻辑运算
    /// </summary>
    public class Op : Expr
    {
        public Op(Token tok, Type p): base(tok, p) { }

        public override Expr reduce()
        {
            Expr x = gen();
            Temp t = new Temp(type);
            emit(t.ToString() + " = " + x.ToString());
            return t;
        }
    }
}
