﻿using Front.front.lexer;
using Front.front.global;
using System;

namespace Front.front.inter
{
    public class Node
    {
        int lexline = 0;

        public Node() { lexline = Lexer.line; }

        public void error(string s) { throw new Exception("第 " + lexline + " 行: " + s); }

        protected static int labels = 0;

        public int newlabel() { return ++labels; }

        public void emitlabel(int i) { Print.Out.Write("L" + i + ":"); }

        public void emit(string s) { Print.Out.WriteLine("\t" + s); }
    }
}
