﻿using Front.front.lexer;
using Front.front.symbols;

namespace Front.front.inter
{
    public class Temp : Expr
    {
        static int count = 0;
        int number = 0;

        public Temp(Type p) : base(Word.temp, p) { number = ++count; }
        public static void clear() { count = 0; }

        public override string ToString() { return "t" + number; }
    }
}
