﻿namespace Front.front.inter
{
    public class Break : Stmt
    {
        Stmt stmt;

        public Break()
        {
            if (Stmt.Enclosing == Stmt.Null) error("未关闭的 break 语句");
            stmt = Stmt.Enclosing;
        }

        public override void gen(int b, int a)
        {
            emit("goto L" + stmt.after);
        }
    }
}
