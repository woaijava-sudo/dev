﻿using Front.front.symbols;

namespace Front.front.inter
{
    public class Do : Stmt
    {
        Expr expr; Stmt stmt;

        public Do() { expr = null; stmt = null; }

        public void init(Stmt s, Expr x)
        {
            expr = x; stmt = s;
            if (expr.type != Type.Bool) expr.error("do 表达式需要返回布尔类型");
        }

        public override void gen(int b, int a)
        {
            after = a;
            int label = newlabel();   // label for expr
            stmt.gen(b, label);
            emitlabel(label);
            expr.jumping(b, 0);
        }
    }
}
