﻿using Front.front.lexer;
using Front.front.symbols;

namespace Front.front.inter
{
    /// <summary>
    /// 数组[]
    /// </summary>
    public class Access : Op
    {
        public Id array;
        public Expr index;

        public Access(Id a, Expr i, Type p)  // p is element type after
            : base(new Word("[]", Tag.INDEX), p)  // flattening the array
        {
            array = a; index = i;
        }

        public override Expr gen() { return new Access(array, index.reduce(), type); }

        public override void jumping(int t, int f) { emitjumps(reduce().ToString(), t, f); }

        public override string ToString()
        {
            return array.ToString() + " [ " + index.ToString() + " ]";
        }
    }
}
