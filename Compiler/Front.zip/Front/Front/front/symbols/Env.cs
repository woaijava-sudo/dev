﻿using System.Collections;
using Front.front.lexer;
using Front.front.inter;

namespace Front.front.symbols
{
    public class Env
    {
        private Hashtable table = new Hashtable();
        protected Env prev;

        public Env(Env n)
        {
            prev = n;
        }

        public void put(Token tok, Id id) { table[tok] = id; }

        public Id get(Token tok)
        {
            for (Env e = this; e != null; e = e.prev)
            {
                Id found = (Id)(e.table[tok]);
                if (found != null) return found;
            }
            return null;
        }
    }
}
