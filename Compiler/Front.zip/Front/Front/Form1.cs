﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Front.front.lexer;
using Front.front.parser;

namespace Front
{
    public partial class Form1 : Form
    {
        public static TextWriter writer;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCompile_Click(object sender, EventArgs e)
        {
            textOutput.Text = string.Empty;
            try
            {
	            using(TextReader reader = new StringReader(textInput.Text.Replace("\r\n", "\n")))
	            {
	                using (writer = new StringWriter())
	                {
	                    Lexer lex = new Lexer(reader);
			            Parser parse = new Parser(lex);
			            parse.program();

                        writer.Flush();
                        textOutput.Text = writer.ToString().Replace("\n", "\r\n");
	                }
	            }
            }
            catch (System.Exception ex)
            {
                textOutput.Text = ex.Message;
            }
        }

        private void textInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A && e.Control)
            {
                textInput.SelectAll();
            }
        }
    }
}
