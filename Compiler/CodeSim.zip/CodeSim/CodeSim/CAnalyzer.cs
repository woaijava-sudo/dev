﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeSim
{
	public class CAnalyzer
	{
		CTreeNode m_Program;
		CParser m_Parser;
		CSymTbl m_SymbolTable;
		CFunArgsCheck m_FunArgs;
		string m_global;
		int location;

		public CAnalyzer(string str)
		{
			m_Parser = new CParser(str);
			m_Program = null;
			m_SymbolTable = new CSymTbl();
			m_FunArgs = new CFunArgsCheck();
			m_global = Strings.IDS_A_GLOBAL;

			location = 0;
		}

		void BuildSymbolTable(CTreeNode node)
		{
			traverse(node, a => insertNode(a), a => nullProc(a));
		}

		public CSymTbl GetSymbolTable()
		{
			return m_SymbolTable;
		}

		public CTreeNode GetSyntaxTree()
		{
			return m_Program;
		}

		public void typeCheck(CTreeNode node)
		{
			traverse(node, nullProc, checkNode);
			if (!m_SymbolTable.st_lookup(Strings.IDS_A_MAIN, m_global))
				Program.PrintError(Strings.IDS_E__UNRESOLVED_MAIN);
		}

		public void Run()
		{
			m_Program = m_Parser.BuildSyntaxTree();
			BuildSymbolTable(m_Program);
			typeCheck(m_Program);
		}

		void traverse(CTreeNode t, Action<CTreeNode> preProc, Action<CTreeNode> postProc)
		{
			if (t != null)
			{
				preProc(t);
				for (int i = 0; i < CTreeNode.MAX_CHILDREN; i++)
					traverse(t.child[i], preProc, postProc);
				postProc(t);
				traverse(t.sibling, preProc, postProc);
			}
		}

		void nullProc(CTreeNode t)
		{
			return;
		}

		void insertNode(CTreeNode t)
		{
			switch (t.nodekind)
			{
				case NodeKind.kFunDec:
					if (!m_SymbolTable.st_lookup(t.szName, t.szScope))
					{
						// not defined, so add it to the symbol table
						m_SymbolTable.st_insert(t.szName, t.szScope, t.type, t.lineno, location++);
						// add it to function declaration list
						m_FunArgs.fa_insert(t);
					}
					else // redefinition
						Program.PrintError(Strings.IDS_E__REDEF_FUNC, t.lineno, t.szName);
					break;
				case NodeKind.kVarDec:
				case NodeKind.kParam:
					if (!m_SymbolTable.st_lookup(t.szName, t.szScope))
						// not defined, so add it to the symbol table
						m_SymbolTable.st_insert(t.szName, t.szScope, t.type, t.lineno, location++, t.bArray);
					else // redefinition
						Program.PrintError(Strings.IDS_E__REDEF_VAR, t.lineno, t.szName);
					break;
				case NodeKind.kStmt:
					switch (t.kind.stmt)
					{
						case StmtKind.kLabel:
							if (!m_SymbolTable.st_lookup(t.szName, t.szScope))
								// first time encountered in the scope, add it to the symbol table
								m_SymbolTable.st_insert(t.szName, t.szScope, LTokenType._LABEL, t.lineno, location++);
							else // label redifition
								Program.PrintError(Strings.IDS_E__REDEF_LABEL, t.lineno, t.szName, t.szScope);
							break;
						case StmtKind.kGoto:
							if (!m_SymbolTable.st_lookup(t.szName, t.szScope))
								// label undeclared
								Program.PrintError(Strings.IDS_E__UNDEC_LABEL, t.lineno, t.szName, t.szScope);
							else
								m_SymbolTable.st_insert(t.szName, t.szScope, LTokenType._LABEL, t.lineno, 0);
							break;
						case StmtKind.kCall:
							if (!m_SymbolTable.st_lookup(t.szName, t.szScope))
								Program.PrintError(Strings.IDS_E__UNRESOLVED_SYMBOL, t.lineno, t.szName);
							else
								m_SymbolTable.st_insert(t.szName, t.szScope, LTokenType._ID, t.lineno, 0);
							break;
						default:
							break;
					}
					break;
				case NodeKind.kExp:
					switch (t.kind.exp)
					{
						case ExpKind.kID:
							if (!m_SymbolTable.st_lookup(t.szName, t.szScope) &&
								!m_SymbolTable.st_lookup(t.szName, m_global))
								// undeclared
								Program.PrintError(Strings.IDS_E__UNDEC_VAR, t.lineno, t.szName);
							else if (!m_SymbolTable.st_lookup(t.szName, t.szScope))
							{
								// local variable
								if (t.father != null && (t.father.nodekind != NodeKind.kStmt || t.father.kind.stmt != StmtKind.kCall)/* not in call statement */ &&
									t.bArray != m_SymbolTable.st_lookup_isarray(t.szName, t.szScope))
								{
									// one is array but the other is not
									Program.PrintError(Strings.IDS_E__DECL_ARRAY, t.lineno, t.szName, t.bArray ? "不是" : "为");
									break;
								}
								m_SymbolTable.st_insert(t.szName, t.szScope, t.type, t.lineno, 0);
							}
							else
							{ // global variable
								t.szScope = m_global;
								if (t.father != null && (t.father.nodekind != NodeKind.kStmt || t.father.kind.stmt != StmtKind.kCall)/* not in call statement */ &&
									t.bArray != m_SymbolTable.st_lookup_isarray(t.szName, t.szScope))
								{
									// one is array but the other is not
									Program.PrintError(Strings.IDS_E__DECL_ARRAY, t.lineno, t.szName, t.bArray ? " not " : " ");
									break;
								}
								m_SymbolTable.st_insert(t.szName, t.szScope, t.type, t.lineno, 0);
							}
							break;
						default:
							break;
					}
					break;
				default:
					break;
			}
		}

		void checkNode(CTreeNode t)
		{
			string m_global = Strings.IDS_A_GLOBAL;

			CTreeNode p = t;
			int ret;

			switch (t.nodekind)
			{
				case NodeKind.kStmt:
					switch (t.kind.stmt)
					{
						case StmtKind.kReturn:
							if (t.child[0] == null)
							{ // 'return' returns 'void'
								if (m_SymbolTable.st_lookup_type(t.szName, m_global) != LTokenType._VOID)
									Program.PrintError(Strings.IDS_E__FUNC_RETURN, t.lineno, t.szName);
							}
							break;
						case StmtKind.kBreak:
							while (p.father != null && (p.father.nodekind != NodeKind.kStmt || p.father.kind.stmt != StmtKind.kWhile))
								p = p.father;
							if (p.father == null)
								// 'break' is not within a while statment
								Program.PrintError(Strings.IDS_E__ILLEGAL_BREAK, t.lineno);
							break;
						case StmtKind.kContinue: // treat it like kBreak
							while (p.father != null && (p.father.nodekind != NodeKind.kStmt || p.father.kind.stmt != StmtKind.kWhile))
								p = p.father;
							if (p.father == null)
								// 'continue' is not within a while statment
								Program.PrintError(Strings.IDS_E__ILLEGAL_CONTINUE, t.lineno);
							break;
						case StmtKind.kCall:
							// check if its arguments match declaration
							ret = m_FunArgs.fa_check(t);
							if (ret != -3)
							{// errors 
								if (ret >= 0)
									Program.PrintError(Strings.IDS_E__FUNC_PARA, t.lineno, t.szName, ret);
								else if (ret == -1)
									Program.PrintError(Strings.IDS_E__UNDEC_FUNC, t.lineno, t.szName);
								else
									Program.PrintError(Strings.IDS_E__FUNC_PARA_MISMATCH, t.lineno, t.szName);
								break;
							}
							t.type = m_SymbolTable.st_lookup_type(t.szName, t.szScope);
							break;
						default:
							break;
					}
					break;
				case NodeKind.kExp:
					switch (t.kind.exp)
					{
						case ExpKind.kOp:// assign a type to this op node
							if (t.type == LTokenType.LOGICAL_NOT || t.type == LTokenType.ASSIGN)
								t.type = t.child[0].type;
							else
							{
								// the others are binary operations, 
								// and the type should be the subexpression with higher precision
								if (t.child[0].type == LTokenType._VOID || t.child[1].type == LTokenType._VOID)
									Program.PrintError(Strings.IDS_E__ILLEGAL_USE_VOID, t.lineno);
								else if (t.child[0].type == LTokenType._FLOAT || t.child[1].type == LTokenType._FLOAT)
									t.type = LTokenType._FLOAT;
								else if (t.child[0].type == LTokenType._INT || t.child[1].type == LTokenType._INT)
									t.type = LTokenType._INT;
								else
									t.type = LTokenType._CHAR;
							}
							break;
						case ExpKind.kID:
							// find the type in the symbol table, assign it to the node
							t.type = m_SymbolTable.st_lookup_type(t.szName, t.szScope);
							t.bArray = m_SymbolTable.st_lookup_isarray(t.szName, t.szScope);
							break;
						default:
							break;
					}
					break;
				default:
					break;
			}
		}
	}
}
