﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeSim
{
	public class ParamListRec
	{
		public LTokenType type;
		public bool bArray;

		public ParamListRec()
		{
			bArray = false;
		}
		public ParamListRec(LTokenType t, bool b)
			: this()
		{
			type = t;
			bArray = b;
		}
	};

	public class FunDecListRec
	{
		public string name;
		public LTokenType type;
		public List<ParamListRec> param = new List<ParamListRec>();

		public FunDecListRec()
		{
		}

		public FunDecListRec(string s, LTokenType t)
			: this()
		{
			name = s;
			type = t;
		}
	};

	public class CFunArgsCheck
	{
		List<FunDecListRec> funcs = new List<FunDecListRec>();
		public CFunArgsCheck()
		{
		}

		public void fa_insert(CTreeNode node)
		{
			var temp = new FunDecListRec(node.szName, node.type);
			var p = node.child[0];
			while (p != null)
			{
				temp.param = new List<ParamListRec>();
				temp.param.Add(new ParamListRec(p.type, p.bArray));
				p = p.sibling;
			}
			funcs.Add(temp);
		}

		public int fa_check(CTreeNode node)
		{
			var l = funcs.Find(a => a.name == node.szName);
			if (l == null)
				return -1;

			var i = 0; var p = node.child[0];
			while (i < l.param.Count && p != null)
			{
				if ((l.param[i].type == p.type && l.param[i].bArray == p.bArray) ||
					(p.nodekind == NodeKind.kExp && p.kind.exp == ExpKind.kConst &&
					(p.type == LTokenType._NUM || p.type == LTokenType._CHARACTER)))
				{
					i++; p = p.sibling;
				}
				else
					return -2;
			}

			if (i < l.param.Count || p != null)
			{
				return l.param.Count;
			}

			return -3;
		}
	}
}
