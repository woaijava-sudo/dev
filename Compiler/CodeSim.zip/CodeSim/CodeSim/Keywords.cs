﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeSim
{
	public class Keywords
	{
		// C- Keywords
		static public readonly string[] s_apszCKeywordList = new string[]
		{
			"class",
			"public",
			"private",
			"protected",
			"static",
			"namespace",
			"using",
			"var",
			"new",
			"auto",
			"break",
			"case",
			"continue",
			"const",
			"default",
			"delete",
			"do",
			"else",
			"enum",
			"extern",
			"for",
			"goto",
			"if",
			"while",
			"register",
			"return",
			"sizeof",
			"struct",
			"switch",
			"typedef",
			"union",
			"volatile",
			"mutable",
			"true",
			"false",
		};

		// C- Types
		static public readonly string[] s_apszCTypeList =
		{
			"signed",
			"unsigned",
			"char",
			"bool",
			"short",
			"int",
			"long",
			"float",
			"double",
			"void"
		};

		// Token analysis
		static public readonly string[] s_apszCReservedKeywords =
		{
			// keywords
			"extern", "static", "sizeof",
			"auto", "const", "typedef", "default",
			"struct", "enum", "class", "union",
			"signed", "unsigned",
			"void",
			"char", "int", "double", "float", "long",
			"volatile", "mutable", "register",
			"if", "else", "for", "break", "while", "do", "continue", "switch", "case", "goto",
			"return",

			// functions


			// operations
			"=", "+", "-", "*", "/", "%", "&", "|", "~", "!", "<", ">",

			// interpunctions
			"(", ")", "{", "}", "[", "]", ",", ".", ";", ":"
		};
	}
}
