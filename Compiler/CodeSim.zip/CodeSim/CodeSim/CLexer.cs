﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeSim
{
	public enum LTokenType
	{
		// 保留关键字
		_EXTERN, _STATIC, _SIZEOF,
		_AUTO, _CONST, _TYPEDEF, _DEFAULT,
		_STRUCT, _ENUM, _CLASS, _UNION,
		_SIGNED, _UNSIGNED,
		_VOID,
		_CHAR, _INT, _DOUBLE, _FLOAT, _LONG,
		_VOLATILE, _MUTABLE, _REGISTER,
		_IF, _ELSE, _FOR, _BREAK, _WHILE, _DO, _CONTINUE, _SWITCH, _CASE, _GOTO,
		_RETURN,

		// 函数

		// 操作符
		ASSIGN, PLUS, MINUS, TIMES, DIV, MOD,
		BITWISE_AND, BITWISE_OR, BITWISE_NOT, LOGICAL_NOT, LT, GT,

		// 标点符号
		LPARAN, RPARAN, LBRACE, RBRACE, LSQUARE, RSQUARE, COMMA, DOT, SEMI, COLON,

		// 二元操作符
		EQ					/* == */,
		NEQ					/* != */,
		PLUS_PLUS			/* ++ */,
		MINUS_MINUS			/* -- */,
		PLUS_ASSIGN			/* += */,
		MINUS_ASSIGN		/* -= */,
		TIMES_ASSIGN		/* *= */,
		DIV_ASSIGN			/* /= */,
		NGT					/* <= */,
		NLT					/* >= */,
		LOGICAL_AND			/* && */,
		LOGICAL_OR			/* || */,

		// 其他
		_EOF, _ID, _NUM, _STRING, _CHARACTER, _LABEL, _ERROR, _NONE,
	};

	public struct TOKEN
	{
		public LTokenType type;
		public string str;
	};

	public class CLexer : CToken
	{
		bool m_bPushedBack;
		TOKEN m_token;
		Dictionary<string, int> m_KeyIndex = null;
		Action<string> m_action = null;

		public CLexer(string str)
			: base(str)
		{
			m_bPushedBack = false;
			m_token.type = LTokenType._ID;

			MapKeyword();
		}

		void MapKeyword()
		{
			if (m_KeyIndex == null)
			{
				m_KeyIndex = new Dictionary<string, int>(); int id = 0;
				Keywords.s_apszCReservedKeywords.ToList().ForEach(a => m_KeyIndex.Add(a, id++));
			}
		}

		LTokenType GetTokenType(string str, LTokenType def = LTokenType._ERROR)
		{
			var t = LTokenType._ERROR;
			try
			{
				var index = m_KeyIndex[str];
				if (Enum.IsDefined(typeof(LTokenType), index))
				{
					t = (LTokenType)Enum.ToObject(typeof(LTokenType), index);
				}
			}
			catch (KeyNotFoundException)
			{
				t = def;
			}
			return t;
		}

		public override void PushBack()
		{
			m_bPushedBack = true;
		}

		public TOKEN NextToken()
		{
			if (m_bPushedBack)
			{
				m_bPushedBack = false;
				return m_token;
			}
			if (m_token.type == LTokenType._EOF) return m_token;

			int val = base.QNextToken(); // get token
			int lineno = LineNo(); // the actual line the token is got from

			m_token.type = LTokenType._ERROR;
			m_token.str = "Error";

			if (val == TT_EOF)
			{
				m_token.type = LTokenType._EOF;
				m_token.str = "EOF";
				return m_token;
			}

			if (val == TT_WORD)
			{
				m_token.type = GetTokenType(m_sVal, LTokenType._ID);
				m_token.str = m_sVal;
			}
			else if (val == TT_INTEGER || val == TT_REAL)
			{
				m_token.type = LTokenType._NUM;
				m_token.str = GetStrValue();
			}
			else if (val == TT_STRING)
			{
				m_token.type = LTokenType._STRING;
				m_token.str = m_sVal;
			}
			else if (val == TT_CHAR)
			{
				m_token.type = LTokenType._CHARACTER;
				m_token.str = (m_sVal.Length == 0) ? " " : m_sVal[0].ToString();
			}
			else if (val == TT_EOL)
			{
				return NextToken();
			}
			else if ("=+-*/&|~!<>(){}[],.;:".IndexOf((char)val) != -1)
			{
				m_token.str = ((char)val).ToString();
				m_token.type = GetTokenType(m_token.str);

				// complex operations
				switch (val)
				{
					case '=':
						if (base.QNextToken() == '=')
						{
							m_token.str = "==";
							m_token.type = LTokenType.EQ;
						}
						else
							base.PushBack();
						break;
					case '!':
						if (base.QNextToken() == '=')
						{
							m_token.str = "!=";
							m_token.type = LTokenType.NEQ;
						}
						else
							base.PushBack();
						break;
					case '+':
						if (base.QNextToken() == '=')
						{
							m_token.str = "+=";
							m_token.type = LTokenType.PLUS_ASSIGN;
						}
						else
						{
							base.PushBack();
							if (base.QNextToken() == '+')
							{
								m_token.str = "++";
								m_token.type = LTokenType.PLUS_PLUS;
							}
							else
								base.PushBack();
						}
						break;
					case '-':
						if (base.QNextToken() == '=')
						{
							m_token.str = "-=";
							m_token.type = LTokenType.MINUS_ASSIGN;
						}
						else
						{
							base.PushBack();
							if (base.QNextToken() == '-')
							{
								m_token.str = "--";
								m_token.type = LTokenType.MINUS_MINUS;
							}
							else
								base.PushBack();
						}
						break;
					case '*':
						if (base.QNextToken() == '=')
						{
							m_token.str = "*=";
							m_token.type = LTokenType.TIMES_ASSIGN;
						}
						else
							base.PushBack();
						break;
					case '/':
						if (base.QNextToken() == '=')
						{
							m_token.str = "/=";
							m_token.type = LTokenType.DIV_ASSIGN;
						}
						else
							base.PushBack();
						break;
					case '<':
						if (base.QNextToken() == '>')
						{
							m_token.str = "<>";
							m_token.type = LTokenType.NEQ;
						}
						else
						{
							base.PushBack();
							if (base.QNextToken() == '=')
							{
								m_token.str = "<=";
								m_token.type = LTokenType.NGT;
							}
							else
								base.PushBack();
						}
						break;
					case '>':
						if (base.QNextToken() == '=')
						{
							m_token.str = ">=";
							m_token.type = LTokenType.NLT;
						}
						else
							base.PushBack();
						break;
					case '&':
						if (base.QNextToken() == '&')
						{
							m_token.str = "&&";
							m_token.type = LTokenType.LOGICAL_AND;
						}
						else
							base.PushBack();
						break;
					case '|':
						if (base.QNextToken() == '|')
						{
							m_token.str = "||";
							m_token.type = LTokenType.LOGICAL_OR;
						}
						else
							base.PushBack();
						break;
				}
			}
			else
			{
				Program.PrintError(Strings.IDS_E__SYNTAX_ERROR_EXPRESSION, LineNo(), val);
			}

			if (m_action != null)
			{
				m_action(m_token.str);
			}

			return m_token;
		}

		public void Run(Action<string> act = null)
		{
			TOKEN token;
			m_action = act;
			do
			{
				token = NextToken();
			} while (token.type != LTokenType._EOF);
		}
	}
}
