﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeSim
{
	public partial class CParser
	{
		// Grammar:
		// 1. program->declaration_list
		CTreeNode program()
		{
			return declaration_list();
		}

		// Grammar:
		// 2. declaration_list->declaration_list declaration | declaration
		CTreeNode declaration_list()
		{
			CTreeNode first = null, last = null, temp = null;
			m_token = m_Lexer.NextToken();
			while (m_token.type != LTokenType._EOF)
			{
				if (m_token.type != LTokenType._CHAR && m_token.type != LTokenType._INT &&
					m_token.type != LTokenType._VOID && m_token.type != LTokenType._FLOAT)
				{
					Program.PrintError(Strings.IDS_E__INVALID_TYPE, m_Lexer.LineNo(), m_token.str);
					ConsumeUntil(LTokenType.SEMI /* ';' */, LTokenType.RBRACE /* '}' */ );
				}
				else if ((temp = declaration()) != null)
				{
					// link all declarations together
					if (first == null) { first = temp; last = temp.LastSibling(); }
					else { last.sibling = temp; last = temp.LastSibling(); }
				}
				// read the next token
				m_token = m_Lexer.NextToken();
			}
			return first;
		}

		// Grammar:
		// 3. declaration->var_declaration | fun_declaration
		// m_token is a supported type-identifier token
		CTreeNode declaration()
		{
			m_szScope = Strings.IDS_A_GLOBAL;// global function or variable declaration
			CTreeNode temp = null;

			TypeToken = m_token;
			IDToken = m_token = m_Lexer.NextToken();
			if (IDToken.type != LTokenType._ID)
			{
				Program.PrintError(Strings.IDS_E__RESERVED_KEYWORD, m_Lexer.LineNo(), IDToken.str);
				ConsumeUntil(LTokenType.SEMI /* ';' */, LTokenType.RBRACE /* '}' */ );
			}
			else
			{
				m_token = m_Lexer.NextToken(); // '(', ';', '[', ',' or error
				if (m_token.type == LTokenType.LPARAN) temp = fun_declaration();
				else if (m_token.type == LTokenType.SEMI || m_token.type == LTokenType.LSQUARE || m_token.type == LTokenType.COMMA)
					temp = var_declaration();
				else
				{
					Program.PrintError(Strings.IDS_E__MISSING_SEMI_AFTER, m_Lexer.LineNo(), IDToken.str);
					ConsumeUntil(LTokenType.SEMI /* ';' */, LTokenType.RBRACE /* '}' */ );
				}
			}

			return temp;
		}

		// Grammar:
		// 4. var_declaration->type_specifier ID(, ...)`;` | type_specifier ID `[` NUM `]`(, ...)`;`
		// 5. type_specifier->`int` | `void` | `char`, actually this step is in declaration_list()
		// m_token.str == ";" "," or "["
		CTreeNode var_declaration()
		{
			CTreeNode temp = newNode(NodeKind.kVarDec, TypeToken.type, IDToken.str);

			if (m_token.type == LTokenType.LSQUARE)
			{ // '['
				m_token = m_Lexer.NextToken(); // NUM
				if (m_token.type != LTokenType._NUM)
				{
					Program.PrintError(Strings.IDS_E__MISSING_ARRAY_SIZE, m_Lexer.LineNo(), IDToken.str);
					temp = null;
					ConsumeUntil(LTokenType.SEMI /* ';' */, LTokenType.RBRACE /* '}' */ );
					return null;
				}

				temp.bArray = true;
				temp.iArraySize = m_Lexer.GetIntNumValue();

				if (!match(LTokenType.RSQUARE))
				{ // `]`
					Program.PrintError(Strings.IDS_E__MISSING_ARRAY_SIZE, m_Lexer.LineNo(), IDToken.str);
					m_Lexer.PushBack();
				}
				m_token = m_Lexer.NextToken(); // should be ';' or ','
			}
			if (m_token.type == LTokenType.COMMA)
			{
				IDToken = m_token = m_Lexer.NextToken(); // ID or error
				if (IDToken.type != LTokenType._ID)
				{
					Program.PrintError(Strings.IDS_E__RESERVED_KEYWORD, m_Lexer.LineNo(), IDToken.str);
					ConsumeUntil(LTokenType.SEMI /* ';' */, LTokenType.RBRACE /* '}' */ );
					return temp;
				}
				m_token = m_Lexer.NextToken(); // ';', '[', ',' or error
				if (m_token.type == LTokenType.SEMI || m_token.type == LTokenType.LSQUARE || m_token.type == LTokenType.COMMA)
					temp.sibling = var_declaration(); // link following variable declarations
				else
				{
					Program.PrintError(Strings.IDS_E__MISSING_SEMI_AFTER, m_Lexer.LineNo(), IDToken.str);
					m_Lexer.PushBack();
					return temp;
				}
			}
			else if (m_token.type != LTokenType.SEMI)
			{ // m_token should be ';' now
				Program.PrintError(Strings.IDS_E__MISSING_SEMI, m_Lexer.LineNo());
				ConsumeUntil(LTokenType.SEMI /* ';' */, LTokenType.RBRACE /* '}' */ );
			}

			return temp;
		}

		// Grammar:
		// 6. fun_declaration->type_specifier ID `(` params `)` compound_stmt
		// m_token.str == "(", TypeToken contains type_specifier, IDToken contains ID
		CTreeNode fun_declaration()
		{
			CTreeNode temp = newNode( NodeKind.kFunDec, TypeToken.type, IDToken.str );

			// update function scope
			m_szScope = IDToken.str;

			// params
			CTreeNode p = temp.child[0] = @params();
			if( p != null ) p.father = temp;
			while( p != null && p.sibling != null ) {
				p = p.sibling;	p.father = temp;
			}

			if( !match(LTokenType.RPARAN) ) {
				Program.PrintError( Strings.IDS_E__MISSING_RPARAM, m_Lexer.LineNo(), m_token.str );
				m_Lexer.PushBack();
			}
			// compound statements
			p = temp.child[1] = compound_stmt();
			if( p != null ) p.father = temp;
			while( p != null && p.sibling != null ) {
				p = p.sibling; p.father = temp;
			}

			return temp;
		}

		// Grammar:
		// 7. params->param_list | `void` | empty, `void` is thought as empty
		// 8. param_list->param_list `,` param | param
		// 9. param->type_specifier ID | type_specifier ID `[` `]`
		// m_token.str == "("
		CTreeNode @params()
		{
			CTreeNode first = null, temp = null;

			TypeToken = m_token = m_Lexer.NextToken(); // type-specifier or ')'
			if (m_token.type == LTokenType.RPARAN)
			{
				m_Lexer.PushBack();
				return null;
			}
			if (TypeToken.type == LTokenType._VOID)
				if (match(LTokenType.RPARAN))
				{
					m_Lexer.PushBack();
					return null;
				}
				else m_Lexer.PushBack(); // is not ')', push it back
			while (TypeToken.type == LTokenType._INT || TypeToken.type == LTokenType._CHAR ||
				   TypeToken.type == LTokenType._VOID || TypeToken.type == LTokenType._FLOAT)
			{
				IDToken = m_token = m_Lexer.NextToken();
				if (IDToken.type != LTokenType._ID)
				{
					Program.PrintError(Strings.IDS_E__INVALID_PARAMETER, m_Lexer.LineNo(), IDToken.str);
				}
				else
				{
					temp = newNode(NodeKind.kParam, TypeToken.type, IDToken.str);
					temp.sibling = first; // the FIRST parameter is the LAST sibling node
					first = temp;
				}
				m_token = m_Lexer.NextToken();
				if (m_token.type == LTokenType.LSQUARE)
				{ // '['
					temp.bArray = true;
					if (!match(LTokenType.RSQUARE))
					{ //']'
						Program.PrintError(Strings.IDS_E__MISSING_RSQUARE, m_Lexer.LineNo());
						ConsumeUntil(LTokenType.COMMA /* ',' */, LTokenType.RPARAN /* ')' */ );
					}
					else
						m_token = m_Lexer.NextToken(); // should be ',' or ')'
				}
				if (m_token.type == LTokenType.RPARAN) break; // ')'
				else if (m_token.type == LTokenType.COMMA) // ','
					TypeToken = m_token = m_Lexer.NextToken();
				else
				{
					break;
				}
			}
			m_Lexer.PushBack(); // the next token should be ')'

			return first;
		}

		// Grammar:
		// 10. compound_stmt->`{` loal_declarations statement_list `}` | expression_stmt
		// the next token should be '{'
		CTreeNode compound_stmt()
		{
			CTreeNode first = null, last = null, temp = null;
			bool bHasNoBraces = false;

			if (!match(LTokenType.LBRACE))
			{ // match'{'
				bHasNoBraces = true;
				m_Lexer.PushBack();
			}

			// local_declarations
			while (true)
			{
				TypeToken = m_token = m_Lexer.NextToken();
				if (m_token.type == LTokenType._CHAR || m_token.type == LTokenType._INT ||
					m_token.type == LTokenType._VOID || m_token.type == LTokenType._FLOAT)
					temp = local_declarations();
				else { m_Lexer.PushBack(); break; }
				if (bHasNoBraces) return temp; // has no braces, return when reach the first ';'
				if (temp != null)
				{
					// link all local_declarations together
					if (first == null) { first = temp; last = temp.LastSibling(); }
					else { last.sibling = temp; last = temp.LastSibling(); }
				}
			}

			// statement_list
			// m_token contains the first token of statement_list
			m_token = m_Lexer.NextToken();
			while (true)
			{
				temp = null;
				if (m_token.type == LTokenType.RBRACE)
				{
					if (bHasNoBraces) Program.PrintError(Strings.IDS_E__UNPAIRED_RBRACE, m_Lexer.LineNo());
					break; // '}'
				}
				if (m_token.type == LTokenType._EOF)
				{
					Program.PrintError(Strings.IDS_E__MISSING_RBRACE, m_Lexer.LineNo());
					m_Lexer.PushBack();
					break;
				}

				/* Main Logic Switch */
				switch (m_token.type)
				{
					case LTokenType.SEMI: // ';'
					case LTokenType._NUM:
					case LTokenType._CHARACTER:
					case LTokenType.LOGICAL_NOT:
					case LTokenType.LPARAN:
						temp = expression_stmt(); break;
					case LTokenType._ID:
						temp = subcompound_stmt(); break;
					case LTokenType._IF:
						temp = if_stmt(); break;
					case LTokenType._WHILE:
						temp = while_stmt(); break;
					case LTokenType._FOR:
						temp = for_stmt(); break;
					case LTokenType._GOTO:
						temp = goto_stmt(); break;
					case LTokenType._BREAK:
						temp = break_stmt(); break;
					case LTokenType._CONTINUE:
						temp = continue_stmt(); break;
					case LTokenType._RETURN:
						temp = return_stmt(); break;
					case LTokenType._ELSE:
						Program.PrintError(Strings.IDS_E__UNPAIRED_ELSE, m_Lexer.LineNo());
						ConsumeUntil(LTokenType.SEMI /* ';' */, LTokenType.RBRACE /* '}' */ );
						break;
					default:
						Program.PrintError(Strings.IDS_E__INVALID_SYMBOL, m_Lexer.LineNo(), m_token.str);
						ConsumeUntil(LTokenType.SEMI /* ';' */, LTokenType.RBRACE /* '}' */ );
						break;
				}
				if (bHasNoBraces) return temp; // has no braces, return when reach the first ';'
				if (temp != null)
				{
					// link all statements together
					if (first == null) { first = temp; last = temp.LastSibling(); }
					else { last.sibling = temp; last = temp.LastSibling(); }
				}
				m_token = m_Lexer.NextToken();
			}

			return first;
		}

		// Grammar:
		// 11. local_declarations->local_declarations var_declaration | var_declaration
		// m_token is a supported type-specifier token
		CTreeNode local_declarations()
		{
			CTreeNode temp = null;

			IDToken = m_token = m_Lexer.NextToken(); // ID or error
			if (IDToken.type != LTokenType._ID)
			{
				Program.PrintError(Strings.IDS_E__RESERVED_KEYWORD, m_Lexer.LineNo(), IDToken.str);
				ConsumeUntil(LTokenType.SEMI /* ';' */ );
				return null;
			}
			m_token = m_Lexer.NextToken(); // ';', '[', ',' or error
			if (m_token.type == LTokenType.SEMI || m_token.type == LTokenType.LSQUARE || m_token.type == LTokenType.COMMA)
				temp = var_declaration();
			else
			{
				Program.PrintError(Strings.IDS_E__MISSING_SEMI_AFTER, m_Lexer.LineNo(), IDToken.str);
				m_Lexer.PushBack();
			}
			return temp;
		}

		// Grammar:
		// 15. expression_stmt->expression `;` | `;`
		// m_token is '!', '(', ID, NUM, CHARACTER or ';'
		CTreeNode expression_stmt()
		{
			if (m_token.type == LTokenType.SEMI) return null;
			CTreeNode temp = expression();
			if (!match(LTokenType.SEMI))
			{
				Program.PrintError(Strings.IDS_E__MISSING_SEMI, m_Lexer.LineNo());
				m_Lexer.PushBack();
			}

			return temp;
		}

		// Grammar:
		// 16. expression->var `=` expression | logic1_expression
		// FIRST( expression ) = { `!`, `(`, ID, NUM, CHARACTER }
		// m_token contains the first token of expression
		CTreeNode expression()
		{
			CTreeNode temp = logic1_expression(), p = temp;
			m_token = m_Lexer.NextToken();
			if (m_token.type == LTokenType.ASSIGN)
			{
				if (temp.type != LTokenType._ID && temp.type != LTokenType.ASSIGN)
				{ // left of '=' should be a ID
					Program.PrintError(Strings.IDS_E__INVALID_ASSIGN, m_Lexer.LineNo());
					ConsumeUntil(LTokenType.SEMI /* ';' */, LTokenType.RPARAN /* ')' */ );
					return null;
				}
				p = newExpNode(ExpKind.kOp, m_token.type, m_token.str);
				p.child[0] = temp;
				if (p.child[0] != null) p.child[0].father = p;
				m_token = m_Lexer.NextToken();
				p.child[1] = expression();
				if (p.child[1] != null) p.child[1].father = p;
			}
			else
			{
				m_Lexer.PushBack();
			}

			return p;
		}

		// Grammar:
		// 17. logic1_expression->logic1_expression `||` logic2_expression | logic2_expression
		// m_token contains the first token of logic1_expression
		CTreeNode logic1_expression()
		{
			CTreeNode p = logic2_expression();

			m_token = m_Lexer.NextToken();
			while (m_token.type == LTokenType.LOGICAL_OR)
			{
				CTreeNode temp = newExpNode(ExpKind.kOp, m_token.type, m_token.str);
				temp.child[0] = p;
				p = temp;
				if (p.child[0] != null) p.child[0].father = p;
				m_token = m_Lexer.NextToken();
				if ((p.child[1] = logic2_expression()) != null) p.child[1].father = p;
				m_token = m_Lexer.NextToken();
			}
			m_Lexer.PushBack();

			return p;
		}

		// Grammar:
		// 18. logic2_expression-> logic2_expression `&&` simple_expression | simple_expression
		// m_token contains the first token of logic2_expression
		CTreeNode logic2_expression()
		{
			CTreeNode p = simple_expression();

			m_token = m_Lexer.NextToken();
			while (m_token.type == LTokenType.LOGICAL_AND)
			{
				CTreeNode temp = newExpNode(ExpKind.kOp, m_token.type, m_token.str);
				temp.child[0] = p;
				p = temp;
				if (p.child[0] != null) p.child[0].father = p;
				m_token = m_Lexer.NextToken();
				if ((p.child[1] = simple_expression()) != null) p.child[1].father = p;
				m_token = m_Lexer.NextToken();
			}
			m_Lexer.PushBack();

			return p;
		}

		// Grammar:
		// 19. simple_expression->additive_expression relop additive_expression | additive_expression
		// 20. relop-> `<=` | `<` | `>` | `>=` | `==` | `!=`
		// m_token contains the first token of simple_expression
		CTreeNode simple_expression()
		{
			CTreeNode p = additive_expression();

			m_token = m_Lexer.NextToken();
			if (m_token.type == LTokenType.NGT || m_token.type == LTokenType.LT || m_token.type == LTokenType.GT ||
				m_token.type == LTokenType.NLT || m_token.type == LTokenType.EQ || m_token.type == LTokenType.NEQ)
			{
				CTreeNode temp = newExpNode(ExpKind.kOp, m_token.type, m_token.str);
				temp.child[0] = p;
				p = temp;
				if (p.child[0] != null) p.child[0].father = p;
				m_token = m_Lexer.NextToken();
				if ((p.child[1] = additive_expression()) != null) p.child[1].father = p;
			}
			else
				m_Lexer.PushBack();

			return p;
		}

		// Grammar:
		// 21. additive_expression -> additive_expression addop term | term
		// 22. addop-> `+` | `-`
		// m_token contains the first token of add_expression
		CTreeNode additive_expression()
		{
			CTreeNode p = term();

			m_token = m_Lexer.NextToken();
			while (m_token.type == LTokenType.PLUS || m_token.type == LTokenType.MINUS)
			{
				CTreeNode temp = newExpNode(ExpKind.kOp, m_token.type, m_token.str);
				temp.child[0] = p;
				p = temp;
				if (p.child[0] != null) p.child[0].father = p;
				m_token = m_Lexer.NextToken();
				if ((p.child[1] = term()) != null) p.child[1].father = p;
				m_token = m_Lexer.NextToken();
			}
			m_Lexer.PushBack();

			return p;
		}

		// Grammar:
		// 23. term->term mulop logic3_expression | logic3_expression
		// 24. mulop-> `` | `/` | `%`
		// m_token contains the first token of term
		CTreeNode term()
		{
			CTreeNode p = logic3_expression();

			m_token = m_Lexer.NextToken();
			while (m_token.type == LTokenType.TIMES || m_token.type == LTokenType.DIV || m_token.type == LTokenType.MOD)
			{
				CTreeNode temp = newExpNode(ExpKind.kOp, m_token.type, m_token.str);
				temp.child[0] = p;
				p = temp;
				if (p.child[0] != null) p.child[0].father = p;
				m_token = m_Lexer.NextToken();
				if ((p.child[1] = logic3_expression()) != null) p.child[1].father = p;
				m_token = m_Lexer.NextToken();
			}
			m_Lexer.PushBack();

			return p;
		}

		// Grammar:
		// 25. logic3_expression-> `!` logic3_expression | factor
		// m_token contains the first token of logic3_expression
		CTreeNode logic3_expression()
		{
			CTreeNode p = null, temp = null;

			if (m_token.type == LTokenType.LOGICAL_NOT)
			{
				p = newExpNode(ExpKind.kOp, m_token.type, m_token.str);
				m_token = m_Lexer.NextToken();
				if ((temp = factor()) != null)
				{
					p.child[0] = temp;
					p.child[0].father = p;
				}
			}
			else
				p = factor();

			return p;
		}

		// Grammar:
		// 26. factor->`(` expression `)` | var | call | NUM
		// m_token contains the first token of factor
		CTreeNode factor()
		{
			CTreeNode temp = null;

			switch (m_token.type)
			{
				case LTokenType._NUM:
				case LTokenType._CHARACTER:
					temp = newExpNode(ExpKind.kConst, m_token.type, m_token.str);
					break;
				case LTokenType._ID:
					IDToken = m_token;
					m_token = m_Lexer.NextToken();
					if (m_token.type == LTokenType.LPARAN) temp = call();
					else
					{
						m_Lexer.PushBack();
						temp = var();
					}
					break;
				case LTokenType.LPARAN:
					m_token = m_Lexer.NextToken();
					temp = expression();
					if (!match(LTokenType.RPARAN))
					{ // match ')'
						Program.PrintError(Strings.IDS_E__MISSING_RPARAM, m_Lexer.LineNo());
						m_Lexer.PushBack();
					}
					break;
				default:
					Program.PrintError(Strings.IDS_E__SYNTAX_ERROR, m_Lexer.LineNo());
					ConsumeUntil(LTokenType.SEMI /* ';' */, LTokenType.RBRACE /* '}' */ );
					break;
			}

			return temp;
		}

		// Grammar:
		// 27. var->ID | ID `[` expression `]`
		// IDToken contains ID
		CTreeNode var()
		{
			CTreeNode temp = newExpNode(ExpKind.kID, IDToken.type, IDToken.str);
			m_token = m_Lexer.NextToken(); // should be `[` or just push back
			if (m_token.type == LTokenType.LSQUARE)
			{
				temp.bArray = true;
				m_token = m_Lexer.NextToken();
				temp.child[0] = expression();
				if (!match(LTokenType.RSQUARE))
				{
					Program.PrintError(Strings.IDS_E__MISSING_RSQUARE, m_Lexer.LineNo());
					m_Lexer.PushBack();
				}
			}
			else
				m_Lexer.PushBack();

			return temp;
		}

		// Grammar: 
		// 28. call->ID `(` args `)`
		// m_token.str == "(", IDToken contains ID
		CTreeNode call()
		{
			CTreeNode p = newStmtNode(StmtKind.kCall, IDToken.str), temp = null;
			p.szScope = Strings.IDS_A_GLOBAL;
			if ((p.child[0] = args()) != null) p.child[0].father = p;
			temp = p.child[0];
			while (temp != null && temp.sibling != null)
			{
				temp = temp.sibling;
				temp.father = p;
			}
			if (!match(LTokenType.RPARAN))
			{ // match ')'
				Program.PrintError(Strings.IDS_E__MISSING_RPARAM, m_Lexer.LineNo());
				m_Lexer.PushBack();
			}

			return p;
		}

		// Grammar:
		// 29. args->args_list | empty
		// 30. args_list->args_list `,` expression | expression
		// m_token.str == "("
		CTreeNode args()
		{
			CTreeNode first = null, temp = null;

			m_token = m_Lexer.NextToken();
			if (m_token.type == LTokenType.RPARAN)
			{
				m_Lexer.PushBack();
				return null;
			}
			while (true)
			{
				if ((temp = expression()) != null)
					// link all args together, the LAST argument is the FIRST in the list
					if (first == null) first = temp;
					else { temp.sibling = first; first = temp; }
				m_token = m_Lexer.NextToken();
				if (m_token.type == LTokenType.COMMA) m_token = m_Lexer.NextToken();
				else break;
			}
			m_Lexer.PushBack();

			return first;
		}

		// Grammar:
		// 31: sub_compoundstmt->ID `:` | call `;` | expression_stmt
		// m_token contains the first token of sub_compoundstmt
		CTreeNode subcompound_stmt()
		{
			CTreeNode temp = null;

			IDToken = m_token;
			m_token = m_Lexer.NextToken();
			if (m_token.type == LTokenType.COLON)
			{ // label
				temp = newStmtNode(StmtKind.kLabel, IDToken.str);
			}
			else if (m_token.type == LTokenType.LPARAN)
			{ // call statement
				temp = call();
				if (!match(LTokenType.SEMI))
				{
					Program.PrintError(Strings.IDS_E__MISSING_SEMI, m_Lexer.LineNo());
					m_Lexer.PushBack();
				}
			}
			else
			{
				m_Lexer.PushBack();
				m_token = IDToken;
				temp = expression_stmt();
			}

			return temp;
		}

		// Grammar:
		// 32: if_stmt->`if` `(` expression `)` compound_stmt
		//              | `if` `(` expression `)` compound_stmt `else` compound_stmt
		// m_token.str == "if"
		CTreeNode if_stmt()
		{
			CTreeNode temp = newStmtNode(StmtKind.kIf, m_token.str), p = null;

			if (!match(LTokenType.LPARAN)) // match '('
				Program.PrintError(Strings.IDS_E__MISSING_LPARAM, m_Lexer.LineNo());
			else m_token = m_Lexer.NextToken();
			// m_token should be the first token of expression
			temp.child[0] = expression();
			if (temp.child[0] != null) temp.child[0].father = temp;
			if (!match(LTokenType.RPARAN))
			{ // match ')'
				Program.PrintError(Strings.IDS_E__MISSING_RPARAM, m_Lexer.LineNo());
				m_Lexer.PushBack();
			}
			p = temp.child[1] = compound_stmt();
			if (p != null) p.father = temp;
			while (p != null && p.sibling != null) { p = p.sibling; p.father = temp; }
			m_token = m_Lexer.NextToken();
			if (m_token.type == LTokenType._ELSE)
			{
				p = temp.child[2] = compound_stmt();
				if (p != null) p.father = temp;
				while (p != null && p.sibling != null) { p = p.sibling; p.father = temp; }
			}
			else
				m_Lexer.PushBack();

			return temp;
		}

		// Grammar:
		// 33. while_stmt->`while` `(` expression `)` compound_stmt
		// m_token.str == "while"
		CTreeNode while_stmt()
		{
			CTreeNode temp = newStmtNode(StmtKind.kWhile, m_token.str), p = null;

			if (!match(LTokenType.LPARAN)) // match '('
				Program.PrintError(Strings.IDS_E__MISSING_LPARAM, m_Lexer.LineNo());
			else m_token = m_Lexer.NextToken();
			// m_token should be the first token of expression
			temp.child[0] = expression();
			if (temp.child[0] != null) temp.child[0].father = temp;
			if (!match(LTokenType.RPARAN))
			{ // match ')'
				Program.PrintError(Strings.IDS_E__MISSING_RPARAM, m_Lexer.LineNo());
				m_Lexer.PushBack();
			}
			// the next token should be '{'
			p = temp.child[1] = compound_stmt();
			if (p != null) p.father = temp;
			while (p != null && p.sibling != null) { p = p.sibling; p.father = temp; }

			return temp;
		}

		// Grammar:
		// 34. for_stmt->`for` `(` var `=` expression `;` expression `;` var `=` expression `)` compound_stmt
		// m_token.str == "for"
		CTreeNode for_stmt()
		{
			CTreeNode temp = null, p1 = null, p2 = null, p3 = null;

			if (!match(LTokenType.LPARAN)) // match '('
				Program.PrintError(Strings.IDS_E__MISSING_LPARAM, m_Lexer.LineNo());
			else m_token = m_Lexer.NextToken();
			// m_token should be var or ';'
			if (m_token.type == LTokenType.SEMI)
			{
				p1 = temp = newStmtNode(StmtKind.kWhile, "while");
				m_token = m_Lexer.NextToken();
			}
			else
			{
				if ((temp = expression()) == null)
				{
					Program.PrintError(Strings.IDS_E__SYNTAX_ERROR, m_Lexer.LineNo());
					ConsumeUntil(LTokenType.RBRACE /* '}' */ );
					return null;
				}
				else
					p1 = temp.sibling = newStmtNode(StmtKind.kWhile, "while");

				if (!match(LTokenType.SEMI)) // match ';'
					Program.PrintError(Strings.IDS_E__MISSING_SEMI, m_Lexer.LineNo());
				else m_token = m_Lexer.NextToken();
			}
			// m_token should be the first token of expression
			p1.child[0] = expression();
			if (p1.child[0] == null)
			{
				Program.PrintError(Strings.IDS_E__SYNTAX_ERROR, m_Lexer.LineNo());
				ConsumeUntil(LTokenType.RBRACE /* '}' */ );
				if (temp != null) temp = null;
				return null;
			}
			p1.child[0].father = p1;
			if (!match(LTokenType.SEMI)) // match ';'
				Program.PrintError(Strings.IDS_E__MISSING_SEMI, m_Lexer.LineNo());
			else m_token = m_Lexer.NextToken();
			// m_token should be var
			p2 = expression();
			if (p2 != null) p2.father = p1;
			if (!match(LTokenType.RPARAN))
			{ // match ')'
				Program.PrintError(Strings.IDS_E__MISSING_RPARAM, m_Lexer.LineNo());
				m_Lexer.PushBack();
			}
			// the next token should be '{'
			p3 = p1.child[1] = compound_stmt();
			if (p3 != null) p3.father = p1;
			if (p3 != null && p3.sibling != null)
			{
				p3 = p3.sibling; p3.father = p1;
			}
			if (p3 != null) p3.sibling = p2;
			else p1.child[1] = p2;

			return temp;
		}

		// Grammar:
		// 35. goto_stmt->`goto` ID `;`
		// m_token.str == "goto"
		CTreeNode goto_stmt()
		{
			if (!match(LTokenType._ID))
			{
				Program.PrintError(Strings.IDS_E__MISSING_LABEL, m_Lexer.LineNo());
				ConsumeUntil(LTokenType.SEMI /* ';' */, LTokenType.RBRACE /* '}' */ );
				return null;
			}
			CTreeNode temp = newStmtNode(StmtKind.kGoto, m_token.str);
			if (!match(LTokenType.SEMI))
			{
				Program.PrintError(Strings.IDS_E__MISSING_SEMI, m_Lexer.LineNo());
				m_Lexer.PushBack();
			}
			return temp;
		}

		// Grammar:
		// 36. break_stmt->`break` `;`
		// m_token.str == "break"
		CTreeNode break_stmt()
		{
			CTreeNode temp = newStmtNode(StmtKind.kBreak, m_token.str);
			if (!match(LTokenType.SEMI))
			{ // match ';'
				Program.PrintError(Strings.IDS_E__MISSING_SEMI, m_Lexer.LineNo());
				m_Lexer.PushBack();
			}
			return temp;
		}

		// Grammar:
		// 37. continue_stmt->`continue` `;`
		// m_token.str = "continue"
		CTreeNode continue_stmt()
		{
			CTreeNode temp = newStmtNode(StmtKind.kContinue, m_token.str);
			if (!match(LTokenType.SEMI))
			{
				Program.PrintError(Strings.IDS_E__MISSING_SEMI, m_Lexer.LineNo());
				m_Lexer.PushBack();
			}
			return temp;
		}

		// Grammar:
		// 38. return_stmt->`return` `;` | `return` expression `;`
		// m_token.str = "return"
		CTreeNode return_stmt()
		{
			CTreeNode temp = newStmtNode(StmtKind.kReturn, m_token.str);
			m_token = m_Lexer.NextToken();
			if (m_token.type != LTokenType.SEMI)
			{
				temp.child[0] = expression();
				if (!match(LTokenType.SEMI))
				{
					Program.PrintError(Strings.IDS_E__MISSING_SEMI, m_Lexer.LineNo());
					m_Lexer.PushBack();
				}
			}
			return temp;
		}
	}
}