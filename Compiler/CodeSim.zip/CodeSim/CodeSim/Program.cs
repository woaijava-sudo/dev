﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CodeSim
{
    class Program
    {
		static bool success = true;
		static public void PrintError(string s, params object[] args)
		{
			if (success) success = false;
// 			Console.WriteLine(s, args);
		}

        static void Main(string[] args)
        {
			var ttt = new Dictionary<int, int>();
			var ttt1 = new Dictionary<int, int>();

            Console.Write("请输入文件[1]：");
            string filename1 = Console.ReadLine();
            Console.Write("请输入文件[2]：");
            string filename2 = Console.ReadLine();
            try
            {
                CompSim(filename1, filename2);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
			Console.ReadLine();
        }

        static void CompSim(string fn1, string fn2)
        {
            var txt1 = new StreamReader(fn1).ReadToEnd();
            var txt2 = new StreamReader(fn2).ReadToEnd();
			Console.WriteLine("编译文件 '{0}'...", fn1);
			var a1 = new CAnalyzer(txt1); a1.Run();
			Console.WriteLine("编译文件 '{0}'...", fn2);
			var a2 = new CAnalyzer(txt2); a2.Run();

			if (!success)
			{
				Console.WriteLine("程序有错误，中止语法分析");
				CompLexer(txt1, txt2);
				return;
			}

			var s1 = a1.GetSymbolTable();
			var s2 = a2.GetSymbolTable();
			var t1 = a1.GetSymbolTable().GetTable();
			var t2 = a2.GetSymbolTable().GetTable();

			Console.WriteLine("检查关键字重复...");

			// 总关键字出现次数
			double SumMeanExistKeyCount = new Func<double>(() =>
			{
				var d1 = (from a in t1
						 select (from b in a.Value select b.lineno.Count()).Sum()).Sum();
				var d2 = (from a in t1
						  select (from b in a.Value select b.lineno.Count()).Sum()).Sum();
				return d1 + d2;
			})();
			// 相同关键字出现次数
			double SameExistKeyCount = new Func<double>(() =>
			{
				double sum = 0;
				t1.ToList().ForEach(a =>
				{
					var l1 = a.Value;
					var l2 = new List<BucketListRec>();
					if (t2.TryGetValue(a.Key, out l2))
					{
						l1.ForEach(b =>
						{
							var f = l2.Find(c => b.scope == c.scope);
							if (f == null)
								return;
							var n1 = b.lineno;
							var n2 = f.lineno;
							var maxl = n1.Count() + n2.Count();
							double percent = 1.0;
							if (b.type != f.type)
								percent -= 0.2;
							if (b.bArray != f.bArray)
								percent -= 0.1;
							double sum1 = n1.Sum();
							double sum2 = n2.Sum();
							var simi = sum1 > sum2 ? sum2 / sum1 : sum1 / sum2;
							sum += maxl * percent * simi;
						});
					}
				});
				return sum;
			})();

			if (SumMeanExistKeyCount == 0)
				throw new Exception("关键字没有找到");

			var KeyRepeatPercent = SameExistKeyCount / SumMeanExistKeyCount;

			Console.WriteLine("关键字重复概率：{0:P}", KeyRepeatPercent);

			if (KeyRepeatPercent > 0.6)
			{
				Console.WriteLine("关键字比对结果良好");
				return;
			}

			Console.WriteLine("关键字比对结果较差，将进行模块的特征匹配，以检查关键字更改");

			var m1 = (from a in t1.ToList()
					  from b in a.Value
					  select b.scope).Distinct();
			var m2 = (from a in t2.ToList()
					  from b in a.Value
					  select b.scope).Distinct();

			var mx = Math.Abs(m1.Count() - m2.Count());
			if (mx > 3)
			{
				Console.WriteLine("模块个数差异较大，放弃进一步检查");
				return;
			}

			double result = CompSyntaxTree(a1, a2, m1.ToList(), m2.ToList());
			if (result < 0.6)
				CompLexer(txt1, txt2);
		}

		static void CompLexer(string txt1, string txt2)
		{
			success = true;

			Console.WriteLine("进行词法分析，检查相似度");
			var l1 = new CLexer(txt1);
			var l2 = new CLexer(txt2);

			var s1 = new List<string>();
			var s2 = new List<string>();

			l1.Run(a => s1.Add(a));
			l2.Run(a => s2.Add(a));

			if (!success)
			{
				Console.WriteLine("词法分析失败，检查关键词相似度");
				CompKeyword(txt1, txt2);
				return;
			}

			s1.Sort();
			s2.Sort();

			var d1 = from x in s1 group x by x into y select new { Key = y.Key, Count = y.Count() };
			var d2 = from x in s2 group x by x into y select new { Key = y.Key, Count = y.Count() };

			var r1 = new Dictionary<string, int>();
			var r2 = new Dictionary<string, int>();

			d1.ToList().ForEach(a => r1[a.Key] = a.Count);
			d2.ToList().ForEach(a => r2[a.Key] = a.Count);

			var r3 = r1.Intersect(r2);

			double SumExistKey = r1.Sum(a => a.Value) + r2.Sum(a => a.Value);
			double SimiExistKey = r3.Sum(a => a.Value) * 2;

			if (SumExistKey == 0)
				throw new Exception("关键字没有找到");

			var result = SimiExistKey / SumExistKey;
			Console.WriteLine("词法分析结果，相似度：{0:P}", result);
			if (result > 0.6)
				Console.WriteLine("词法分析结果良好");
			else
			{
				Console.WriteLine("词法分析结果较差，检查关键词相似度");
				CompKeyword(txt1, txt2);
			}
		}

		static void CompKeyword(string txt1, string txt2)
		{
			Console.WriteLine("开始关键字检查...");

			Dictionary<string, int> d1 = new Dictionary<string,int>();
			Dictionary<string, int> d2 = new Dictionary<string,int>();
			Keywords.s_apszCKeywordList.ToList().ForEach(a =>
			{
				var m1 = Regex.Matches(txt1, @"\s" + a + @"\s").Count;
				var m2 = Regex.Matches(txt2, @"\s" + a + @"\s").Count;
				if (m1 > 0)
					d1[a] = m1;
				if (m2 > 0)
					d2[a] = m2;
			});
			Keywords.s_apszCTypeList.ToList().ForEach(a =>
			{
				var m1 = Regex.Matches(txt1, @"\s" + a + @"\s").Count;
				var m2 = Regex.Matches(txt2, @"\s" + a + @"\s").Count;
				if (m1 > 0)
					d1[a] = m1;
				if (m2 > 0)
					d2[a] = m2;
			});

			var d3 = d1.Intersect(d2);

			double SumExistKey = d1.Sum(a => a.Value) + d2.Sum(a => a.Value);
			double SimiExistKey = d3.Sum(a => a.Value) * 2;

			if (SumExistKey == 0)
				throw new Exception("关键字没有找到");

			var result = SimiExistKey / SumExistKey;
			Console.WriteLine("关键词分析结果，相似度：{0:P}", result);
			if (result > 0.6)
				Console.WriteLine("关键词分析结果良好");
		}

		static double CompSyntaxTree(CAnalyzer a1, CAnalyzer a2, List<string> l1, List<string> l2)
		{
			Console.WriteLine("正在进行语法树比较...");

			l1.Remove(Strings.IDS_A_GLOBAL);
			l2.Remove(Strings.IDS_A_GLOBAL);

			var t1 = a1.GetSyntaxTree();
			var t2 = a2.GetSyntaxTree();

			var l1_2 = l1.Intersect(l2);
			var p1 = l1.Except(l1_2).ToList();
			var p2 = l2.Except(l1_2).ToList();
			var e = new List<string>();

			double SumExistKey = l1.Count() + l2.Count() - l1_2.Count();
			double SimiExistKey = 0.0;

			if (SumExistKey == 0)
				throw new Exception("关键字没有找到");

			l1_2.ToList().ForEach(a =>
			{
				SimiExistKey += SimiSyntaxTree(GetFuncNode(t1, a), GetFuncNode(t2, a));
			});
			p1.ForEach(a =>
			{
				var s = new List<double>();
				p2.ForEach(b =>
				{
					s.Add(2 * SimiSyntaxTree(GetFuncNode(t1, a), GetFuncNode(t2, b)));
				});
				var v = s.Select((data, index) => new { I = index, D = data }).OrderByDescending(n => n.D).First();
				if (v.D > 0.8)
				{
					SimiExistKey += v.D;
					e.Add(a);
					p2.RemoveAt(v.I);
				}
			});
			p1.Except(e);
			e.Clear();
			p2.ForEach(a =>
			{
				var s = new List<double>();
				p1.ForEach(b =>
				{
					s.Add(2 * SimiSyntaxTree(GetFuncNode(t1, b), GetFuncNode(t2, a)));
				});
				var v = s.Select((data, index) => new { I = index, D = data }).OrderByDescending(n => n.D).First();
				if (v.D > 0.8)
				{
					SimiExistKey += v.D;
					p1.RemoveAt(v.I);
				}
			});

			var result = SimiExistKey / SumExistKey;
			Console.WriteLine("语法树比较结果，相似度：{0:P}", result);
			if (result > 0.6)
				Console.WriteLine("语法分析结果良好");
			else
			{
				Console.WriteLine("语法分析结果较差，进行词法分析");
			}

			return result;
		}

		static double SimiSyntaxTree(CTreeNode node1, CTreeNode node2)
		{
			var n1 = node1;
			var n2 = node2;
			double bingo = 0, all = 0;
			while (n1 != null && n2 != null)
			{
				var s = SimiSyntaxTreeRecursion(node1, node2);
				bingo += s.Item1;
				all += s.Item2;
				n1 = n1.sibling; n2 = n2.sibling;
			}
			if (all == 0) return 0;
			return bingo / all;
		}

		static Tuple<double, double> SimiSyntaxTreeRecursion(CTreeNode node1, CTreeNode node2)
		{
			if (node1 == null || node2 == null)
				return new Tuple<double, double>(0, 0);

			double bingo = 0, oops = 1;
			if (node1.szName == node2.szName)
				bingo = 1;
			else if (node1.nodekind == node2.nodekind)
			{
				bingo = 0.5;
				if (Math.Abs(node1.lineno - node2.lineno) < 5)
					bingo += 0.3;
				if (node1.bArray == node2.bArray)
				{
					if (node1.bArray)
					{
						if (Math.Abs(node1.iArraySize - node2.iArraySize) < 2)
							bingo += 0.1;
					}
					else
						bingo += 0.1;
				}
			}

			for (int i = 0; i < 3; i++)
			{
				var tp = SimiSyntaxTreeRecursion(node1.child[i], node2.child[i]);
				bingo += tp.Item1; oops += tp.Item2;
			}

			return new Tuple<double, double>(bingo, oops);
		}

		static CTreeNode GetFuncNode(CTreeNode node, string func)
		{
			CTreeNode p = node;
			while (p != null)
			{
				Debug.Assert(p.nodekind == NodeKind.kFunDec);
				if (p.szName == func)
				{
					return p;
				}

				p = p.sibling;
			}
			return null;
		}
    }
}
