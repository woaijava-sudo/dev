﻿	using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeSim
{
	// 文法分析是编译器的核心
	// 采用自顶向下的递归下降分析方法

	/* 文法生成

		主入口		program				->		declaration_list
		声明列表	declaration_list	->		declaration_list declaration
											  | declaration
		声明		declaration			->		var_declaration
											  | fun_declaration
		变量声明	var_declaration		->		type_specifier @ID(, ...) `;`
											  | type_specifier @ID `[` NUM `]` (, ...) `;`
		函数声明	fun_declaration		->		type_specifier @ID `(` params `)` compound_stmt
		参数		params				->		param_list
											  | `void`
											  | empty
		参数		param_list			->		param_list `,` param
											  | param
		参数		param				->		type_specifier ID
											  | type_specifier ID `[` `]`
		函数体		compound_stmt		->		`{` local_declarations statement_list `}`
											  | expression_stmt
		函数内声明	local_declarations	->		local_declarations var_declaration
											  | var_declaration
		表达式语句	expression_stmt		->		expression `;`
											  | `;`
		表达式		expression			->		var `=` expression
											  | logic1_expression
					logic1_expression	->		logic1_expression `||` logic2_expression
											  | logic2_expression
					logic2_expression	->		logic2_expression `&&` simple_expression
											  | simple_expression
		简单表达式	simple_expression	->		additive_expression relop additive_expression
											  | additive_expression
		子表达式	additive_expression ->		additive_expression addop term
											  | term
					term				->		term mulop logic3_expression
											  | logic3_expression
					logic3_expression	->		`!` logic3_expression
											  | factor
					factor				->		`(` expression `)`
											  | var
											  | call
											  | NUM
					var					->		ID
											  | ID `[` expression `]`
					call				->		ID `(` args `)`
					args				->		args_list
											  | empty
					args_list			->		args_list `,` expression
											  | expression
					sub_compoundstmt	->		ID `:`
											  | call `;`
											  | expression_stmt

		逻辑语句

		if			if_stmt				->		`if` `(` expression `)` compound_stmt
											  | `if` `(` expression `)` compound_stmt `else` compound_stmt
		while		while_stmt			->		`while` `(` expression `)` compound_stmt
		for			for_stmt			->		`for` `(` var `=` expression `;` expression `;` var `=` expression `)` compound_stmt
		goto		goto_stmt			->		`goto` ID `;`
		break		break_stmt			->		`break` `;`
		continue	continue_stmt		->		`continue` `;`
		return		return_stmt			->		`return` `;`
											  | `return` expression `;`

		终结符：

		一元操作符	addop	->	`+` | `-`
		一元操作符	mulop	->	`*` | `/` | `%`
		二元操作符	relop	->	`<=` | `<` | `>` | `>=` | `==` | `!=`
		变量类型	type_specifier	->	`int` | `void` | `char` | `double` | `float`
	*/
	public partial class CParser
	{
		CLexer m_Lexer;
		TOKEN m_token, TypeToken, IDToken; // the latter two are for temporary use
		string m_szScope;	// 域(eg. global)
		CTreeNode m_Program;

		public CParser(string str)
		{
			m_Lexer = new CLexer(str);
			m_Program = null;
		}

		public CTreeNode BuildSyntaxTree()
		{
			m_Program = program();
			return m_Program; // 语法树
		}

		CTreeNode newNode(NodeKind kind, LTokenType type, string ID)
		{
			return new CTreeNode()
			{
				lineno = m_Lexer.LineNo(),
				nodekind = kind,
				type = type,
				szName = ID,
				szScope = m_szScope
			};
		}
		CTreeNode newStmtNode(StmtKind skind, string ID)
		{
			return new CTreeNode()
			{
				lineno = m_Lexer.LineNo(),
				nodekind = NodeKind.kStmt,
				kind = new UndefKind() { stmt = skind },
				type = LTokenType._NONE,
				szName = ID,
				szScope = m_szScope
			};
		}
		CTreeNode newExpNode(ExpKind skind, LTokenType stype, string ID)
		{
			return new CTreeNode()
			{
				lineno = m_Lexer.LineNo(),
				nodekind = NodeKind.kExp,
				kind = new UndefKind() { exp = skind },
				type = stype,
				szName = ID,
				szScope = m_szScope
			};
		}

		bool match(LTokenType type)
		{
			m_token = m_Lexer.NextToken();
			return m_token.type == type;
		}
		void ConsumeUntil(LTokenType type)
		{
			while (m_token.type != type && m_token.type != LTokenType._EOF)
				m_token = m_Lexer.NextToken();
		}
		void ConsumeUntil(LTokenType type1, LTokenType type2)
		{
			while (m_token.type != type1 && m_token.type != type2 && m_token.type != LTokenType._EOF)
				m_token = m_Lexer.NextToken();
		}
	}
}
