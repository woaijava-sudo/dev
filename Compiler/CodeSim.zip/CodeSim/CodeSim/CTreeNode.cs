﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeSim
{
	// 语法树结点类型
	public enum NodeKind
	{
		kVarDec,		// 变量声明
		kFunDec,		// 函数声明
		kParam,			// 参数
		kStmt,			// 语句
		kExp			// 表达式
	};

	// 语句类型
	public enum StmtKind
	{
		kIf,
		kWhile,
		kGoto,
		kBreak,
		kContinue,
		kReturn,
		kLabel,
		kCall
	};

	// 表达式类型
	public enum ExpKind
	{
		kOp,
		kConst,
		kID
	};

	// 联合体
	public struct UndefKind
	{
		public StmtKind	stmt;
		public ExpKind exp;
	};

	public class CTreeNode
	{
		public static int MAX_CHILDREN = 3;

		public CTreeNode father;			// point to father node
		public CTreeNode[] child;			// point to child node
		public CTreeNode sibling;			// point to sibling node
		public int lineno;
		public NodeKind nodekind;
		public UndefKind kind;
		public LTokenType type;
		public string szName;
		public string szScope;				// node function scope
		public bool bArray;					// is this an array declaration
		public int iArraySize;				// array size

		public CTreeNode()
		{
			father = sibling = null;
			lineno = 0;
			bArray = false;
			child = new CTreeNode[] { null, null, null };
		}

		public CTreeNode LastSibling()
		{
			CTreeNode last = this;
			while (last.sibling != null) last = last.sibling;
			return last;
		}
	}
}
