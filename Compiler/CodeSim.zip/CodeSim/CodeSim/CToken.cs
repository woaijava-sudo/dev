﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace System
{
	static class CharHelper
	{
		public static bool IsSpace(this char c)
		{
			return " \t\r\n\v\f".IndexOf(c) != -1;
		}
	}
}

namespace CodeSim
{
	public class CToken
	{
		protected const int TT_EOL = '\n';
		protected const int TT_EOF = 1;
		protected const int TT_INTEGER = -2;
		protected const int TT_REAL = -3;
		protected const int TT_WORD = -4;
		protected const int TT_STRING = '"';
		protected const int TT_CHAR = '\'';

		string m_sString;						// the tokenized string

		bool m_bSlSlComments;				// Slash slash comments enabled
		bool m_bSlStComments;				// Slash star comments enabled
		bool m_bEolIsSignificant;			// Specifies that EOL is significant or not
		bool m_bForceLower;					// Enable / disable case sensitivity
		bool m_bPushedBack;					// Enable Pushed Back

		int m_peekc;
		int m_iLineNo;
		int m_tType;						// The last read token type

		protected string m_sVal;			// the value of the token
		double m_dVal;
		int m_iChar;						// the index of the current character
		int m_nToken;						// length of text

		public CToken(string s)
		{
			m_bPushedBack = false;
			m_bEolIsSignificant = true;
			m_bSlSlComments = true;
			m_bSlStComments = true;
			m_bForceLower = false;				// case sensitive
			m_iLineNo = 1;						// the first line
			m_iChar = 0;
			m_nToken = s.Length;
			m_peekc = ' ';
			m_sString = s;
			m_sString += TT_EOF;
		}

		int GetChar()
		{
			if (m_iChar >= m_nToken)
				return TT_EOF;
			return m_sString[m_iChar++];
		}

		public virtual void PushBack()
		{
			m_bPushedBack = true;
		}

		// Specifies that EOL is significant or not
		void EolIsSignificant(bool bFlag)
		{
			m_bEolIsSignificant = bFlag;
		}

		// Enable C Style comments
		void SlStComments(bool bFlag)
		{
			m_bSlStComments = bFlag;
		}

		// Enable C++ Style comments
		void SlSlComments(bool bFlag)
		{
			m_bSlSlComments = bFlag;
		}

		// Enable / disable case sensitivity
		void LowerCaseMode(bool bFlag)
		{
			m_bForceLower = bFlag;
		}

		// gives the next Token, returns the token type
		protected int QNextToken()
		{
			m_tType = InternalNextToken();
			return m_tType;
		}

		int InternalNextToken()
		{
			if (m_bPushedBack)
			{
				m_bPushedBack = false;
				return m_tType;
			}

			int c = m_peekc;
			m_sVal = "";

			if (c == TT_EOF) return TT_EOF;

			// is this a space 
			while (((char)c).IsSpace())
			{
				if (c == '\r')
				{
					m_iLineNo++;
					c = GetChar();
					if (c == '\n') c = GetChar();
					if (m_bEolIsSignificant)
					{
						m_peekc = c;
						return TT_EOL;
					}
				}
				else
				{
					if (c == '\n')
					{
						m_iLineNo++;
						if (m_bEolIsSignificant)
						{
							m_peekc = ' ';
							return TT_EOL;
						}
					}
					c = GetChar();
				}

				if (c == TT_EOF) return TT_EOF;
			}

			// is this a number
			if (char.IsDigit((char)c) || c == '-')
			{
				bool neg = false;
				if (c == '-')
				{
					c = GetChar();
					if (c != '.' && !char.IsDigit((char)c))
					{
						m_peekc = c;
						return '-';
					}
					neg = true;
				}
				double v = 0;
				int decexp = 0;
				int seendot = 0;
				while (true)
				{
					if (c == '.' && seendot == 0)
						seendot = 1;
					else if (char.IsDigit((char)c))
					{
						v = v * 10 + (c - '0');
						decexp += seendot;
					}
					else
						break;
					c = GetChar();
				}
				m_peekc = c;
				if (decexp != 0)
				{
					double denom = 10;
					decexp--;
					while (decexp > 0)
					{
						denom *= 10;
						decexp--;
					}
					v = v / denom;
				}
				else if (seendot == 1)
				{
					m_iChar--;
					m_peekc = '.';
					seendot = 0;
				}
				m_dVal = neg ? -v : v;
				if (seendot == 0)
					return TT_INTEGER;
				else
					return TT_REAL;
			}

			// is this a word
			if (char.IsLetter((char)c) || c == '_')
			{
				m_sVal = "";
				do
				{
					m_sVal = m_sVal + (char)c;
					c = GetChar();
				} while (char.IsLetterOrDigit((char)c) || c == '_');
				m_peekc = c;
				if (m_bForceLower)
					m_sVal = m_sVal.ToLower();
				return TT_WORD;
			}

			// now the char & string
			if (c == '\'' || c == '"')
			{
				m_sVal = "";
				m_tType = c; // enclosed tag
				m_peekc = ' ';
				int c2;
				while ((c = GetChar()) != TT_EOF && c != m_tType && c != '\n' && c != '\r')
				{
					if (c == '\\')// escape
						switch (c = GetChar())
						{
							case 'a': c = '\x7'; break;
							case 'b': c = '\b'; break;
							case 'f': c = '\xC'; break;
							case 'n': c = '\n'; break;
							case 'r': c = '\r'; break;
							case 't': c = '\t'; break;
							case 'v': c = '\xB'; break;
							case '0':
							case '1':
							case '2':
							case '3':
							case '4':
							case '5':
							case '6':
							case '7':
								c = c - '0';
								c2 = GetChar();
								if (c2 == m_tType)
								{
									m_sVal += (char)c;
									return m_tType;
								}
								if ('0' <= c2 && c2 <= '7')
								{ // octal
									c = (c << 3) + (c2 - '0');
									c2 = GetChar();
									if (c2 == m_tType)
									{
										m_sVal += (char)c;
										return m_tType;
									}
									if ('0' <= c2 && c2 <= '7')
										c = (c << 3) + (c2 - '0');
									else
									{
										m_sVal += (char)c;
										c = c2;
									}
								}
								else
								{
									m_sVal += (char)c;
									c = c2;
								}
								break;
							default:
								// warning: 'c' : unrecognized character escape sequence
								Program.PrintError(Strings.IDS_E__SYNTAX_ERROR, m_iLineNo);
								break;
						}
					m_sVal += (char)c;
				}
				if (c == TT_EOF)
				{
					// error msg: syntax error in line %d: missing '"'
					Program.PrintError(Strings.IDS_E__MISSING_QUOTATION, m_iLineNo);
				}
				else if (c == '\r' || c == '\n')
				{
					// error msg: syntax error in line %d: new line inant
					Program.PrintError(Strings.IDS_E__NEW_LINE_IN_CONSTANT, m_iLineNo);
				}

				return m_tType;
			}

			// #include... ignore
			if (c == '#')
			{
				while ((c = GetChar()) != '\n' && c != '\r') ;
				m_peekc = c;
				return InternalNextToken();
			}

			// and now the comment
			// "//" or "/*...*/"
			if (c == '/' && (m_bSlSlComments || m_bSlStComments))
			{
				c = GetChar();
				if (c == '*' && m_bSlStComments)
				{
					int prevc = 0;
					while ((c = GetChar()) != '/' || prevc != '*')
					{
						if (c == '\n') m_iLineNo++;
						if (c == TT_EOF) return TT_EOF;
						prevc = c;
					}
					m_peekc = ' ';
					return InternalNextToken();
				}
				else
				{
					if (c == '/' && m_bSlSlComments)
					{
						while ((c = GetChar()) != '\n' && c != '\r') ;
						m_peekc = c;
						return InternalNextToken();
					}
					else
					{
						m_peekc = c;
						return '/';
					}
				}
			}

			m_peekc = ' ';
			return c;
		}

		public int LineNo()
		{
			return m_iLineNo;
		}

		protected string GetStrValue()
		{
			switch (m_tType)
			{
				case TT_EOF:
					return "EOF";
				case TT_EOL:
					return "EOL";
				case TT_WORD:
					return m_sVal;
				case TT_STRING:
					return m_sVal;
				case TT_INTEGER:
				case TT_REAL:
					return string.Format("{0}", m_dVal);
				default:
					return string.Format("\'{0}\'", (char)m_tType);
			}
		}

		double GetDoubleNumValue()
		{
			return m_dVal;
		}

		public int GetIntNumValue()
		{
			return (int)m_dVal;
		}
	}
}
