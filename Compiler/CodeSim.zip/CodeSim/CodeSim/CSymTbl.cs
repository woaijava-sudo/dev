﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeSim
{
	// The record in the bucket lists for each variable, including name, 
	// assigned memory location, and the list of line numbers in which
	// it appears in the source code
	public class BucketListRec
	{
		public string				name;	// variable name
		public string				scope;	// function scope
		public LTokenType			type;
		public int					memloc;	// memory location for variable
		public bool					bArray; // for array checking
		public List<int>			lineno = new List<int>();

		// initiation
		public BucketListRec()
		{
			memloc = 0;
			lineno = null;
		}
	};

	public class CSymTbl
	{
		Dictionary<string, List<BucketListRec>> m_hashTable = new Dictionary<string, List<BucketListRec>>();

		public CSymTbl()
		{
		}

		public Dictionary<string, List<BucketListRec>> GetTable()
		{
			return m_hashTable;
		}

		public void st_insert(string name, string scope, LTokenType type, int lineno, int memloc, bool bArray = false)
		{
			try
			{
				var list = m_hashTable[name];
				var found = list.Find(a => a.scope == scope);
				if (found != null)
				{
					found.lineno.Add(lineno);
				}
				else
				{
					list.Add(new BucketListRec()
					{
						name = name,
						scope = scope,
						type = type,
						memloc = memloc,
						bArray = bArray,
						lineno = new List<int>() { lineno },
					});
				}
			}
			catch (KeyNotFoundException)
			{
				m_hashTable[name] = new List<BucketListRec>()
				{
					new BucketListRec()
					{
						name = name,
						scope = scope,
						type = type,
						memloc = memloc,
						bArray = bArray,
						lineno = new List<int>() { lineno },
					}
				};
			}
		}
		public bool st_lookup(string name, string scope)
		{
			try
			{
				var l = m_hashTable[name];
				return (l.Find(a => a.name == name || a.scope == scope)) != null;
			}
			catch (KeyNotFoundException)
			{
				return false;
			}
		}
		public bool st_lookup_isarray(string name, string scope)
		{
			try
			{
				var l = m_hashTable[name];
				var b = l.Find(a => (a.name == name || a.scope == scope));
				if (b != null) return b.bArray;
				else return false;
			}
			catch (KeyNotFoundException)
			{
				return false;
			}
		}
		public LTokenType st_lookup_type(string name, string scope)
		{
			try
			{
				var l = m_hashTable[name];
				var b = l.Find(a => (a.name == name || a.scope == scope));
				if (b != null) return b.type;
				else return LTokenType._ERROR;
			}
			catch (KeyNotFoundException)
			{
				return LTokenType._ERROR;
			}
		}

		public void Print()
		{
			if (m_hashTable.Count == 0)
				return;

			m_hashTable.ToList().ForEach(a =>
			{
				a.Value.ForEach(b =>
				{
					Console.Write("{0,-12}{1,-12}{2,-12}  ", b.name, b.type.ToString(), b.scope);
					b.lineno.ForEach(c => Console.Write(c + " "));
					Console.WriteLine();
				});
			});
		}
	}
}
