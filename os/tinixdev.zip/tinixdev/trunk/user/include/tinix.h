#ifndef _INCLUDE_TINIX_H
#define _INCLUDE_TINIX_H

#include <types.h>
#include <stdarg.h>
#include <string.h>
#include <syscall.h>

#endif
