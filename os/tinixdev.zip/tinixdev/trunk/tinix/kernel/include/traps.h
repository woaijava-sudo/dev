/*
 * 陷阱
 */

#ifndef _TRAP_H
#define _TRAP_H

#include <include/types.h>

extern void init_traps();

#endif
