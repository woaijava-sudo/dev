#ifndef _SYSFS_H
#define _SYSFS_H

#include <include/types.h>

extern void init_sysfs();
#endif

