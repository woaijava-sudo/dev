#ifndef _KEYBOARD_H
#define _KEYBOARD_H

extern void kbd_handler(void);
extern void init_kbd();
#endif
