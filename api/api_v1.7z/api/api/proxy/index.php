<?php

if (!isset($_GET['url'])) {
     header('HTTP/1.1 404 Not Found');
     header('status: 404 Not Found');
     exit;
}

$url = $_GET['url'];

function _addEtag() {
    // always send headers
    $etag = 'bajdcc_cache_system';
    header("Etag: $etag"); 
    // exit if not modified
    if (isset($_SERVER['HTTP_IF_NONE_MATCH'])) {
        header("HTTP/1.1 304 Not Modified");
        exit; 
    }
}

_addEtag();



?>