﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _403ErrPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        _Method.Text = Request.RequestType;
        string sParams = Request.Url.ToString();
        int nIndex = sParams.IndexOf("?");
        _ErrCode.Text = sParams.Substring(nIndex + 1, 3);
        _Url.Text = sParams.Substring(nIndex + 5);
        _IP.Text = Request.UserHostAddress;
        _Lang.Text = Request.UserLanguages == null ? "Unknown" : Request.UserLanguages[0];
        _Browser.Text = Request.ServerVariables["HTTP_USER_AGENT"];
        _OS.Text = Request.Browser.Platform;
        Response.StatusCode = 403;
    }
}