function gup(name) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(location.search);
    if (results === null) {
        return null;
    }
    else {
        return results[1];
    }
}
window.toast_old = Materialize.toast;
window.toast = (function () {
    return function () {
        var args = Array.prototype.slice.call(arguments);
        var obj = args.shift(1);
        var id = obj.id || '[ID]';
        var text = obj.text || '[TEXT]';
        var type = obj.type || 'INFO';
        var color = '';
        if (type === 'INFO') {
            color = 'white';
        } else if (type === 'WARN') {
            color = 'yellow';
        } else if (type === 'ERROR') {
            color = 'red';
        } else {
            color = 'blue';
        }
        return window.toast_old.apply(this, [
            '<a class="' + color + '-text">[' + id + ']<a>&emsp;' +
            '<span class="white-text">' + text + '</span>'
        ].concat(args));
    };
})();
function calcMod(str) {
    str = str || '';
    var s = 0;
    for (var i = 0; i < str.length; i++) {
        s += str.charCodeAt(i);
    }
    return s;
}
window.kpid = md5(uuid.v4()).substring(0, 8);
function initMqtt() {
    // Create a client instance
    client = new Paho.MQTT.Client(location.hostname, Number(61614), "WebKP/" + kpid);

    // set callback handlers
    client.onConnectionLost = onConnectionLost;
    client.onMessageArrived = onMessageArrived;

    // connect the client
    client.connect({ onSuccess: onConnect });
}

// called when the client connects
function onConnect() {
    // Once a connection has been made, make a subscription and send a message.
    console.log("MQTT CONNECT");
    var t = (window.server ? window.kpid : window.serverKey);
    t = calcMod(t) % 4;
    window.topic = '/mqtt/kp/' + t;
    client.subscribe(topic);
    if (window.server) {
        toast({ id: "MQTT", type: "INFO", text: "Success! Waiting for connection." }, 5000);
    } else {
        var msg = new Paho.MQTT.Message('$client_echo$');
        msg.destinationName = window.topic;
        client.send(msg);
    }
}

// called when the client loses its connection
function onConnectionLost(responseObject) {
    if (responseObject.errorCode !== 0) {
        console.log("MQTT ERROR: " + responseObject.errorMessage);
        toast({ id: "MQTT", type: "ERROR", text: "Error! Refresh in 5 seconds." });
        setTimeout(function () { location.href = '.'; location.reload(); }, 5000);
    }
}

// called when a message arrives
function onMessageArrived(message) {
    var msg = message.payloadString;
    if (msg === '$client_echo$') {
        if (server) {
            toast({ id: "MQTT", type: "INFO", text: "Client say hi! Send response." }, 3000);
            var _msg = new Paho.MQTT.Message('$server_echo$');
            _msg.destinationName = window.topic;
            client.send(_msg);
            setTimeout(function(){
                $("header").addClass('hide');
                $("footer").addClass('hide');
                $('#qrcode').addClass('hide');
                $("#qrtalk").removeClass('hide');
                $('#url').addClass('hide');
                $("body").addClass('bg');
            }, 100);
        }
    } else if (msg === '$server_echo$') {
        if (!server) {
            toast({ id: "MQTT", type: "INFO", text: "Server say hi!" }, 3000);
            setTimeout(function(){
                $("header").addClass('hide');
                $("footer").addClass('hide');
                $("#qrtalk").removeClass('hide');
                $("body").addClass('bg');
            }, 100);
        }
    } else {
        if (msg.length < 2) return;
        var s = msg[0];
        var shouldShow;
        if (s === 'C') {
            shouldShow = window.server;
        } else if (s === 'S') {
            shouldShow = !window.server;
        } else {
            return;
        }
        msg = msg.substring(2);
        console.log("MQTT RECV: " + msg);
        //toast({ id: "MESSAGE", type: "INFO", text: msg }, 5000);
        var li = $('<li></li>');
        li.html(msg);
        li.addClass(!shouldShow ? 'old' : 'even');
        li.appendTo('.chat-thread');
        $('.chat-thread')[0].scrollTop = $('.chat-thread')[0].scrollHeight;
    }
}
(function ($) {
    $(function () {
        var key = gup('key');
        if (key && key.length === 8) {
            window.server = false;
            window.serverKey = key;
            $('#qrcode').addClass('hide');
            $('#url').addClass('hide');
        } else {
            window.server = true;
            var url = location.origin + '/kp/?key=' + kpid;
            // $('#qrcode').qrcode(url);
            new QRCode(document.getElementById("qrcode"), {
                text: url,
                width: 300,
                height: 300,
                colorDark : "#F44336",
                colorLight : "#ffffff",
                correctLevel : QRCode.CorrectLevel.H
            });
            $('#url').attr('href', url);
            $('#url').html(url);
        }
        initMqtt();
        $('.chat-window').submit(function (e) {
            e.preventDefault();
            var msg = $('#text').val();
            if (!msg) return;
            $('#text').val('');
            msg = (window.server ? 'S' : 'C') + '$' + msg; 
            var _msg = new Paho.MQTT.Message(msg);
            _msg.destinationName = window.topic;
            client.send(_msg);
            return false;
        });
    });
})($);