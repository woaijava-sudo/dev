<?php

header("X-Powered-By: bajdcc");

header("HTTP/1.1 302 Found");
header("Location: /x/remote_console/app-debug.apk");

?>
