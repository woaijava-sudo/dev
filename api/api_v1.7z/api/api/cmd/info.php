<?php

function _get($str){
    $val = isset($_GET[$str]) ? $_GET[$str] : '';
    return $val;
}

$arr = array(
    'server' => $_SERVER['HTTP_HOST'],
    'ip' => _get('ip')
);
echo json_encode($arr, 1);