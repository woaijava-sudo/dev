(function(){
    var page = $(".content"),
        playCtrl = $("#playerCtrl"),
        panelGroup = page.find(".panelGroup"),
        panels = panelGroup.find(".panel");
    var pageWidth = page.outerWidth();
    page.bind("swipeleft",function(evt){
        evt.preventDefault();
        page.next();
    });
    page.bind("swiperight",function(evt){
        evt.preventDefault();
        page.prev();
    });
    window.page0 = page;
    $(window).resize(function() {
        //pageWidth = page.outerWidth();
    });
    window.cycle = false;
    $(document).bind("keydown",'s',function(evt){
        window.cycle = !window.cycle;
    });
    $(document).bind("keydown",'p',function(evt){
        $.get('/rpc/danmuku.full');
    });
    $(document).bind("keydown",'space',function(evt){
        playCtrl.find(".play").trigger("click");
    });
    $(document).bind("keydown",'left',function(evt){
        page.prev0();
    });
    $(document).bind("keydown",'right',function(evt){
        page.next0();
    });
    $(document).bind("keydown",'[',function(evt){
        playCtrl.find(".prev").trigger('click');
    });
    $(document).bind("keydown",']',function(evt){
        playCtrl.find(".next").trigger('click');
    });
    $(document).bind("keydown",'home',function(evt){
        page.homing();
    });
    page.currentPageIndex = 0;
    page.setLeft = function(left,duration){
        if(!duration)duration = 0;
        panelGroup.css("transition","all "+duration+"ms");
        panelGroup.css("transform","translateX("+left+"px)");
        //panelGroup.css({"-webkit-transition":"left "+duration+"ms","left":left});
    };
    page.slideTo = function(pageIndex){
        if(pageIndex == this.currentPageIndex)return;
        page.setLeft(pageWidth*pageIndex,300);
        this.currentPageIndex = pageIndex;
    };
    page.prev0 = function(){
        var prev = this.currentPageIndex-1;
        if(prev<0)return this.homing();
        page.setLeft(-(pageWidth*prev),300);
        this.currentPageIndex = prev;
    };
    page.next0 = function(){
        var next = this.currentPageIndex+1;
        if(next>=3)return this.homing();
        page.setLeft(-(pageWidth*next),300);
        this.currentPageIndex = next;
    };
    page.homing = function(){
        page.setLeft(-(pageWidth*this.currentPageIndex),300);
    };

    window.addEventListener("load",function(){
       pageWidth =  page.outerWidth();
    });
})();