_.templateSettings = {
    interpolate: /\{\{(.+?)\}\}/g
};
var playCtrl = $("#playerCtrl"),
    musicList = $("#music_list"),
    playerProgress = $("#playerProgress"),
    playInfo = $(".playing_info"),
    album_art = $(".album_art"),
    lyric_wrap = $(".lyric_wrap"),
    lyric = lyric_wrap.find("#lyric");
$(document).ready(onReady);
function onReady(){
    getPlayList();
    initPlayerProgress();
    initPlayCtrl();
    $player.bind("error",function(e){
        //console.error(e.message);
        $player.trigger('ended');
    });
    initMqtt();
    initHTML();
}

function initPlayerProgress(){
    var total =  playerProgress.find(".totalTime"),
        current = playerProgress.find(".currentTime");
    $player.bind("timeupdate",function(){
        var currentTime = this.currentTime,
            duration = this.duration;
        $progressbar.setProgress(currentTime/duration*100);
        current.html(parseTime(currentTime));
    });
    $player.bind("ended",function(){
        setTimeout(function(){
            if (window.cycle){
                playCtrl.find(".play").trigger('click');
            }else{
                playCtrl.find(".next").trigger('click');
            }
        },2000);
    });
    $player.bind("playing",function(){
        $progressbar.slideable = true;
        musicList.find(".selected").addClass("playing");
        playCtrl.find(".play").addClass("playing");
        total.html(parseTime(this.duration));
        renderInfo($player.music);
        renderLyric($player.music);
    });
    $player.bind("pause ended",function(evt){
        musicList.find(".selected").removeClass("playing");
        playCtrl.find(".play").removeClass("playing");
        album_art.removeClass("active");
        if(evt.type == "ended"){
            $progressbar.slideable = false;
            $player.unbind("timeupdate",updateLyric);
            text_temp = undefined;
        }
    });
    $progressbar.bind("change",function(){
        if(!$player.music)return;
        var p = $progressbar.progress;
        var time = $player.geDuration()*(p/100);
        $player.seekTo(time);
    });
    function parseTime(time){
        var min = String(parseInt(time/60)),
            sec = String(parseInt(time%60));
        if(min.length==1)min = "0"+min;
        if(sec.length==1)sec = "0"+sec;
        return min+":"+sec;
    }
}

window.oldpic = '';
function renderInfo(music){
    var k = music.name+' -- '+music.singer;
    $.get('/rpc/danmuku.exe', {user:'',text:k,warn:true});
    window.playing_title = k;
    var message = new Paho.MQTT.Message('正在播放\n'+k);
    message.destinationName = '/mqtt/public/android';
    client.send(message);
    window.picsrc = location.origin+"/image?"+music.cover+
    "?width=400&height=300&blur=5&sigma=4&threshold=20&brightness=-50&bgcolor=black";
    window.picsrc = "api/image_proxy.php?url="+encodeURIComponent(window.picsrc);
    if ($('#for_cache').length) $('#for_cache').remove();
    $('<img style="display:none" src="'+window.picsrc+'" id="for_cache"/>').appendTo('body');
    if (window.oldpic !== music.cover){
    $('body').removeAttr('style');
    setTimeout(function(){
        $('#for_cache').remove();
        $('body').attr('style', 'background:url("'+window.picsrc+'");background-size:cover;');
    },5000);
    }
    window.oldpic = music.cover;
    document.title = k;
    playInfo.find(".songName").html(music.name);
    playInfo.find(".singer").html(music.singer);
    album_art.addClass("active");
    album_art.find(".cover").attr("src",music.cover);
    var infoTemp = _.template($("#music_info").html());
    $(".music_info").html(infoTemp(music));
}

var sp = "……";
function renderLyric(music){
    lyric.html("");
    var lyricLineHeight = 57;
        offset = lyric_wrap.outerHeight()*0.44;
    music.lyric.fetch(function(data){
        music.lyric.parsed = {};
        var i = 0;
        
        for(var k in data){
            var txt = data[k];
            if(!$.trim(txt))txt = sp;
            music.lyric.parsed[k] = {
                index:i++,
                text:txt,
                top: i*lyricLineHeight-offset
            };
            if(txt===sp)lyric.append($("<li class='emit'>"+txt+"</li>"));
            else lyric.append($("<li>"+txt+"</li>"));
        }
        lyric.css("margin-top","0px");
        $player.bind("timeupdate",updateLyric);
    },function(){
        lyric.html("<li style='text-align: center'>歌词加载失败</li>");
    });
}

var text_temp;
function updateLyric(){
    var data = $player.music.lyric.parsed;
    if(!data)return;
    var currentTime = Math.round(this.currentTime);
    var lrc = data[currentTime];
    if(!lrc)return;
    var text = lrc.text;
    if(text != text_temp){
        locationLrc(lrc,text);
        text_temp = text;
    }
    function locationLrc(lrc,text){
        if ($.trim(text)&&text!==sp) {
            var tmplrc = '♪ '+text;
            $.get('/rpc/danmuku.exe', {user:'',text:tmplrc,warn:false});
            var title=window.playing_title;
            var message = new Paho.MQTT.Message(title+'\n'+text);
            message.destinationName = '/mqtt/public/android';
            client.send(message);
        }
        lyric_wrap.find(".on").removeClass("on");
        var li = lyric_wrap.find("li:nth-child("+(lrc.index+1)+")");
        li.addClass("on");
        var top = Math.min(0,-lrc.top);
        //lyric.css({"-webkit-transform":"translate(0,-"+lrc.top+"px)"});
        lyric.css("margin-top",top+"px");
    }
}
function gup(name) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(location.search);
    if (results === null) {
        return null;
    }
    else {
        return results[1];
    }
}
function getPlayList(){
    var list = $("#music_list");
    var mapi = '';
    if (gup('tmp')) {
        mapi = "api/"+gup('tmp')+"music.json";
    } else if (gup('s')) {
        mapi = "api/suggest/?s="+gup('s');
    } else {
        mapi = "api/music.json";
    }
    $.ajax({
        url:mapi,
        cache:false,
        success:function(data){
            list.empty();
            $player.playList.add(data);
            var template = _.template($("#music_list_item").html());
            $.each($player.playList.all(),function(i,m){
                if(m["link_lrc"])m.lyric = new Lyrics(m["link_lrc"]);
                var dom = $(template(m)).get(0);
                dom.index = i;
                dom.music = m;
                list.append(dom);
            })
        },
        error:function(){
            list.html('<li style="text-align: center;display: block;">音乐列表获取失败！</li>');
        }
    });
    list.on("click","li",function(){
        musicList.find(".selected").removeClass("selected");
        $(this).addClass("selected");
        $player.play(this.music);
    });
}

function initPlayCtrl(){
    playCtrl.find(".loop").bind("click",function(){
        window.cycle = !window.cycle;
    });
    playCtrl.find(".play").bind("click",function(){
        if($player.music){
            $player.play($player.music);
        }else{
            musicList.find("li:first-child").trigger("click");
        }
    });
    playCtrl.find(".prev").bind("click",function(){
        var prev = musicList.find(".selected").prev("li");
        prev.trigger("click");
    });
    playCtrl.find(".next").bind("click",function(){
        var next = musicList.find(".selected").next("li");
        if(next.length>0)next.trigger("click");
        else{
            musicList.find("li:first-child").trigger("click");
        }
    });
}

function initMqtt() {
    // Create a client instance
    client = new Paho.MQTT.Client(location.hostname, Number(61614), "Web/"+md5(uuid.v4()).substring(0, 8));

    // set callback handlers
    client.onConnectionLost = onConnectionLost;
    client.onMessageArrived = onMessageArrived;

    // connect the client
    client.connect({onSuccess:onConnect});
}

// called when the client connects
function onConnect() {
  // Once a connection has been made, make a subscription and send a message.
  console.log("mqtt connect");
  var topic = '/mqtt/public/music';
  client.subscribe(topic);
  var message = new Paho.MQTT.Message("Ready");
  message.destinationName = topic;
  client.send(message);
}

// called when the client loses its connection
function onConnectionLost(responseObject) {
  if (responseObject.errorCode !== 0) {
    console.log("mqtt lost connection: "+responseObject.errorMessage);
    setTimeout(function(){initMqtt();},5000);
  }
}

// called when a message arrives
function onMessageArrived(message) {
  var msg = message.payloadString;
  console.log("mqtt receive: "+msg);
  var page = window.page0, playCtrl = $("#playerCtrl");
  var e;
  if (msg === 'prev') {
	playCtrl.find(".prev").trigger('click');
  } else if (msg === 'next') {
	playCtrl.find(".next").trigger('click');
  } else if (msg === 'space') {
	playCtrl.find(".play").trigger("click");
  } else if (msg === 'single') {
	window.cycle = !window.cycle;
  } else if (msg === 'danmuku') {
	$.get('/rpc/danmuku.full');
  } else if (msg === 'left') {
    page.prev0();
  } else if (msg === 'right') {
	page.next0();
  } else if (msg === 'ready') {
    console.log('ready');
  }
}

function initHTML() {
    if (gup('s')) {
        $('#text').val(decodeURIComponent(gup('s').replace(/[+]/g,'%20')));
    }
}