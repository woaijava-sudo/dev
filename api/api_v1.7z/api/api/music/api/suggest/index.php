<?php

error_reporting(E_ALL & ~E_NOTICE);

if (!isset($_GET['s'])) {
    echo ('Missing parameters.');
	header('HTTP/1.1 404 Not Found');
	header('status: 404 Not Found');
}

$id = $_GET['s'];

function getSuggest($s) {
	
	$url = 'http://music.163.com/api/search/suggest/web';
	$data = array('s' => $s);

	$options = array(
	CURLOPT_HEADER => 0,
	CURLOPT_REFERER => 'http://music.163.com',
    CURLOPT_POST=> 1,
    CURLOPT_POSTFIELDS => http_build_query($data),
	CURLOPT_URL => $url,
	CURLOPT_RETURNTRANSFER => 1,
	CURLOPT_TIMEOUT => 5,
	CURLOPT_FOLLOWLOCATION => 1,
	CURLOPT_BINARYTRANSFER => true,
	CURLOPT_SSL_VERIFYPEER => 0,
	CURLOPT_SSL_VERIFYHOST => 0,
	CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36'
	);
	
	$ch = curl_init();
	curl_setopt_array($ch, $options);
	
	if (!$html = curl_exec($ch)) {
		echo (curl_error($ch));
		header('HTTP/1.1 404 Not Found');
		header('status: 404 Not Found');
		exit;
	}

    return $html;
	
	curl_close($ch);
}

function getSuggestIds($json) {
    $obj = json_decode($json, true);
    $ids = array();
	if (!isset($obj["result"]["songs"])) {
		return $ids;
	}
    foreach ($obj["result"]["songs"] as $s) {
        $ids[] = $s["id"];
    }
    return $ids;
}

function getJson($s) {
	$url = 'http://music.163.com/api/song/detail/';
	$data = array('id' => $s, "ids" => "[$s]");

	$options = array(
	CURLOPT_HEADER => 0,
	CURLOPT_REFERER => 'http://music.163.com',
    CURLOPT_POST=> 1,
    CURLOPT_POSTFIELDS => http_build_query($data),
	CURLOPT_URL => $url,
	CURLOPT_RETURNTRANSFER => 1,
	CURLOPT_TIMEOUT => 5,
	CURLOPT_FOLLOWLOCATION => 1,
	CURLOPT_BINARYTRANSFER => true,
	CURLOPT_SSL_VERIFYPEER => 0,
	CURLOPT_SSL_VERIFYHOST => 0,
	CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36'
	);
	
	$ch = curl_init();
	curl_setopt_array($ch, $options);
	
	if (!$html = curl_exec($ch)) {
		echo (curl_error($ch));
		header('HTTP/1.1 404 Not Found');
		header('status: 404 Not Found');
		exit;
	}

    return $html;
	
	curl_close($ch);
}

function buildJson($ids) {
    $ja = array();
    foreach ($ids as $id) {
        $detail = json_decode(getJson($id), true);
        $songs = $detail['songs'][0];
        $obj = array(
            "name" => $songs['name'],
            "duration" => $songs['duration'],
            "composer" => "--",
            "lyrics" => "--",
            "singer" => $songs['artists'][0]['name'],
            "album" => $songs['album']['name'],
            "type" => $songs['album']['type'],
            "cover" => $songs['album']['picUrl'],
            "link_url" => $songs['mp3Url'],
            "link_lrc" => "api/proxy.php?id=" . $id
        );
        $ja[] = $obj;
    }
    return json_encode($ja, JSON_UNESCAPED_SLASHES);
}

$sjson = getSuggest($id);
$sids = getSuggestIds($sjson);
$buildjson = buildJson($sids);

header("Content-Type: application/json");

function _addEtag() {
    // always send headers
    $etag = 'bajdcc_cache_system';
    header("Etag: $etag"); 
    // exit if not modified
    if (isset($_SERVER['HTTP_IF_NONE_MATCH'])) {
        header("HTTP/1.1 304 Not Modified");
        exit; 
    }
}

_addEtag();

echo $buildjson;

?>