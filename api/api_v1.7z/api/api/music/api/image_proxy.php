<?php

header("X-Powered-By: bajdcc");

if (!isset($_GET['url'])) {
    header('HTTP/1.1 404 Not Found');
    header('status: 404 Not Found');
    exit;
}

$url = $_GET['url'];

if (!preg_match('/^http/', $url)) {
    header('HTTP/1.1 404 Not Found');
    header('status: 404 Not Found');
    exit;
}

$url = urldecode($url);

function remote_file_exists(&$url)
{
    if (strlen($url) == 4) {
        goto FAILURE_LABEL;
    }

    $ch = curl_init();

    $options = array(
        CURLOPT_URL => $url,
        CURLOPT_HEADER => 1,
        CURLOPT_NOBODY => 1,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36'
    );

    curl_setopt_array($ch, $options);
    curl_exec($ch);
    if (curl_errno($ch)) {
        goto FAILURE_LABEL;
    }

    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $length = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
    curl_close($ch);

    if ($code != "404") {
        header("X-Test: true");
        return true;
    }

    FAILURE_LABEL:

	header("X-Test: false");
    return false;
}

if (remote_file_exists($url)) {
    header("HTTP/1.1 302 Found");
    header("Location: $url");
    header("X-Tested-By: bajdcc_server");
    exit;
}

header("HTTP/1.1 302 Found");
header("Location: /music/res/images/bg2.jpg");

?>
