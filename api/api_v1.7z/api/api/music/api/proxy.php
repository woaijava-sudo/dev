<?php

$id = $_GET['id'];
if (!preg_match('/^\\d+$/', $id)) {
     header('HTTP/1.1 404 Not Found');
     header('status: 404 Not Found');
     exit;
}

function _addEtag() {
    // always send headers
    $etag = 'bajdcc_cache_system';
    header("Etag: $etag"); 
    // exit if not modified
    if (isset($_SERVER['HTTP_IF_NONE_MATCH'])) {
        header("HTTP/1.1 304 Not Modified");
        exit; 
    }
}

_addEtag();

$url='http://music.163.com/api/song/media?id=' . $id;

$options = array(
            CURLOPT_HEADER => 0,
            CURLOPT_REFERER => 'http://music.163.com',
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_FOLLOWLOCATION => 1,
            CURLOPT_BINARYTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36'
        );

        $ch = curl_init();
        curl_setopt_array($ch, $options);
        if (!$html = curl_exec($ch)) {
            echo (curl_error($ch));
            header('HTTP/1.1 404 Not Found');
            header('status: 404 Not Found');
            exit;
        }
        curl_close($ch);


//$html = file_get_contents($url);
//$html = stripslashes($html);
echo $html;

?>