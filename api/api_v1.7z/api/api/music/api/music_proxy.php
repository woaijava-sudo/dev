<?php

if (!isset($_GET['url'])) {
    header('HTTP/1.1 404 Not Found');
    header('status: 404 Not Found');
    exit;
}

$url = $_GET['url'];

if (!preg_match('/^http/', $url)) {
    header('HTTP/1.1 404 Not Found');
    header('status: 404 Not Found');
    exit;
}

$url = urldecode($url);

function remote_file_exists(&$url)
{
    if (strlen($url) == 4) {
        goto CACHE_LABEL;
    }

    $ch = curl_init();

    $options = array(
        CURLOPT_URL => $url,
        CURLOPT_HEADER => 1,
        CURLOPT_NOBODY => 1,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36'
    );

    curl_setopt_array($ch, $options);
    curl_exec($ch);
    if (curl_errno($ch)) {
        goto CACHE_LABEL;
    }

    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $length = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
    curl_close($ch);

    if ($code != "404") {
        header("X-Hit: hit");
        header("X-Content-Length: $length");
        return true;
    }

    CACHE_LABEL:

    if (!isset($_GET['singer']) || !isset($_GET['name'])) {
        header("X-Hit: miss");
        return false;
    }

    $singer = urldecode($_GET['singer']);
    $name = urldecode($_GET['name']);

    $host = isset($_SERVER['HTTP_X_FORWARDED_HOST']) ? $_SERVER['HTTP_X_FORWARDED_HOST'] :
        (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');

    $url = "http://$host/music/cache/$singer - $name.mp3";

    header("X-Hit: mirror");
    return true;
}

if (remote_file_exists($url)) {
    header("HTTP/1.1 302 Found");
    header("Location: $url");
    header("X-Cached-By: bajdcc_server");
    exit;
}

header('HTTP/1.1 404 Not Found');
header('status: 404 Not Found');

?>
