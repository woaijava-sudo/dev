<?php

$data = $_POST['data'];
$data = stripslashes($data);
echo $data;

?>