﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;
using System.Threading;
using System.Web;
using System.Windows.Forms;
using Apache.NMS;
using Apache.NMS.ActiveMQ;
using Apache.NMS.ActiveMQ.Commands;
using CookComputing.XmlRpc;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;


namespace api
{
    // 注意: 使用“重构”菜单上的“重命名”命令，可以同时更改代码、svc 和配置文件中的类名“Service1”。
    // 注意: 为了启动 WCF 测试客户端以测试此服务，请在解决方案资源管理器中选择 Service1.svc 或 Service1.svc.cs，然后开始调试。
    [ServiceContract(Namespace = "http://www.bajdcc.com")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class ApiService
    {
        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "desktop.jpg")]
        public Stream BuildImage()
        {
            var res = WebOperationContext.Current.OutgoingResponse;
            try
            {
                IRpcDesktop proxy = XmlRpcProxyGen.Create<IRpcDesktop>();
                string base64data = proxy.get_desktop_base64();
                var ms = new MemoryStream(Convert.FromBase64String(base64data));
                res.ContentType = "image/jpeg";
                res.ContentLength = ms.Length;
                return ms;
            }
            catch (Exception e)
            {
                PassSession0.CreateProcess("DesktopRPCServer.exe", @"O:\csharp\DesktopRPCServer\DesktopRPCServer\bin\Debug");
                Thread.Sleep(5000);
                res.StatusCode = HttpStatusCode.InternalServerError;
                var ms = new MemoryStream(Encoding.UTF8.GetBytes(e.Message));
                res.ContentType = "text/plain";
                res.ContentLength = ms.Length;
                return ms;
            }
        }

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "danmuku.exe?user={user}&text={text}&warn={warn}", RequestFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        public Result FireDanmuku(string user, string text, string warn)
        {
            try
            {
                IRpcDanmuku proxy = XmlRpcProxyGen.Create<IRpcDanmuku>();
                proxy.NonStandard = XmlRpcNonStandard.AllowStringFaultCode;
                proxy.send_danmuku(user, text, warn);
                return new Result("Success");
            }
            catch (Exception e)
            {
                PassSession0.CreateProcess("DanmukuRPCServer.exe", @"O:\csharp\DanmukuRPCServer\bin\Debug");
                Thread.Sleep(5000);
                return new Result(e.Message);
            }
        }

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "danmuku.shutdown", RequestFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        public Result ShutdownDanmuku()
        {
            try
            {
                IRpcDanmuku proxy = XmlRpcProxyGen.Create<IRpcDanmuku>();
                proxy.NonStandard = XmlRpcNonStandard.AllowStringFaultCode;
                proxy.shutdown_danmuku();
                return new Result("Success");
            }
            catch (Exception e)
            {
                return new Result(e.Message);
            }
        }

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "danmuku.full", RequestFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        public Result ToogleDanmuku()
        {
            try
            {
                IRpcDanmuku proxy = XmlRpcProxyGen.Create<IRpcDanmuku>();
                proxy.NonStandard = XmlRpcNonStandard.AllowStringFaultCode;
                proxy.toogle_danmuku();
                return new Result("Success");
            }
            catch (Exception e)
            {
                return new Result(e.Message);
            }
        }

        // 在此处添加更多操作并使用 [OperationContract] 标记它们
        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "lock.exe",
            ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Result LockSystem()
        {
            return new Result(PassSession0.CreateProcess("Win32Draw.exe", @"F:\VC++\LockConsole\AttachUI\Release"));
        }

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "alert.exe/{arg}",
            ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        public string ShowMsgBox(string arg)
        {
            PassSession0.ShowMessageBox(HttpUtility.UrlDecode(arg), PassSession0.caption);
            return "Success";
        }

        /// <summary>
        /// ActiveMQ - OpenWire
        /// </summary>
        /// <param name="message">消息</param>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "broadcast.openwire?msg={message}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        public Result BroadcastMessageWithOpenWire(string message)
        {
            try
            {
                // Create the Connection Factory
                var factory = new ConnectionFactory("tcp://localhost:61616/");
                using (var connection = factory.CreateConnection())
                {
                    // Create the Session
                    using (var session = connection.CreateSession())
                    {
                        // Create the Producer for the topic/queue
                        var prod = session.CreateProducer(new ActiveMQTopic("public"));

                        // Send Messages  
                        var msg = prod.CreateTextMessage();
                        msg.Text = message;
                        prod.Send(msg, MsgDeliveryMode.NonPersistent,
                            MsgPriority.Normal, TimeSpan.MinValue);
                    }
                }
            }
            catch (System.Exception e)
            {
                return new Result(e.Message);
            }
            return new Result("Success");
        }

        /// <summary>
        /// ActiveMQ - Mqtt
        /// </summary>
        /// <param name="message">消息</param>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "broadcast.mqtt?msg={message}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        public Result BroadcastMessageWithMqtt(string message)
        {
            try
            {
                var client = new MqttClient("localhost");

                string clientId = Guid.NewGuid().ToString();
                client.Connect(clientId);

                // publish a message on topic with QoS 2
                client.Publish("/mqtt/public/android",
                    Encoding.UTF8.GetBytes(message),
                    MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);
            }
            catch (System.Exception e)
            {
                return new Result(e.Message);
            }
            return new Result("Success");
        }
    }

    [DataContract]
    public class Result
    {
        string message = string.Empty;

        public Result(string msg)
        {
            message = msg;
        }

        [DataMember]
        public string Message
        {
            get { return message; }
            set { message = value; }
        }

    }
}
