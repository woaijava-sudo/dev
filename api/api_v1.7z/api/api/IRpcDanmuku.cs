﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CookComputing.XmlRpc;

namespace api
{
    [XmlRpcUrl("http://127.0.0.1:7773")]
    public interface IRpcDanmuku : IXmlRpcProxy
    {
        [XmlRpcMethod("fire_danmuku")]
        void send_danmuku(string user, string text, string warn);

        [XmlRpcMethod("shutdown_danmuku")]
        void shutdown_danmuku();

        [XmlRpcMethod("toogle_danmuku")]
        void toogle_danmuku();
    }
}