﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CookComputing.XmlRpc;

namespace api
{
    [XmlRpcUrl("http://127.0.0.1:7776")]
    public interface IRpcDesktop : IXmlRpcProxy
    {
        [XmlRpcMethod("desktop")]
        string get_desktop_base64();
    }
}