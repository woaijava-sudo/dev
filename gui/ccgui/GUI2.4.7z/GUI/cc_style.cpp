#include "stdafx.h"
#include "cc_element.h"
#include "cc_control.h"
#include "cc_style.h"
#include <gdiplus.h>

using namespace cc::presentation::element;

namespace cc
{
	namespace presentation
	{
		namespace control
		{
			namespace style
			{
				DefaultBehaviorStyleController::DefaultBehaviorStyleController()
				{

				}

				DefaultBehaviorStyleController::~DefaultBehaviorStyleController()
				{

				}

				void DefaultBehaviorStyleController::AttachWindow(PassRefPtr<Window> _window)
				{
					window = _window;
				}

				void DefaultBehaviorStyleController::InitializeWindowProperties()
				{

				}

				void DefaultBehaviorStyleController::SetSizeState(IWindow::WindowSizeState value)
				{

				}

				bool DefaultBehaviorStyleController::GetMaximizedBox()
				{
					if (window->GetWindow())
					{
						return window->GetWindow()->GetMaximizedBox();
					}
					else
					{
						return false;
					}
				}

				void DefaultBehaviorStyleController::SetMaximizedBox(bool visible)
				{
					if (window->GetWindow())
					{
						window->GetWindow()->SetMaximizedBox(visible);
					}
				}

				bool DefaultBehaviorStyleController::GetMinimizedBox()
				{
					if (window->GetWindow())
					{
						return window->GetWindow()->GetMinimizedBox();
					}
					else
					{
						return false;
					}
				}

				void DefaultBehaviorStyleController::SetMinimizedBox(bool visible)
				{
					if (window->GetWindow())
					{
						window->GetWindow()->SetMinimizedBox(visible);
					}
				}

				bool DefaultBehaviorStyleController::GetBorder()
				{
					if (window->GetWindow())
					{
						return window->GetWindow()->GetBorder();
					}
					else
					{
						return false;
					}
				}

				void DefaultBehaviorStyleController::SetBorder(bool visible)
				{
					if (window->GetWindow())
					{
						window->GetWindow()->SetBorder(visible);
					}
				}

				bool DefaultBehaviorStyleController::GetSizeBox()
				{
					if (window->GetWindow())
					{
						return window->GetWindow()->GetSizeBox();
					}
					else
					{
						return false;
					}
				}

				void DefaultBehaviorStyleController::SetSizeBox(bool visible)
				{
					if (window->GetWindow())
					{
						window->GetWindow()->SetSizeBox(visible);
					}
				}

				bool DefaultBehaviorStyleController::GetIconVisible()
				{
					if (window->GetWindow())
					{
						return window->GetWindow()->GetIconVisible();
					}
					else
					{
						return false;
					}
				}

				void DefaultBehaviorStyleController::SetIconVisible(bool visible)
				{
					if (window->GetWindow())
					{
						window->GetWindow()->SetIconVisible(visible);
					}
				}

				bool DefaultBehaviorStyleController::GetTitleBar()
				{
					if (window->GetWindow())
					{
						return window->GetWindow()->GetTitleBar();
					}
					else
					{
						return false;
					}
				}

				void DefaultBehaviorStyleController::SetTitleBar(bool visible)
				{
					if (window->GetWindow())
					{
						window->GetWindow()->SetTitleBar(visible);
					}
				}

				PassRefPtr<IWindowStyleController> Win8Style::CreateWindowStyle()
				{
					return adoptRef(new Win8WindowStyle);
				}

				PassRefPtr<IControlStyleController> Win8Style::CreateCustomControlStyle()
				{
					return adoptRef(new EmptyStyleController);
				}

				Win8WindowStyle::Win8WindowStyle()
				{
					RefPtr<SolidBackgroundElement> element = SolidBackgroundElement::Create();
					element->SetColor(GetSystemWindowColor());

					boundsComposition = adoptRef(new BoundsComposition);
					boundsComposition->SetOwnedElement(element);
				}

				Win8WindowStyle::~Win8WindowStyle()
				{

				}

				PassRefPtr<BoundsComposition> Win8WindowStyle::GetBoundsComposition()
				{
					return boundsComposition;
				}

				PassRefPtr<Composition> Win8WindowStyle::GetContainerComposition()
				{
					return boundsComposition;
				}

				void Win8WindowStyle::SetFocusableComposition(PassRefPtr<Composition> value)
				{

				}

				void Win8WindowStyle::SetText(const CString& value)
				{

				}

				void Win8WindowStyle::SetFont(const Font& value)
				{

				}

				void Win8WindowStyle::SetVisuallyEnabled(bool value)
				{

				}

				CColor Win8WindowStyle::GetSystemWindowColor()
				{
					return Gdiplus::Color::WhiteSmoke;
				}

				CColor Win8WindowStyle::GetSystemTextColor(bool enabled)
				{
					return enabled ? CColor() : CColor(131, 131, 131);
				}

				CColor Win8WindowStyle::GetSystemBorderColor()
				{
					return CColor(171, 173, 179);
				}

				ColorEntry Win8WindowStyle::GetTextColor()
				{
					ColorEntry entry;
					entry.normal.text = Win8WindowStyle::GetSystemTextColor(true);
					entry.normal.background = CColor(0, 0, 0, 0);
					entry.selectedFocused.text = Win8WindowStyle::GetSystemTextColor(true);
					entry.selectedFocused.background = CColor(173, 214, 255);
					entry.selectedUnfocused.text = Win8WindowStyle::GetSystemTextColor(true);
					entry.selectedUnfocused.background = CColor(229, 235, 241);
					return entry;
				}

				EmptyStyleController::EmptyStyleController()
				{
					boundsComposition = adoptRef(new BoundsComposition);
				}

				EmptyStyleController::~EmptyStyleController()
				{

				}

				PassRefPtr<BoundsComposition> EmptyStyleController::GetBoundsComposition()
				{
					return boundsComposition;
				}

				PassRefPtr<Composition> EmptyStyleController::GetContainerComposition()
				{
					return boundsComposition;
				}

				void EmptyStyleController::SetFocusableComposition(PassRefPtr<Composition> value)
				{

				}

				void EmptyStyleController::SetText(const CString& value)
				{

				}

				void EmptyStyleController::SetFont(const Font& value)
				{

				}

				void EmptyStyleController::SetVisuallyEnabled(bool value)
				{

				}
			}
		}
	}
}