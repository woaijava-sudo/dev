#ifndef CC_TEMPLATE
#define CC_TEMPLATE

#include "stdafx.h"
#include "cc_base.h"
#include "WTF\PassRefPtr.h"

namespace cc
{
	namespace base
	{
		template<typename T>
		class NullableObject : Object
		{
		private:
			std::auto_ptr<T> object;

		public:
			NullableObject()
			{
			}

			NullableObject(const T & value)
				: object(new T(value))
			{
			}

			NullableObject(T && value)
				: object(value)
			{
			}

			NullableObject(const NullableObject & nullable)
				: object(nullable.object)
			{
			}

			NullableObject(NullableObject && nullable)
				: object(nullable.object)
			{
			}

			~NullableObject()
			{
			}

			NullableObject & operator=(const T & value)
			{
				object = new T(value);
				return(*this);
			}

			NullableObject & operator=(NullableObject && nullable)
			{
				object = nullable.object;
				return(*this);
			}

			static bool Equals(const NullableObject & a, const NullableObject & b)
			{
				return
					(a.object
					? b.object
					? *a.object == *b.object
					: false
					: b.object
					? false
					: true);
			}

			static cint Compare(const NullableObject & a, const NullableObject & b)
			{
				return
					(a.object
					? b.object
					? (*a.object == *b.object ? 0 : *a.object < *b.object ? -1 : 1)
					: 1
					: b.object
					? -1
					: 0);
			}

			bool operator==(const NullableObject & nullable) const
			{
				return(Equals(*this, nullable));
			}

			bool operator!=(const NullableObject & nullable) const
			{
				return(!Equals(*this, nullable));
			}

			bool operator<(const NullableObject & nullable) const
			{
				return(Compare(*this, nullable) < 0);
			}

			bool operator<=(const NullableObject & nullable) const
			{
				return(Compare(*this, nullable) <= 0);
			}

			bool operator>(const NullableObject & nullable) const
			{
				return(Compare(*this, nullable) > 0);
			}

			bool operator>=(const NullableObject & nullable) const
			{
				return(Compare(*this, nullable) >= 0);
			}

			operator bool() const
			{
				return(object != 0);
			}

			const T & Value() const
			{
				return(*object);
			}
		};

		template <class T>
		class RawPtr
		{
		public:
			RawPtr() : m_ptr(nullptr){}
			RawPtr(T* ptr) : m_ptr(ptr){}
			RawPtr(const PassRefPtr<T>& ptr){ m_ptr = ptr.get(); }
			~RawPtr(){ m_ptr = nullptr; }

			RawPtr& operator=(T* ptr)
			{
				m_ptr = ptr;
				return *this;
			}
			RawPtr& operator=(const PassRefPtr<T>& ptr)
			{
				m_ptr = ptr.get();
				return *this;
			}
			T* operator->() const
			{
				ASSERT(m_ptr);
				return m_ptr;
			}
			T* get() { return m_ptr; }
			T& operator*() const { return *m_ptr; }
			T* operator~() const { return m_ptr; }
			bool operator!() const { return !m_ptr; }
			operator bool() const { return m_ptr != nullptr; }
			bool operator!=(const PassRefPtr<T>& ptr) const { return m_ptr != ptr.get(); }
			bool operator==(const PassRefPtr<T>& ptr) const { return m_ptr == ptr.get(); }
			operator T*() { return m_ptr; }
			template<class X> operator PassRefPtr<X>() { return dynamic_cast<X*>(m_ptr); }
			template<class X> operator X*() { return dynamic_cast<X*>(m_ptr); }

		private:
			T* m_ptr;
		};
	}
}

#endif