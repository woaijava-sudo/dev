#ifndef CS_POOL
#define CS_POOL

#include "stdafx.h"
#include "WTF/RefPtr.h"
#include "WTF/AVLTree.h"
#include "../GUI/cc_base.h"

#define POOL_SIZE 256

using namespace std;
using namespace cc::base;

namespace cc
{
	namespace script
	{
		template<typename _Object>
		class Cs_PoolInit
		{
		public:
			void Init(_Object* Object)
			{
			};
		};

		template<typename _Object, typename _Init = Cs_PoolInit<_Object>, size_t _Size = POOL_SIZE>
		class Cs_FixedPool : public Cs_Object
		{
			static_assert(std::is_pod<_Object>::value, "Object must be POD type");
		public:
			typedef Cs_FixedPool<_Object>	_Pool;
			typedef const _Object*			_Pointer;

			Cs_FixedPool(_Init* initializer = nullptr)
			{
				auto size = __max(_Size, 2);
				Objects.resize(size);
				FreeObj.resize(size);
				for (size_t i = 0; i < size; i++)
				{
					FreeObj[i] = i;
				}
				Initializer = initializer;
			}

			~Cs_FixedPool()
			{

			}

			size_t used_cnt() const
			{
				return Objects.size() - FreeObj.size();
			}

			size_t free_cnt() const
			{
				return FreeObj.size();
			}

			size_t size() const
			{
				return Objects.size();
			}

			auto bits() const -> const bitset<_Size>&
			{
				return Used;
			}

			bool full() const
			{
				return FreeObj.empty();
			}

			const _Object* data() const
			{
				return Objects.data();
			}

			_Object* alloc()
			{
				if (!FreeObj.empty())
				{
					auto Index = FreeObj.back();
					FreeObj.pop_back();
					Used.set(Index);
					return &Objects[Index];
				}
				else
				{
					return nullptr;
				}
			}

			bool free(_Object* Object)
			{
				if (Object < Objects.data())
				{
					return false;
				}
				size_t Index = Object - Objects.data();
				if ((Index >= Objects.size()) || !Used.test(Index))
				{
					return false;
				}
				else
				{
					Used.reset(Index);
					FreeObj.push_back(Index);
					return true;
				}
			}

			bool operator < (const _Pool& Pool)
			{
				return Objects.data() < Pool.Objects.data();
			}
			bool operator > (const _Pool& Pool)
			{
				return Objects.data() > Pool.Objects.data();
			}
			bool operator == (const _Pool& Pool)
			{
				return Objects.data() == Pool.Objects.data();
			}
			bool operator != (const _Pool& Pool)
			{
				return Objects.data() != Pool.Objects.data();
			}
			bool operator <= (const _Pool& Pool)
			{
				return Objects.data() <= Pool.Objects.data();
			}
			bool operator >= (const _Pool& Pool)
			{
				return Objects.data() >= Pool.Objects.data();
			}

			bool operator < (const _Object* Object)
			{
				return Object >= Objects.data() + Objects.size();
			}
			bool operator > (const _Object* Object)
			{
				return Object < Objects.data();
			}
			bool operator == (const _Object* Object)
			{
				return !(*this < Object || *this > Object);
			}
			bool operator <= (const _Object* Object)
			{
				return Object >= Objects.data();
			}
			bool operator >= (const _Object* Object)
			{
				return Object > Objects.data() + Objects.size();
			}
			bool operator != (const _Object* Object)
			{
				return *this < Object || *this > Object;
			}

			template<typename _O, typename _I>
			friend _tstringstream& operator << (_tstringstream& ss, const Cs_FixedPool<_O, _I>& x)
			{
				ss << _T("Size: ") << x.size()
					<< _T("\tFree: ") << x.free_cnt()
					<< _T("\tUsed: ") << x.used_cnt()
					<< _T("\tAddr: ") << (void*)x.data()
					<< _T("\tBits: ") << x.bits()
					<< endl;
				return ss;
			}

		protected:
			vector<_Object>			Objects;
			bitset<_Size>			Used;
			vector<cint>			FreeObj;
			RawPtr<_Init>			Initializer;
		};


		template<typename _Object, typename _Init = Cs_PoolInit<_Object>, size_t _Size = POOL_SIZE>
		class Cs_Pool : public Cs_Object
		{
		protected:
			using _PoolObj = Cs_FixedPool<_Object, _Init, _Size>;
			using _PoolPtr = auto_ptr<_PoolObj>;
			using _PoolList = vector<_PoolPtr>;

			typedef typename _PoolObj::_Pointer		_Key;
			typedef _PoolObj*						_Value;

			template <class _key, class _value>
			struct AVLTreeNode {
				_key key;
				_value value;

				AVLTreeNode* less;
				AVLTreeNode* greater;
				int balanceFactor;
			};

			template <class _key, class _value>
			struct AVLTreeAbstractor {
				typedef AVLTreeNode<_key, _value> tree_node;
				typedef tree_node* handle;
				typedef _key key;
				typedef size_t size;
				size pack_size;

				handle get_less(handle h) { return h->less; }
				void set_less(handle h, handle less) { h->less = less; }
				handle get_greater(handle h) { return h->greater; }
				void set_greater(handle h, handle greater) { h->greater = greater; }

				int get_balance_factor(handle h) { return h->balanceFactor; }
				void set_balance_factor(handle h, int bf) { h->balanceFactor = bf; }

				int compare_key_node(const key& k, handle h) { return *h->value == k ? 0 : *h->value > k ? -1 : 1; }
				int compare_node_node(handle ha, handle hb) { return *ha->value == *hb->value ? 0 : *ha->value < *hb->value ? -1 : 1; }

				static handle null() { return nullptr; }
			};

			typedef WTF::AVLTree<AVLTreeAbstractor<typename _Key, typename _Value>> _PoolTree;

		public:
			Cs_Pool()
			{

			}

			~Cs_Pool()
			{
				_PoolTree::Iterator iterator;
				iterator.start_iter_least(PoolTree);

				vector<_PoolTree::tree_node*> nodes;

				while (*iterator) {
					nodes.push_back(*iterator);
					++iterator;
				}
				PoolTree.purge();

				for (size_t i = 0; i < nodes.size(); ++i)
					delete(nodes[i]);
			}

			_Object* alloc()
			{
				RawPtr<_PoolObj> FreePool;
				for (auto & OwnPool : PoolList)
				{
					auto* CurrentPool = OwnPool.get();
					if (!CurrentPool->full())
					{
						FreePool = CurrentPool;
						break;
					}
				}
				if (!FreePool)
				{
					FreePool = new _PoolObj(&Initializer);
					PoolList.push_back(_PoolPtr(FreePool));
					auto node = new _PoolTree::tree_node;
					node->key = FreePool->data();
					node->value = FreePool;
					PoolTree.insert(node);
				}
				return FreePool->alloc();
			}

			bool free(_Object* Object)
			{
				auto Node = PoolTree.search(Object, _PoolTree::EQUAL);
				if (Node)
				{
					return Node->value->free(Object);
				}
				else
				{
					return false;
				}
			}

			template<typename _O, typename _I>
			friend _tstringstream& operator << (_tstringstream& ss, const Cs_Pool<_O, _I>& x)
			{
				for (auto & pool : x.PoolList)
				{
					ss << *pool;
				}
				return ss;
			}

			_Init* GetInitializer()
			{
				return &Initializer;
			}

		protected:
			_PoolList		PoolList;
			_PoolTree		PoolTree;
			_Init			Initializer;
		};
	}
}

#endif