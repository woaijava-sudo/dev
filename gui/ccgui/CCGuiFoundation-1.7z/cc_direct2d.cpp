#include "stdafx.h"
#include "cc_direct2d.h"
#include "cc_presentation.h"

namespace cc
{
	namespace presentation
	{
		namespace direct2d
		{
			D2D1::ColorF GetD2DColor(CColor color)
			{
				return D2D1::ColorF(color.r / 255.0f, color.g / 255.0f, color.b / 255.0f, color.a / 255.0f);
			}

			D2DControllerListener::D2DControllerListener()
			{
				HRESULT hr;
				ID2D1Factory* d2d1;
				hr = D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, &d2d1);
				if (SUCCEEDED(hr))
					D2D1Factory.Attach(d2d1);
				IDWriteFactory* dwrite;
				hr = DWriteCreateFactory(DWRITE_FACTORY_TYPE_ISOLATED, __uuidof(IDWriteFactory), reinterpret_cast<IUnknown**>(&dwrite));
				if (SUCCEEDED(hr))
					DWriteFactory.Attach(dwrite);
			}

			void D2DControllerListener::WindowCreated(PassRefPtr<IWindow> window)
			{
				RefPtr<IWindow> Window = window;
				RefPtr<D2DWindowListener> listener = adoptRef(new D2DWindowListener(Window, D2D1Factory));
				Window->InstallListener(listener);
				WindowListeners.insert(make_pair(Window, listener));
			}

			void D2DControllerListener::WindowDestroying(PassRefPtr<IWindow> window)
			{
				RefPtr<IWindow> Window = window;
				RefPtr<D2DWindowListener> listener = WindowListeners[Window];
				WindowListeners.erase(Window);
				Window->UninstallListener(listener);
			}			

			D2DWindowListener::D2DWindowListener(PassRefPtr<IWindow> _window, CComPtr<ID2D1Factory> _d2dFactory)
				: window(_window)
				, d2dFactory(_d2dFactory)
			{

			}

			void D2DWindowListener::RebuildCanvas(CSize size)
			{
				if (!d2dRenderTarget)
				{
					ID2D1HwndRenderTarget* renderTarget;
					RefPtr<IForm> form = GetForm(window);
					D2D1_RENDER_TARGET_PROPERTIES tp = D2D1::RenderTargetProperties();
					tp.dpiX = 96;
					tp.dpiY = 96;
					HRESULT hr = d2dFactory->CreateHwndRenderTarget(
						tp,
						D2D1::HwndRenderTargetProperties(
						form->GetWindowHandle(),
						D2D1::SizeU((int)size.cx, (int)size.cy)
						),
						&renderTarget
						);
					if (SUCCEEDED(hr))
					{
						d2dRenderTarget.Attach(renderTarget);
						d2dRenderTarget->SetTextAntialiasMode(D2D1_TEXT_ANTIALIAS_MODE_CLEARTYPE);
					}
				}
				else if (previousSize != size)
				{
					d2dRenderTarget->Resize(D2D1::SizeU((int)size.cx, (int)size.cy));
				}
				previousSize = size;
			}

			void D2DWindowListener::Moved()
			{
				RebuildCanvas(window->GetClientSize());
			}

			void D2DWindowListener::Paint()
			{

			}

			void D2DWindowListener::RecreateRenderTarget()
			{
				if (d2dRenderTarget)
				{
					d2dRenderTarget = nullptr;
				}
			}

			CComPtr<ID2D1RenderTarget> D2DWindowListener::GetDirect2DRenderTarget()
			{
				if (!d2dRenderTarget) Moved();
				return dynamic_cast<ID2D1RenderTarget*>(d2dRenderTarget.p);
			}

			void D2DProvider::RecreateRenderTarget(PassRefPtr<IWindow> window)
			{
				GetStorage()->RecreateDirect2DRenderTarget(window);
			}

			CComPtr<ID2D1RenderTarget> D2DProvider::GetDirect2DRenderTarget(PassRefPtr<IWindow> window)
			{
				return GetStorage()->GetDirect2DRenderTarget(window);
			}

			CComPtr<ID2D1Factory> D2DProvider::GetDirect2DFactory()
			{
				return GetStorage()->GetDirect2DFactory();
			}

			CComPtr<IDWriteFactory> D2DProvider::GetDirectWriteFactory()
			{
				return GetStorage()->GetDirectWriteFactory();
			}

			PassRefPtr<ID2DRenderTarget> D2DProvider::GetBindedRenderTarget(PassRefPtr<IWindow> window)
			{
				return GetForm(window)->GetGraphicsHandler();
			}

			void D2DProvider::SetBindedRenderTarget(PassRefPtr<IWindow> window, PassRefPtr<ID2DRenderTarget> renderTarget)
			{
				GetForm(window)->SetGraphicsHandler(renderTarget);
			}

			CComPtr<IWICImagingFactory> D2DProvider::GetWICImagingFactory()
			{
				return cc::presentation::windows::helper::GetWICImagingFactory();
			}

			CComPtr<IWICBitmap> D2DProvider::GetWICBitmap(PassRefPtr<IImageFrame> frame)
			{
				return cc::presentation::windows::helper::GetWICBitmap(frame);
			}

			D2DImageFrameCache::D2DImageFrameCache(PassRefPtr<ID2DRenderTarget> _renderTarget)
				: renderTarget(_renderTarget)
			{

			}

			D2DImageFrameCache::~D2DImageFrameCache()
			{

			}

			void D2DImageFrameCache::OnAttach(PassRefPtr<IImageFrame> frame)
			{
				cachedFrame = frame;
				ID2D1Bitmap* d2dBitmap;
				HRESULT hr = renderTarget->GetDirect2DRenderTarget()->CreateBitmapFromWicBitmap(
					GetStorage()->GetDirect2DProvider()->GetWICBitmap(frame),
					&d2dBitmap
					);
				if (SUCCEEDED(hr))
				{
					bitmap.Attach(d2dBitmap);
				}
			}

			void D2DImageFrameCache::OnDetach(PassRefPtr<IImageFrame> frame)
			{
				renderTarget->DestroyBitmapCache(cachedFrame);
			}

			PassRefPtr<IImageFrame> D2DImageFrameCache::GetFrame()
			{
				return cachedFrame;
			}

			CComPtr<ID2D1Bitmap> D2DImageFrameCache::GetBitmap(bool enabled)
			{
				if (enabled)
				{
					return bitmap;
				}
				else
				{
					if (!disabledBitmap)
					{
						CComPtr<IWICBitmap> frameBitmap = GetStorage()->GetDirect2DProvider()->GetWICBitmap(cachedFrame);
						ID2D1Bitmap* d2dBitmap;
						HRESULT hr = renderTarget->GetDirect2DRenderTarget()->CreateBitmapFromWicBitmap(
							frameBitmap,
							&d2dBitmap
							);
						if (SUCCEEDED(hr))
						{
							disabledBitmap.Attach(d2dBitmap);

							WICRect rect;
							rect.X = 0;
							rect.Y = 0;
							rect.Width = bitmap->GetPixelSize().width;
							rect.Height = bitmap->GetPixelSize().height;
							BYTE* buffer = new BYTE[rect.Width*rect.Height * 4];
							hr = frameBitmap->CopyPixels(&rect, rect.Width * 4, rect.Width*rect.Height * 4, buffer);
							if (SUCCEEDED(hr))
							{
								cuint count = rect.Width*rect.Height;
								BYTE* read = buffer;
								for (cuint i = 0; i < count; i++)
								{
									BYTE g = (read[0] + read[1] + read[2]) / 6 + read[3] / 2;
									read[0] = g;
									read[1] = g;
									read[2] = g;
									read += 4;
								}
								D2D1_RECT_U d2dRect;
								d2dRect.left = 0;
								d2dRect.top = 0;
								d2dRect.right = rect.Width;
								d2dRect.bottom = rect.Height;
								d2dBitmap->CopyFromMemory(&d2dRect, buffer, rect.Width * 4);
							}
							delete[] buffer;
						}
					}
					return disabledBitmap;
				}
			}

			CComPtr<IDWriteRenderingParams> D2DRenderTarget::CreateRenderingParams(DWRITE_RENDERING_MODE renderingMode, CComPtr<IDWriteRenderingParams> defaultParams, CComPtr<IDWriteFactory> dwriteFactory)
			{
				IDWriteRenderingParams* renderingParams;
				FLOAT gamma = defaultParams->GetGamma();
				FLOAT enhancedContrast = defaultParams->GetEnhancedContrast();
				FLOAT clearTypeLevel = defaultParams->GetClearTypeLevel();
				DWRITE_PIXEL_GEOMETRY pixelGeometry = defaultParams->GetPixelGeometry();
				HRESULT hr = dwriteFactory->CreateCustomRenderingParams(
					gamma,
					enhancedContrast,
					clearTypeLevel,
					pixelGeometry,
					renderingMode,
					&renderingParams);
				if (SUCCEEDED(hr))
				{
					CComPtr<IDWriteRenderingParams> RenderingParams;
					RenderingParams.Attach(renderingParams);
					return RenderingParams;
				}
				else
				{
					return nullptr;
				}
			}

			D2DRenderTarget::D2DRenderTarget(PassRefPtr<IWindow> _window)
				: window(_window.get())
				, clipperCoverWholeTargetCounter(0)
			{
				solidBrushes.SetRenderTarget(this);
				linearBrushes.SetRenderTarget(this);

				CComPtr<IDWriteFactory> dwriteFactory = GetStorage()->GetDirect2DProvider()->GetDirectWriteFactory();
				CComPtr<IDWriteRenderingParams> defaultParams;
				HRESULT hr = dwriteFactory->CreateRenderingParams(&defaultParams);
				if (SUCCEEDED(hr))
				{
					noAntialiasParams = CreateRenderingParams(DWRITE_RENDERING_MODE_CLEARTYPE_GDI_NATURAL, defaultParams, dwriteFactory);
					horizontalAntialiasParams = CreateRenderingParams(DWRITE_RENDERING_MODE_CLEARTYPE_NATURAL, defaultParams, dwriteFactory);
					bidirectionalAntialiasParams = CreateRenderingParams(DWRITE_RENDERING_MODE_CLEARTYPE_NATURAL_SYMMETRIC, defaultParams, dwriteFactory);
				}
			}

			D2DRenderTarget::~D2DRenderTarget()
			{
				for (auto & imageCache : imageCaches)
				{
					imageCache->GetFrame()->RemoveCache(this);
				}
			}

			CComPtr<ID2D1RenderTarget> D2DRenderTarget::GetDirect2DRenderTarget()
			{
				return d2dRenderTarget ?
					dynamic_cast<ID2D1RenderTarget*>(d2dRenderTarget.p) :
					GetStorage()->GetDirect2DProvider()->GetDirect2DRenderTarget(window);
			}

			CComPtr<ID2D1Bitmap> D2DRenderTarget::GetBitmap(PassRefPtr<IImageFrame> frame, bool enabled)
			{
				RefPtr<IImageFrameCache> cache = frame->GetCache(this);
				if (cache)
				{
					return dynamic_cast<D2DImageFrameCache*>(cache.get())->GetBitmap(enabled);
				}
				else
				{
					RefPtr<D2DImageFrameCache> d2dCache = adoptRef(new D2DImageFrameCache(this));
					if (frame->SetCache(this, d2dCache))
					{
						imageCaches.insert(d2dCache);
						return d2dCache->GetBitmap(enabled);
					}
					else
					{
						return nullptr;
					}
				}
			}

			void D2DRenderTarget::DestroyBitmapCache(PassRefPtr<IImageFrame> frame)
			{
				imageCaches.erase(frame->GetCache(this));
			}

			void D2DRenderTarget::SetTextAntialias(bool antialias, bool verticalAntialias)
			{
				CComPtr<IDWriteRenderingParams> params;
				if (!antialias)
				{
					params = noAntialiasParams;
				}
				else if (!verticalAntialias)
				{
					params = horizontalAntialiasParams;
				}
				else
				{
					params = bidirectionalAntialiasParams;
				}
				if (params.p != NULL && d2dRenderTarget.p != NULL)
				{
					d2dRenderTarget->SetTextRenderingParams(params);
				}
			}

			void D2DRenderTarget::StartRendering()
			{
				d2dRenderTarget = GetStorage()->GetDirect2DProvider()->GetDirect2DRenderTarget(window);
				d2dRenderTarget->BeginDraw();
				d2dRenderTarget->Clear(GetD2DColor(Win8WindowStyle::GetSystemWindowColor()));
			}

			bool D2DRenderTarget::StopRendering()
			{
				HRESULT result = d2dRenderTarget->EndDraw();
				d2dRenderTarget = nullptr;
				return SUCCEEDED(result);
			}

			void D2DRenderTarget::PushClipper(CRect clipper)
			{
				if (clipperCoverWholeTargetCounter > 0)
				{
					clipperCoverWholeTargetCounter++;
				}
				else
				{
					CRect previousClipper = GetClipper();
					CRect currentClipper;

					if (currentClipper.IntersectRect(&previousClipper, &clipper))
					{
						clippers.push_back(currentClipper);
						d2dRenderTarget->PushAxisAlignedClip(
							D2D1::RectF((FLOAT)currentClipper.left, (FLOAT)currentClipper.top, (FLOAT)currentClipper.right, (FLOAT)currentClipper.bottom),
							D2D1_ANTIALIAS_MODE_PER_PRIMITIVE
							);
					}
					else
					{
						clipperCoverWholeTargetCounter++;
					}
				}
			}

			void D2DRenderTarget::PopClipper()
			{
				if (clipperCoverWholeTargetCounter > 0)
				{
					clipperCoverWholeTargetCounter--;
				}
				else if (!clippers.empty())
				{
					clippers.pop_back();
					d2dRenderTarget->PopAxisAlignedClip();
				}
			}

			CRect D2DRenderTarget::GetClipper()
			{
				if (clippers.empty())
				{
					return CRect(CPoint(), window->GetClientSize());
				}
				else
				{
					return *clippers.rbegin();
				}
			}

			bool D2DRenderTarget::IsClipperCoverWholeTarget()
			{
				return clipperCoverWholeTargetCounter > 0;
			}

			CComPtr<ID2D1SolidColorBrush> D2DRenderTarget::CreateDirect2DBrush(CColor color)
			{
				return solidBrushes.Create(color);
			}

			void D2DRenderTarget::DestroyDirect2DBrush(CColor color)
			{
				solidBrushes.Destroy(color);
			}

			CComPtr<ID2D1LinearGradientBrush> D2DRenderTarget::CreateDirect2DLinearBrush(CColor c1, CColor c2)
			{
				return linearBrushes.Create(pair<CColor, CColor>(c1, c2));
			}

			void D2DRenderTarget::DestroyDirect2DLinearBrush(CColor c1, CColor c2)
			{
				linearBrushes.Destroy(pair<CColor, CColor>(c1, c2));
			}

			PassRefPtr<IGraphicsParagraph> D2DLayoutProvider::CreateParagraph(const CString& text, PassRefPtr<IGraphicsRenderTarget> renderTarget)
			{
				return new D2DParagraph(this, text, renderTarget);
			}

			D2DElementInlineObject::D2DElementInlineObject(const IGraphicsParagraph::InlineObjectProperties& _properties, IGraphicsElement* _element, PassRefPtr<IRendererCallback> _rendererCallback, cint _start, cint _length) : counter(1)
				, properties(_properties)
				, element(_element)
				, rendererCallback(_rendererCallback)
				, start(_start)
				, length(_length)
			{

			}

			D2DElementInlineObject::~D2DElementInlineObject()
			{
				RefPtr<IGraphicsRenderer> graphicsRenderer = element->GetRenderer();
				if (graphicsRenderer)
				{
					graphicsRenderer->SetRenderTarget(nullptr);
				}
			}

			cint D2DElementInlineObject::GetStart()
			{
				return start;
			}

			cint D2DElementInlineObject::GetLength()
			{
				return length;
			}

			IGraphicsElement* D2DElementInlineObject::GetElement()
			{
				return element;
			}

			HRESULT STDMETHODCALLTYPE D2DElementInlineObject::QueryInterface(
				REFIID riid,
				void __RPC_FAR *__RPC_FAR *ppvObject
				)
			{
				if (ppvObject)
				{
					*ppvObject = NULL;
				}
				return E_NOINTERFACE;
			}

			ULONG STDMETHODCALLTYPE D2DElementInlineObject::AddRef(void)
			{
				++counter;
				return S_OK;
			}

			ULONG STDMETHODCALLTYPE D2DElementInlineObject::Release(void)
			{
				if (--counter == 0)
				{
					delete this;
				}
				return S_OK;
			}

			HRESULT D2DElementInlineObject::Draw(
				void* clientDrawingContext,
				IDWriteTextRenderer* renderer,
				FLOAT originX,
				FLOAT originY,
				BOOL isSideways,
				BOOL isRightToLeft,
				IUnknown* clientDrawingEffect
				)
			{
				RefPtr<IGraphicsRenderer> graphicsRenderer = element->GetRenderer();
				if (graphicsRenderer)
				{
					CRect bounds(CPoint((cint)originX, (cint)originY), properties.size);
					graphicsRenderer->Render(bounds);

					CColor color = rendererCallback->GetBackgroundColor(start);
					if (color.a != 0)
					{
						color.a /= 2;
						if (RefPtr<ID2DRenderTarget> renderTarget = rendererCallback->GetDirect2DRenderTarget())
						{
							CComPtr<ID2D1SolidColorBrush> brush = renderTarget->CreateDirect2DBrush(color);

							renderTarget->GetDirect2DRenderTarget()->FillRectangle(
								D2D1::RectF(bounds.left - 0.5f, bounds.top - 0.5f, bounds.right + 0.5f, bounds.bottom + 0.5f),
								brush
								);

							renderTarget->DestroyDirect2DBrush(color);
						}
					}
				}
				return S_OK;
			}

			HRESULT D2DElementInlineObject::GetMetrics(
				DWRITE_INLINE_OBJECT_METRICS* metrics
				)
			{
				metrics->width = (FLOAT)properties.size.cx;
				metrics->height = (FLOAT)properties.size.cy;
				metrics->baseline = (FLOAT)(properties.baseline == -1 ? properties.size.cy : properties.baseline);
				metrics->supportsSideways = TRUE;
				return S_OK;
			}

			HRESULT D2DElementInlineObject::GetOverhangMetrics(
				DWRITE_OVERHANG_METRICS* overhangs
				)
			{
				overhangs->left = 0;
				overhangs->right = 0;
				overhangs->top = 0;
				overhangs->bottom = 0;
				return S_OK;
			}

			HRESULT D2DElementInlineObject::GetBreakConditions(
				DWRITE_BREAK_CONDITION* breakConditionBefore,
				DWRITE_BREAK_CONDITION* breakConditionAfter
				)
			{
				switch (properties.breakCondition)
				{
					case IGraphicsParagraph::StickToPreviousRun:
						*breakConditionBefore = DWRITE_BREAK_CONDITION_MAY_NOT_BREAK;
						*breakConditionAfter = DWRITE_BREAK_CONDITION_CAN_BREAK;
						break;
					case IGraphicsParagraph::StickToNextRun:
						*breakConditionBefore = DWRITE_BREAK_CONDITION_CAN_BREAK;
						*breakConditionAfter = DWRITE_BREAK_CONDITION_MAY_NOT_BREAK;
						break;
					default:
						*breakConditionBefore = DWRITE_BREAK_CONDITION_CAN_BREAK;
						*breakConditionAfter = DWRITE_BREAK_CONDITION_CAN_BREAK;
				}
				return S_OK;
			}

			D2DParagraph::D2DParagraph(PassRefPtr<IGraphicsLayoutProvider> _provider, const CString& _text, PassRefPtr<IGraphicsRenderTarget> _renderTarget) : provider(_provider)
				, dwriteFactory(GetStorage()->GetDirect2DProvider()->GetDirectWriteFactory())
				, renderTarget(_renderTarget)
				, paragraphText(_text)
				, wrapLine(true)
				, maxWidth(-1)
				, caret(-1)
				, caretFrontSide(false)
				, formatDataAvailable(false)
			{
				Font defaultFont = GetStorage()->GetController()->GetResourceService()->GetDefaultFont();
				RefPtr<D2DTextFormatPackage> package = GetStorage()->GetDirect2DResourceManager()->CreateDirect2DTextFormat(defaultFont);
				defaultTextColor = renderTarget->CreateDirect2DBrush(CColor());
				usedColors.push_back(CColor());

				IDWriteTextLayout* rawTextLayout;
				BSTR __text = _text.AllocSysString();
				HRESULT hr = dwriteFactory->CreateTextLayout(
					__text,
					_text.GetLength(),
					package->textFormat,
					0,
					0,
					&rawTextLayout);
				SysFreeString(__text);
				if (SUCCEEDED(hr))
				{
					textLayout.Attach(rawTextLayout);
					textLayout->SetWordWrapping(DWRITE_WORD_WRAPPING_WRAP);
				}
				graphicsElements.insert(make_pair(TextRange(0, _text.GetLength()), RefPtr<IGraphicsElement>(nullptr)));
				backgroundColors.insert(make_pair(TextRange(0, _text.GetLength()), CColor(0, 0, 0, 0)));

				GetStorage()->GetDirect2DResourceManager()->DestroyDirect2DTextFormat(defaultFont);
			}

			D2DParagraph::~D2DParagraph()
			{
				CloseCaret();
				for (auto & color : usedColors)
				{
					renderTarget->DestroyDirect2DBrush(color);
				}
			}

			PassRefPtr<IGraphicsLayoutProvider> D2DParagraph::GetProvider()
			{
				return provider;
			}

			PassRefPtr<IGraphicsRenderTarget> D2DParagraph::GetRenderTarget()
			{
				return renderTarget;
			}

			bool D2DParagraph::GetWrapLine()
			{
				return wrapLine;
			}

			void D2DParagraph::SetWrapLine(bool value)
			{
				if (wrapLine != value)
				{
					wrapLine = value;
					textLayout->SetWordWrapping(value ? DWRITE_WORD_WRAPPING_WRAP : DWRITE_WORD_WRAPPING_NO_WRAP);
					formatDataAvailable = false;
				}
			}

			cint D2DParagraph::GetMaxWidth()
			{
				return maxWidth;
			}

			void D2DParagraph::SetMaxWidth(cint value)
			{
				if (maxWidth != value)
				{
					maxWidth = value;
					textLayout->SetMaxWidth(value == -1 ? 65536 : (FLOAT)value);
					formatDataAvailable = false;
				}
			}

			IGraphicsParagraph::Alignment D2DParagraph::GetParagraphAlignment()
			{
				switch (textLayout->GetTextAlignment())
				{
					case DWRITE_TEXT_ALIGNMENT_LEADING:
						return Alignment::Left;
					case DWRITE_TEXT_ALIGNMENT_CENTER:
						return Alignment::Center;
					case DWRITE_TEXT_ALIGNMENT_TRAILING:
						return Alignment::Right;
					default:
						return Alignment::Left;
				}
			}

			void D2DParagraph::SetParagraphAlignment(Alignment value)
			{
				formatDataAvailable = false;
				switch (value)
				{
					case Alignment::Left:
						textLayout->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_LEADING);
						break;
					case Alignment::Center:
						textLayout->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
						break;
					case Alignment::Right:
						textLayout->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_TRAILING);
						break;
				}
			}

			bool D2DParagraph::SetFont(cint start, cint length, const CString& value)
			{
				if (length == 0) return true;
				formatDataAvailable = false;

				DWRITE_TEXT_RANGE range;
				range.startPosition = (int)start;
				range.length = (int)length;
				BSTR _value = value.AllocSysString();
				HRESULT hr = textLayout->SetFontFamilyName(_value, range);
				SysFreeString(_value);
				return SUCCEEDED(hr);
			}

			bool D2DParagraph::SetSize(cint start, cint length, cint value)
			{
				if (length == 0) return true;
				formatDataAvailable = false;

				DWRITE_TEXT_RANGE range;
				range.startPosition = (int)start;
				range.length = (int)length;
				HRESULT hr = textLayout->SetFontSize((FLOAT)value, range);
				return SUCCEEDED(hr);
			}

			bool D2DParagraph::SetStyle(cint start, cint length, TextStyle value)
			{
				if (length == 0) return true;
				formatDataAvailable = false;

				DWRITE_TEXT_RANGE range;
				range.startPosition = (int)start;
				range.length = (int)length;
				HRESULT hr = S_OK;

				hr = textLayout->SetFontStyle(value&Italic ? DWRITE_FONT_STYLE_ITALIC : DWRITE_FONT_STYLE_NORMAL, range);
				if (FAILED(hr)) return false;
				hr = textLayout->SetFontWeight(value&Bold ? DWRITE_FONT_WEIGHT_BOLD : DWRITE_FONT_WEIGHT_NORMAL, range);
				if (FAILED(hr)) return false;
				hr = textLayout->SetUnderline(value&Underline ? TRUE : FALSE, range);
				if (FAILED(hr)) return false;
				hr = textLayout->SetStrikethrough(value&Strikeline ? TRUE : FALSE, range);
				if (FAILED(hr)) return false;

				return true;
			}

			bool D2DParagraph::SetColor(cint start, cint length, CColor value)
			{
				if (length == 0) return true;
				formatDataAvailable = false;

				CComPtr<ID2D1SolidColorBrush> brush = renderTarget->CreateDirect2DBrush(value);
				usedColors.push_back(value);

				DWRITE_TEXT_RANGE range;
				range.startPosition = (int)start;
				range.length = (int)length;
				HRESULT hr = textLayout->SetDrawingEffect(brush, range);
				return SUCCEEDED(hr);
			}

			bool D2DParagraph::SetBackgroundColor(cint start, cint length, CColor value)
			{
				SetMap(backgroundColors, start, length, value);
				return true;
			}

			bool D2DParagraph::SetInlineObject(cint start, cint length, const InlineObjectProperties& properties, PassRefPtr<IGraphicsElement> value)
			{
				if (inlineElements.find(value) == inlineElements.end())
					return false;

				for (auto & inlineElement : inlineElements)
				{
					CComPtr<D2DElementInlineObject> & inlineObject = inlineElement.second;
					if (start < inlineObject->GetStart() + inlineObject->GetLength() && inlineObject->GetStart() < start + length)
					{
						return false;
					}
				}
				formatDataAvailable = false;

				CComPtr<D2DElementInlineObject> inlineObject;
				inlineObject.Attach(new D2DElementInlineObject(properties, value.get(), this, start, length));
				DWRITE_TEXT_RANGE range;
				range.startPosition = (int)start;
				range.length = (int)length;
				HRESULT hr = textLayout->SetInlineObject(inlineObject, range);
				if (SUCCEEDED(hr))
				{
					RefPtr<IGraphicsRenderer> renderer = value->GetRenderer();
					if (renderer)
					{
						renderer->SetRenderTarget(renderTarget);
					}
					inlineElements.insert(make_pair(value, inlineObject));
					SetMap(graphicsElements, start, length, value);
					return true;
				}
				else
				{
					return false;
				}
			}

			bool D2DParagraph::ResetInlineObject(cint start, cint length)
			{
				RefPtr<IGraphicsElement> element;
				if (GetMap(graphicsElements, start, element) && element)
				{
					CComPtr<D2DElementInlineObject>& inlineObject = inlineElements[element];
					DWRITE_TEXT_RANGE range;
					range.startPosition = (int)inlineObject->GetStart();
					range.length = (int)inlineObject->GetLength();
					HRESULT hr = textLayout->SetInlineObject(NULL, range);
					if (SUCCEEDED(hr))
					{
						formatDataAvailable = false;
						inlineElements.erase(element);
						SetMap(graphicsElements, range.startPosition, range.length, nullptr);
						return true;
					}
					else
					{
						return false;
					}
				}
				return false;
			}

			cint D2DParagraph::GetHeight()
			{
				DWRITE_TEXT_METRICS metrics;
				textLayout->GetMetrics(&metrics);
				return (cint)metrics.height;
			}

			CColor D2DParagraph::GetBackgroundColor(cint textPosition)
			{
				CColor color;
				if (GetMap(backgroundColors, textPosition, color))
				{
					return color;
				}
				else
				{
					return CColor(0, 0, 0, 0);
				}
			}

			PassRefPtr<ID2DRenderTarget> D2DParagraph::GetDirect2DRenderTarget()
			{
				return renderTarget;
			}

			bool D2DParagraph::OpenCaret(cint _caret, CColor _color, bool _frontSide)
			{
				if (!IsValidCaret(_caret)) return false;
				if (caret != -1) CloseCaret();
				caret = _caret;
				caretColor = _color;
				caretFrontSide = _frontSide;
				caretBrush = renderTarget->CreateDirect2DBrush(caretColor);
				return true;
			}

			bool D2DParagraph::CloseCaret()
			{
				if (caret == -1) return false;
				caret = -1;
				renderTarget->DestroyDirect2DBrush(caretColor);
				caretBrush = nullptr;
				return true;
			}

			void D2DParagraph::Render(CRect bounds)
			{
				PrepareFormatData();
				for (auto & backgroundColor : backgroundColors)
				{
					const TextRange & key = backgroundColor.first;
					const CColor & color = backgroundColor.second;
					if (color.a > 0)
					{
						CComPtr<ID2D1SolidColorBrush> brush = renderTarget->CreateDirect2DBrush(color);

						cuint start = key.start;
						if (start < 0)
						{
							start = 0;
						}

						while (start < charHitTestMap.size() && start < key.end)
						{
							cuint index = charHitTestMap[start];
							DWRITE_HIT_TEST_METRICS& hitTest = hitTestMetrics[index];

							FLOAT x1 = hitTest.left + (FLOAT)bounds.left;
							FLOAT y1 = hitTest.top + (FLOAT)bounds.top;
							FLOAT x2 = x1 + hitTest.width;
							FLOAT y2 = y1 + hitTest.height;

							x1 -= 0.5f;
							y1 -= 0.0f;
							x2 += 0.5f;
							y2 += 0.5f;

							renderTarget->GetDirect2DRenderTarget()->FillRectangle(
								D2D1::RectF(x1, y1, x2, y2),
								brush
								);

							start = hitTest.textPosition + hitTest.length;
						}

						renderTarget->DestroyDirect2DBrush(color);
					}
				}

				renderTarget->GetDirect2DRenderTarget()->DrawTextLayout(
					D2D1::Point2F((FLOAT)bounds.left, (FLOAT)bounds.top),
					textLayout,
					defaultTextColor,
					D2D1_DRAW_TEXT_OPTIONS_NO_SNAP);

				if (caret != -1)
				{
					CRect caretBounds = GetCaretBounds(caret, caretFrontSide);
					cint x = caretBounds.left + bounds.left;
					cint y1 = caretBounds.top + bounds.top;
					cint y2 = y1 + caretBounds.Height();

					renderTarget->GetDirect2DRenderTarget()->DrawLine(
						D2D1::Point2F((FLOAT)x - 0.5f, (FLOAT)y1 + 0.5f),
						D2D1::Point2F((FLOAT)x - 0.5f, (FLOAT)y2 + 0.5f),
						caretBrush
						);
					renderTarget->GetDirect2DRenderTarget()->DrawLine(
						D2D1::Point2F((FLOAT)x + 0.5f, (FLOAT)y1 + 0.5f),
						D2D1::Point2F((FLOAT)x + 0.5f, (FLOAT)y2 + 0.5f),
						caretBrush
						);
				}
			}

			void D2DParagraph::GetLineIndexFromTextPos(cint textPos, cint& frontLineIndex, cint& backLineIndex)
			{
				frontLineIndex = -1;
				backLineIndex = -1;
				cint start = 0;
				cint end = lineMetrics.size() - 1;
				while (start <= end)
				{
					cint middle = (start + end) / 2;
					DWRITE_LINE_METRICS& metrics = lineMetrics[middle];
					cint lineStart = lineStarts[middle];
					cint lineEnd = lineStart + metrics.length - metrics.newlineLength;

					if (textPos<lineStart)
					{
						end = middle - 1;
					}
					else if (textPos>lineEnd)
					{
						start = middle + 1;
					}
					else if (textPos == lineStart && middle != 0)
					{
						DWRITE_LINE_METRICS& anotherLine = lineMetrics[middle - 1];
						frontLineIndex = anotherLine.newlineLength == 0 ? middle - 1 : middle;
						backLineIndex = middle;
						return;
					}
					else if (textPos == lineEnd && middle != lineMetrics.size() - 1)
					{
						frontLineIndex = middle;
						backLineIndex = metrics.newlineLength == 0 ? middle + 1 : middle;
						return;
					}
					else
					{
						frontLineIndex = middle;
						backLineIndex = middle;
						return;
					}
				}
			}

			pair<FLOAT, FLOAT> D2DParagraph::GetLineYRange(cint lineIndex)
			{
				DWRITE_LINE_METRICS& line = lineMetrics[lineIndex];
				FLOAT top = lineTops[lineIndex];
				return pair<FLOAT, FLOAT>(top, top + line.height);
			}

			cint D2DParagraph::GetLineIndexFromY(cint y)
			{
				if (paragraphText.GetLength() == 0) return 0;
				FLOAT minY = 0;
				FLOAT maxY = 0;
				{
					minY = hitTestMetrics[0].top;
					DWRITE_HIT_TEST_METRICS& hitTest = hitTestMetrics[hitTestMetrics.size() - 1];
					maxY = hitTest.top + hitTest.height;
				}

				if (y < minY)
				{
					return 0;
				}
				else if (y >= maxY)
				{
					return lineMetrics.size() - 1;
				}

				cint start = 0;
				cint end = lineMetrics.size() - 1;
				while (start <= end)
				{
					cint middle = (start + end) / 2;
					pair<FLOAT, FLOAT> yRange = GetLineYRange(middle);
					minY = yRange.first;
					maxY = yRange.second;

					if (y < minY)
					{
						end = middle - 1;
					}
					else if (y >= maxY)
					{
						start = middle + 1;
					}
					else
					{
						return middle;
					}
				}
				return -1;
			}

			cint D2DParagraph::GetCaretFromXWithLine(cint x, cint lineIndex)
			{
				DWRITE_LINE_METRICS& line = lineMetrics[lineIndex];
				cint lineStart = lineStarts[lineIndex];
				cint lineEnd = lineStart + line.length - line.newlineLength;

				FLOAT minLineX = 0;
				FLOAT maxLineX = 0;

				for (cint i = lineStart; i<lineEnd;)
				{
					cint index = charHitTestMap[i];
					DWRITE_HIT_TEST_METRICS& hitTest = hitTestMetrics[index];
					FLOAT minX = hitTest.left;
					FLOAT maxX = minX + hitTest.width;

					if (minLineX>minX) minLineX = minX;
					if (maxLineX < maxX) maxLineX = maxX;

					if (minX <= x && x < maxX)
					{
						DWRITE_CLUSTER_METRICS& cluster = clusterMetrics[index];
						FLOAT d1 = x - minX;
						FLOAT d2 = maxX - x;
						if (d1 <= d2)
						{
							return cluster.isRightToLeft ? i + hitTest.length : i;
						}
						else
						{
							return cluster.isRightToLeft ? i : i + hitTest.length;
						}
					}
					i += hitTest.length;
				}

				if (x < minLineX) return lineStart;
				if (x >= maxLineX) return lineEnd;
				return lineStart;
			}

			cint D2DParagraph::GetCaret(cint comparingCaret, CaretRelativePosition position, bool& preferFrontSide)
			{
				PrepareFormatData();
				if (position == CaretFirst) return 0;
				if (position == CaretLast) return paragraphText.GetLength();
				if (!IsValidCaret(comparingCaret)) return -1;

				cint frontLineIndex = -1;
				cint backLineIndex = -1;
				GetLineIndexFromTextPos(comparingCaret, frontLineIndex, backLineIndex);
				cint lineIndex = preferFrontSide ? frontLineIndex : backLineIndex;
				DWRITE_LINE_METRICS& line = lineMetrics[lineIndex];
				cint lineStart = lineStarts[lineIndex];
				cint lineEnd = lineStart + line.length - line.newlineLength;

				switch (position)
				{
					case CaretLineFirst:
						return lineStarts[lineIndex];
					case CaretLineLast:
						return lineStarts[lineIndex] + line.length - line.newlineLength;
					case CaretMoveLeft:
					{
						if (comparingCaret == 0)
						{
							return 0;
						}
						else if (comparingCaret == lineStart)
						{
							cint offset = lineMetrics[lineIndex - 1].newlineLength;
							if (offset > 0)
							{
								return lineStart - offset;
							}
						}
						return hitTestMetrics[charHitTestMap[comparingCaret - 1]].textPosition;
					}
					case CaretMoveRight:
					{
						if (comparingCaret == paragraphText.GetLength())
						{
							return paragraphText.GetLength();
						}
						else if (comparingCaret == lineEnd && line.newlineLength != 0)
						{
							return lineEnd + line.newlineLength;
						}
						else
						{
							cint index = charHitTestMap[comparingCaret];
							if (index == hitTestMetrics.size() - 1) return paragraphText.GetLength();
							return hitTestMetrics[index + 1].textPosition;
						}
					}
					case CaretMoveUp:
					{
						if (lineIndex == 0)
						{
							return comparingCaret;
						}
						else
						{
							CRect bounds = GetCaretBounds(comparingCaret, preferFrontSide);
							preferFrontSide = true;
							return GetCaretFromXWithLine(bounds.left, lineIndex - 1);
						}
					}
					case CaretMoveDown:
					{
						if (lineIndex == lineMetrics.size() - 1)
						{
							return comparingCaret;
						}
						else
						{
							CRect bounds = GetCaretBounds(comparingCaret, preferFrontSide);
							preferFrontSide = false;
							return GetCaretFromXWithLine(bounds.left, lineIndex + 1);
						}
					}
				}
				return -1;
			}

			CRect D2DParagraph::GetCaretBounds(cint caret, bool frontSide)
			{
				PrepareFormatData();
				if (!IsValidCaret(caret)) return CRect();
				if (paragraphText.GetLength() == 0) return CRect(CPoint(), CSize(0, GetHeight()));

				cint frontLineIndex = -1;
				cint backLineIndex = -1;
				GetLineIndexFromTextPos(caret, frontLineIndex, backLineIndex);
				cint lineIndex = frontSide ? frontLineIndex : backLineIndex;

				pair<FLOAT, FLOAT> lineYRange = GetLineYRange(lineIndex);
				DWRITE_LINE_METRICS& line = lineMetrics[lineIndex];
				if (line.length - line.newlineLength == 0)
				{
					return CRect(0, (cint)lineYRange.first, 0, (cint)lineYRange.second);
				}
				else
				{
					cint lineStart = lineStarts[lineIndex];
					cint lineEnd = lineStart + line.length - line.newlineLength;
					if (caret == lineStart)
					{
						frontSide = false;
					}
					else if (caret == lineEnd)
					{
						frontSide = true;
					}
					if (frontSide)
					{
						caret--;
					}

					cint index = charHitTestMap[caret];
					DWRITE_HIT_TEST_METRICS& hitTest = hitTestMetrics[index];
					DWRITE_CLUSTER_METRICS& cluster = clusterMetrics[index];
					if (cluster.isRightToLeft)
					{
						frontSide = !frontSide;
					}

					if (frontSide)
					{
						return CRect(
							CPoint((cint)(hitTest.left + hitTest.width), (cint)hitTest.top),
							CSize(0, (cint)hitTest.height)
							);
					}
					else
					{
						return CRect(
							CPoint((cint)hitTest.left, (cint)hitTest.top),
							CSize(0, (cint)hitTest.height)
							);
					}
				}
			}

			cint D2DParagraph::GetCaretFromPoint(CPoint point)
			{
				PrepareFormatData();
				cint lineIndex = GetLineIndexFromY(point.y);
				cint caret = GetCaretFromXWithLine(point.x, lineIndex);
				return caret;
			}

			PassRefPtr<IGraphicsElement> D2DParagraph::GetInlineObjectFromPoint(CPoint point, cint& start, cint& length)
			{
				DWRITE_HIT_TEST_METRICS metrics = { 0 };
				BOOL trailingHit = FALSE;
				BOOL inside = FALSE;
				start = -1;
				length = 0;
				HRESULT hr = textLayout->HitTestPoint((FLOAT)point.x, (FLOAT)point.y, &trailingHit, &inside, &metrics);
				if (hr == S_OK)
				{
					RefPtr<IGraphicsElement> element;
					if (GetMap(graphicsElements, metrics.textPosition, element) && element)
					{
						CComPtr<D2DElementInlineObject>& inlineObject = inlineElements[element];
						start = inlineObject->GetStart();
						length = inlineObject->GetLength();
						return inlineObject->GetElement();
					}
				}
				return 0;
			}

			cint D2DParagraph::GetNearestCaretFromTextPos(cint textPos, bool frontSide)
			{
				PrepareFormatData();
				if (!IsValidTextPos(textPos)) return -1;
				if (textPos == 0 || textPos == paragraphText.GetLength()) return textPos;

				cint index = charHitTestMap[textPos];
				DWRITE_HIT_TEST_METRICS& hitTest = hitTestMetrics[index];
				if (hitTest.textPosition == textPos)
				{
					return textPos;
				}
				else if (frontSide)
				{
					return hitTest.textPosition;
				}
				else
				{
					return hitTest.textPosition + hitTest.length;
				}
			}

			bool D2DParagraph::IsValidCaret(cint caret)
			{
				PrepareFormatData();
				if (!IsValidTextPos(caret)) return false;
				if (caret == 0 || caret == paragraphText.GetLength()) return true;
				if (hitTestMetrics[charHitTestMap[caret]].textPosition == caret) return true;

				cint frontLineIndex = -1;
				cint backLineIndex = -1;
				GetLineIndexFromTextPos(caret, frontLineIndex, backLineIndex);
				if (frontLineIndex == -1 && backLineIndex == -1) return false;
				return false;
			}

			bool D2DParagraph::IsValidTextPos(cint textPos)
			{
				return 0 <= textPos && textPos <= paragraphText.GetLength();
			}

			void D2DParagraph::PrepareFormatData()
			{
				if (!formatDataAvailable)
				{
					formatDataAvailable = true;
					{
						UINT32 lineCount = 0;
						textLayout->GetLineMetrics(NULL, 0, &lineCount);
						lineMetrics.resize(lineCount);
						if (lineCount > 0)
						{
							textLayout->GetLineMetrics(&lineMetrics[0], lineCount, &lineCount);
						}

						lineStarts.resize(lineCount);
						lineTops.resize(lineCount);
						cint start = 0;
						FLOAT top = 0;
						for (cuint i = 0; i < lineMetrics.size(); i++)
						{
							DWRITE_LINE_METRICS& metrics = lineMetrics[i];

							lineStarts[i] = start;
							start += metrics.length;

							lineTops[i] = top;
							top += metrics.height;
						}
					}
					{
						UINT32 clusterCount = 0;
						textLayout->GetClusterMetrics(NULL, 0, &clusterCount);
						clusterMetrics.resize(clusterCount);
						if (clusterCount > 0)
						{
							textLayout->GetClusterMetrics(&clusterMetrics[0], clusterCount, &clusterCount);
						}
					}
					{
						cint textPos = 0;
						hitTestMetrics.resize(clusterMetrics.size());
						for (cuint i = 0; i < hitTestMetrics.size(); i++)
						{
							FLOAT x = 0;
							FLOAT y = 0;
							DWRITE_HIT_TEST_METRICS& metrics = hitTestMetrics[i];
							textLayout->HitTestTextPosition((UINT32)textPos, FALSE, &x, &y, &metrics);
							textPos += metrics.length;
						}
					}
					{
						charHitTestMap.resize(paragraphText.GetLength());
						for (cuint i = 0; i < hitTestMetrics.size(); i++)
						{
							DWRITE_HIT_TEST_METRICS& metrics = hitTestMetrics[i];
							for (UINT32 j = 0; j < metrics.length; j++)
							{
								charHitTestMap[metrics.textPosition + j] = i;
							}
						}
					}
				}
			}
		}
	}
}