#include "stdafx.h"
#include "cc_control.h"
#include "cc_presentation.h"
#include "cc_composition.h"

using namespace cc::presentation::windows;

namespace cc
{
	namespace presentation
	{
		namespace control
		{
			namespace event_args
			{
				EventReceiver::EventReceiver(PassRefPtr<Composition> _sender)
					: sender(_sender.get())
					, leftButtonDown(_sender.get())
					, leftButtonUp(_sender.get())
					, leftButtonDoubleClick(_sender.get())
					, middleButtonDown(_sender.get())
					, middleButtonUp(_sender.get())
					, middleButtonDoubleClick(_sender.get())
					, rightButtonDown(_sender.get())
					, rightButtonUp(_sender.get())
					, rightButtonDoubleClick(_sender.get())
					, horizontalWheel(_sender.get())
					, verticalWheel(_sender.get())
					, mouseMove(_sender.get())
					, mouseEnter(_sender.get())
					, mouseLeave(_sender.get())
					, previewKey(_sender.get())
					, keyDown(_sender.get())
					, keyUp(_sender.get())
					, systemKeyDown(_sender.get())
					, systemKeyUp(_sender.get())
					, previewCharInput(_sender.get())
					, charInput(_sender.get())
					, gotFocus(_sender.get())
					, lostFocus(_sender.get())
					, caretNotify(_sender.get())
					, clipboardNotify(_sender.get())
				{

				}

				EventReceiver::~EventReceiver()
				{

				}

				PassRefPtr<Composition> EventReceiver::GetAssociatedComposition()
				{
					return sender;
				}

				EventArgs::EventArgs() : handled(false)
				{

				}

				EventArgs::EventArgs(PassRefPtr<Composition> composition) : compositionSource(composition.get())
					, eventSource(composition.get())
					, handled(false)
				{

				}

				RequestEventArgs::RequestEventArgs() :cancel(false)
				{

				}

				RequestEventArgs::RequestEventArgs(PassRefPtr<Composition> composition) : EventArgs(composition)
					, cancel(false)
				{

				}

				KeyEventArgs::KeyEventArgs()
				{

				}

				KeyEventArgs::KeyEventArgs(PassRefPtr<Composition> composition) : EventArgs(composition)
				{

				}

				CharEventArgs::CharEventArgs()
				{

				}

				CharEventArgs::CharEventArgs(PassRefPtr<Composition> composition) : EventArgs(composition)
				{

				}

				MouseEventArgs::MouseEventArgs()
				{

				}

				MouseEventArgs::MouseEventArgs(PassRefPtr<Composition> composition) : EventArgs(composition)
				{

				}
			}

			namespace composition
			{
				Composition::Composition()
					: parent(nullptr)
					, associatedHost(nullptr)
					, associatedControl(nullptr)
					, associatedCursor(nullptr)
					, associatedHitTestResult(IWindowListener::NoDecision)
					, visible(true)
					, minSizeLimitation(NoLimit)
				{
					relaxAdoptionRequirement();
				}

				Composition::~Composition()
				{

				}

				PassRefPtr<Composition> Composition::GetParent()
				{
					return parent;
				}

				const Composition::CompositionList&& Composition::Children()
				{
					return move(children);
				}

				bool Composition::AddChild(PassRefPtr<Composition> child)
				{
					return InsertChild(children.size(), child);
				}

				bool Composition::InsertChild(cint index, PassRefPtr<Composition> child)
				{
					RefPtr<Composition> _child = child;
					if (!_child) return false;
					if (_child->GetParent()) return false;
					children.insert(children.begin() + index, _child);
					_child->parent = this;
					_child->SetRenderTarget(renderTarget);
					OnChildInserted(_child);
					_child->OnParentChanged(nullptr, _child->parent);
					return true;
				}

				bool Composition::RemoveChild(PassRefPtr<Composition> child)
				{
					RefPtr<Composition> _child = child;
					if (!_child) return false;
					auto found = find(children.begin(), children.end(), _child);
					if (found == children.end()) return false;
					_child->OnParentChanged(_child->parent, nullptr);
					OnChildRemoved(_child);
					_child->SetRenderTarget(nullptr);
					_child->parent = nullptr;
					RefPtr<GraphicsHost> host = GetRelatedGraphicsHost();
					if (host)
					{
						host->DisconnectComposition(_child);
					}
					children.erase(found);
					return true;
				}

				bool Composition::MoveChild(PassRefPtr<Composition> child, cint newIndex)
				{
					RefPtr<Composition> _child = child;
					if (!_child) return false;
					auto found = find(children.begin(), children.end(), _child);
					if (found == children.end()) return false;
					children.erase(found);
					children.insert(children.begin() + newIndex, _child);
					return true;
				}

				PassRefPtr<IGraphicsElement> Composition::GetOwnedElement()
				{
					return ownedElement;
				}

				void Composition::SetOwnedElement(PassRefPtr<IGraphicsElement> element)
				{
					if (ownedElement)
					{
						RefPtr<IGraphicsRenderer> renderer = ownedElement->GetRenderer();
						if (renderer)
						{
							renderer->SetRenderTarget(nullptr);
						}
					}
					ownedElement = element;
					if (ownedElement)
					{
						RefPtr<IGraphicsRenderer> renderer = ownedElement->GetRenderer();
						if (renderer)
						{
							renderer->SetRenderTarget(renderTarget);
						}
					}
				}

				bool Composition::GetVisible()
				{
					return visible;
				}

				void Composition::SetVisible(bool value)
				{
					visible = value;
				}

				Composition::MinSizeLimitation Composition::GetMinSizeLimitation()
				{
					return minSizeLimitation;
				}

				void Composition::SetMinSizeLimitation(MinSizeLimitation value)
				{
					minSizeLimitation = value;
				}

				PassRefPtr<IGraphicsRenderTarget> Composition::GetRenderTarget()
				{
					return renderTarget;
				}

				void Composition::SetRenderTarget(PassRefPtr<IGraphicsRenderTarget> value)
				{
					renderTarget = value;
					if (ownedElement)
					{
						RefPtr<IGraphicsRenderer> renderer = ownedElement->GetRenderer();
						if (renderer)
						{
							renderer->SetRenderTarget(renderTarget);
						}
					}
					for (auto & child : children)
					{
						child->SetRenderTarget(renderTarget);
					}
					OnRenderTargetChanged();
				}

				void Composition::Render(CSize offset)
				{
					if (visible && renderTarget && !renderTarget->IsClipperCoverWholeTarget())
					{
						CRect bounds = GetBounds();
						bounds.DeflateRect(margin);

						if (bounds.Width() >= 0 && bounds.Height() >= 0)
						{
							bounds.OffsetRect(offset);

							if (ownedElement)
							{
								RefPtr<IGraphicsRenderer> renderer = ownedElement->GetRenderer();
								if (renderer)
								{
									renderer->Render(bounds);
								}
							}
							if (!children.empty())
							{
								bounds.DeflateRect(internalMargin);

								if (bounds.Width() >= 0 && bounds.Height() >= 0)
								{
									offset = bounds.Size();
									renderTarget->PushClipper(bounds);
									if (!renderTarget->IsClipperCoverWholeTarget())
									{
										for (auto & child : children)
										{
											child->Render(CSize(bounds.left, bounds.top));
										}
									}
									renderTarget->PopClipper();
								}
							}
						}
					}
				}

				PassRefPtr<EventReceiver> Composition::GetEventReceiver()
				{
					if (!eventReceiver)
					{
						eventReceiver = adoptRef(new EventReceiver(this));
					}
					return eventReceiver;
				}

				bool Composition::HasEventReceiver()
				{
					return eventReceiver;
				}

				PassRefPtr<Composition> Composition::FindComposition(CPoint location)
				{
					if (!visible) return 0;
					CRect bounds = GetBounds();
					CRect relativeBounds = CRect(CPoint(), bounds.Size());
					if (relativeBounds.PtInRect(location))
					{
						CRect clientArea = GetClientArea();
						for (auto it = children.rbegin(); it != children.rend(); it++)
						{
							RefPtr<Composition> & child = *it;
							CRect childBounds = child->GetBounds();
							CSize offset = childBounds.TopLeft() + clientArea.TopLeft() - bounds.TopLeft();
							CPoint newLocation = location - offset;
							RefPtr<Composition> childResult = child->FindComposition(newLocation);
							if (childResult)
							{
								return childResult;
							}
						}
						return this;
					}
					else
					{
						return nullptr;
					}
				}

				CRect Composition::GetGlobalBounds()
				{
					CRect bounds = GetBounds();
					RefPtr<Composition> _composition = parent;
					while (_composition)
					{
						CRect clientArea = _composition->GetClientArea();
						bounds.OffsetRect(clientArea.TopLeft());
						_composition = _composition->parent;
					}
					return bounds;
				}

				PassRefPtr<Control> Composition::GetAssociatedControl()
				{
					return associatedControl;
				}

				PassRefPtr<GraphicsHost> Composition::GetAssociatedHost()
				{
					return associatedHost;
				}

				PassRefPtr<ICursor> Composition::GetAssociatedCursor()
				{
					return associatedCursor;
				}

				void Composition::SetAssociatedCursor(PassRefPtr<ICursor> cursor)
				{
					associatedCursor = associatedCursor = cursor.get();
				}

				IWindowListener::HitTestResult Composition::GetAssociatedHitTestResult()
				{
					return associatedHitTestResult;
				}

				void Composition::SetAssociatedHitTestResult(IWindowListener::HitTestResult value)
				{
					associatedHitTestResult = value;
				}

				PassRefPtr<Control> Composition::GetRelatedControl()
				{
					RefPtr<Composition> _composition = this;
					while (_composition)
					{
						if (_composition->GetAssociatedControl())
						{
							return _composition->GetAssociatedControl();
						}
						else
						{
							_composition = _composition->GetParent();
						}
					}
					return nullptr;
				}

				PassRefPtr<GraphicsHost> Composition::GetRelatedGraphicsHost()
				{
					RefPtr<Composition> _composition = this;
					while (_composition)
					{
						if (_composition->GetAssociatedHost())
						{
							return _composition->GetAssociatedHost();
						}
						else
						{
							_composition = _composition->GetParent();
						}
					}
					return nullptr;
				}

				PassRefPtr<ControlHost> Composition::GetRelatedControlHost()
				{
					RefPtr<Composition> _composition = this;
					while (_composition)
					{
						if (_composition->GetAssociatedControl())
						{
							RefPtr<ControlHost> controlHost = _composition->GetAssociatedControl();
							if (controlHost)
							{
								return controlHost;
							}
						}
						_composition = _composition->GetParent();
					}
					return nullptr;
				}

				PassRefPtr<ICursor> Composition::GetRelatedCursor()
				{
					RefPtr<Composition> _composition = this;
					while (_composition)
					{
						if (_composition->GetAssociatedCursor())
						{
							return _composition->GetAssociatedCursor();
						}
						else
						{
							_composition = _composition->GetParent();
						}
					}
					return nullptr;
				}

				CRect Composition::GetMargin()
				{
					return margin;
				}

				void Composition::SetMargin(CRect value)
				{
					margin = value;
				}

				CRect Composition::GetInternalMargin()
				{
					return internalMargin;
				}

				void Composition::SetInternalMargin(CRect value)
				{
					internalMargin = value;
				}

				CSize Composition::GetPreferredMinSize()
				{
					return preferredMinSize;
				}

				void Composition::SetPreferredMinSize(CSize value)
				{
					preferredMinSize = value;
				}

				CRect Composition::GetClientArea()
				{
					CRect bounds = GetBounds();
					bounds.DeflateRect(margin);
					bounds.DeflateRect(internalMargin);
					return bounds;
				}

				void Composition::ForceCalculateSizeImmediately()
				{
					for (auto & child : children)
					{
						child->ForceCalculateSizeImmediately();
					}
				}

				bool Composition::IsSizeAffectParent()
				{
					return true;
				}

				CSize Composition::GetMinPreferredClientSize()
				{
					CSize minSize;
					if (minSizeLimitation != Composition::NoLimit)
					{
						if (ownedElement)
						{
							RefPtr<IGraphicsRenderer> renderer = ownedElement->GetRenderer();
							if (renderer)
							{
								minSize = renderer->GetMinSize();
							}
						}
					}
					if (minSizeLimitation == Composition::LimitToElementAndChildren)
					{
						for (auto & child : children)
						{
							if (child->IsSizeAffectParent())
							{
								CRect childBounds = child->GetPreferredBounds();
								if (minSize.cx < childBounds.right) minSize.cx = childBounds.right;
								if (minSize.cy < childBounds.bottom) minSize.cy = childBounds.bottom;
							}
						}
					}
					return minSize;
				}

				void Composition::OnControlParentChanged(PassRefPtr<Control> control)
				{
					if (associatedControl && associatedControl != control)
					{
						if (associatedControl->GetParent())
						{
							associatedControl->GetParent()->OnChildRemoved(associatedControl);
						}
						if (control)
						{
							control->OnChildInserted(associatedControl);
						}
					}
					else
					{
						for (auto & child : children)
						{
							child->OnControlParentChanged(control);
						}
					}
				}

				void Composition::OnChildInserted(PassRefPtr<Composition> child)
				{
					child->OnControlParentChanged(GetRelatedControl());
				}

				void Composition::OnChildRemoved(PassRefPtr<Composition> child)
				{
					child->OnControlParentChanged(nullptr);
				}

				void Composition::OnParentChanged(PassRefPtr<Composition> oldParent, PassRefPtr<Composition> newParent)
				{
					OnParentLineChanged();
				}

				void Composition::OnParentLineChanged()
				{
					for (auto & child : children)
					{
						child->OnParentLineChanged();
					}
				}

				void Composition::OnRenderTargetChanged()
				{
					if (associatedControl)
					{
						associatedControl->OnRenderTargetChanged(renderTarget);
					}
				}

				void Composition::SetAssociatedControl(PassRefPtr<Control> control)
				{
					if (associatedControl)
					{
						for (auto & child : children)
						{
							child->OnControlParentChanged(0);
						}
					}
					associatedControl = control.get();
					if (associatedControl)
					{
						for (auto & child : children)
						{
							child->OnControlParentChanged(associatedControl);
						}
					}
				}

				void Composition::SetAssociatedHost(PassRefPtr<GraphicsHost> host)
				{
					associatedHost = host.get();
				}


				GraphicsSite::GraphicsSite()
				{
					BoundsChanged.SetAssociatedComposition(this);
				}

				GraphicsSite::~GraphicsSite()
				{

				}

				bool GraphicsSite::IsSizeAffectParent()
				{
					return true;
				}

				CSize GraphicsSite::GetMinPreferredClientSize()
				{
					CSize minSize;
					if (minSizeLimitation != Composition::NoLimit)
					{
						if (ownedElement)
						{
							RefPtr<IGraphicsRenderer> renderer = ownedElement->GetRenderer();
							if (renderer)
							{
								minSize = renderer->GetMinSize();
							}
						}
					}
					if (minSizeLimitation == Composition::LimitToElementAndChildren)
					{
						for (auto & child : children)
						{
							if (child->IsSizeAffectParent())
							{
								CRect childBounds = child->GetPreferredBounds();
								if (minSize.cx < childBounds.right) minSize.cx = childBounds.right;
								if (minSize.cy < childBounds.bottom) minSize.cy = childBounds.bottom;
							}
						}
					}
					return minSize;
				}

				CRect GraphicsSite::GetPreferredBounds()
				{
					return GetBoundsInternal(CRect(CPoint(), GetMinPreferredClientSize()));
				}

				CRect GraphicsSite::GetBoundsInternal(CRect expectedBounds)
				{
					CSize minSize = GetMinPreferredClientSize();
					if (minSize.cx < preferredMinSize.cx) minSize.cx = preferredMinSize.cx;
					if (minSize.cy < preferredMinSize.cy) minSize.cy = preferredMinSize.cy;

					minSize = minSize + margin.TopLeft() + margin.BottomRight() + internalMargin.TopLeft() + internalMargin.BottomRight();
					cint w = expectedBounds.Width();
					cint h = expectedBounds.Height();
					if (minSize.cx < w) minSize.cx = w;
					if (minSize.cy < h) minSize.cy = h;
					return CRect(expectedBounds.TopLeft(), minSize);
				}

				void GraphicsSite::UpdatePreviousBounds(CRect bounds)
				{
					if (previousBounds != bounds)
					{
						previousBounds = bounds;
						EventArgs arguments(this);
						BoundsChanged.Execute(arguments);
					}
				}

				WindowComposition::WindowComposition() : attachedWindow(nullptr)
				{

				}

				WindowComposition::~WindowComposition()
				{

				}

				PassRefPtr<IWindow> WindowComposition::GetAttachedWindow()
				{
					return attachedWindow;
				}

				void WindowComposition::SetAttachedWindow(PassRefPtr<IWindow> window)
				{
					attachedWindow = window.get();
					SetRenderTarget(attachedWindow ? GetStorage()->GetGraphicsResourceManager()->GetRenderTarget(attachedWindow) : nullptr);
				}

				CRect WindowComposition::GetBounds()
				{
					return attachedWindow ? CRect(CPoint(), attachedWindow->GetClientSize()) : CRect();
				}

				void WindowComposition::SetMargin(CRect value)
				{

				}

				BoundsComposition::BoundsComposition()
				{
					ClearAlignmentToParent();
				}

				BoundsComposition::~BoundsComposition()
				{

				}

				CRect BoundsComposition::GetPreferredBounds()
				{
					CRect result = GetBoundsInternal(compositionBounds);
					if (GetParent() && IsAlignedToParent())
					{
						if (alignmentToParent.left >= 0)
						{
							cint offset = alignmentToParent.left - result.left;
							result.left += offset;
							result.right += offset;
						}
						if (alignmentToParent.top >= 0)
						{
							cint offset = alignmentToParent.top - result.top;
							result.top += offset;
							result.bottom += offset;
						}
						if (alignmentToParent.right >= 0)
						{
							result.right += alignmentToParent.right;
						}
						if (alignmentToParent.bottom >= 0)
						{
							result.bottom += alignmentToParent.bottom;
						}
					}
					return result;
				}

				CRect BoundsComposition::GetBounds()
				{
					CRect result = GetPreferredBounds();
					if (GetParent() && IsAlignedToParent())
					{
						CSize clientSize = GetParent()->GetClientArea().Size();
						if (alignmentToParent.left >= 0 && alignmentToParent.right >= 0)
						{
							result.left = alignmentToParent.left;
							result.right = clientSize.cx - alignmentToParent.right;
						}
						else if (alignmentToParent.left >= 0)
						{
							cint width = result.Width();
							result.left = alignmentToParent.left;
							result.right = result.left + width;
						}
						else if (alignmentToParent.right >= 0)
						{
							cint width = result.Width();
							result.right = clientSize.cx - alignmentToParent.right;
							result.left = result.right - width;
						}

						if (alignmentToParent.top >= 0 && alignmentToParent.bottom >= 0)
						{
							result.top = alignmentToParent.top;
							result.bottom = clientSize.cy - alignmentToParent.bottom;
						}
						else if (alignmentToParent.top >= 0)
						{
							cint height = result.Height();
							result.top = alignmentToParent.top;
							result.bottom = result.top + height;
						}
						else if (alignmentToParent.bottom >= 0)
						{
							cint height = result.Height();
							result.bottom = clientSize.cy - alignmentToParent.bottom;
							result.top = result.bottom - height;
						}
					}
					UpdatePreviousBounds(result);
					return result;
				}

				void BoundsComposition::SetBounds(CRect value)
				{
					compositionBounds = value;
				}

				void BoundsComposition::ClearAlignmentToParent()
				{
					alignmentToParent = CRect(-1, -1, -1, -1);
				}

				CRect BoundsComposition::GetAlignmentToParent()
				{
					return alignmentToParent;
				}

				void BoundsComposition::SetAlignmentToParent(CRect value)
				{
					alignmentToParent = value;
				}

				bool BoundsComposition::IsAlignedToParent()
				{
					return (alignmentToParent != CRect(-1, -1, -1, -1)) == TRUE;
				}

				CellComposition::CellComposition()
					: row(-1)
					, column(-1)
					, rowSpan(1)
					, columnSpan(1)
					, tableParent(nullptr)
				{
					SetMinSizeLimitation(Composition::LimitToElementAndChildren);
				}

				CellComposition::~CellComposition()
				{

				}

				PassRefPtr<TableComposition> CellComposition::GetTableParent()
				{
					return tableParent;
				}

				cint CellComposition::GetRow()
				{
					return row;
				}

				cint CellComposition::GetRowSpan()
				{
					return rowSpan;
				}

				cint CellComposition::GetColumn()
				{
					return column;
				}

				cint CellComposition::GetColumnSpan()
				{
					return columnSpan;
				}

				bool CellComposition::SetSite(cint _row, cint _column, cint _rowSpan, cint _columnSpan)
				{
					if (SetSiteInternal(_row, _column, _rowSpan, _columnSpan))
					{
						if (tableParent)
						{
							tableParent->UpdateCellBounds();
						}
						return true;
					}
					else
					{
						return false;
					}
				}

				CRect CellComposition::GetBounds()
				{
					CRect result;
					if (tableParent && row != -1 && column != -1)
					{
						CRect bounds1, bounds2;
						{
							cint index = tableParent->GetSiteIndex(tableParent->rows, tableParent->columns, row, column);
							bounds1 = tableParent->cellBounds[index];
						}
						{
							cint index = tableParent->GetSiteIndex(tableParent->rows, tableParent->columns, row + rowSpan - 1, column + columnSpan - 1);
							bounds2 = tableParent->cellBounds[index];
							if (tableParent->GetMinSizeLimitation() == Composition::NoLimit)
							{
								if (row + rowSpan == tableParent->rows)
								{
									bounds2.bottom += tableParent->rowExtending;
								}
								if (column + columnSpan == tableParent->columns)
								{
									bounds2.right += tableParent->columnExtending;
								}
							}
						}
						auto t = bounds2.BottomRight();
						result = CRect(bounds1.TopLeft(), bounds2.BottomRight());
					}
					else
					{
						result = CRect();
					}
					UpdatePreviousBounds(result);
					return result;
				}

				void CellComposition::ClearSitedCells(PassRefPtr<TableComposition> table)
				{
					if (row != -1 && column != -1)
					{
						for (cint r = 0; r < rowSpan; r++)
						{
							for (cint c = 0; c < columnSpan; c++)
							{
								table->SetSitedCell(row + r, column + c, nullptr);
							}
						}
					}
				}

				void CellComposition::SetSitedCells(PassRefPtr<TableComposition> table)
				{
					for (cint r = 0; r < rowSpan; r++)
					{
						for (cint c = 0; c < columnSpan; c++)
						{
							table->SetSitedCell(row + r, column + c, this);
						}
					}
				}

				void CellComposition::ResetSiteInternal()
				{
					row = -1;
					column = -1;
					rowSpan = 1;
					columnSpan = 1;
				}

				bool CellComposition::SetSiteInternal(cint _row, cint _column, cint _rowSpan, cint _columnSpan)
				{
					if (tableParent)
					{
						if (_row < 0 || _row >= tableParent->rows || _column < 0 || _column >= tableParent->columns) return false;
						if (_rowSpan<1 || _row + _rowSpan>tableParent->rows || _columnSpan<1 || _column + _columnSpan>tableParent->columns) return false;

						for (cint r = 0; r < _rowSpan; r++)
						{
							for (cint c = 0; c < _columnSpan; c++)
							{
								RefPtr<CellComposition> cell = tableParent->GetSitedCell(_row + r, _column + c);
								if (cell && cell != this)
								{
									return false;
								}
							}
						}
						ClearSitedCells(tableParent);
					}

					row = _row;
					column = _column;
					rowSpan = _rowSpan;
					columnSpan = _columnSpan;

					if (tableParent)
					{
						SetSitedCells(tableParent);
					}
					return true;
				}

				void CellComposition::OnParentChanged(PassRefPtr<Composition> oldParent, PassRefPtr<Composition> newParent)
				{
					RefPtr<Composition> _oldParent = oldParent;
					RefPtr<Composition> _newParent = newParent;
					GraphicsSite::OnParentChanged(_oldParent, _newParent);
					if (tableParent)
					{
						ClearSitedCells(tableParent);
					}
					tableParent = dynamic_cast<TableComposition*>(_newParent.get());
					if (!tableParent || !SetSiteInternal(row, column, rowSpan, columnSpan))
					{
						ResetSiteInternal();
					}
					if (tableParent)
					{
						if (row != -1 && column != -1)
						{
							SetSiteInternal(row, column, rowSpan, columnSpan);
						}
						tableParent->UpdateCellBounds();
					}
				}

				void CellComposition::OnTableRowsAndColumnsChanged()
				{
					if (!SetSiteInternal(row, column, rowSpan, columnSpan))
					{
						ResetSiteInternal();
					}
				}

				TableComposition::TableComposition()
					: rows(0)
					, columns(0)
					, cellPadding(0)
					, rowExtending(0)
					, columnExtending(0)
				{
					SetRowsAndColumns(1, 1);
				}

				TableComposition::~TableComposition()
				{
				}

				cint TableComposition::GetRows()
				{
					return rows;
				}

				cint TableComposition::GetColumns()
				{
					return columns;
				}

				bool TableComposition::SetRowsAndColumns(cint _rows, cint _columns)
				{
					if (_rows <= 0 || _columns <= 0) return false;
					rowOptions.resize(_rows);
					columnOptions.resize(_columns);
					cellCompositions.resize(_rows*_columns);
					cellBounds.resize(_rows*_columns);
					for (cint i = 0; i < _rows*_columns; i++)
					{
						cellCompositions[i] = nullptr;
						cellBounds[i] = CRect();
					}
					rows = _rows;
					columns = _columns;
					for (auto & child : Children())
					{
						RefPtr<CellComposition> cell = dynamic_cast<CellComposition*>(child.get());
						if (cell)
						{
							cell->OnTableRowsAndColumnsChanged();
						}
					}
					UpdateCellBounds();
					return true;
				}

				PassRefPtr<CellComposition> TableComposition::GetSitedCell(cint _row, cint _column)
				{
					return cellCompositions[GetSiteIndex(rows, columns, _row, _column)];
				}

				CellOption TableComposition::GetRowOption(cint _row)
				{
					return rowOptions[_row];
				}

				void TableComposition::SetRowOption(cint _row, CellOption option)
				{
					rowOptions[_row] = option;
				}

				CellOption TableComposition::GetColumnOption(cint _column)
				{
					return columnOptions[_column];
				}

				void TableComposition::SetColumnOption(cint _column, CellOption option)
				{
					columnOptions[_column] = option;
				}

				cint TableComposition::GetCellPadding()
				{
					return cellPadding;
				}

				void TableComposition::SetCellPadding(cint value)
				{
					if (value < 0) value = 0;
					cellPadding = value;
				}

				CRect TableComposition::GetCellArea()
				{
					CRect bounds(CPoint(), BoundsComposition::GetBounds().Size());
					bounds.DeflateRect(margin);
					bounds.DeflateRect(internalMargin);
					bounds.DeflateRect(CSize(cellPadding, cellPadding));
					if (bounds.right < bounds.left) bounds.right = bounds.left;
					if (bounds.bottom < bounds.top) bounds.bottom = bounds.top;
					return bounds;
				}

				void TableComposition::UpdateCellBounds()
				{
					UpdateCellBoundsInternal();
					UpdateTableContentMinSize();
				}

				void TableComposition::ForceCalculateSizeImmediately()
				{
					BoundsComposition::ForceCalculateSizeImmediately();
					UpdateCellBounds();
					UpdateCellBounds();
				}

				CSize TableComposition::GetMinPreferredClientSize()
				{
					return tableContentMinSize;
				}

				CRect TableComposition::GetBounds()
				{
					CRect result;
					if (!IsAlignedToParent() && GetMinSizeLimitation() != Composition::NoLimit)
					{
						result = CRect(compositionBounds.TopLeft(), compositionBounds.Size() - CSize(columnExtending, rowExtending));
					}
					else
					{
						result = BoundsComposition::GetBounds();
					}

					bool cellMinSizeModified = false;
					set<RefPtr<CellComposition>> cells;
					for (auto & cell : cellCompositions)
					{
						if (cell && cells.insert(cell).second)
						{
							CSize newSize = cell->GetPreferredBounds().Size();
							if (cell->lastPreferredSize != newSize)
							{
								cell->lastPreferredSize = newSize;
								cellMinSizeModified = true;
							}
						}
					}

					if (previousBounds != result || cellMinSizeModified)
					{
						previousBounds = result;
						UpdateCellBounds();
					}
					return result;
				}

				cint TableComposition::GetSiteIndex(cint _rows, cint _columns, cint _row, cint _column)
				{
					return _row*_columns + _column;
				}

				void TableComposition::SetSitedCell(cint _row, cint _column, PassRefPtr<CellComposition> cell)
				{
					cellCompositions[GetSiteIndex(rows, columns, _row, _column)] = cell.get();
				}

				void TableComposition::UpdateCellBoundsInternal(
					vector<cint>& dimSizes,
					cint& dimSize,
					cint& dimSizeWithPercentage,
					vector<CellOption>& dimOptions,
					cint TableComposition::* dim1,
					cint TableComposition::* dim2,
					cint(*getSize)(CSize),
					cint(*getLocation)(PassRefPtr<CellComposition>),
					cint(*getSpan)(PassRefPtr<CellComposition>),
					cint(*getRow)(cint, cint),
					cint(*getCol)(cint, cint),
					cint maxPass
					)
				{
					for (cint pass = 0; pass < maxPass; pass++)
					{
						for (cint i = 0; i < this->*dim1; i++)
						{
							CellOption option = dimOptions[i];
							if (pass == 0)
							{
								dimSizes[i] = 0;
							}
							switch (option.composeType)
							{
								case CellOption::Absolute:
								{
									dimSizes[i] = option.absolute;
								}
									break;
								case CellOption::MinSize:
								{
									for (cint j = 0; j < this->*dim2; j++)
									{
										RefPtr<CellComposition> cell = GetSitedCell(getRow(i, j), getCol(i, j));
										if (cell)
										{
											bool accept = false;
											if (pass == 0)
											{
												accept = getSpan(cell) == 1;
											}
											else
											{
												accept = getLocation(cell) + getSpan(cell) == i + 1;
											}
											if (accept)
											{
												cint size = getSize(cell->GetPreferredBounds().Size());
												cint span = getSpan(cell);
												for (cint k = 1; k < span; k++)
												{
													size -= dimSizes[i - k] + cellPadding;
												}
												if (dimSizes[i] < size)
												{
													dimSizes[i] = size;
												}
											}
										}
									}
								}
									break;
							}
						}
					}

					bool percentageExists = false;
					for (cint i = 0; i < this->*dim1; i++)
					{
						CellOption option = dimOptions[i];
						if (option.composeType == CellOption::Percentage)
						{
							if (0.001 < option.percentage)
							{
								percentageExists = true;
							}
						}
					}

					if (percentageExists)
					{
						for (cint i = 0; i < this->*dim1; i++)
						{
							CellOption option = dimOptions[i];
							if (option.composeType == CellOption::Percentage)
							{
								if (0.001 < option.percentage)
								{
									for (cint j = 0; j < this->*dim2; j++)
									{
										RefPtr<CellComposition> cell = GetSitedCell(getRow(i, j), getCol(i, j));
										if (cell)
										{
											cint size = getSize(cell->GetPreferredBounds().Size());
											cint start = getLocation(cell);
											cint span = getSpan(cell);
											size -= (span - 1)*cellPadding;
											double totalPercentage = 0;

											for (cint k = start; k < start + span; k++)
											{
												if (dimOptions[k].composeType == CellOption::Percentage)
												{
													if (0.001 < dimOptions[k].percentage)
													{
														totalPercentage += dimOptions[k].percentage;
													}
												}
												else
												{
													size -= dimSizes[k];
												}
											}

											size = (cint)ceil(size*option.percentage / totalPercentage);
											if (dimSizes[i] < size)
											{
												dimSizes[i] = size;
											}
										}
									}
								}
							}
						}

						cint percentageTotalSize = 0;
						for (cint i = 0; i < this->*dim1; i++)
						{
							CellOption option = dimOptions[i];
							if (option.composeType == CellOption::Percentage)
							{
								if (0.001 < option.percentage)
								{
									cint size = (cint)ceil(dimSizes[i] / option.percentage);
									if (percentageTotalSize < size)
									{
										percentageTotalSize = size;
									}
								}
							}
						}

						double totalPercentage = 0;
						for (cint i = 0; i < this->*dim1; i++)
						{
							CellOption option = dimOptions[i];
							if (option.composeType == CellOption::Percentage)
							{
								if (0.001 < option.percentage)
								{
									totalPercentage += option.percentage;
								}
							}
						}

						for (cint i = 0; i < this->*dim1; i++)
						{
							CellOption option = dimOptions[i];
							if (option.composeType == CellOption::Percentage)
							{
								if (0.001 < option.percentage)
								{
									cint size = (cint)ceil(percentageTotalSize*option.percentage / totalPercentage);
									if (dimSizes[i] < size)
									{
										dimSizes[i] = size;
									}
								}
							}
						}
					}

					for (cint i = 0; i < this->*dim1; i++)
					{
						if (dimOptions[i].composeType != CellOption::Percentage)
						{
							dimSize += dimSizes[i];
						}
						dimSizeWithPercentage += dimSizes[i];
					}
				}

				void TableComposition::UpdateCellBoundsPercentages(
					vector<cint>& dimSizes,
					cint dimSize,
					cint maxDimSize,
					vector<CellOption>& dimOptions
					)
				{
					if (maxDimSize > dimSize)
					{
						double totalPercentage = 0;
						cint percentageCount = 0;
						for (auto & dimOption : dimOptions)
						{
							CellOption & option = dimOption;
							if (option.composeType == CellOption::Percentage)
							{
								totalPercentage += option.percentage;
								percentageCount++;
							}
						}
						if (percentageCount>0 && totalPercentage > 0.001)
						{
							for (cuint i = 0; i < dimOptions.size(); i++)
							{
								CellOption option = dimOptions[i];
								if (option.composeType == CellOption::Percentage)
								{
									dimSizes[i] = (cint)((maxDimSize - dimSize)*option.percentage / totalPercentage);
								}
							}
						}
					}
				}

				cint TableComposition::UpdateCellBoundsOffsets(
					vector<cint>& offsets,
					vector<cint>& sizes,
					cint start,
					cint max
					)
				{
					offsets[0] = start;
					for (cuint i = 1; i < offsets.size(); i++)
					{
						start += cellPadding + sizes[i - 1];
						offsets[i] = start;
					}

					cint last = offsets.size() - 1;
					cint right = offsets[last] + sizes[last];
					return max - right;
				}

				void TableComposition::UpdateCellBoundsInternal()
				{
					vector<cint> rowOffsets, columnOffsets, rowSizes, columnSizes;
					rowOffsets.resize(rows);
					rowSizes.resize(rows);
					columnOffsets.resize(columns);
					columnSizes.resize(columns);
					{
						cint rowTotal = (rows - 1)*cellPadding;
						cint columnTotal = (columns - 1)*cellPadding;
						cint rowTotalWithPercentage = rowTotal;
						cint columnTotalWithPercentage = columnTotal;

						UpdateCellBoundsInternal(
							rowSizes,
							rowTotal,
							rowTotalWithPercentage,
							rowOptions,
							&TableComposition::rows,
							&TableComposition::columns,
							&Y,
							&RL,
							&RS,
							&First,
							&Second,
							1
							);
						UpdateCellBoundsInternal(
							columnSizes,
							columnTotal,
							columnTotalWithPercentage,
							columnOptions,
							&TableComposition::columns,
							&TableComposition::rows,
							&X,
							&CL,
							&CS,
							&Second,
							&First,
							1
							);

						CRect area = GetCellArea();
						UpdateCellBoundsPercentages(rowSizes, rowTotal, area.Height(), rowOptions);
						UpdateCellBoundsPercentages(columnSizes, columnTotal, area.Width(), columnOptions);
						rowExtending = UpdateCellBoundsOffsets(rowOffsets, rowSizes, cellPadding, cellPadding + area.Height());
						columnExtending = UpdateCellBoundsOffsets(columnOffsets, columnSizes, cellPadding, cellPadding + area.Width());

						for (cint i = 0; i < rows; i++)
						{
							for (cint j = 0; j < columns; j++)
							{
								cint index = GetSiteIndex(rows, columns, i, j);
								cellBounds[index] = CRect(CPoint(columnOffsets[j], rowOffsets[i]), CSize(columnSizes[j], rowSizes[i]));
							}
						}
					}
				}

				void TableComposition::UpdateTableContentMinSize()
				{
					vector<cint> rowSizes, columnSizes;
					rowSizes.resize(rows);
					columnSizes.resize(columns);
					{
						cint rowTotal = (rows + 1)*cellPadding;
						cint columnTotal = (columns + 1)*cellPadding;
						cint rowTotalWithPercentage = rowTotal;
						cint columnTotalWithPercentage = columnTotal;

						UpdateCellBoundsInternal(
							rowSizes,
							rowTotal,
							rowTotalWithPercentage,
							rowOptions,
							&TableComposition::rows,
							&TableComposition::columns,
							&Y,
							&RL,
							&RS,
							&First,
							&Second,
							2
							);
						UpdateCellBoundsInternal(
							columnSizes,
							columnTotal,
							columnTotalWithPercentage,
							columnOptions,
							&TableComposition::columns,
							&TableComposition::rows,
							&X,
							&CL,
							&CS,
							&Second,
							&First,
							2
							);
						tableContentMinSize = CSize(columnTotalWithPercentage, rowTotalWithPercentage);
					}
					if (previousContentMinSize != tableContentMinSize)
					{
						previousContentMinSize = tableContentMinSize;
						UpdateCellBoundsInternal();
					}
				}

				void TableComposition::OnRenderTargetChanged()
				{
					if (GetRenderTarget())
					{
						UpdateTableContentMinSize();
					}
				}

				cint TableComposition::First(cint a, cint b)
				{
					return a;
				}

				cint TableComposition::Second(cint a, cint b)
				{
					return b;
				}

				cint TableComposition::X(CSize s)
				{
					return s.cx;
				}

				cint TableComposition::Y(CSize s)
				{
					return s.cy;
				}

				cint TableComposition::RL(PassRefPtr<CellComposition> cell)
				{
					return cell->GetRow();
				}

				cint TableComposition::CL(PassRefPtr<CellComposition> cell)
				{
					return cell->GetColumn();
				}

				cint TableComposition::RS(PassRefPtr<CellComposition> cell)
				{
					return cell->GetRowSpan();
				}

				cint TableComposition::CS(PassRefPtr<CellComposition> cell)
				{
					return cell->GetColumnSpan();
				}
			}
		}
	}
}