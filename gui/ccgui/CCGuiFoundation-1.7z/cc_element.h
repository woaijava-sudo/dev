#ifndef CC_ELEMENT
#define CC_ELEMENT

#include "stdafx.h"
#include "cc_base.h"
#include "cc_interface.h"
#include "cc_presentation.h"

using namespace cc::base;
using namespace cc::presentation::windows;

namespace cc
{
	namespace presentation
	{
		namespace element
		{
			namespace graphics_element
			{
#pragma region Base
				template <class TElement>
				class GraphicsElement : public IGraphicsElement
				{
				public:
					class Factory : public IGraphicsElementFactory
					{
					public:
						Factory()
						{
							relaxAdoptionRequirement();
						}
						CString GetElementTypeName()
						{
							return TElement::GetElementTypeName();
						}
						PassRefPtr<IGraphicsElement> Create()
						{
							RefPtr<TElement> element = adoptRef(new TElement);
							element->factory = this;
							RefPtr<IGraphicsRendererFactory> rendererFactory = GetStorage()->GetGraphicsResourceManager()->GetRendererFactory(GetElementTypeName());
							if (rendererFactory)
							{
								element->renderer = rendererFactory->Create();
								element->renderer->Initialize(element);
							}
							return element;
						}
					};
				public:
					static PassRefPtr<TElement> Create()
					{
						return GetStorage()->GetGraphicsResourceManager()->GetElementFactory(TElement::GetElementTypeName())->Create();
					}
					PassRefPtr<IGraphicsElementFactory> GetFactory()override
					{
						return factory;
					}
					PassRefPtr<IGraphicsRenderer> GetRenderer()override
					{
						return renderer;
					}
				protected:
					IGraphicsElementFactory*				factory;
					RefPtr<IGraphicsRenderer>				renderer;
				};

				template <class TElement, class TRenderer, class TTarget>
				class GraphicsRenderer : public IGraphicsRenderer
				{
				public:
					class Factory : public IGraphicsRendererFactory
					{
					public:
						Factory()
						{
							relaxAdoptionRequirement();
						}
						PassRefPtr<IGraphicsRenderer> Create()
						{
							RefPtr<TRenderer> renderer = adoptRef(new TRenderer);
							renderer->factory = this;
							renderer->element = nullptr;
							renderer->renderTarget = nullptr;
							return renderer;
						}
					};
				public:
					GraphicsRenderer()
						: element(nullptr)
						, factory(nullptr)
						, renderTarget(nullptr)
					{

					}
					static void Register()
					{
						GetStorage()->RegisterFactories(adoptRef(new TElement::Factory), adoptRef(new TRenderer::Factory));
					}
					PassRefPtr<IGraphicsRendererFactory> GetFactory()override
					{
						return factory;
					}
					void Initialize(PassRefPtr<IGraphicsElement> _element)override
					{
						element = dynamic_cast<TElement*>(_element.get());
						InitializeInternal();
					}
					void Finalize()override
					{
						FinalizeInternal();
					}
					void SetRenderTarget(PassRefPtr<IGraphicsRenderTarget> _renderTarget)override
					{
						RefPtr<TTarget> oldRenderTarget = renderTarget;
						renderTarget = dynamic_cast<ID2DRenderTarget*>(_renderTarget.get());
						RenderTargetChangedInternal(oldRenderTarget, renderTarget);
					}
					CSize GetMinSize()override
					{
						return minSize;
					}
					virtual void InitializeInternal() = 0;
					virtual void FinalizeInternal() = 0;
					virtual void RenderTargetChangedInternal(PassRefPtr<ID2DRenderTarget> oldRenderTarget, PassRefPtr<ID2DRenderTarget> newRenderTarget) = 0;

				protected:
					IGraphicsRendererFactory*			factory;
					TElement*							element;
					TTarget*							renderTarget;
					CSize								minSize;
				};

				template <class TElement, class TRenderer, class TBrush, class TBrushProperty>
				class GraphicsBrushRenderer : public GraphicsRenderer<TElement, TRenderer, ID2DRenderTarget>
				{
				public:
					void OnElementStateChanged()override
					{
						if (renderTarget)
						{
							CColor color = element->GetColor();
							if (oldColor != color)
							{
								DestroyBrush(renderTarget);
								CreateBrush(renderTarget);
							}
						}
					}

				protected:
					void CreateBrush(PassRefPtr<ID2DRenderTarget> _renderTarget)
					{
						if (_renderTarget)
						{
							oldColor = element->GetColor();
							brush = _renderTarget->CreateDirect2DBrush(oldColor);
						}
					}
					void DestroyBrush(PassRefPtr<ID2DRenderTarget> _renderTarget)
					{
						if (_renderTarget && brush)
						{
							_renderTarget->DestroyDirect2DBrush(oldColor);
							brush = nullptr;
						}
					}
					void InitializeInternal()override
					{

					}
					void FinalizeInternal()override
					{
						DestroyBrush(renderTarget);
					}
					void RenderTargetChangedInternal(PassRefPtr<ID2DRenderTarget> oldRenderTarget, PassRefPtr<ID2DRenderTarget> newRenderTarget)override
					{
						DestroyBrush(oldRenderTarget.get());
						CreateBrush(newRenderTarget.get());
					}

					TBrushProperty			oldColor;
					CComPtr<TBrush>			brush;
				};
			}
#pragma endregion Base

			using namespace cc::presentation::element::graphics_element;

			enum ElementShape
			{
				Rectangle,
				Ellipse,
			};

#pragma region SolidBackground
			class SolidBackgroundElement : public GraphicsElement<SolidBackgroundElement>
			{
			public:
				SolidBackgroundElement();
				~SolidBackgroundElement();

				static CString			GetElementTypeName();

				CColor					GetColor();
				void					SetColor(CColor value);
				ElementShape			GetShape();
				void					SetShape(ElementShape value);

			protected:
				CColor					color;
				ElementShape			shape;
			};

			class SolidBackgroundElementRenderer : public GraphicsBrushRenderer<SolidBackgroundElement, SolidBackgroundElementRenderer, ID2D1Brush, CColor>
			{
			public:
				void					Render(CRect bounds)override;
			};
#pragma endregion SolidBackground

#pragma region SolidBorder
			class SolidBorderElement : public GraphicsElement<SolidBorderElement>
			{
			public:
				SolidBorderElement();
				~SolidBorderElement();

				static CString			GetElementTypeName();

				CColor					GetColor();
				void					SetColor(CColor value);
				ElementShape			GetShape();
				void					SetShape(ElementShape value);

			protected:
				CColor					color;
				ElementShape			shape;
			};

			class SolidBorderElementRenderer : public GraphicsBrushRenderer<SolidBorderElement, SolidBorderElementRenderer, ID2D1Brush, CColor>
			{
			public:
				void					Render(CRect bounds)override;
			};
#pragma endregion SolidBorder

#pragma region SolidLabel
			class SolidLabelElement : public GraphicsElement<SolidLabelElement>
			{
			public:
				SolidLabelElement();
				~SolidLabelElement();

				static CString			GetElementTypeName();

				CColor					GetColor();
				void					SetColor(CColor value);

				const Font&				GetFont();
				void					SetFont(const Font& value);

				const CString&			GetText();
				void					SetText(const CString& value);

				Alignment				GetHorizontalAlignment();
				Alignment				GetVerticalAlignment();
				void					SetHorizontalAlignment(Alignment value);
				void					SetVerticalAlignment(Alignment value);
				void					SetAlignments(Alignment horizontal, Alignment vertical);

				bool					GetWrapLine();
				void					SetWrapLine(bool value);

				bool					GetEllipse();
				void					SetEllipse(bool value);

				bool					GetMultiline();
				void					SetMultiline(bool value);

				bool					GetWrapLineHeightCalculation();
				void					SetWrapLineHeightCalculation(bool value);

			protected:
				CColor					color;
				Font					fontProperties;
				CString					text;
				Alignment				hAlignment;
				Alignment				vAlignment;
				bool					wrapLine;
				bool					ellipse;
				bool					multiline;
				bool					wrapLineHeightCalculation;
			};

			class SolidLabelElementRenderer : public GraphicsRenderer<SolidLabelElement, SolidLabelElementRenderer, ID2DRenderTarget>
			{
			public:
				SolidLabelElementRenderer();

				void					Render(CRect bounds)override;
				void					OnElementStateChanged()override;

			protected:
				void					CreateBrush(PassRefPtr<ID2DRenderTarget> _renderTarget);
				void					DestroyBrush(PassRefPtr<ID2DRenderTarget> _renderTarget);
				void					CreateTextFormat(PassRefPtr<ID2DRenderTarget> _renderTarget);
				void					DestroyTextFormat(PassRefPtr<ID2DRenderTarget> _renderTarget);
				void					CreateTextLayout();
				void					DestroyTextLayout();
				void					UpdateMinSize();

				void					InitializeInternal();
				void					FinalizeInternal();
				void					RenderTargetChangedInternal(PassRefPtr<ID2DRenderTarget> oldRenderTarget, PassRefPtr<ID2DRenderTarget> newRenderTarget);

				CColor							oldColor;
				Font							oldFont;
				CString							oldText;
				CComPtr<ID2D1SolidColorBrush>	brush;
				RefPtr<D2DTextFormatPackage>	textFormat;
				CComPtr<IDWriteTextLayout>		textLayout;
				cint							oldMaxWidth;
			};
#pragma endregion SolidLabel


		}
	}
}

#endif