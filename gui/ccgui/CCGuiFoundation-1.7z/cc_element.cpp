#include "stdafx.h"
#include "cc_element.h"

namespace cc
{
	namespace presentation
	{
		namespace element
		{
#pragma region SolidBackground
			SolidBackgroundElement::SolidBackgroundElement()
				: shape(ElementShape::Rectangle)
			{

			}

			SolidBackgroundElement::~SolidBackgroundElement()
			{
				renderer->Finalize();
			}

			CString SolidBackgroundElement::GetElementTypeName()
			{
				return _T("SolidBackground");
			}

			CColor SolidBackgroundElement::GetColor()
			{
				return color;
			}

			void SolidBackgroundElement::SetColor(CColor value)
			{
				if (color != value)
				{
					color = value;
					if (renderer)
					{
						renderer->OnElementStateChanged();
					}
				}
			}

			ElementShape SolidBackgroundElement::GetShape()
			{
				return shape;
			}

			void SolidBackgroundElement::SetShape(ElementShape value)
			{
				shape = value;
			}

			void SolidBackgroundElementRenderer::Render(CRect bounds)
			{
				CComPtr<ID2D1RenderTarget> d2dRenderTarget = renderTarget->GetDirect2DRenderTarget();
				switch (element->GetShape())
				{
					case ElementShape::Rectangle:
						d2dRenderTarget->FillRectangle(
							D2D1::RectF((FLOAT)bounds.left, (FLOAT)bounds.top, (FLOAT)bounds.right, (FLOAT)bounds.bottom),
							brush
							);
						break;
					case ElementShape::Ellipse:
						d2dRenderTarget->FillEllipse(
							D2D1::Ellipse(D2D1::Point2F((bounds.left + bounds.right) / 2.0f, (bounds.top + bounds.bottom) / 2.0f), bounds.Width() / 2.0f, bounds.Height() / 2.0f),
							brush
							);
						break;
				}
			}
#pragma endregion SolidBackground

#pragma region SolidBorder
			SolidBorderElement::SolidBorderElement()
				: shape(ElementShape::Rectangle)
			{

			}

			SolidBorderElement::~SolidBorderElement()
			{
				renderer->Finalize();
			}

			CString SolidBorderElement::GetElementTypeName()
			{
				return _T("SolidBorder");
			}

			CColor SolidBorderElement::GetColor()
			{
				return color;
			}

			void SolidBorderElement::SetColor(CColor value)
			{
				if (color != value)
				{
					color = value;
					if (renderer)
					{
						renderer->OnElementStateChanged();
					}
				}
			}

			ElementShape SolidBorderElement::GetShape()
			{
				return shape;
			}

			void SolidBorderElement::SetShape(ElementShape value)
			{
				shape = value;
			}

			void SolidBorderElementRenderer::Render(CRect bounds)
			{
				CComPtr<ID2D1RenderTarget> d2dRenderTarget = renderTarget->GetDirect2DRenderTarget();
				switch (element->GetShape())
				{
					case ElementShape::Rectangle:
						d2dRenderTarget->DrawRectangle(
							D2D1::RectF((FLOAT)bounds.left + 0.5f, (FLOAT)bounds.top + 0.5f, (FLOAT)bounds.right - 0.5f, (FLOAT)bounds.bottom - 0.5f),
							brush
							);
						break;
					case ElementShape::Ellipse:
						d2dRenderTarget->DrawEllipse(
							D2D1::Ellipse(D2D1::Point2F((bounds.left + bounds.right) / 2.0f, (bounds.top + bounds.bottom) / 2.0f), bounds.Width() / 2.0f, bounds.Height() / 2.0f),
							brush
							);
						break;
				}
			}
#pragma endregion SolidBorder

#pragma region SolidLabel
			SolidLabelElement::SolidLabelElement()
				: hAlignment(Alignment::StringAlignmentNear)
				, vAlignment(Alignment::StringAlignmentNear)
				, wrapLine(false)
				, ellipse(false)
				, multiline(false)
				, wrapLineHeightCalculation(false)
			{
				fontProperties.fontFamily = _T("Microsoft Yahei");
				fontProperties.size = 12;
			}

			SolidLabelElement::~SolidLabelElement()
			{
				renderer->Finalize();
			}

			CString SolidLabelElement::GetElementTypeName()
			{
				return _T("SolidLabel");
			}

			CColor SolidLabelElement::GetColor()
			{
				return color;
			}

			void SolidLabelElement::SetColor(CColor value)
			{
				if (color != value)
				{
					color = value;
					if (renderer)
					{
						renderer->OnElementStateChanged();
					}
				}
			}

			const Font& SolidLabelElement::GetFont()
			{
				return fontProperties;
			}

			void SolidLabelElement::SetFont(const Font& value)
			{
				if (fontProperties != value)
				{
					fontProperties = value;
					if (renderer)
					{
						renderer->OnElementStateChanged();
					}
				}
			}

			const CString& SolidLabelElement::GetText()
			{
				return text;
			}

			void SolidLabelElement::SetText(const CString& value)
			{
				if (text != value)
				{
					text = value;
					if (renderer)
					{
						renderer->OnElementStateChanged();
					}
				}
			}

			Alignment SolidLabelElement::GetHorizontalAlignment()
			{
				return hAlignment;
			}

			Alignment SolidLabelElement::GetVerticalAlignment()
			{
				return vAlignment;
			}

			void SolidLabelElement::SetHorizontalAlignment(Alignment value)
			{
				SetAlignments(value, vAlignment);
			}

			void SolidLabelElement::SetVerticalAlignment(Alignment value)
			{
				SetAlignments(hAlignment, value);
			}

			void SolidLabelElement::SetAlignments(Alignment horizontal, Alignment vertical)
			{
				if (hAlignment != horizontal || vAlignment != vertical)
				{
					hAlignment = horizontal;
					vAlignment = vertical;
					if (renderer)
					{
						renderer->OnElementStateChanged();
					}
				}
			}

			bool SolidLabelElement::GetWrapLine()
			{
				return wrapLine;
			}

			void SolidLabelElement::SetWrapLine(bool value)
			{
				if (wrapLine != value)
				{
					wrapLine = value;
					if (renderer)
					{
						renderer->OnElementStateChanged();
					}
				}
			}

			bool SolidLabelElement::GetEllipse()
			{
				return ellipse;
			}

			void SolidLabelElement::SetEllipse(bool value)
			{
				if (ellipse != value)
				{
					ellipse = value;
					if (renderer)
					{
						renderer->OnElementStateChanged();
					}
				}
			}

			bool SolidLabelElement::GetMultiline()
			{
				return multiline;
			}

			void SolidLabelElement::SetMultiline(bool value)
			{
				if (multiline != value)
				{
					multiline = value;
					if (renderer)
					{
						renderer->OnElementStateChanged();
					}
				}
			}

			bool SolidLabelElement::GetWrapLineHeightCalculation()
			{
				return wrapLineHeightCalculation;
			}

			void SolidLabelElement::SetWrapLineHeightCalculation(bool value)
			{
				if (wrapLineHeightCalculation != value)
				{
					wrapLineHeightCalculation = value;
					if (renderer)
					{
						renderer->OnElementStateChanged();
					}
				}
			}

			SolidLabelElementRenderer::SolidLabelElementRenderer()
				: oldMaxWidth(-1)
			{

			}

			void SolidLabelElementRenderer::Render(CRect bounds)
			{
				if (!textLayout)
				{
					CreateTextLayout();
				}

				cint x = 0;
				cint y = 0;
				switch (element->GetHorizontalAlignment())
				{
					case Alignment::StringAlignmentNear:
						x = bounds.left;
						break;
					case Alignment::StringAlignmentCenter:
						x = bounds.left + (bounds.Width() - minSize.cx) / 2;
						break;
					case Alignment::StringAlignmentFar:
						x = bounds.right - minSize.cx;
						break;
				}
				switch (element->GetVerticalAlignment())
				{
					case Alignment::StringAlignmentNear:
						y = bounds.top;
						break;
					case Alignment::StringAlignmentCenter:
						y = bounds.top + (bounds.Height() - minSize.cy) / 2;
						break;
					case Alignment::StringAlignmentFar:
						y = bounds.bottom - minSize.cy;
						break;
				}

				renderTarget->SetTextAntialias(oldFont.antialias, oldFont.verticalAntialias);

				if (!element->GetEllipse() && !element->GetMultiline() && !element->GetWrapLine())
				{
					CComPtr<ID2D1RenderTarget> d2dRenderTarget = renderTarget->GetDirect2DRenderTarget();
					d2dRenderTarget->DrawTextLayout(
						D2D1::Point2F((FLOAT)x, (FLOAT)y),
						textLayout,
						brush,
						D2D1_DRAW_TEXT_OPTIONS_NO_SNAP
						);
				}
				else
				{
					CComPtr<IDWriteFactory> dwriteFactory = GetStorage()->GetDirect2DProvider()->GetDirectWriteFactory();
					DWRITE_TRIMMING trimming;
					CComPtr<IDWriteInlineObject> inlineObject;
					textLayout->GetTrimming(&trimming, &inlineObject);

					textLayout->SetWordWrapping(element->GetWrapLine() ? DWRITE_WORD_WRAPPING_WRAP : DWRITE_WORD_WRAPPING_NO_WRAP);
					if (element->GetEllipse())
					{
						textLayout->SetTrimming(&textFormat->trimming, textFormat->ellipseInlineObject);
					}
					switch (element->GetHorizontalAlignment())
					{
						case Alignment::StringAlignmentNear:
							textLayout->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_LEADING);
							break;
						case Alignment::StringAlignmentCenter:
							textLayout->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
							break;
						case Alignment::StringAlignmentFar:
							textLayout->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_TRAILING);
							break;
					}
					if (!element->GetMultiline() && !element->GetWrapLine())
					{
						switch (element->GetVerticalAlignment())
						{
							case Alignment::StringAlignmentNear:
								textLayout->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_NEAR);
								break;
							case Alignment::StringAlignmentCenter:
								textLayout->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
								break;
							case Alignment::StringAlignmentFar:
								textLayout->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_FAR);
								break;
						}
					}

					CRect textBounds = bounds;
					if (element->GetEllipse() && !element->GetMultiline() && !element->GetWrapLine())
					{
						textBounds = CRect(CPoint(textBounds.left, y), CSize(bounds.Width(), minSize.cy));
					}

					textLayout->SetMaxWidth((FLOAT)textBounds.Width());
					textLayout->SetMaxHeight((FLOAT)textBounds.Height());

					CComPtr<ID2D1RenderTarget> d2dRenderTarget = renderTarget->GetDirect2DRenderTarget();
					d2dRenderTarget->DrawTextLayout(
						D2D1::Point2F((FLOAT)textBounds.left, (FLOAT)textBounds.top),
						textLayout,
						brush,
						D2D1_DRAW_TEXT_OPTIONS_NO_SNAP
						);

					textLayout->SetTrimming(&trimming, inlineObject);
					if (oldMaxWidth != textBounds.Width())
					{
						oldMaxWidth = textBounds.Width();
						UpdateMinSize();
					}
				}
			}

			void SolidLabelElementRenderer::OnElementStateChanged()
			{
				if (renderTarget)
				{
					CColor color = element->GetColor();
					if (oldColor != color)
					{
						DestroyBrush(renderTarget);
						CreateBrush(renderTarget);
					}

					Font font = element->GetFont();
					if (oldFont != font)
					{
						DestroyTextFormat(renderTarget);
						CreateTextFormat(renderTarget);
					}
				}
				oldText = element->GetText();
				UpdateMinSize();
			}

			void SolidLabelElementRenderer::CreateBrush(PassRefPtr<ID2DRenderTarget> _renderTarget)
			{
				if (_renderTarget)
				{
					oldColor = element->GetColor();
					brush = _renderTarget->CreateDirect2DBrush(oldColor);
				}
			}

			void SolidLabelElementRenderer::DestroyBrush(PassRefPtr<ID2DRenderTarget> _renderTarget)
			{
				if (_renderTarget && brush)
				{
					_renderTarget->DestroyDirect2DBrush(oldColor);
					brush = nullptr;
				}
			}

			void SolidLabelElementRenderer::CreateTextFormat(PassRefPtr<ID2DRenderTarget> _renderTarget)
			{
				if (_renderTarget)
				{
					RefPtr<ID2DResourceManager> resourceManager = GetStorage()->GetDirect2DResourceManager();
					oldFont = element->GetFont();
					textFormat = resourceManager->CreateDirect2DTextFormat(oldFont);
				}
			}

			void SolidLabelElementRenderer::DestroyTextFormat(PassRefPtr<ID2DRenderTarget> _renderTarget)
			{
				if (_renderTarget && textFormat)
				{
					RefPtr<ID2DResourceManager> resourceManager = GetStorage()->GetDirect2DResourceManager();
					resourceManager->DestroyDirect2DTextFormat(oldFont);
					textFormat = nullptr;
				}
			}

			void SolidLabelElementRenderer::CreateTextLayout()
			{
				if (textFormat)
				{
					BSTR _text = oldText.AllocSysString();
					HRESULT hr = GetStorage()->GetDirect2DProvider()->GetDirectWriteFactory()->CreateTextLayout(
						_text,
						oldText.GetLength(),
						textFormat->textFormat,
						0,
						0,
						&textLayout);
					SysFreeString(_text);
					if (SUCCEEDED(hr))
					{
						if (oldFont.underline)
						{
							DWRITE_TEXT_RANGE textRange;
							textRange.startPosition = 0;
							textRange.length = oldText.GetLength();
							textLayout->SetUnderline(TRUE, textRange);
						}
						if (oldFont.strikeline)
						{
							DWRITE_TEXT_RANGE textRange;
							textRange.startPosition = 0;
							textRange.length = oldText.GetLength();
							textLayout->SetStrikethrough(TRUE, textRange);
						}
					}
					else
					{
						textLayout = nullptr;
					}
				}
			}

			void SolidLabelElementRenderer::DestroyTextLayout()
			{
				if (textLayout)
				{
					textLayout = nullptr;
				}
			}

			void SolidLabelElementRenderer::UpdateMinSize()
			{
				float maxWidth = 0;
				DestroyTextLayout();
				bool calculateSizeFromTextLayout = false;
				if (renderTarget)
				{
					if (element->GetWrapLine())
					{
						if (element->GetWrapLineHeightCalculation())
						{
							CreateTextLayout();
							if (textLayout)
							{
								maxWidth = textLayout->GetMaxWidth();
								if (oldMaxWidth != -1)
								{
									textLayout->SetWordWrapping(DWRITE_WORD_WRAPPING_WRAP);
									textLayout->SetMaxWidth((float)oldMaxWidth);
								}
								calculateSizeFromTextLayout = true;
							}
						}
					}
					else
					{
						CreateTextLayout();
						if (textLayout)
						{
							maxWidth = textLayout->GetMaxWidth();
							calculateSizeFromTextLayout = true;
						}
					}
				}
				if (calculateSizeFromTextLayout)
				{
					DWRITE_TEXT_METRICS metrics;
					HRESULT hr = textLayout->GetMetrics(&metrics);
					if (SUCCEEDED(hr))
					{
						cint width = 0;
						if (!element->GetEllipse() && !element->GetWrapLine() && !element->GetMultiline())
						{
							width = (cint)ceil(metrics.widthIncludingTrailingWhitespace);
						}
						minSize = CSize(width, (cint)ceil(metrics.height));
					}
					textLayout->SetMaxWidth(maxWidth);
				}
				else
				{
					minSize = CSize();
				}
			}

			void SolidLabelElementRenderer::InitializeInternal()
			{

			}

			void SolidLabelElementRenderer::FinalizeInternal()
			{
				DestroyTextLayout();
				DestroyBrush(renderTarget);
				DestroyTextFormat(renderTarget);
			}

			void SolidLabelElementRenderer::RenderTargetChangedInternal(PassRefPtr<ID2DRenderTarget> oldRenderTarget, PassRefPtr<ID2DRenderTarget> newRenderTarget)
			{
				DestroyBrush(oldRenderTarget.get());
				DestroyTextFormat(oldRenderTarget.get());
				CreateBrush(newRenderTarget.get());
				CreateTextFormat(newRenderTarget.get());
				UpdateMinSize();
			}
#pragma endregion SolidLabel
		}
	}
}