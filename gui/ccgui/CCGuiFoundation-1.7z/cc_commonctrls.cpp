#include "stdafx.h"
#include "cc_commonctrls.h"
#include "cc_presentation.h"

using namespace cc::presentation::windows;
using namespace cc::presentation::element;

namespace cc
{
	namespace global
	{
		PassRefPtr<Window> ControlFactory::NewWindow()
		{
			return adoptRef(new Window(GetStorage()->GetTheme()->CreateWindowStyle()));
		}

		PassRefPtr<Label> ControlFactory::NewLabel()
		{
			return adoptRef(new Label(GetStorage()->GetTheme()->CreateLabelStyle()));
		}

		PassRefPtr<Label> ControlFactory::NewHyperlinkLabel()
		{
			return adoptRef(new Label(GetStorage()->GetTheme()->CreateHyperlinkLabelStyle()));
		}
	}
}