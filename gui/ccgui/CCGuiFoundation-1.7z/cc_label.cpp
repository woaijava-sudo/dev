#include "stdafx.h"
#include "cc_commonctrls.h"
#include "cc_presentation.h"

using namespace cc::presentation::windows;
using namespace cc::presentation::element;

namespace cc
{
	namespace presentation
	{
		namespace control
		{
			namespace style
			{
#pragma region Label
				PassRefPtr<ILabelStyleController> Win8Style::CreateLabelStyle()
				{
					return adoptRef(new Win8LabelStyle);
				}

				PassRefPtr<ILabelStyleController> Win8Style::CreateHyperlinkLabelStyle()
				{
					return adoptRef(new Win8LabelStyle(true));
				}

				Label::Label(PassRefPtr<ILabelStyleController> _styleController)
					: Control(_styleController.get())
					, styleController(_styleController.get())
				{

				}

				Label::~Label()
				{

				}

				CColor Label::GetTextColor()
				{
					return textColor;
				}

				void Label::SetTextColor(CColor value)
				{
					if (textColor != value)
					{
						textColor = value;
						styleController->SetTextColor(textColor);
					}
				}


				Win8LabelStyle::Win8LabelStyle(bool forShortcutKey /*= false*/)
				{
					textElement = SolidLabelElement::Create();
					textElement->SetColor(GetDefaultTextColor());

					boundsComposition = adoptRef(new BoundsComposition);
					boundsComposition->SetMinSizeLimitation(BoundsComposition::LimitToElementAndChildren);
					
					if (forShortcutKey)
					{
						{
							RefPtr<SolidBorderElement> element = SolidBorderElement::Create();
							element->SetColor(CColor(100, 100, 100));
							boundsComposition->SetOwnedElement(element);
						}
						RefPtr<BoundsComposition> containerComposition = adoptRef(new BoundsComposition);
						{
							containerComposition->SetAlignmentToParent(CRect(1, 1, 1, 1));
							containerComposition->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
							boundsComposition->AddChild(containerComposition);
						}
						{
							RefPtr<SolidBackgroundElement> element = SolidBackgroundElement::Create();
							element->SetColor(CColor(Gdiplus::Color::White));
							containerComposition->SetOwnedElement(element);
						}
						{
							RefPtr<BoundsComposition> labelComposition = adoptRef(new BoundsComposition);
							labelComposition->SetAlignmentToParent(CRect(2, 2, 2, 2));
							labelComposition->SetMinSizeLimitation(Composition::LimitToElement);
							labelComposition->SetOwnedElement(textElement);
							containerComposition->AddChild(labelComposition);
						}
					}
					else
					{
						boundsComposition->SetOwnedElement(textElement);
					}
				}

				Win8LabelStyle::~Win8LabelStyle()
				{

				}

				PassRefPtr<BoundsComposition> Win8LabelStyle::GetBoundsComposition()
				{
					return boundsComposition;
				}

				PassRefPtr<Composition> Win8LabelStyle::GetContainerComposition()
				{
					return boundsComposition;
				}

				void Win8LabelStyle::SetFocusableComposition(PassRefPtr<Composition> value)
				{

				}

				void Win8LabelStyle::SetText(const CString& value)
				{
					textElement->SetText(value);
				}

				void Win8LabelStyle::SetFont(const Font& value)
				{
					textElement->SetFont(value);
				}

				void Win8LabelStyle::SetVisuallyEnabled(bool value)
				{

				}

				CColor Win8LabelStyle::GetDefaultTextColor()
				{
					return Win8WindowStyle::GetSystemTextColor(true);
				}

				void Win8LabelStyle::SetTextColor(CColor value)
				{
					textElement->SetColor(value);
				}
#pragma endregion Label
			}
		}
	}
}