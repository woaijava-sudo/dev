#include "stdafx.h"
#include "cc_presentation.h"
#include "cc_controller.h"
#include "cc_direct2d.h"

void SetupD2D();

namespace cc
{
	namespace presentation
	{
		namespace windows
		{
			GlobalStorage::GlobalStorage()
			{

			}

			GlobalStorage::~GlobalStorage()
			{

			}

			void GlobalStorage::Init(PassRefPtr<IController> controller,
				PassRefPtr<IControllerListener> contrllerListener,
				PassRefPtr<D2DControllerListener> controllerListenerD2D)
			{
				this->controller = controller;
				this->controllerListener = contrllerListener;
				this->controllerListenerD2D = controllerListenerD2D;
				debug_msgMap.reset(new MSGMAP);
				Msg_Init(*debug_msgMap);
			}
			
			void GlobalStorage::Init2(PassRefPtr<Application> application,
				PassRefPtr<ITheme> theme)
			{
				this->application = application;
				this->theme = theme;
			}

			void GlobalStorage::Destroy()
			{
				debug_msgMap.reset();

				theme.release();
				application.release();

				d2dProvider.release();
				d2dResourceManager.release();

				graphicsResourceManager.release();

				controllerListenerD2D.release();
				controllerListener.release();
				controller.release();
			}

			PassRefPtr<Application> GlobalStorage::GetApplication()
			{
				return application;
			}

			PassRefPtr<ITheme> GlobalStorage::GetTheme()
			{
				return theme;
			}

			PassRefPtr<IController> GlobalStorage::GetController()
			{
				return controller;
			}

			PassRefPtr<IControllerListener> GlobalStorage::GetControllerListener()
			{
				return controllerListener;
			}

			PassRefPtr<D2DControllerListener> GlobalStorage::GetDirect2DControllerListener()
			{
				return controllerListenerD2D;
			}

			PassRefPtr<GraphicsResourceManager> GlobalStorage::GetGraphicsResourceManager()
			{
				return graphicsResourceManager;
			}

			void GlobalStorage::SetGraphicsResourceManager(PassRefPtr<GraphicsResourceManager> resourceManager)
			{
				graphicsResourceManager = resourceManager;
			}

			bool GlobalStorage::RegisterFactories(PassRefPtr<IGraphicsElementFactory> elementFactory, PassRefPtr<IGraphicsRendererFactory> rendererFactory)
			{
				RefPtr<IGraphicsElementFactory> _elementFactory = elementFactory;
				RefPtr<IGraphicsRendererFactory> _rendererFactory = rendererFactory;
				if (graphicsResourceManager && _elementFactory && _rendererFactory)
				{
					if (graphicsResourceManager->RegisterElementFactory(_elementFactory))
					{
						if (graphicsResourceManager->RegisterRendererFactory(_elementFactory->GetElementTypeName(), _rendererFactory))
						{
							return true;
						}
					}
				}
				return false;
			}

			PassRefPtr<D2DResourceManager> GlobalStorage::GetDirect2DResourceManager()
			{
				return d2dResourceManager;
			}

			void GlobalStorage::SetDirect2DResourceManager(PassRefPtr<D2DResourceManager> resourceManager)
			{
				d2dResourceManager = resourceManager;
			}

			HINSTANCE GlobalStorage::GetInstance()
			{
				return (HINSTANCE)GetModuleHandle(NULL);
			}

			GlobalStorage* GlobalStorage::GetStorage()
			{
				static GlobalStorage This;
				return &This;
			}

			CComPtr<ID2D1RenderTarget> GlobalStorage::GetDirect2DRenderTarget(PassRefPtr<IWindow> window)
			{
				auto found = controllerListenerD2D->WindowListeners.find(window);
				return found == controllerListenerD2D->WindowListeners.end() ? nullptr : found->second->GetDirect2DRenderTarget();
			}

			void GlobalStorage::RecreateDirect2DRenderTarget(PassRefPtr<IWindow> window)
			{
				auto found = controllerListenerD2D->WindowListeners.find(window);
				if (found == controllerListenerD2D->WindowListeners.end())
				{
					found->second->RecreateRenderTarget();
				}
			}

			CComPtr<ID2D1Factory> GlobalStorage::GetDirect2DFactory()
			{
				return controllerListenerD2D->D2D1Factory;
			}

			CComPtr<IDWriteFactory> GlobalStorage::GetDirectWriteFactory()
			{
				return controllerListenerD2D->DWriteFactory;
			}

			PassRefPtr<ID2DProvider> GlobalStorage::GetDirect2DProvider()
			{
				return d2dProvider;
			}

			void GlobalStorage::SetDirect2DProvider(PassRefPtr<ID2DProvider> provider)
			{
				d2dProvider = provider;
			}

			LPCTSTR GlobalStorage::DebugGetMessageName(UINT message)
			{
				auto found = debug_msgMap->find(message);
				if (found != debug_msgMap->end())
					return found->second;
				else
					return _T("UNKNOWN");
			}

			GlobalStorage* GetStorage()
			{
				return GlobalStorage::GetStorage();
			}

			WinClass::WinClass(CString _name, bool shadow, bool ownDC, WNDPROC procedure, HINSTANCE hInstance)
			{
				name = _name;
				windowClass.cbSize = sizeof(windowClass);
				windowClass.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS | (shadow ? CS_DROPSHADOW : 0) | (ownDC ? CS_OWNDC : 0);
				windowClass.lpfnWndProc = procedure;
				windowClass.cbClsExtra = 0;
				windowClass.cbWndExtra = 0;
				windowClass.hInstance = hInstance;
				windowClass.hIcon = ::LoadIcon(NULL, IDI_APPLICATION);
				windowClass.hCursor = NULL;
				windowClass.hbrBackground = (HBRUSH)::GetStockObject(WHITE_BRUSH);
				windowClass.lpszMenuName = NULL;
				windowClass.lpszClassName = name.GetBuffer();
				windowClass.hIconSm = NULL;
				windowAtom = ::RegisterClassEx(&windowClass);
			}

			bool WinClass::IsAvailable() const
			{
				return windowAtom != 0;
			}

			CString WinClass::GetName() const
			{
				return name;
			}

			ATOM WinClass::GetClassAtom() const
			{
				return windowAtom;
			}
		}
	}
}
