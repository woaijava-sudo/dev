#include "stdafx.h"
#include <Gdiplus.h>
#include "cc_include.h"
#include "cc_base.h"
#include "cc_interface.h"
#include "cc_resource.h"
#include "cc_presentation.h"
#include "cc_controller.h"
#include "cc_direct2d.h"
#include "cc_control.h"
#include "cc_element.h"
#include "cc_commonctrls.h"

using namespace cc::interfaces::windows;
using namespace cc::presentation::control;
using namespace cc::presentation::control::composition;
using namespace cc::presentation::control::event_args;
using namespace cc::presentation::direct2d;
using namespace cc::presentation::direct2d::resource;
using namespace cc::presentation::element;
using namespace cc::presentation::windows;
using namespace cc::presentation::windows::controller;

void SetupD2D();

//////////////////////////////////////////////////////////////////////////

extern "C" CCGUI_API int SetupCCGuiFoundation()
{
	_tsetlocale(LC_CTYPE, _T("chs"));
	_CrtSetDbgFlag(_CRTDBG_LEAK_CHECK_DF | _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG));
// 	_CrtSetBreakAlloc(160);
	::CoInitializeEx(NULL, COINIT_MULTITHREADED);
	ULONG_PTR gdiplus_token;
	Gdiplus::GdiplusStartupInput gdiplusStartupInput;
	Gdiplus::GdiplusStartup(&gdiplus_token, &gdiplusStartupInput, NULL);
	SetupD2D();
	Gdiplus::GdiplusShutdown(gdiplus_token);
	::CoUninitialize();
	_CrtDumpMemoryLeaks();
	return 0;
}

void SetupD2D()
{
	auto * pStorage = GetStorage();
	auto instance = pStorage->GetInstance();
	{
		RefPtr<IController> controller = adoptRef(new Controller(instance));
		RefPtr<IControllerListener> controllerListener = adoptRef(new D2DControllerListener);
		pStorage->SetDirect2DProvider(adoptRef(new D2DProvider()));
		pStorage->Init(controller, controllerListener, controllerListener);
		RefPtr<Application> application = adoptRef(new Application);
		RefPtr<ITheme> theme = adoptRef(new Win8Style);
		pStorage->Init2(application, theme);
	}
	{
		auto callbackService = pStorage->GetController()->GetCallbackService();
		RefPtr<IControllerListener> listener = pStorage->GetControllerListener();
		callbackService->InstallListener(listener);
		callbackService->InstallListener(pStorage->GetApplication());
		{
			RefPtr<D2DResourceManager> resourseManager = adoptRef(new D2DResourceManager);
			pStorage->SetGraphicsResourceManager(resourseManager);
			pStorage->SetDirect2DResourceManager(resourseManager);
			callbackService->InstallListener(resourseManager);
			pStorage->GetController()->GetInputService()->StartTimer();
			{
				SolidBackgroundElementRenderer::Register();
				SolidBorderElementRenderer::Register();
				SolidLabelElementRenderer::Register();
			}
			{
				RefPtr<Window> window = cc::global::ControlFactory::NewWindow();
				{
					Font font;
					font.size = 48;
					font.fontFamily = _T("��������_GBK");

					window->SetText(_T("Test"));

					RefPtr<TableComposition> table = adoptRef(new TableComposition);
					table->SetRowsAndColumns(2, 2);
					table->SetRowOption(0, CellOption::PercentageOption(0.5));
					table->SetRowOption(1, CellOption::PercentageOption(0.5));
					table->SetColumnOption(0, CellOption::PercentageOption(0.5));
					table->SetColumnOption(1, CellOption::PercentageOption(0.5));
					table->SetAlignmentToParent(CRect());
					table->SetCellPadding(6);

					window->GetContainerComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
					window->GetContainerComposition()->AddChild(table);

					{
						RefPtr<CellComposition> cell = adoptRef(new CellComposition);
						cell->SetSite(0, 0, 1, 2);

						table->AddChild(cell);

						RefPtr<Label> label = cc::global::ControlFactory::NewLabel();
						{
							label->SetFont(font);
							label->SetText(_T("Welcome to CC GUI Foundation!\n����һ�����Գ���"));
							label->GetBoundsComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
							label->GetBoundsComposition()->SetAlignmentToParent(CRect());
						}

						cell->AddChild(label->GetBoundsComposition());
					}
					{
						RefPtr<CellComposition> cell = adoptRef(new CellComposition);
						cell->SetSite(1, 0, 1, 1);

						table->AddChild(cell);

						RefPtr<Label> label = cc::global::ControlFactory::NewLabel();
						{
							label->SetFont(font);
							label->SetText(_T("Welcome!"));
							label->GetBoundsComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
							label->GetBoundsComposition()->SetAlignmentToParent(CRect());
						}

						cell->AddChild(label->GetBoundsComposition());
					}
					{
						RefPtr<CellComposition> cell = adoptRef(new CellComposition);
						cell->SetSite(1, 1, 1, 1);

						table->AddChild(cell);

						RefPtr<Label> label = cc::global::ControlFactory::NewHyperlinkLabel();
						{
							RefPtr<ICursor> hand = GetStorage()->GetController()->GetResourceService()->GetSystemCursor(ICursor::Hand);
							label->GetBoundsComposition()->SetAssociatedCursor(hand);

							label->SetFont(font);
							label->SetText(_T("Welcome!"));
							label->GetBoundsComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
							label->GetBoundsComposition()->SetAlignmentToParent(CRect());

							label->GetEventReceiver()->mouseEnter.AttachLambda([](PassRefPtr<Composition> sender, EventArgs& arguments)
							{
								Font font = sender->GetRelatedControl()->GetFont();
								font.underline = true;
								sender->GetRelatedControl()->SetFont(font);
							});
							label->GetEventReceiver()->mouseLeave.AttachLambda([](PassRefPtr<Composition> sender, EventArgs& arguments)
							{
								Font font = sender->GetRelatedControl()->GetFont();
								font.underline = false;
								sender->GetRelatedControl()->SetFont(font);
							});
						}

						cell->AddChild(label->GetBoundsComposition());
					}

					window->ForceCalculateSizeImmediately();
					window->MoveToScreenCenter();
				}
				pStorage->GetApplication()->Run(window);
			}
			pStorage->SetDirect2DResourceManager(nullptr);
			pStorage->SetGraphicsResourceManager(nullptr);
		}
		callbackService->UninstallListener(pStorage->GetApplication());
		callbackService->UninstallListener(listener);
	}
	pStorage->Destroy();
}
