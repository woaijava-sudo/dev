#include "stdafx.h"
#include "cc_control.h"
#include "cc_presentation.h"
#include "cc_element.h"

using namespace cc::presentation::windows;

namespace cc
{
	namespace presentation
	{
		namespace control
		{
			Application::Application()
			{

			}

			Application::~Application()
			{

			}

			void Application::LeftButtonDown(CPoint position)
			{
				OnMouseDown(position);
			}

			void Application::RightButtonDown(CPoint position)
			{
				OnMouseDown(position);
			}

			void Application::ClipboardUpdated()
			{
				for (auto & window : windows)
				{
					EventArgs arguments = window->GetNotifyEventArguments();
					window->ClipboardUpdated.Execute(window->GetNotifyEventArguments());
					InvokeClipboardNotify(window->GetBoundsComposition(), arguments);
				}
			}

			void Application::RegisterWindow(Window* window)
			{
				windows.insert(window);
			}

			void Application::UnregisterWindow(Window* window)
			{
				windows.erase(window);
			}

			void Application::OnMouseDown(CPoint location)
			{
				RefPtr<Window> Window = GetWindow(location);
				for (auto & window : windows)
				{
					if (window != Window)
					{
						window->MouseClickedOnOtherWindow(window);
					}
				}
			}

			void Application::Run(PassRefPtr<Window> window)
			{
				if (!mainWindow)
				{
					mainWindow = window;
					GetStorage()->GetController()->GetWindowService()->Run(mainWindow->GetWindow());
					mainWindow.release();
				}
			}

			PassRefPtr<Window> Application::GetMainWindow()
			{
				return mainWindow;
			}

			vector<Window*>&& Application::GetWindows()
			{
				vector<Window*> _windows;
				copy(windows.begin(), windows.end(), _windows.begin());
				return move(_windows);
			}

			PassRefPtr<Window> Application::GetWindow(CPoint location)
			{
				RefPtr<IWindow> Window = GetStorage()->GetController()->GetWindowService()->GetWindow(location);
				if (Window)
				{
					for (auto & window : windows)
					{
						if (window->GetWindow() == Window)
						{
							return window;
						}
					}
				}
				return nullptr;
			}

			void Application::InvokeClipboardNotify(PassRefPtr<Composition> composition, EventArgs& arguments)
			{
				RefPtr<Composition> _composition = composition;
				if (_composition->HasEventReceiver())
				{
					_composition->GetEventReceiver()->clipboardNotify.Execute(arguments);
				}
				for (auto & subComposition : _composition->Children())
				{
					InvokeClipboardNotify(subComposition, arguments);
				}
			}

			bool Application::IsInMainThread()
			{
				return GetStorage()->GetController()->GetAsyncService()->IsInMainThread();
			}

			void Application::InvokeAsync(const Action& proc)
			{
				return GetStorage()->GetController()->GetAsyncService()->InvokeAsync(proc);
			}

			void Application::InvokeInMainThread(const Action& proc)
			{
				return GetStorage()->GetController()->GetAsyncService()->InvokeInMainThread(proc);
			}

			bool Application::InvokeInMainThreadAndWait(const Action& proc, cint milliseconds /*= -1*/)
			{
				return GetStorage()->GetController()->GetAsyncService()->InvokeInMainThreadAndWait(proc);
			}

			PassRefPtr<IDelay> Application::DelayExecute(const Action& proc, cint milliseconds)
			{
				return GetStorage()->GetController()->GetAsyncService()->DelayExecute(proc, milliseconds);
			}

			PassRefPtr<IDelay> Application::DelayExecuteInMainThread(const Action& proc, cint milliseconds)
			{
				return GetStorage()->GetController()->GetAsyncService()->DelayExecuteInMainThread(proc, milliseconds);
			}

			void Application::RunTask(const Action& proc)
			{
				if (IsInMainThread())
				{
					proc();
				}
				else
				{
					InvokeInMainThreadAndWait([&proc]()
					{
						proc();
					});
				}
			}

			Control::Control(PassRefPtr<IControlStyleController> _styleController)
				: parent(nullptr)
				, styleController(_styleController.get())
				, boundsComposition(_styleController->GetBoundsComposition())
				, eventReceiver(_styleController->GetBoundsComposition()->GetEventReceiver())
				, isEnabled(true)
				, isVisuallyEnabled(true)
				, isVisible(true)
			{
				relaxAdoptionRequirement();
				boundsComposition->SetAssociatedControl(this);
				VisibleChanged.SetAssociatedComposition(boundsComposition);
				EnabledChanged.SetAssociatedComposition(boundsComposition);
				VisuallyEnabledChanged.SetAssociatedComposition(boundsComposition);
				AltChanged.SetAssociatedComposition(boundsComposition);
				TextChanged.SetAssociatedComposition(boundsComposition);
				FontChanged.SetAssociatedComposition(boundsComposition);

				font = GetStorage()->GetController()->GetResourceService()->GetDefaultFont();
				styleController->SetFont(font);
				styleController->SetText(text);
				styleController->SetVisuallyEnabled(isVisuallyEnabled);
			}

			Control::~Control()
			{
				if (parent || !styleController)
				{
					children.clear();
				}
				else
				{
					for (auto it = children.rbegin(); it != children.rend(); it++)
					{
						(*it)->GetBoundsComposition()->GetParent()->RemoveChild((*it)->GetBoundsComposition());
					}
					children.clear();
					boundsComposition.release();
				}
			}

			EventArgs Control::GetNotifyEventArguments()
			{
				return EventArgs(boundsComposition);
			}

			PassRefPtr<IControlStyleController> Control::GetStyleController()
			{
				return styleController;
			}

			PassRefPtr<BoundsComposition> Control::GetBoundsComposition()
			{
				return boundsComposition;
			}

			PassRefPtr<Composition> Control::GetContainerComposition()
			{
				return styleController->GetContainerComposition();
			}

			PassRefPtr<Composition> Control::GetFocusableComposition()
			{
				return focusableComposition;
			}

			PassRefPtr<EventReceiver> Control::GetEventReceiver()
			{
				return eventReceiver;
			}

			PassRefPtr<Control> Control::GetParent()
			{
				return parent;
			}

			cint Control::GetChildrenCount()
			{
				return children.size();
			}

			PassRefPtr<Control> Control::GetChild(cint index)
			{
				return children[index];
			}

			bool Control::AddChild(PassRefPtr<Control> control)
			{
				return GetContainerComposition()->AddChild(control->GetBoundsComposition());
			}

			bool Control::HasChild(PassRefPtr<Control> control)
			{
				return find(children.begin(), children.end(), control) != children.end();
			}

			PassRefPtr<ControlHost> Control::GetRelatedControlHost()
			{
				return parent ? parent->GetRelatedControlHost() : nullptr;
			}

			bool Control::GetVisuallyEnabled()
			{
				return isVisuallyEnabled;
			}

			bool Control::GetEnabled()
			{
				return isEnabled;
			}

			void Control::SetEnabled(bool value)
			{
				if ((isEnabled && !value) || (!isEnabled && value))
				{
					isEnabled = value;
					EnabledChanged.Execute(GetNotifyEventArguments());
					UpdateVisuallyEnabled();
				}
			}

			bool Control::GetVisible()
			{
				return isVisible;
			}

			void Control::SetVisible(bool value)
			{
				boundsComposition->SetVisible(value);
				if ((isVisible && !value) || (!isVisible && value))
				{
					isVisible = value;
					VisibleChanged.Execute(GetNotifyEventArguments());
				}
			}

			const CString& Control::GetAlt()
			{
				return alt;
			}

			bool Control::SetAlt(const CString& value)
			{
				if (alt != value)
				{
					alt = value;
					AltChanged.Execute(GetNotifyEventArguments());
				}
				return true;
			}

			const CString& Control::GetText()
			{
				return text;
			}

			void Control::SetText(const CString& value)
			{
				if (text != value)
				{
					text = value;
					styleController->SetText(text);
					TextChanged.Execute(GetNotifyEventArguments());
				}
			}

			const Font& Control::GetFont()
			{
				return font;
			}

			void Control::SetFont(const Font& value)
			{
				if (font != value)
				{
					font = value;
					styleController->SetFont(font);
					FontChanged.Execute(GetNotifyEventArguments());
				}
			}

			void Control::SetFocus()
			{
				if (focusableComposition)
				{
					RefPtr<GraphicsHost> host = focusableComposition->GetRelatedGraphicsHost();
					if (host)
					{
						host->SetFocus(focusableComposition);
					}
				}
			}

			void Control::OnChildInserted(PassRefPtr<Control> control)
			{
				RefPtr<Control> _control = control;
				RefPtr<Control> oldParent = _control->parent;
				children.push_back(_control);
				_control->parent = this;
				_control->OnParentChanged(oldParent, _control->parent);
				_control->UpdateVisuallyEnabled();
			}

			void Control::OnChildRemoved(PassRefPtr<Control> control)
			{
				RefPtr<Control> _control = control;
				RefPtr<Control> oldParent = _control->parent;
				_control->parent = nullptr;
				children.erase(find(children.begin(), children.end(), _control));
				_control->OnParentChanged(oldParent, _control->parent);
			}

			void Control::OnParentChanged(PassRefPtr<Control> oldParent, PassRefPtr<Control> newParent)
			{
				OnParentLineChanged();
			}

			void Control::OnParentLineChanged()
			{
				for (auto & child : children)
				{
					child->OnParentLineChanged();
				}
			}

			void Control::OnRenderTargetChanged(PassRefPtr<IGraphicsRenderTarget> renderTarget)
			{

			}

			void Control::OnBeforeReleaseGraphicsHost()
			{
				for (auto & child : children)
				{
					child->OnBeforeReleaseGraphicsHost();
				}
			}

			void Control::UpdateVisuallyEnabled()
			{
				bool newValue = isEnabled && (parent == nullptr ? true : parent->GetVisuallyEnabled());
				if (isVisuallyEnabled != newValue)
				{
					isVisuallyEnabled = newValue;
					styleController->SetVisuallyEnabled(isVisuallyEnabled);
					VisuallyEnabledChanged.Execute(GetNotifyEventArguments());

					for (auto & child : children)
					{
						child->UpdateVisuallyEnabled();
					}
				}
			}

			void Control::SetFocusableComposition(PassRefPtr<Composition> value)
			{
				if (focusableComposition != value)
				{
					focusableComposition = value;
					styleController->SetFocusableComposition(focusableComposition);
				}
			}

			Component::Component()
			{

			}

			Component::~Component()
			{

			}

			void Component::Attach(PassRefPtr<ControlHostRoot> rootObject)
			{

			}

			void Component::Detach(PassRefPtr<ControlHostRoot> rootObject)
			{

			}

			ControlHostRoot::ControlHostRoot()
			{

			}

			ControlHostRoot::~ControlHostRoot()
			{

			}

			bool ControlHostRoot::AddComponent(PassRefPtr<Component> component)
			{
				RefPtr<Component> _component = component;
				if (!components.insert(_component).second)
				{
					return false;
				}
				else
				{
					_component->Attach(this);
					return true;
				}
			}

			bool ControlHostRoot::RemoveComponent(PassRefPtr<Component> component)
			{
				RefPtr<Component> _component = component;
				if (components.erase(_component) == 1)
				{
					_component->Detach(this);
					return true;
				}
				return false;
			}

			bool ControlHostRoot::ContainsComponent(PassRefPtr<Component> component)
			{
				return components.find(component) != components.end();
			}

			void ControlHostRoot::ClearComponents()
			{
				for (auto & component : components)
				{
					component->Detach(this);
				}
				components.clear();
			}

			void ControlHostRoot::FinalizeInstance()
			{
				ClearComponents();
			}

			ControlHost::ControlHost(PassRefPtr<IControlStyleController> _styleController)
				: Control(_styleController.get())
			{
				GetStyleController()->GetBoundsComposition()->SetAlignmentToParent(CRect());

				WindowGotFocus.SetAssociatedComposition(GetStyleController()->GetBoundsComposition());
				WindowLostFocus.SetAssociatedComposition(GetStyleController()->GetBoundsComposition());
				WindowActivated.SetAssociatedComposition(GetStyleController()->GetBoundsComposition());
				WindowDeactivated.SetAssociatedComposition(GetStyleController()->GetBoundsComposition());
				WindowOpened.SetAssociatedComposition(GetStyleController()->GetBoundsComposition());
				WindowClosing.SetAssociatedComposition(GetStyleController()->GetBoundsComposition());
				WindowClosed.SetAssociatedComposition(GetStyleController()->GetBoundsComposition());
				WindowDestroying.SetAssociatedComposition(GetStyleController()->GetBoundsComposition());

				host = adoptRef(new GraphicsHost);
				host->GetMainComposition()->AddChild(GetStyleController()->GetBoundsComposition());
			}

			ControlHost::~ControlHost()
			{
				OnBeforeReleaseGraphicsHost();
				FinalizeInstance();
				styleController = nullptr;
			}

			PassRefPtr<GraphicsHost> ControlHost::GetGraphicsHost()
			{
				return host;
			}

			PassRefPtr<Composition> ControlHost::GetMainComposition()
			{
				return host->GetMainComposition();
			}

			PassRefPtr<IWindow> ControlHost::GetWindow()
			{
				return host->GetWindow();
			}

			void ControlHost::SetWindow(PassRefPtr<IWindow> window)
			{
				if (host->GetWindow())
				{
					host->GetWindow()->UninstallListener(this);
				}
				host->SetWindow(window);
				if (host->GetWindow())
				{
					host->GetWindow()->InstallListener(this);
				}
				OnWindowChanged();
			}

			void ControlHost::ForceCalculateSizeImmediately()
			{
				boundsComposition->ForceCalculateSizeImmediately();
				SetBounds(GetBounds());
			}

			bool ControlHost::GetEnabled()
			{
				if (host->GetWindow())
				{
					return host->GetWindow()->IsEnabled();
				}
				else
				{
					return false;
				}
			}

			void ControlHost::SetEnabled(bool value)
			{
				if (host->GetWindow())
				{
					if (value)
					{
						host->GetWindow()->Enable();
					}
					else
					{
						host->GetWindow()->Disable();
					}
				}
			}

			bool ControlHost::GetFocused()
			{
				if (host->GetWindow())
				{
					return host->GetWindow()->IsFocused();
				}
				else
				{
					return false;
				}
			}

			void ControlHost::SetFocused()
			{
				if (host->GetWindow())
				{
					host->GetWindow()->SetFocus();
				}
			}

			bool ControlHost::GetActivated()
			{
				if (host->GetWindow())
				{
					return host->GetWindow()->IsActivated();
				}
				else
				{
					return false;
				}
			}

			void ControlHost::SetActivated()
			{
				if (host->GetWindow())
				{
					host->GetWindow()->SetActivate();
				}
			}

			bool ControlHost::GetShowInTaskBar()
			{
				if (host->GetWindow())
				{
					return host->GetWindow()->IsAppearedInTaskBar();
				}
				else
				{
					return false;
				}
			}

			void ControlHost::SetShowInTaskBar(bool value)
			{
				if (host->GetWindow())
				{
					if (value)
					{
						host->GetWindow()->ShowInTaskBar();
					}
					else
					{
						host->GetWindow()->HideInTaskBar();
					}
				}
			}

			bool ControlHost::GetEnabledActivate()
			{
				if (host->GetWindow())
				{
					return host->GetWindow()->IsEnabledActivate();
				}
				else
				{
					return false;
				}
			}

			void ControlHost::SetEnabledActivate(bool value)
			{
				if (host->GetWindow())
				{
					if (value)
					{
						host->GetWindow()->EnableActivate();
					}
					else
					{
						host->GetWindow()->DisableActivate();
					}
				}
			}

			bool ControlHost::GetTopMost()
			{
				if (host->GetWindow())
				{
					return host->GetWindow()->GetTopMost();
				}
				else
				{
					return false;
				}
			}

			void ControlHost::SetTopMost(bool topmost)
			{
				if (host->GetWindow())
				{
					host->GetWindow()->SetTopMost(topmost);
				}
			}

			CSize ControlHost::GetClientSize()
			{
				if (host->GetWindow())
				{
					return host->GetWindow()->GetClientSize();
				}
				else
				{
					return CSize();
				}
			}

			void ControlHost::SetClientSize(CSize value)
			{
				if (host->GetWindow())
				{
					host->GetWindow()->SetClientSize(value);
				}
			}

			CRect ControlHost::GetBounds()
			{
				if (host->GetWindow())
				{
					return host->GetWindow()->GetBounds();
				}
				else
				{
					return CRect();
				}
			}

			void ControlHost::SetBounds(CRect value)
			{
				if (host->GetWindow())
				{
					host->GetWindow()->SetBounds(value);
				}
			}

			PassRefPtr<ControlHost> ControlHost::GetRelatedControlHost()
			{
				return this;
			}

			const CString& ControlHost::GetText()
			{
				CString result;
				if (host->GetWindow())
				{
					result = host->GetWindow()->GetTitle();
				}
				if (result != Control::GetText())
				{
					Control::SetText(result);
				}
				return Control::GetText();
			}

			void ControlHost::SetText(const CString& value)
			{
				if (host->GetWindow())
				{
					host->GetWindow()->SetTitle(value);
					Control::SetText(value);
				}
			}

			PassRefPtr<IScreen> ControlHost::GetRelatedScreen()
			{
				if (host->GetWindow())
				{
					return GetStorage()->GetController()->GetScreenService()->GetScreen(host->GetWindow());
				}
				else
				{
					return nullptr;
				}
			}

			void ControlHost::Show()
			{
				if (host->GetWindow())
				{
					host->GetWindow()->Show();
				}
			}

			void ControlHost::ShowDeactivated()
			{
				if (host->GetWindow())
				{
					host->GetWindow()->ShowDeactivated();
				}
			}

			void ControlHost::ShowRestored()
			{
				if (host->GetWindow())
				{
					host->GetWindow()->ShowRestored();
				}
			}

			void ControlHost::ShowMaximized()
			{
				if (host->GetWindow())
				{
					host->GetWindow()->ShowMaximized();
				}
			}

			void ControlHost::ShowMinimized()
			{
				if (host->GetWindow())
				{
					host->GetWindow()->ShowMinimized();
				}
			}

			void ControlHost::Hide()
			{
				if (host->GetWindow())
				{
					host->GetWindow()->Hide();
				}
			}

			void ControlHost::Close()
			{
				RefPtr<IWindow> window = host->GetWindow();
				if (window)
				{
					if (GetStorage()->GetController()->GetWindowService()->GetMainWindow() != window)
					{
						window->Hide();
					}
					else
					{
						SetWindow(nullptr);
						GetStorage()->GetController()->GetWindowService()->DestroyWindow(window);
					}
				}
			}

			bool ControlHost::GetOpening()
			{
				RefPtr<IWindow> window = host->GetWindow();
				if (window)
				{
					return window->IsVisible();
				}
				return false;
			}

			void ControlHost::OnWindowChanged()
			{

			}

			void ControlHost::OnVisualStatusChanged()
			{

			}

			void ControlHost::MouseMoving(const MouseInfo& info)
			{

			}

			void ControlHost::MouseLeaved()
			{

			}

			void ControlHost::Moved()
			{
				OnVisualStatusChanged();
			}

			void ControlHost::Enabled()
			{
				Control::SetEnabled(true);
				OnVisualStatusChanged();
			}

			void ControlHost::Disabled()
			{
				Control::SetEnabled(false);
				OnVisualStatusChanged();
			}

			void ControlHost::GotFocus()
			{
				WindowGotFocus.Execute(GetNotifyEventArguments());
				OnVisualStatusChanged();
			}

			void ControlHost::LostFocus()
			{
				WindowLostFocus.Execute(GetNotifyEventArguments());
				OnVisualStatusChanged();
			}

			void ControlHost::Activated()
			{
				WindowActivated.Execute(GetNotifyEventArguments());
				OnVisualStatusChanged();
			}

			void ControlHost::Deactivated()
			{
				WindowDeactivated.Execute(GetNotifyEventArguments());
				OnVisualStatusChanged();
			}

			void ControlHost::Opened()
			{
				WindowOpened.Execute(GetNotifyEventArguments());
			}

			void ControlHost::Closing(bool& cancel)
			{
				RequestEventArgs arguments(GetStyleController()->GetBoundsComposition());
				arguments.cancel = cancel;
				WindowClosing.Execute(arguments);
				if (!arguments.handled)
				{
					cancel = arguments.cancel;
				}
			}

			void ControlHost::Closed()
			{
				WindowClosed.Execute(GetNotifyEventArguments());
			}

			void ControlHost::Destroying()
			{
				WindowDestroying.Execute(GetNotifyEventArguments());
				SetWindow(nullptr);
			}

			GraphicsHost::GraphicsHost()
				: lastCaretTime(0)
				, CaretInterval(500)
			{
				relaxAdoptionRequirement();
				windowComposition = adoptRef(new WindowComposition);
				windowComposition->SetAssociatedHost(this);
				windowComposition->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
			}

			GraphicsHost::~GraphicsHost()
			{

			}

			PassRefPtr<IWindow> GraphicsHost::GetWindow()
			{
				return window;
			}

			void GraphicsHost::SetWindow(PassRefPtr<IWindow> _window)
			{
				if (window != _window)
				{
					if (window)
					{
						GetStorage()->GetController()->GetCallbackService()->UninstallListener(this);
						window->UninstallListener(this);
					}
					window = _window;
					windowComposition->SetAttachedWindow(window);
					if (window)
					{
						window->InstallListener(this);
						GetStorage()->GetController()->GetCallbackService()->InstallListener(this);
						previousClientSize = window->GetClientSize();
						minSize = windowComposition->GetPreferredBounds().Size();
						window->SetCaretPoint(caretPoint);
					}
				}
			}

			PassRefPtr<Composition> GraphicsHost::GetMainComposition()
			{
				return windowComposition;
			}

			void GraphicsHost::Render()
			{
				if (window && window->IsVisible())
				{
					windowComposition->GetRenderTarget()->StartRendering();
					windowComposition->Render(CSize());
					bool success = windowComposition->GetRenderTarget()->StopRendering();
					window->RedrawContent();

					if (!success)
					{
						windowComposition->SetAttachedWindow(nullptr);
						GetStorage()->GetGraphicsResourceManager()->RecreateRenderTarget(window);
						windowComposition->SetAttachedWindow(window);
					}
				}
			}

			bool GraphicsHost::SetFocus(PassRefPtr<Composition> composition)
			{
				RefPtr<Composition> _composition = composition;
				if (!_composition || _composition->GetRelatedGraphicsHost() != this)
				{
					return false;
				}
				if (focusedComposition && focusedComposition->HasEventReceiver())
				{
					EventArgs arguments;
					arguments.compositionSource = focusedComposition;
					arguments.eventSource = focusedComposition;
					focusedComposition->GetEventReceiver()->lostFocus.Execute(arguments);
				}
				focusedComposition = _composition;
				SetCaretPoint(CPoint());
				if (focusedComposition && focusedComposition->HasEventReceiver())
				{
					EventArgs arguments;
					arguments.compositionSource = focusedComposition;
					arguments.eventSource = focusedComposition;
					focusedComposition->GetEventReceiver()->gotFocus.Execute(arguments);
				}
				return true;
			}

			PassRefPtr<Composition> GraphicsHost::GetFocusedComposition()
			{
				return focusedComposition;
			}

			CPoint GraphicsHost::GetCaretPoint()
			{
				return caretPoint;
			}

			void GraphicsHost::SetCaretPoint(CPoint value, PassRefPtr<Composition> referenceComposition /*= nullptr*/)
			{
				if (referenceComposition)
				{
					CRect bounds = referenceComposition->GetGlobalBounds();
					value += bounds.TopLeft();
				}
				caretPoint = value;
				if (window)
				{
					window->SetCaretPoint(caretPoint);
				}
			}

			void GraphicsHost::DisconnectComposition(PassRefPtr<Composition> composition)
			{
				DisconnectCompositionInternal(composition);
			}

			void GraphicsHost::DisconnectCompositionInternal(PassRefPtr<Composition> composition)
			{
				RefPtr<Composition> _composition = composition;
				for (auto & child : _composition->Children())
				{
					DisconnectCompositionInternal(child);
				}
				if (mouseCaptureComposition == _composition)
				{
					if (window)
					{
						window->ReleaseCapture();
					}
					mouseCaptureComposition = nullptr;
				}
				if (focusedComposition == _composition)
				{
					focusedComposition = nullptr;
				}
				mouseEnterCompositions.erase(find(mouseEnterCompositions.begin(), mouseEnterCompositions.end(), _composition));
			}

			void GraphicsHost::MouseCapture(const MouseInfo& info)
			{
				if (window && (info.left || info.middle || info.right))
				{
					if (!window->IsCapturing() && !info.nonClient)
					{
						window->RequireCapture();
						mouseCaptureComposition = windowComposition->FindComposition(info.pt);
					}
				}
			}

			void GraphicsHost::MouseUncapture(const MouseInfo& info)
			{
				if (window && !(info.left || info.middle || info.right))
				{
					window->ReleaseCapture();
					mouseCaptureComposition = nullptr;
				}
			}

			void GraphicsHost::OnCharInput(const CharInfo& info, PassRefPtr<Composition> composition, CharEvent EventReceiver::* eventReceiverEvent)
			{
				vector<RefPtr<Composition>> compositions;
				RefPtr<Composition> _composition = composition;
				while (_composition)
				{
					if (_composition->HasEventReceiver())
					{
						compositions.push_back(_composition);
					}
					_composition = _composition->GetParent();
				}

				CharEventArgs arguments(_composition);
				(CharInfo&)arguments = info;

				for (auto it = compositions.rbegin(); it != compositions.rend(); it++)
				{
					(*it)->GetEventReceiver()->previewCharInput.Execute(arguments);
					if (arguments.handled)
					{
						return;
					}
				}

				for (auto & __composition : compositions)
				{
					(__composition->GetEventReceiver().get()->*eventReceiverEvent).Execute(arguments);
					if (arguments.handled)
					{
						return;
					}
				}
			}

			void GraphicsHost::OnKeyInput(const KeyInfo& info, PassRefPtr<Composition> composition, KeyEvent EventReceiver::* eventReceiverEvent)
			{
				vector<RefPtr<Composition>> compositions;
				RefPtr<Composition> _composition = composition;
				while (_composition)
				{
					if (_composition->HasEventReceiver())
					{
						compositions.push_back(_composition);
					}
					_composition = _composition->GetParent();
				}

				KeyEventArgs arguments(_composition);
				(KeyInfo&)arguments = info;

				for (auto it = compositions.rbegin(); it != compositions.rend(); it++)
				{
					(*it)->GetEventReceiver()->previewKey.Execute(arguments);
					if (arguments.handled)
					{
						return;
					}
				}

				for (auto & __composition : compositions)
				{
					(__composition->GetEventReceiver().get()->*eventReceiverEvent).Execute(arguments);
					if (arguments.handled)
					{
						return;
					}
				}
			}

			void GraphicsHost::RaiseMouseEvent(MouseEventArgs& arguments, PassRefPtr<Composition> composition, MouseEvent EventReceiver::* eventReceiverEvent)
			{
				RefPtr<Composition> _composition = composition;
				arguments.compositionSource = _composition;
				arguments.eventSource = nullptr;
				CPoint pt = arguments.pt;

				while (_composition)
				{
					if (_composition->HasEventReceiver())
					{
						if (!arguments.eventSource)
						{
							arguments.eventSource = _composition;
						}
						RefPtr<EventReceiver> eventReceiver = _composition->GetEventReceiver();
						(eventReceiver.get()->*eventReceiverEvent).Execute(arguments);
						if (arguments.handled)
						{
							break;
						}
					}

					RefPtr<Composition> parent = _composition->GetParent();
					if (parent)
					{
						CRect parentBounds = parent->GetBounds();
						CRect clientArea = parent->GetClientArea();
						CRect childBounds = _composition->GetBounds();

						pt += childBounds.TopLeft() + clientArea.TopLeft() - parentBounds.TopLeft();
						arguments.pt = pt;
					}
					_composition = parent;
				}
			}

			void GraphicsHost::OnMouseInput(const MouseInfo& info, MouseEvent EventReceiver::* eventReceiverEvent)
			{
				RefPtr<Composition> _composition;
				if (mouseCaptureComposition)
				{
					_composition = mouseCaptureComposition;
				}
				else
				{
					_composition = windowComposition->FindComposition(info.pt);
				}
				if (_composition)
				{
					CRect bounds = _composition->GetGlobalBounds();
					MouseEventArgs arguments;
					(MouseInfo&)arguments = info;
					arguments.pt -= bounds.TopLeft();
					RaiseMouseEvent(arguments, _composition, eventReceiverEvent);
				}
			}

			IWindowListener::HitTestResult GraphicsHost::HitTest(CPoint location)
			{
				CRect bounds = window->GetBounds();
				CRect clientBounds = window->GetClientBoundsInScreen();
				CPoint clientLocation = location + bounds.TopLeft() - clientBounds.TopLeft();
				RefPtr<Composition> hitComposition = windowComposition->FindComposition(clientLocation);
				while (hitComposition)
				{
					IWindowListener::HitTestResult result = hitComposition->GetAssociatedHitTestResult();
					if (result == IWindowListener::NoDecision)
					{
						hitComposition = hitComposition->GetParent();
					}
					else
					{
						return result;
					}
				}
				return IWindowListener::NoDecision;
			}

			void GraphicsHost::Moving(CRect& bounds, bool fixSizeOnly)
			{
				CRect oldBounds = window->GetBounds();
				minSize = windowComposition->GetPreferredBounds().Size();
				CSize minWindowSize = minSize + (oldBounds.Size() - window->GetClientSize());
				if (bounds.Width() < minWindowSize.cx)
				{
					if (fixSizeOnly)
					{
						if (bounds.Width() < minWindowSize.cx)
						{
							bounds.right = bounds.left + minWindowSize.cx;
						}
					}
					else if (oldBounds.left != bounds.left)
					{
						bounds.left = oldBounds.right - minWindowSize.cx;
					}
					else if (oldBounds.right != bounds.right)
					{
						bounds.right = oldBounds.left + minWindowSize.cx;
					}
				}
				if (bounds.Height() < minWindowSize.cy)
				{
					if (fixSizeOnly)
					{
						if (bounds.Height() < minWindowSize.cy)
						{
							bounds.bottom = bounds.top + minWindowSize.cy;
						}
					}
					else if (oldBounds.top != bounds.top)
					{
						bounds.top = oldBounds.bottom - minWindowSize.cy;
					}
					else if (oldBounds.bottom != bounds.bottom)
					{
						bounds.bottom = oldBounds.top + minWindowSize.cy;
					}
				}
			}

			void GraphicsHost::Moved()
			{
				CSize size = window->GetClientSize();
				if (previousClientSize != size)
				{
					previousClientSize = size;
					minSize = windowComposition->GetPreferredBounds().Size();
					Render();
				}
			}

			void GraphicsHost::LeftButtonDown(const MouseInfo& info)
			{
				MouseCapture(info);
				OnMouseInput(info, &EventReceiver::leftButtonDown);
			}

			void GraphicsHost::LeftButtonUp(const MouseInfo& info)
			{
				OnMouseInput(info, &EventReceiver::leftButtonUp);
				MouseUncapture(info);
			}

			void GraphicsHost::LeftButtonDoubleClick(const MouseInfo& info)
			{
				LeftButtonDown(info);
				OnMouseInput(info, &EventReceiver::leftButtonDoubleClick);
			}

			void GraphicsHost::RightButtonDown(const MouseInfo& info)
			{
				MouseCapture(info);
				OnMouseInput(info, &EventReceiver::rightButtonDown);
			}

			void GraphicsHost::RightButtonUp(const MouseInfo& info)
			{
				OnMouseInput(info, &EventReceiver::rightButtonUp);
				MouseUncapture(info);
			}

			void GraphicsHost::RightButtonDoubleClick(const MouseInfo& info)
			{
				RightButtonDown(info);
				OnMouseInput(info, &EventReceiver::rightButtonDoubleClick);
			}

			void GraphicsHost::MiddleButtonDown(const MouseInfo& info)
			{
				MouseCapture(info);
				OnMouseInput(info, &EventReceiver::middleButtonDown);
			}

			void GraphicsHost::MiddleButtonUp(const MouseInfo& info)
			{
				OnMouseInput(info, &EventReceiver::middleButtonUp);
				MouseUncapture(info);
			}

			void GraphicsHost::MiddleButtonDoubleClick(const MouseInfo& info)
			{
				MiddleButtonDown(info);
				OnMouseInput(info, &EventReceiver::middleButtonDoubleClick);
			}

			void GraphicsHost::HorizontalWheel(const MouseInfo& info)
			{
				OnMouseInput(info, &EventReceiver::horizontalWheel);
			}

			void GraphicsHost::VerticalWheel(const MouseInfo& info)
			{
				OnMouseInput(info, &EventReceiver::verticalWheel);
			}

			void GraphicsHost::MouseMoving(const MouseInfo& info)
			{
				CompositionList newCompositions;
				{
					RefPtr<Composition> _composition = windowComposition->FindComposition(info.pt);
					while (_composition)
					{
						newCompositions.insert(newCompositions.begin(), _composition);
						_composition = _composition->GetParent();
					}
				}

				cint firstDifferentIndex = mouseEnterCompositions.size();
				for (cint i = 0; i < (cint)mouseEnterCompositions.size(); i++)
				{
					if (i == newCompositions.size())
					{
						firstDifferentIndex = newCompositions.size();
						break;
					}
					if (mouseEnterCompositions[i] != newCompositions[i])
					{
						firstDifferentIndex = i;
						break;
					}
				}

				for (cint i = (cint)mouseEnterCompositions.size() - 1; i >= firstDifferentIndex; i--)
				{
					RefPtr<Composition> _composition = mouseEnterCompositions[i];
					if (_composition->HasEventReceiver())
					{
						_composition->GetEventReceiver()->mouseLeave.Execute(EventArgs(_composition));
					}
				}

				mouseEnterCompositions.resize(newCompositions.size());
				copy(newCompositions.begin(), newCompositions.end(), mouseEnterCompositions.begin());
				for (cint i = firstDifferentIndex; i < (cint)mouseEnterCompositions.size(); i++)
				{
					RefPtr<Composition> _composition = mouseEnterCompositions[i];
					if (_composition->HasEventReceiver())
					{
						_composition->GetEventReceiver()->mouseEnter.Execute(EventArgs(_composition));
					}
				}

				RefPtr<ICursor> cursor;
				if (newCompositions.size() > 0)
				{
					cursor = (*newCompositions.rbegin())->GetRelatedCursor();
				}
				if (cursor)
				{
					window->SetCursor(cursor);
				}
				else
				{
					window->SetCursor(GetStorage()->GetController()->GetResourceService()->GetDefaultSystemCursor());
				}

				OnMouseInput(info, &EventReceiver::mouseMove);
			}

			void GraphicsHost::MouseEntered()
			{

			}

			void GraphicsHost::MouseLeaved()
			{
				for (auto it = mouseEnterCompositions.rbegin(); it != mouseEnterCompositions.rend(); it++)
				{
					RefPtr<Composition>& _composition = *it;
					if (_composition->HasEventReceiver())
					{
						_composition->GetEventReceiver()->mouseLeave.Execute(EventArgs(_composition));
					}
				}
				mouseEnterCompositions.clear();
			}

			void GraphicsHost::KeyDown(const KeyInfo& info)
			{
				if (focusedComposition && focusedComposition->HasEventReceiver())
				{
					OnKeyInput(info, focusedComposition, &EventReceiver::keyDown);
				}
			}

			void GraphicsHost::KeyUp(const KeyInfo& info)
			{
				if (focusedComposition && focusedComposition->HasEventReceiver())
				{
					OnKeyInput(info, focusedComposition, &EventReceiver::keyUp);
				}
			}

			void GraphicsHost::SysKeyDown(const KeyInfo& info)
			{
				if (focusedComposition && focusedComposition->HasEventReceiver())
				{
					OnKeyInput(info, focusedComposition, &EventReceiver::systemKeyDown);
				}
			}

			void GraphicsHost::SysKeyUp(const KeyInfo& info)
			{
				if (info.code == VK_MENU && window)
				{
					if (window)
					{
						window->SupressAlt();
					}
				}

				if (focusedComposition && focusedComposition->HasEventReceiver())
				{
					OnKeyInput(info, focusedComposition, &EventReceiver::systemKeyUp);
				}
			}

			void GraphicsHost::Char(const CharInfo& info)
			{
				if (focusedComposition && focusedComposition->HasEventReceiver())
				{
					OnCharInput(info, focusedComposition, &EventReceiver::charInput);
				}
			}

			void GraphicsHost::GlobalTimer()
			{
				auto now = std::chrono::duration_cast<chrono::milliseconds>
					(chrono::system_clock::now().time_since_epoch()).count();
				if (now - lastCaretTime >= CaretInterval)
				{
					lastCaretTime = now;
					if (focusedComposition && focusedComposition->HasEventReceiver())
					{
						focusedComposition->GetEventReceiver()->caretNotify.Execute(EventArgs(focusedComposition));
					}
				}

				Render();
			}

			Window::Window(PassRefPtr<IWindowStyleController> _styleController)
				: ControlHost(_styleController.get())
				, styleController(_styleController.get())
			{
				RefPtr<IWindow> window = GetStorage()->GetController()->GetWindowService()->CreateWindowEx();
				styleController->AttachWindow(this);
				SetWindow(window);
				GetStorage()->GetApplication()->RegisterWindow(this);
				ClipboardUpdated.SetAssociatedComposition(GetBoundsComposition());
			}

			Window::~Window()
			{
				GetStorage()->GetApplication()->UnregisterWindow(this);
				RefPtr<IWindow> window = host->GetWindow();
				if (window)
				{
					SetWindow(nullptr);
					GetStorage()->GetController()->GetWindowService()->DestroyWindow(window);
				}
			}

			void Window::MoveToScreenCenter()
			{
				RefPtr<IScreen> screen = GetRelatedScreen();
				if (screen)
				{
					CRect screenBounds = screen->GetClientBounds();
					CRect windowBounds = GetBounds();
					windowBounds.OffsetRect(CSize((screenBounds.Width() - windowBounds.Width()) / 2, (screenBounds.Height() - windowBounds.Height()) / 2));
					SetBounds(windowBounds);
				}
			}

			bool Window::GetMaximizedBox()
			{
				return styleController->GetMaximizedBox();
			}

			void Window::SetMaximizedBox(bool visible)
			{
				styleController->SetMaximizedBox(visible);
			}

			bool Window::GetMinimizedBox()
			{
				return styleController->GetMinimizedBox();
			}

			void Window::SetMinimizedBox(bool visible)
			{
				styleController->SetMinimizedBox(visible);
			}

			bool Window::GetBorder()
			{
				return styleController->GetBorder();
			}

			void Window::SetBorder(bool visible)
			{
				styleController->SetBorder(visible);
			}

			bool Window::GetSizeBox()
			{
				return styleController->GetSizeBox();
			}

			void Window::SetSizeBox(bool visible)
			{
				styleController->SetSizeBox(visible);
			}

			bool Window::GetIconVisible()
			{
				return styleController->GetIconVisible();
			}

			void Window::SetIconVisible(bool visible)
			{
				styleController->SetIconVisible(visible);
			}

			bool Window::GetTitleBar()
			{
				return styleController->GetTitleBar();
			}

			void Window::SetTitleBar(bool visible)
			{
				styleController->SetTitleBar(visible);
			}

			void Window::ShowModal(PassRefPtr<Window> owner, const function<void()>& callback)
			{
				owner->SetEnabled(false);
				GetWindow()->SetParent(owner->GetWindow());
				auto_ptr<Event<EventArgs>::HandlerContainer> container;
				container.reset(new Event<EventArgs>::HandlerContainer);
				container->handler = WindowClosed.AttachLambda([&](PassRefPtr<Composition> sender, EventArgs& arguments)
				{
					GetStorage()->GetApplication()->InvokeInMainThread([&]()
					{
						WindowClosed.Detach(container->handler);
						GetWindow()->SetParent(nullptr);
						callback();
						owner->SetEnabled(true);
						owner->SetActivated();
					});
				});
				Show();
			}

			void Window::ShowModalAndDelete(PassRefPtr<Window> owner, const function<void()>& callback)
			{
				owner->SetEnabled(false);
				GetWindow()->SetParent(owner->GetWindow());
				WindowClosed.AttachLambda([&](PassRefPtr<Composition> sender, EventArgs& arguments)
				{
					GetStorage()->GetApplication()->InvokeInMainThread([&]()
					{
						GetWindow()->SetParent(nullptr);
						callback();
						owner->SetEnabled(true);
						owner->SetActivated();
						delete this;
					});
				});
				Show();
			}

			void Window::Moved()
			{
				ControlHost::Moved();
				styleController->SetSizeState(GetWindow()->GetSizeState());
			}

			void Window::OnWindowChanged()
			{
				styleController->InitializeWindowProperties();
				ControlHost::OnWindowChanged();
			}

			void Window::OnVisualStatusChanged()
			{
				ControlHost::OnVisualStatusChanged();
			}

			void Window::MouseClickedOnOtherWindow(PassRefPtr<Window> window)
			{

			}
		}
	}
}