#ifndef CS_POOL
#define CS_POOL

#include "stdafx.h"
#include "WTF/RefPtr.h"
#include "WTF/AVLTree.h"
#include "WTF/BitVector.h"
#include "../GUI/cc_base.h"

using namespace std;
using namespace cc::base;

namespace cc
{
	namespace script
	{
		template<typename _Object>
		class Cs_FixedPool : public Cs_Object
		{
			static_assert(std::is_pod<_Object>::value, "Object must be POD type");
		public:
			typedef Cs_FixedPool<_Object>	_Pool;
			typedef _Object*				_Pointer;

			Cs_FixedPool(size_t size)
			{
				size = __max(size, 2);
				Objects.resize(size);
				Used.resize(size);
				FreeObj.resize(size);
				for (size_t i = 0; i < size; i++)
				{
					FreeObj[i] = i;
				}
			}

			~Cs_FixedPool()
			{

			}

			size_t GetUsedCount() const
			{
				return Objects.size() - FreeObj.size();
			}

			size_t GetFreeCount() const
			{
				return FreeObj.size();
			}

			size_t GetSize() const
			{
				return Objects.size();
			}

			bool IsFull() const
			{
				return FreeObj.empty();
			}

			_Object* Data()
			{
				return Objects.data();
			}

			_Object* Alloc()
			{
				if (!FreeObj.empty())
				{
					auto Index = FreeObj.back();
					FreeObj.pop_back();
					Used.set(Index);
					return &Objects[Index];
				}
				else
				{
					return nullptr;
				}
			}

			bool Free(_Object* Object)
			{
				if (Object < Objects.data())
				{
					return false;
				}
				size_t Index = Object - Objects.data();
				if ((Index >= Objects.size()) || !Used.get(Index))
				{
					return false;
				}
				else
				{
					Used.clear(Index);
					FreeObj.push_back(Index);
					return true;
				}
			}

			bool operator < (const _Pool& Pool)
			{
				return Objects.data() < Pool.Objects.data();
			}
			bool operator > (const _Pool& Pool)
			{
				return Objects.data() > Pool.Objects.data();
			}
			bool operator == (const _Pool& Pool)
			{
				return Objects.data() == Pool.Objects.data();
			}
			bool operator != (const _Pool& Pool)
			{
				return Objects.data() != Pool.Objects.data();
			}
			bool operator <= (const _Pool& Pool)
			{
				return Objects.data() <= Pool.Objects.data();
			}
			bool operator >= (const _Pool& Pool)
			{
				return Objects.data() >= Pool.Objects.data();
			}

			bool operator < (const _Object* Object)
			{
				return Object >= Objects.data() + Objects.size();
			}
			bool operator > (const _Object* Object)
			{
				return Object < Objects.data();
			}
			bool operator == (const _Object* Object)
			{
				return !(*this < Object || *this > Object);
			}
			bool operator <= (const _Object* Object)
			{
				return Object >= Objects.data();
			}
			bool operator >= (const _Object* Object)
			{
				return Object > Objects.data() + Objects.size();
			}
			bool operator != (const _Object* Object)
			{
				return *this < Object || *this > Object;
			}

			_tstringstream& operator >> (_tstringstream& ss)
			{
				ss << _T("Size: ") << GetSize()
					<< _T("\tFree: ") << GetFreeCount()
					<< _T("\tUsed: ") << GetUsedCount()
					<< _T("\tAddr: ") << (void*)Data()
					<< endl;
				return ss;
			}

		protected:
			vector<_Object>			Objects;
			BitVector				Used;
			vector<cint>			FreeObj;
		};

		template<typename _Object>
		class Cs_Pool : public Cs_Object
		{
		protected:
			typedef Cs_FixedPool<_Object>			_PoolObj;
			typedef auto_ptr<_PoolObj>				_PoolPtr;
			typedef vector<_PoolPtr>				_PoolList;

			typedef typename _PoolObj::_Pointer		_Key;
			typedef _PoolObj*						_Value;

			template <class _key, class _value>
			struct AVLTreeNode {
				_key key;
				_value value;

				AVLTreeNode* less;
				AVLTreeNode* greater;
				int balanceFactor;
			};

			template <class _key, class _value>
			struct AVLTreeAbstractor {
				typedef AVLTreeNode<_key, _value> tree_node;
				typedef tree_node* handle;
				typedef _key key;
				typedef size_t size;
				size pack_size;

				handle get_less(handle h) { return h->less; }
				void set_less(handle h, handle less) { h->less = less; }
				handle get_greater(handle h) { return h->greater; }
				void set_greater(handle h, handle greater) { h->greater = greater; }

				int get_balance_factor(handle h) { return h->balanceFactor; }
				void set_balance_factor(handle h, int bf) { h->balanceFactor = bf; }

				int compare_key_node(const key& k, handle h) { return *h->value == k ? 0 : *h->value > k ? -1 : 1; }
				int compare_node_node(handle ha, handle hb) { return *ha->value == *hb->value ? 0 : *ha->value < *hb->value ? -1 : 1; }

				static handle null() { return nullptr; }
			};

			typedef WTF::AVLTree<AVLTreeAbstractor<typename _Key, typename _Value>> _PoolTree;

		public:
			Cs_Pool(size_t size)
				: PackSize(size)
			{

			}

			~Cs_Pool()
			{
				_PoolTree::Iterator iterator;
				iterator.start_iter_least(PoolTree);

				vector<_PoolTree::tree_node*> nodes;

				while (*iterator) {
					nodes.push_back(*iterator);
					++iterator;
				}
				PoolTree.purge();

				for (size_t i = 0; i < nodes.size(); ++i)
					delete(nodes[i]);
			}

			_Object* Alloc()
			{
				RawPtr<_PoolObj> FreePool;
				for (auto & OwnPool : PoolList)
				{
					auto* CurrentPool = OwnPool.get();
					if (!CurrentPool->IsFull())
					{
						FreePool = CurrentPool;
						break;
					}
				}
				if (!FreePool)
				{
					FreePool = new _PoolObj(PackSize);
					PoolList.push_back(_PoolPtr(FreePool));
					auto node = new _PoolTree::tree_node;
					node->key = FreePool->Data();
					node->value = FreePool;
					PoolTree.insert(node);
				}
				return FreePool->Alloc();
			}

			bool Free(_Object* Object)
			{
				auto Node = PoolTree.search(Object, _PoolTree::EQUAL);
				if (Node)
				{
					return Node->value->Free(Object);
				}
				else
				{
					return false;
				}
			}

			_tstringstream& operator >> (_tstringstream& ss)
			{
				for (auto & pool : PoolList)
				{
					*pool >> ss;
				}
				return ss;
			}

		protected:
			_PoolList		PoolList;
			_PoolTree		PoolTree;
			size_t			PackSize;
		};
	}
}

#endif