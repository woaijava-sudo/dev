#include "stdafx.h"
#include "GUI\cc_exception.h"
#include "GUI\cc_console.h"
#include "cs_inst.h"
#include "cs_pool.h"

using namespace cc::exception;
using namespace cc::script;
using namespace cc::presentation::windows;
using namespace cc::presentation::element;

namespace cc
{
	namespace presentation
	{
		namespace control
		{
			void Console::ConsoleThread::ConsoleThreadCallback()
			{
				try
				{
					Wait();
					CString str;
					Cs_Pool<char> pool(2);
					while (true)
					{
						SetColorToDefault();
						Output(_T(">> "));
						SetColor(CColor(Gdiplus::Color::Gray));
						Input(str);
						SetColor(CColor(Gdiplus::Color::Orange));
						Output(_T("Result: \n"));
						SetColor(CColor(Gdiplus::Color::Brown));
						//Output(str);
						do
						{
							_tstring input = str;
							_tstringstream ss;
							if (input == L"a")
							{
								ss << L"PTR: " << (void*)pool.Alloc() << endl;
								Output(ss.str());
								break;
							}
							if (input == L"s")
							{
								pool >> ss;
								Output(ss.str());
								break;
							}
							_tsmatch matches;
							if (regex_match(input, matches, _tregex(L"^f (\\w+)$")))
							{
								void* sz;
								ss << matches[1].str();
								ss >> sz;
								ss.str(L"");
								ss.clear();
								ss << boolalpha << pool.Free((char*)sz) << endl;
								Output(ss.str());
								break;
							}

							SetColor(CColor(Gdiplus::Color::Red));
							Output(_T("Error\n"));
						} while (0);
// 						SetColor(CColor(Gdiplus::Color::Red));
// 						Cs_InstPage page;
// 						Output(page.ToString().c_str());
// 						Output(_T("Sleep..."));
// 						const auto MAX_TIME = 5;
// 						for (auto i = 0; i < MAX_TIME; i++)
// 						{
// 							this_thread::sleep_for(chrono::seconds(1));
// 							ClearLastLine();
// 							CString str;
// 							str.Format(_T("Sleep... %d"), i);
// 							Output(str);
// 						}
// 						Output(_T("\n"));
					}
				}
				catch (const runtime_thread_interrupt& e)
				{
					ATLTRACE(atlTraceException, 0, "%s", e.what());
				}
			}
		}
	}
}