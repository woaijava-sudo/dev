#include "stdafx.h"
#include "cs_inst.h"

namespace cc
{
	namespace script
	{
		_tstringstream& operator<<(_tstringstream& ss, Cs_InstType inst)
		{
			switch (inst)
			{
				case i_int:
					ss << (_T("int"));
					break;
				case i_float:
					ss << (_T("float"));
					break;
				case i_string:
					ss << (_T("string"));
					break;
				case i_local_ref:
					ss << (_T("local_ref"));
					break;
				case i_fixed_ref:
					ss << (_T("fixed_ref"));
					break;
				case i_field_ref:
					ss << (_T("field_ref"));
					break;
				case i_ref:
					ss << (_T("ref"));
					break;
				case i_func:
					ss << (_T("func"));
					break;
				case i_neg:
					ss << (_T("neg"));
					break;
				case i_add:
					ss << (_T("add"));
					break;
				case i_sub:
					ss << (_T("sub"));
					break;
				case i_mul:
					ss << (_T("mul"));
					break;
				case i_div:
					ss << (_T("div"));
					break;
				case i_idiv:
					ss << (_T("idiv"));
					break;
				case i_mod:
					ss << (_T("mod"));
					break;
				case i_and:
					ss << (_T("and"));
					break;
				case i_or:
					ss << (_T("or"));
					break;
				case i_xor:
					ss << (_T("xor"));
					break;
				case i_not:
					ss << (_T("not"));
					break;
				case i_less:
					ss << (_T("less"));
					break;
				case i_larger:
					ss << (_T("larger"));
					break;
				case i_less_equal:
					ss << (_T("less_equal"));
					break;
				case i_larger_equal:
					ss << (_T("larger_equal"));
					break;
				case i_equal:
					ss << (_T("equal"));
					break;
				case i_not_equal:
					ss << (_T("not_equal"));
					break;
				case i_join:
					ss << (_T("join"));
					break;
				case i_copy:
					ss << (_T("copy"));
					break;
				case i_length:
					ss << (_T("length"));
					break;
				case i_index:
					ss << (_T("index"));
					break;
				case i_index_rm:
					ss << (_T("index_rm"));
					break;
				case i_index_ref:
					ss << (_T("index_ref"));
					break;
				case i_range:
					ss << (_T("range"));
					break;
				case i_range_rm:
					ss << (_T("range_rm"));
					break;
				case i_range_ref:
					ss << (_T("range_ref"));
					break;
				case i_rangerev:
					ss << (_T("rangerev"));
					break;
				case i_rangerev_rm:
					ss << (_T("rangerev_rm"));
					break;
				case i_rangerev_ref:
					ss << (_T("rangerev_ref"));
					break;
				case i_block:
					ss << (_T("block"));
					break;
				case i_block_rm:
					ss << (_T("block_rm"));
					break;
				case i_block_ref:
					ss << (_T("block_ref"));
					break;
				case i_invoke:
					ss << (_T("invoke"));
					break;
				case i_invoke_arr:
					ss << (_T("invoke_arr"));
					break;
				case i_assign:
					ss << (_T("assign"));
					break;
				case i_array:
					ss << (_T("array"));
					break;
				case i_push:
					ss << (_T("push"));
					break;
				case i_pop:
					ss << (_T("pop"));
					break;
				case i_jump:
					ss << (_T("jump"));
					break;
				case i_jump_true:
					ss << (_T("jump_true"));
					break;
				case i_jump_false:
					ss << (_T("jump_false"));
					break;
				case i_result:
					ss << (_T("result"));
					break;
				case i_make_ctor:
					ss << (_T("make_ctor"));
					break;
				case i_ctor_base:
					ss << (_T("ctor_base"));
					break;
				case i_call_ctor:
					ss << (_T("call_ctor"));
					break;
				case i_element:
					ss << (_T("element"));
					break;
				case i_field:
					ss << (_T("field"));
					break;
				case i_remove:
					ss << (_T("remove"));
					break;
				case i_copy_stack:
					ss << (_T("copy_stack"));
					break;
				case i_insert_env:
					ss << (_T("insert_env"));
					break;
				case i_using_env:
					ss << (_T("using_env"));
					break;
				case i_is_bool:
					ss << (_T("is_bool"));
					break;
				case i_is_int:
					ss << (_T("is_int"));
					break;
				case i_is_numeric:
					ss << (_T("is_numeric"));
					break;
				case i_is_value:
					ss << (_T("is_value"));
					break;
				case i_is_func:
					ss << (_T("is_func"));
					break;
				case i_is_env:
					ss << (_T("is_env"));
					break;
				case i_is_external:
					ss << (_T("is_external"));
					break;
				case i_is_array:
					ss << (_T("is_array"));
					break;
				case i_is_ctor:
					ss << (_T("is_ctor"));
					break;
				case i_is_null:
					ss << (_T("is_null"));
					break;
				case i_is_fromCtor:
					ss << (_T("is_fromCtor"));
					break;
				case i_raise_error:
					ss << (_T("raise_error"));
					break;
				case i_unknown:
					ss << (_T("unknown"));
					break;
				default:
					break;
			}
			return ss;
		}


		Cs_Inst::Cs_Inst()
		{

		}
		Cs_Inst::Cs_Inst(Cs_InstType Instruction, _tstring Parameter, cint CodeLine)
		{
			Inst = Instruction;
			Param = Parameter;
			Line = CodeLine;
			IntParam = 0;
		}


		Cs_Func::Cs_Func(Cs_InstPage* Page)
			: OwnerPage(Page)
			, VariableParamCount(false)
		{

		}

		void Cs_Func::RegisterLabel(_tstring Label)
		{
			Labels.insert(make_pair(Label, (cint)InstList.size()));
		}

		void Cs_Func::ProcessLabel()
		{
			for (auto & Inst : InstList)
			{
				switch (Inst.Inst)
				{
					case i_jump:
					case i_jump_true:
					case i_jump_false:
						Inst.IntParam = Labels[Inst.Param];
						break;
					case i_int:
					case i_func:
					case i_invoke:
					case i_array:
					case i_copy_stack:
						Inst.IntParam = _ttoi(Inst.Param.c_str());
						break;
				}
			}
		}


		Cs_InstPage::Cs_InstPage()
		{

		}

		_tstring Cs_InstPage::ToString()
		{
			_tstringstream Result;
			auto EntryIndex = find(Functions.begin(), Functions.end(), ~Entry);
			if (EntryIndex != Functions.end())
			{
				Result << _T("Entry: ") << *EntryIndex << endl;
			}
			else
			{
				Result << _T("Entry: ") << _T("Unknown") << endl;
			}
			cuint i = 0;
			for (auto & Func : Functions)
			{
				Result << endl;
				Result << _T("func ") << i << (Func->VariableParamCount ? _T(" varparam") : _T("")) << endl;
				for (auto & Param : Func->Params)
				{
					Result << _T("  ") << Param << endl;
				}
				Result << _T("begin") << endl;
				cuint j = 0;
				for (auto & InstList : Func->InstList)
				{
					for (auto & Label : Func->Labels)
					{
						if (Label.second == j)
						{
							Result << Label.first << _T(" :") << endl;
						}
					}
					if (j < Func->InstList.size())
					{
						Result << _T("  [Line : ") << (InstList.Line + 1) << _T("]\t") << InstList.Inst << InstList.Param << endl;
					}
					j++;
				}
				Result << _T("end") << endl;
				i++;
			}
			return Result.str();
		}

		void Cs_InstPage::ProcessLabel()
		{
			for (auto & Func : Functions)
			{
				Func->ProcessLabel();
			}
		}

	}
}
