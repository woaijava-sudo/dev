#ifndef CC_LIST
#define CC_LIST

#include "stdafx.h"
#include "cc_base.h"
#include "cc_interface.h"
#include "cc_control.h"
#include "cc_element.h"

using namespace cc::base;
using namespace cc::interfaces::windows;
using namespace cc::presentation::control;
using namespace cc::presentation::element;

namespace cc
{
	namespace presentation
	{
		namespace control
		{
			namespace helper
			{
				template<typename T>
				class ItemsBase : public Object
				{
				public:
					ItemsBase()
					{
					}

					~ItemsBase()
					{
					}

					bool NotifyUpdate(cint start, cint count = 1)
					{
						auto count = Count();
						if (start < 0 ||
							start >= count ||
							count <= 0 ||
							start + count > count)
						{
							return false;
						}
						else
						{
							NotifyUpdateInternal(start, count, count);
							return true;
						}
					}

					bool Contains(const T& item) const
					{
						return find(items.begin(), items.end(), item) != items.end();
					}

					cint Count() const
					{
						return (cint)items.size();
					}

					cint Count()
					{
						return (cint)items.size();
					}

					const T& Get(cint index) const
					{
						return items.at(index);
					}

					const T& operator[](cint index) const
					{
						return items.at(index);
					}

					cint Add(const T& item)
					{
						if (QueryInsert(index, item))
						{
							BeforeInsert(index, item);
							items.push_back(item);
							AfterInsert(index, item);
							NotifyUpdateInternal(index, 0, 1);
							return index;
						}
						else
						{
							return -1;
						}
					}

					cint Insert(cint index, const T& item)
					{
						if (0 <= index && index <= Count() && QueryInsert(index, item))
						{
							BeforeInsert(index, item);
							items.insert(items.begin() + index, item);
							AfterInsert(index, item);
							NotifyUpdateInternal(index, 0, 1);
							return index;
						}
						else
						{
							return -1;
						}
					}

					bool Set(cint index, const T& item)
					{
						if (0 <= index && index < Count())
						{
							if (QueryRemove(index, Get(index)) && QueryInsert(index, item))
							{
								BeforeRemove(index, Get(index));
								items.erase(items.begin() + index);
								AfterRemove(index, 1);

								BeforeInsert(index, item);
								items.Insert(items.begin() + index, item);
								AfterInsert(index, item);

								NotifyUpdateInternal(index, 1, 1);
								return true;
							}
						}
						return false;
					}

					bool Remove(const T& item)
					{
						auto found = find(items.begin(), items.end(), item);
						if (found != items.end())
						{
							BeforeRemove(index, *found);
							items.erase(found);
							AfterRemove(index, 1);
							NotifyUpdateInternal(index, 1, 0);
						}
						return false;
					}

					bool RemoveAt(cint index)
					{
						if (0 <= index && index < Count() && QueryRemove(index, Get(index)))
						{
							BeforeRemove(index, Get(index));
							items.erase(items.begin() + index);
							AfterRemove(index, 1);
							NotifyUpdateInternal(index, 1, 0);
							return true;
						}
						return false;
					}

					bool RemoveRange(cint index, cint count)
					{
						if (count <= 0)
						{
							return false;
						}
						if (0 <= index && index < Count() && index + count <= Count())
						{
							for (cint i = 0; i < count; i++)
							{
								if (!QueryRemove(index + 1, Get(index + i)))
								{
									return false;
								}
							}
							for (cint i = 0; i < count; i++)
							{
								BeforeRemove(index + i, Get(index + i));
							}
							items.erase(items.begin() + index, items.begin() + index + count);
							AfterRemove(index, count);
							NotifyUpdateInternal(index, count, 0);
							return true;
						}
						return false;
					}

					bool Clear()
					{
						auto count = Count();
						for (cint i = 0; i < count; i++)
						{
							if (!QueryRemove(i, Get(i))) return false;
						}
						for (cint i = 0; i < count; i++)
						{
							BeforeRemove(i, Get(i));
						}
						items.clear();
						AfterRemove(0, count);
						NotifyUpdateInternal(0, count, 0);
						return true;
					}

				protected:
					virtual void NotifyUpdateInternal(cint start, cint count, cint newCount)
					{
					}

					virtual bool QueryInsert(cint index, const T& value)
					{
						return true;
					}

					virtual void BeforeInsert(cint index, const T& value)
					{
					}

					virtual void AfterInsert(cint index, const T& value)
					{
					}

					virtual bool QueryRemove(cint index, const T& value)
					{
						return true;
					}

					virtual void BeforeRemove(cint index, const T& value)
					{
					}

					virtual void AfterRemove(cint index, cint count)
					{
					}

					std::vector<T> items;
				};
			}
		}
	}
}

#endif