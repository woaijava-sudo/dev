#ifndef CC_TOOLSTRIP
#define CC_TOOLSTRIP

#include "stdafx.h"
#include "cc_base.h"
#include "cc_interface.h"
#include "cc_control.h"
#include "cc_element.h"

using namespace cc::base;
using namespace cc::interfaces::windows;
using namespace cc::presentation::control;
using namespace cc::presentation::element;

namespace cc
{
	namespace presentation
	{
		namespace control
		{
// 			class IMenuService;
// 			class Menu;
// 
// 			class IMenuService : public Interface
// 			{
// 			public:
// 				enum Direction
// 				{
// 					Horizontal,
// 					Vertical,
// 				};
// 
// 			public:
// 				IMenuService();
// 
// 				virtual PassRefPtr<IMenuService>		GetParentMenuService() = 0;
// 				virtual Direction						GetPreferredDirection() = 0;
// 				virtual bool							IsActiveState() = 0;
// 				virtual bool							IsSubMenuActivatedByMouseDown() = 0;
// 
// 				virtual void							MenuItemExecuted();
// 				virtual PassRefPtr<Menu>				GetOpeningMenu();
// 				virtual void							MenuOpened(PassRefPtr<Menu> menu);
// 				virtual void							MenuClosed(PassRefPtr<Menu> menu);
// 
// 			protected:
// 				RawPtr<Menu>							openingMenu;
// 			};
// 
// 			class Menu : public Popup, private IMenuService
// 			{
// 			private:
// 				IMenuService*						parentMenuService;
// 
// 				IMenuService*						GetParentMenuService()override;
// 				Direction								GetPreferredDirection()override;
// 				bool									IsActiveState()override;
// 				bool									IsSubMenuActivatedByMouseDown()override;
// 				void									MenuItemExecuted()override;
// 			protected:
// 				Control*								owner;
// 
// 				void									OnDeactivatedAltHost()override;
// 				void									MouseClickedOnOtherWindow(Window* window)override;
// 				void									OnWindowOpened(compositions::GraphicsComposition* sender, compositions::EventArgs& arguments);
// 				void									OnWindowClosed(compositions::GraphicsComposition* sender, compositions::EventArgs& arguments);
// 			public:
// 				Menu(IStyleController* _styleController, Control* _owner);
// 				~Menu();
// 
// 				void									UpdateMenuService();
// 				IDescriptable*							QueryService(const WString& identifier)override;
// 			};
// 
// 			class MenuBar : public Control, private IMenuService, public Description<MenuBar>
// 			{
// 			private:
// 				IMenuService*						GetParentMenuService()override;
// 				Direction								GetPreferredDirection()override;
// 				bool									IsActiveState()override;
// 				bool									IsSubMenuActivatedByMouseDown()override;
// 			public:
// 				MenuBar(Control::IStyleController* _styleController);
// 				~MenuBar();
// 
// 				IDescriptable*							QueryService(const WString& identifier)override;
// 			};
// 
// 			class MenuButton : public SelectableButton, public Description<MenuButton>
// 			{
// 			public:
// 				class IStyleController : public virtual SelectableButton::IStyleController, public Description<IStyleController>
// 				{
// 				public:
// 					virtual Menu::IStyleController*	CreateSubMenuStyleController() = 0;
// 					virtual void						SetSubMenuExisting(bool value) = 0;
// 					virtual void						SetSubMenuOpening(bool value) = 0;
// 					virtual Button*					GetSubMenuHost() = 0;
// 					virtual void						SetImage(Ptr<ImageData> value) = 0;
// 					virtual void						SetShortcutText(const WString& value) = 0;
// 				};
// 			protected:
// 				IStyleController*						styleController;
// 				Ptr<ImageData>						image;
// 				WString									shortcutText;
// 				Menu*								subMenu;
// 				bool									ownedSubMenu;
// 				Size									preferredMenuClientSize;
// 				IMenuService*						ownerMenuService;
// 				bool									cascadeAction;
// 
// 				Button*								GetSubMenuHost();
// 				void									OpenSubMenuInternal();
// 				void									OnParentLineChanged()override;
// 				bool									IsAltAvailable()override;
// 				compositions::IAltActionHost*		GetActivatingAltHost()override;
// 
// 				void									OnSubMenuWindowOpened(compositions::GraphicsComposition* sender, compositions::EventArgs& arguments);
// 				void									OnSubMenuWindowClosed(compositions::GraphicsComposition* sender, compositions::EventArgs& arguments);
// 				void									OnMouseEnter(compositions::GraphicsComposition* sender, compositions::EventArgs& arguments);
// 				void									OnClicked(compositions::GraphicsComposition* sender, compositions::EventArgs& arguments);
// 
// 				virtual IMenuService::Direction		GetSubMenuDirection();
// 			public:
// 				MenuButton(IStyleController* _styleController);
// 				~MenuButton();
// 
// 				compositions::NotifyEvent			SubMenuOpeningChanged;
// 				compositions::NotifyEvent			ImageChanged;
// 				compositions::NotifyEvent			ShortcutTextChanged;
// 
// 				Ptr<ImageData>						GetImage();
// 				void									SetImage(Ptr<ImageData> value);
// 				const WString&							GetShortcutText();
// 				void									SetShortcutText(const WString& value);
// 
// 				bool									IsSubMenuExists();
// 				Menu*								GetSubMenu();
// 				void									CreateSubMenu(Menu::IStyleController* subMenuStyleController = 0);
// 				void									SetSubMenu(Menu* value, bool owned);
// 				void									DestroySubMenu();
// 				bool									GetOwnedSubMenu();
// 
// 				bool									GetSubMenuOpening();
// 				void									SetSubMenuOpening(bool value);
// 
// 				Size									GetPreferredMenuClientSize();
// 				void									SetPreferredMenuClientSize(Size value);
// 
// 				bool									GetCascadeAction();
// 				void									SetCascadeAction(bool value);
// 			};
// 
// 			class ToolstripCommand : public Component, public Description<ToolstripCommand>
// 			{
// 			public:
// 				class ShortcutBuilder : public Object
// 				{
// 				public:
// 					WString									text;
// 					bool									ctrl;
// 					bool									shift;
// 					bool									alt;
// 					vint									key;
// 				};
// 			protected:
// 				Ptr<ImageData>							image;
// 				WString										text;
// 				compositions::IShortcutKeyItem*			shortcutKeyItem;
// 				bool										enabled;
// 				bool										selected;
// 				Ptr<compositions::NotifyEvent::IHandler>	shortcutKeyItemExecutedHandler;
// 				Ptr<ShortcutBuilder>						shortcutBuilder;
// 				ControlHost*								shortcutOwner;
// 
// 				void										OnShortcutKeyItemExecuted(compositions::GraphicsComposition* sender, compositions::EventArgs& arguments);
// 				void										InvokeDescriptionChanged();
// 				void										ReplaceShortcut(compositions::IShortcutKeyItem* value, Ptr<ShortcutBuilder> builder);
// 				void										BuildShortcut(const WString& builderText);
// 			public:
// 				ToolstripCommand();
// 				~ToolstripCommand();
// 
// 				void										Attach(InstanceRootObject* rootObject)override;
// 				void										Detach(InstanceRootObject* rootObject)override;
// 
// 				compositions::NotifyEvent				Executed;
// 
// 				compositions::NotifyEvent				DescriptionChanged;
// 
// 				Ptr<ImageData>							GetImage();
// 				void										SetImage(Ptr<ImageData> value);
// 				const WString&								GetText();
// 				void										SetText(const WString& value);
// 				compositions::IShortcutKeyItem*			GetShortcut();
// 				void										SetShortcut(compositions::IShortcutKeyItem* value);
// 				WString										GetShortcutBuilder();
// 				void										SetShortcutBuilder(const WString& value);
// 				bool										GetEnabled();
// 				void										SetEnabled(bool value);
// 				bool										GetSelected();
// 				void										SetSelected(bool value);
// 			};
// 
// 			class ToolstripCollection : public list::ItemsBase<Control*>
// 			{
// 			public:
// 				class IContentCallback : public Interface
// 				{
// 				public:
// 					virtual void							UpdateLayout() = 0;
// 				};
// 			protected:
// 				IContentCallback*							contentCallback;
// 				compositions::StackComposition*			stackComposition;
// 
// 				void										InvokeUpdateLayout();
// 				void										OnInterestingMenuButtonPropertyChanged(compositions::GraphicsComposition* sender, compositions::EventArgs& arguments);
// 				bool										QueryInsert(vint index, Control* const& child)override;
// 				bool										QueryRemove(vint index, Control* const& child)override;
// 				void										BeforeInsert(vint index, Control* const& child)override;
// 				void										BeforeRemove(vint index, Control* const& child)override;
// 				void										AfterInsert(vint index, Control* const& child)override;
// 				void										AfterRemove(vint index, vint count)override;
// 			public:
// 				ToolstripCollection(IContentCallback* _contentCallback, compositions::StackComposition* _stackComposition);
// 				~ToolstripCollection();
// 			};
// 
// 			/***********************************************************************
// 			Toolstrip Builder Facade
// 			***********************************************************************/
// 
// 			class ToolstripButton;
// 
// 			class ToolstripBuilder : public Object
// 			{
// 				friend class ToolstripMenu;
// 				friend class ToolstripMenuBar;
// 				friend class ToolstripToolBar;
// 			protected:
// 				enum Environment
// 				{
// 					Menu,
// 					MenuBar,
// 					ToolBar,
// 				};
// 
// 				Environment									environment;
// 				ToolstripCollection*						toolstripItems;
// 				ToolstripBuilder*						previousBuilder;
// 				theme::ITheme*								theme;
// 				ToolstripButton*							lastCreatedButton;
// 
// 				ToolstripBuilder(Environment _environment, ToolstripCollection* _toolstripItems);
// 			public:
// 				~ToolstripBuilder();
// 
// 				ToolstripBuilder*						Button(Ptr<ImageData> image, const WString& text, ToolstripButton** result = 0);
// 				ToolstripBuilder*						Button(ToolstripCommand* command, ToolstripButton** result = 0);
// 				ToolstripBuilder*						DropdownButton(Ptr<ImageData> image, const WString& text, ToolstripButton** result = 0);
// 				ToolstripBuilder*						DropdownButton(ToolstripCommand* command, ToolstripButton** result = 0);
// 				ToolstripBuilder*						SplitButton(Ptr<ImageData> image, const WString& text, ToolstripButton** result = 0);
// 				ToolstripBuilder*						SplitButton(ToolstripCommand* command, ToolstripButton** result = 0);
// 				ToolstripBuilder*						Splitter();
// 				ToolstripBuilder*						Control(Control* control);
// 				ToolstripBuilder*						BeginSubMenu();
// 				ToolstripBuilder*						EndSubMenu();
// 			};
// 
// 			/***********************************************************************
// 			Toolstrip Container
// 			***********************************************************************/
// 
// 			class ToolstripMenu : public Menu, protected ToolstripCollection::IContentCallback, Description<ToolstripMenu>
// 			{
// 			protected:
// 				compositions::SharedSizeRootComposition*	sharedSizeRootComposition;
// 				compositions::StackComposition*			stackComposition;
// 				Ptr<ToolstripCollection>					toolstripItems;
// 				Ptr<ToolstripBuilder>					builder;
// 
// 				void										UpdateLayout()override;
// 			public:
// 				ToolstripMenu(IStyleController* _styleController, Control* _owner);
// 				~ToolstripMenu();
// 
// 				ToolstripCollection&						GetToolstripItems();
// 				ToolstripBuilder*						GetBuilder(theme::ITheme* themeObject = 0);
// 			};
// 
// 			class ToolstripMenuBar : public MenuBar, public Description<ToolstripMenuBar>
// 			{
// 			protected:
// 				compositions::StackComposition*			stackComposition;
// 				Ptr<ToolstripCollection>					toolstripItems;
// 				Ptr<ToolstripBuilder>					builder;
// 
// 			public:
// 				ToolstripMenuBar(IStyleController* _styleController);
// 				~ToolstripMenuBar();
// 
// 				ToolstripCollection&						GetToolstripItems();
// 				ToolstripBuilder*						GetBuilder(theme::ITheme* themeObject = 0);
// 			};
// 
// 			class ToolstripToolBar : public Control, public Description<ToolstripToolBar>
// 			{
// 			protected:
// 				compositions::StackComposition*			stackComposition;
// 				Ptr<ToolstripCollection>					toolstripItems;
// 				Ptr<ToolstripBuilder>					builder;
// 
// 			public:
// 				ToolstripToolBar(IStyleController* _styleController);
// 				~ToolstripToolBar();
// 
// 				ToolstripCollection&						GetToolstripItems();
// 				ToolstripBuilder*						GetBuilder(theme::ITheme* themeObject = 0);
// 			};
// 
// 			/***********************************************************************
// 			Toolstrip Component
// 			***********************************************************************/
// 
// 			class ToolstripButton : public MenuButton, public Description<ToolstripButton>
// 			{
// 			protected:
// 				ToolstripCommand*							command;
// 				Ptr<compositions::NotifyEvent::IHandler>		descriptionChangedHandler;
// 
// 				void											UpdateCommandContent();
// 				void											OnClicked(compositions::GraphicsComposition* sender, compositions::EventArgs& arguments);
// 				void											OnCommandDescriptionChanged(compositions::GraphicsComposition* sender, compositions::EventArgs& arguments);
// 			public:
// 				ToolstripButton(IStyleController* _styleController);
// 				~ToolstripButton();
// 
// 				ToolstripCommand*							GetCommand();
// 				void											SetCommand(ToolstripCommand* value);
// 
// 				ToolstripMenu*								GetToolstripSubMenu();
// 				void											CreateToolstripSubMenu(ToolstripMenu::IStyleController* subMenuStyleController = 0);
// 			};
		}
	}
}

#endif