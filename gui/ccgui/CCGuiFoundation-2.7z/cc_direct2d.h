#ifndef CC_DIRECT2D
#define CC_DIRECT2D

#include "stdafx.h"
#include <DXGIDebug.h>
#include "cc_interface.h"
#include "cc_resource.h"

using namespace cc::interfaces::windows;
using namespace cc::presentation::windows;
using namespace cc::presentation::windows::helper;
using namespace cc::presentation::direct2d::allocator;

namespace cc
{
	namespace presentation
	{
		namespace direct2d
		{
			D2D1::ColorF GetD2DColor(CColor color);

			class D2DControllerListener;
			class D2DWindowListener;

			class D2DProvider;
			class D2DParagraph;

			class D2DControllerListener : public IControllerListener
			{
			public:
				D2DControllerListener();

				void WindowCreated(PassRefPtr<IWindow> window);
				void WindowDestroying(PassRefPtr<IWindow> window);

				map<RefPtr<IWindow>, RefPtr<D2DWindowListener>>	WindowListeners;
				CComPtr<ID2D1Factory>							D2D1Factory;
				CComPtr<IDWriteFactory>							DWriteFactory;
			};

			class D2DWindowListener : public IWindowListener
			{
			public:
				D2DWindowListener(PassRefPtr<IWindow> _window, CComPtr<ID2D1Factory> _d2dFactory);

				void Moved();
				void Paint();
				CComPtr<ID2D1RenderTarget> GetDirect2DRenderTarget();
				void RecreateRenderTarget();

			protected:
				void RebuildCanvas(CSize size);

				CComPtr<ID2D1Factory>			d2dFactory;
				CComPtr<ID2D1HwndRenderTarget>	d2dRenderTarget;
				RefPtr<IWindow>					window;
				CSize							previousSize;
			};

			class D2DProvider : public ID2DProvider
			{
			public:
				virtual void							RecreateRenderTarget(PassRefPtr<IWindow> window);
				virtual CComPtr<ID2D1RenderTarget>		GetDirect2DRenderTarget(PassRefPtr<IWindow> window);
				virtual CComPtr<ID2D1Factory>			GetDirect2DFactory();
				virtual CComPtr<IDWriteFactory>			GetDirectWriteFactory();
				virtual PassRefPtr<ID2DRenderTarget>	GetBindedRenderTarget(PassRefPtr<IWindow> window);
				virtual void							SetBindedRenderTarget(PassRefPtr<IWindow> window, PassRefPtr<ID2DRenderTarget> renderTarget);
				virtual CComPtr<IWICImagingFactory>		GetWICImagingFactory();
				virtual CComPtr<IWICBitmap>				GetWICBitmap(PassRefPtr<IImageFrame> frame);
			};

			class D2DElementInlineObject : public IDWriteInlineObject
			{
			public:
				D2DElementInlineObject(
					const IGraphicsParagraph::InlineObjectProperties& _properties,
					IGraphicsElement* _element,
					PassRefPtr<IRendererCallback> _rendererCallback,
					cint _start,
					cint _length
					);

				~D2DElementInlineObject();

				cint GetStart();
				cint GetLength();
				IGraphicsElement* GetElement();

				HRESULT STDMETHODCALLTYPE QueryInterface(
					REFIID riid,
					void __RPC_FAR *__RPC_FAR *ppvObject
					);

				ULONG STDMETHODCALLTYPE AddRef(void);

				ULONG STDMETHODCALLTYPE Release(void);

				STDMETHOD(Draw)(
					void* clientDrawingContext,
					IDWriteTextRenderer* renderer,
					FLOAT originX,
					FLOAT originY,
					BOOL isSideways,
					BOOL isRightToLeft,
					IUnknown* clientDrawingEffect
					)override;

				STDMETHOD(GetMetrics)(
					DWRITE_INLINE_OBJECT_METRICS* metrics
					)override;

				STDMETHOD(GetOverhangMetrics)(
					DWRITE_OVERHANG_METRICS* overhangs
					)override;

				STDMETHOD(GetBreakConditions)(
					DWRITE_BREAK_CONDITION* breakConditionBefore,
					DWRITE_BREAK_CONDITION* breakConditionAfter
					)override;

			protected:
				cint												counter;
				IGraphicsParagraph::InlineObjectProperties			properties;
				IGraphicsElement*									element;
				RefPtr<IRendererCallback>							rendererCallback;
				cint												start;
				cint												length;
			};

			class D2DParagraph : public IGraphicsParagraph, public IRendererCallback
			{
			public:
				D2DParagraph(PassRefPtr<IGraphicsLayoutProvider> _provider, const CString& _text, PassRefPtr<IGraphicsRenderTarget> _renderTarget);
				~D2DParagraph();

				PassRefPtr<IGraphicsLayoutProvider>					GetProvider()override;
				PassRefPtr<IGraphicsRenderTarget>					GetRenderTarget()override;

				bool												GetWrapLine()override;
				void												SetWrapLine(bool value)override;

				cint												GetMaxWidth()override;
				void												SetMaxWidth(cint value)override;

				Alignment											GetParagraphAlignment()override;
				void												SetParagraphAlignment(Alignment value)override;

				bool												SetFont(cint start, cint length, const CString& value)override;
				bool												SetSize(cint start, cint length, cint value)override;
				bool												SetStyle(cint start, cint length, TextStyle value)override;
				bool												SetColor(cint start, cint length, CColor value)override;
				bool												SetBackgroundColor(cint start, cint length, CColor value)override;

				bool												SetInlineObject(cint start, cint length, const InlineObjectProperties& properties, PassRefPtr<IGraphicsElement> value)override;
				bool												ResetInlineObject(cint start, cint length)override;

				cint												GetHeight()override;

				CColor												GetBackgroundColor(cint textPosition)override;

				PassRefPtr<ID2DRenderTarget>						GetDirect2DRenderTarget()override;

				bool												OpenCaret(cint _caret, CColor _color, bool _frontSide)override;
				bool												CloseCaret()override;

				void												Render(CRect bounds)override;

				void												GetLineIndexFromTextPos(cint textPos, cint& frontLineIndex, cint& backLineIndex);
				pair<FLOAT, FLOAT>									GetLineYRange(cint lineIndex);
				cint												GetLineIndexFromY(cint y);

				cint												GetCaretFromXWithLine(cint x, cint lineIndex);
				cint												GetCaret(cint comparingCaret, CaretRelativePosition position, bool& preferFrontSide)override;
				CRect												GetCaretBounds(cint caret, bool frontSide)override;
				cint												GetCaretFromPoint(CPoint point)override;

				PassRefPtr<IGraphicsElement>						GetInlineObjectFromPoint(CPoint point, cint& start, cint& length)override;

				cint												GetNearestCaretFromTextPos(cint textPos, bool frontSide)override;

				bool												IsValidCaret(cint caret)override;
				bool												IsValidTextPos(cint textPos);

			protected:
				template<typename T>
				void CutMap(map<TextRange, T>& maps, cuint start, cuint length)
				{
					cuint end = start + length;
					for (auto it = maps.rbegin(); it != maps.rend(); it++)
					{
						const TextRange & key = it->first;
						if (key.start < end && start < key.end)
						{
							const T & value = it->second;

							cuint s1 = key.start;
							cuint s2 = key.start > start ? key.start : start;
							cuint s3 = key.end < end ? key.end : end;
							cuint s4 = key.end;

							maps.erase(it->first);
							if (s1 < s2)
							{
								maps.insert(make_pair(TextRange(s1, s2), value));
							}
							if (s2 < s3)
							{
								maps.insert(make_pair(TextRange(s2, s3), value));
							}
							if (s3 < s4)
							{
								maps.insert(make_pair(TextRange(s3, s4), value));
							}
						}
					}
				}

				template<typename T, typename U>
				void UpdateOverlappedMap(map<TextRange, T>& maps, cuint start, cuint length, const U& value)
				{
					cuint end = start + length;
					for (auto it = maps.rbegin(); it != maps.rend(); it++)
					{
						const TextRange & key = it->first;
						if (key.start < end && start < key.end)
						{
							T _value = value;
							maps.insert(make_pair(key, _value));
						}
					}
				}

				template<typename T>
				void DefragmentMap(map<TextRange, T>& maps)
				{
					auto last = maps.rbegin();
					for (auto it = maps.rbegin(); it != maps.rend(); it++)
					{
						auto next = it; next++;
						if (it == maps.rend() || next->second != last->second)
						{
							if (next != last)
							{
								cuint start = it->first.start;
								cuint end = it->first.end;
								TextRange key(start, end);

								for (auto j = last; j != next; j++)
								{
									maps.erase(j->first);
								}
								maps.insert(make_pair(key, last->second));
							}
							last = next;
						}
					}
				}

				template<typename T, typename U>
				void SetMap(map<TextRange, T>& maps, cuint start, cuint length, const U& value)
				{
					CutMap(maps, start, length);
					UpdateOverlappedMap(maps, start, length, value);
					DefragmentMap(maps);
				}

				template<typename T, typename U>
				bool GetMap(map<TextRange, T>& maps, cuint textPosition, U& value)
				{
					auto found = equal_range(maps.begin(), maps.end(),
						pair<TextRange, T>(TextRange(UINT_MAX, 0), T()),
						[=](const pair<TextRange, T>& a, const pair<TextRange, T>& b)
					{
						if (a.first.start == UINT_MAX)
							return textPosition < b.first.start;
						else if (b.first.start == UINT_MAX)
							return textPosition >= a.first.end;
						return false;
					});
					if (found.first == found.second)
						return false;
					value = found.first->second;
					return true;
				}

				void PrepareFormatData();

			protected:
				RefPtr<IGraphicsLayoutProvider>			provider;
				CComPtr<ID2D1SolidColorBrush>			defaultTextColor;
				CComPtr<IDWriteFactory>					dwriteFactory;
				RefPtr<ID2DRenderTarget>				renderTarget;
				CString									paragraphText;
				CComPtr<IDWriteTextLayout>				textLayout;
				bool									wrapLine;
				cint									maxWidth;
				vector<CColor>							usedColors;

				typedef map<RefPtr<IGraphicsElement>, CComPtr<D2DElementInlineObject>>
					InlineElementMap;
				typedef map<TextRange, CColor>
					ColorMap;
				typedef map<TextRange, RefPtr<IGraphicsElement>>
					GraphicsElementMap;

				InlineElementMap						inlineElements;
				GraphicsElementMap						graphicsElements;
				ColorMap								backgroundColors;

				cint									caret;
				CColor									caretColor;
				bool									caretFrontSide;
				CComPtr<ID2D1SolidColorBrush>			caretBrush;

				bool									formatDataAvailable;
				vector<DWRITE_LINE_METRICS>				lineMetrics;
				vector<cint>							lineStarts;
				vector<FLOAT>							lineTops;
				vector<DWRITE_CLUSTER_METRICS>			clusterMetrics;
				vector<DWRITE_HIT_TEST_METRICS>			hitTestMetrics;
				vector<cint>							charHitTestMap;
			};

			class D2DImageFrameCache : public IImageFrameCache
			{
			protected:
				RefPtr<ID2DRenderTarget>		renderTarget;
				RefPtr<IImageFrame>				cachedFrame;
				CComPtr<ID2D1Bitmap>			bitmap;
				CComPtr<ID2D1Bitmap>			disabledBitmap;
			public:
				D2DImageFrameCache(PassRefPtr<ID2DRenderTarget> _renderTarget);
				~D2DImageFrameCache();

				void OnAttach(PassRefPtr<IImageFrame> frame)override;
				void OnDetach(PassRefPtr<IImageFrame> frame)override;
				PassRefPtr<IImageFrame> GetFrame();
				CComPtr<ID2D1Bitmap> GetBitmap(bool enabled);
			};

			class D2DRenderTarget : public ID2DRenderTarget
			{
			public:
				D2DRenderTarget(PassRefPtr<IWindow> _window);
				~D2DRenderTarget();

				CComPtr<ID2D1RenderTarget>			GetDirect2DRenderTarget()override;
				CComPtr<ID2D1Bitmap>				GetBitmap(PassRefPtr<IImageFrame> frame, bool enabled)override;
				void								DestroyBitmapCache(PassRefPtr<IImageFrame> frame)override;
				void								SetTextAntialias(bool antialias, bool verticalAntialias)override;
				void								StartRendering()override;
				bool								StopRendering()override;
				void								PushClipper(CRect clipper)override;
				void								PopClipper()override;
				CRect								GetClipper()override;
				bool								IsClipperCoverWholeTarget()override;
				CComPtr<ID2D1SolidColorBrush>		CreateDirect2DBrush(CColor color)override;
				void								DestroyDirect2DBrush(CColor color)override;
				CComPtr<ID2D1LinearGradientBrush>	CreateDirect2DLinearBrush(CColor c1, CColor c2)override;
				void								DestroyDirect2DLinearBrush(CColor c1, CColor c2)override;

			protected:
				CComPtr<IDWriteRenderingParams> CreateRenderingParams(DWRITE_RENDERING_MODE renderingMode, CComPtr<IDWriteRenderingParams> defaultParams, CComPtr<IDWriteFactory> dwriteFactory);

				IWindow*						window;
				CComPtr<ID2D1HwndRenderTarget>	d2dRenderTarget;
				vector<CRect>					clippers;
				cuint							clipperCoverWholeTargetCounter;

				CachedSolidBrushAllocator		solidBrushes;
				CachedLinearBrushAllocator		linearBrushes;
				set<RefPtr<D2DImageFrameCache>>	imageCaches;

				CComPtr<IDWriteRenderingParams>	noAntialiasParams;
				CComPtr<IDWriteRenderingParams>	horizontalAntialiasParams;
				CComPtr<IDWriteRenderingParams>	bidirectionalAntialiasParams;
			};

			class D2DLayoutProvider : public IGraphicsLayoutProvider
			{
			public:
				PassRefPtr<IGraphicsParagraph> CreateParagraph(const CString& text, PassRefPtr<IGraphicsRenderTarget> renderTarget)override;
			};
		}
	}
}

#endif