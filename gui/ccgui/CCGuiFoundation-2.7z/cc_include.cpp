#include "stdafx.h"
#include <Gdiplus.h>
#include "cc_include.h"
#include "cc_base.h"
#include "cc_interface.h"
#include "cc_resource.h"
#include "cc_presentation.h"
#include "cc_controller.h"
#include "cc_direct2d.h"
#include "cc_control.h"
#include "cc_element.h"
#include "cc_commonctrls.h"

using namespace cc::interfaces::windows;
using namespace cc::presentation::control;
using namespace cc::presentation::control::composition;
using namespace cc::presentation::control::event_args;
using namespace cc::presentation::direct2d;
using namespace cc::presentation::direct2d::resource;
using namespace cc::presentation::element;
using namespace cc::presentation::windows;
using namespace cc::presentation::windows::controller;

void SetupD2D();

//////////////////////////////////////////////////////////////////////////

extern "C" CCGUI_API int SetupCCGuiFoundation()
{
	_tsetlocale(LC_CTYPE, _T("chs"));
	_CrtSetDbgFlag(_CRTDBG_LEAK_CHECK_DF | _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG));
// 	_CrtSetBreakAlloc(160);
	::CoInitializeEx(NULL, COINIT_MULTITHREADED);
	ULONG_PTR gdiplus_token;
	Gdiplus::GdiplusStartupInput gdiplusStartupInput;
	Gdiplus::GdiplusStartup(&gdiplus_token, &gdiplusStartupInput, NULL);
	SetupD2D();
	Gdiplus::GdiplusShutdown(gdiplus_token);
	::CoUninitialize();
	_CrtDumpMemoryLeaks();
	return 0;
}

void SetupD2D()
{
	auto * pStorage = GetStorage();
	auto instance = pStorage->GetInstance();
	{
		RefPtr<IController> controller = adoptRef(new Controller(instance));
		RefPtr<IControllerListener> controllerListener = adoptRef(new D2DControllerListener);
		pStorage->SetDirect2DProvider(adoptRef(new D2DProvider()));
		pStorage->Init(controller, controllerListener, controllerListener);
		RefPtr<Application> application = adoptRef(new Application);
		RefPtr<ITheme> theme = adoptRef(new Win8Style);
		pStorage->Init2(application, theme);
	}
	{
		auto callbackService = pStorage->GetController()->GetCallbackService();
		RefPtr<IControllerListener> listener = pStorage->GetControllerListener();
		callbackService->InstallListener(listener);
		callbackService->InstallListener(pStorage->GetApplication());
		{
			RefPtr<D2DResourceManager> resourseManager = adoptRef(new D2DResourceManager);
			pStorage->SetGraphicsResourceManager(resourseManager);
			pStorage->SetDirect2DResourceManager(resourseManager);
			callbackService->InstallListener(resourseManager);
			pStorage->GetController()->GetInputService()->StartTimer();
			{
				SolidBorderElementRenderer::Register();
				RoundBorderElementRenderer::Register();
				Splitter3DElementRenderer::Register();
				SolidBackgroundElementRenderer::Register();
				GradientBackgroundElementRenderer::Register();
				Border3DElementRenderer::Register();
				SolidLabelElementRenderer::Register();
				ImageFrameElementRenderer::Register();
				PolygonElementRenderer::Register();
				ColorizedTextElementRenderer::Register();
				Direct2DElementRenderer::Register();
			}
			{
				RefPtr<Window> window = cc::global::ControlFactory::NewWindow();
				{
					Font font;
					font.size = 48;
					font.fontFamily = _T("��������_GBK");

					Font font1;
					font1.size = 12;
					font1.fontFamily = _T("Microsoft Yahei");

					window->SetText(_T("Test"));

					RefPtr<TableComposition> table = adoptRef(new TableComposition);
					table->SetRowsAndColumns(4, 3);
					table->SetRowOption(0, CellOption::PercentageOption(0.4));
					table->SetRowOption(1, CellOption::PercentageOption(0.4));
					table->SetRowOption(2, CellOption::PercentageOption(0.1));
					table->SetRowOption(3, CellOption::AbsoluteOption(140));
					table->SetColumnOption(0, CellOption::PercentageOption(0.35));
					table->SetColumnOption(1, CellOption::PercentageOption(0.35));
					table->SetColumnOption(2, CellOption::PercentageOption(0.30));
					table->SetAlignmentToParent(CRect());
					table->SetCellPadding(6);

					window->GetContainerComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
					window->GetContainerComposition()->AddChild(table);

					{
						RefPtr<TableCellComposition> cell = adoptRef(new TableCellComposition);
						cell->SetSite(0, 0, 1, 2);

						table->AddChild(cell);

						RefPtr<Label> label = cc::global::ControlFactory::NewLabel();
						{
							label->SetFont(font);
							label->SetText(_T("GUI Foundation!\n����һ�����Գ���"));
							label->GetBoundsComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
							label->GetBoundsComposition()->SetAlignmentToParent(CRect());
						}

						cell->AddChild(label->GetBoundsComposition());
					}
					{
						RefPtr<TableCellComposition> cell = adoptRef(new TableCellComposition);
						cell->SetSite(1, 0, 1, 1);

						table->AddChild(cell);

						RefPtr<Label> label = cc::global::ControlFactory::NewLabel();
						{
							label->SetFont(font);
							label->SetText(_T("Welcome!"));
							label->GetBoundsComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
							label->GetBoundsComposition()->SetAlignmentToParent(CRect());

							label->GetEventReceiver()->leftButtonDown.AttachLambda([](PassRefPtr<Composition> sender, EventArgs& arguments)
							{
								GetStorage()->GetApplication()->InvokeAsync([]()
								{
									Sleep(1000);
									GetStorage()->GetApplication()->InvokeInMainThreadAndWait([](){
										RefPtr<IWindow> w = GetStorage()->GetApplication()->GetMainWindow()->GetWindow();
										GetStorage()->GetController()->GetDialogService()->
											ShowMessageBox(w, L"hello", L"hello");
									});
								});
							});
						}

						cell->AddChild(label->GetBoundsComposition());
					}
					{
						RefPtr<TableCellComposition> cell = adoptRef(new TableCellComposition);
						cell->SetSite(1, 1, 1, 1);

						table->AddChild(cell);

						RefPtr<Label> label = cc::global::ControlFactory::NewLabel();
						{
							RefPtr<ICursor> hand = GetStorage()->GetController()->GetResourceService()->GetSystemCursor(ICursor::Hand);
							label->GetBoundsComposition()->SetAssociatedCursor(hand);

							label->SetFont(font);
							label->SetText(_T("Welcome!"));
							label->SetTextColor(Gdiplus::Color::Blue);
							label->GetBoundsComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
							label->GetBoundsComposition()->SetAlignmentToParent(CRect());

							label->GetEventReceiver()->mouseEnter.AttachLambda([](PassRefPtr<Composition> sender, EventArgs& arguments)
							{
								Font font = sender->GetRelatedControl()->GetFont();
								font.underline = true;
								sender->GetRelatedControl()->SetFont(font);
							});
							label->GetEventReceiver()->mouseLeave.AttachLambda([](PassRefPtr<Composition> sender, EventArgs& arguments)
							{
								Font font = sender->GetRelatedControl()->GetFont();
								font.underline = false;
								sender->GetRelatedControl()->SetFont(font);
							});
							label->GetEventReceiver()->leftButtonDown.AttachLambda([](PassRefPtr<Composition> sender, EventArgs& arguments)
							{
								{
									vector<CString> selectionFileNames;
									cint selectionFilterIndex = 0;
									if (GetStorage()->GetController()->GetDialogService()->ShowFileDialog(
										sender->GetRelatedGraphicsHost()->GetWindow(),
										selectionFileNames,
										selectionFilterIndex,
										IDialogService::FileDialogOpen,
										L"Open a text document",
										L"",
										L"",
										L".txt",
										L"Text Files(*.txt)|*.txt|All Files(*.*)|*.*",
										(IDialogService::FileDialogOptions)
										(IDialogService::FileDialogAddToRecent
										| IDialogService::FileDialogDereferenceLinks
										| IDialogService::FileDialogDirectoryMustExist
										| IDialogService::FileDialogFileMustExist
										)
										))
									{
										GetStorage()->GetController()->GetDialogService()->ShowMessageBox(sender->GetRelatedGraphicsHost()->GetWindow(), selectionFileNames[0], L"hello");
									}
								}
							});
						}

						cell->AddChild(label->GetBoundsComposition());
					}
					{
						RefPtr<TableCellComposition> cell = adoptRef(new TableCellComposition);
						cell->SetSite(2, 0, 1, 2);

						table->AddChild(cell);

						RefPtr<Direct2DElement> element = Direct2DElement::Create();
						element->BeforeRenderTargetChanged.AttachLambda([](PassRefPtr<Composition> sender, Direct2DElementEventArgs& args){
							RefPtr<IWindow> window = sender->GetRelatedGraphicsHost()->GetWindow();
							if (window)
							{
								GetStorage()->GetDirect2DProvider()->GetBindedRenderTarget(window)
									->DestroyDirect2DBrush(Gdiplus::Color::Blue);
								GetStorage()->GetDirect2DProvider()->GetBindedRenderTarget(window)
									->DestroyDirect2DBrush(Gdiplus::Color::Gray);
							}
						});
// 						element->AfterRenderTargetChanged.AttachLambda([](PassRefPtr<Composition> sender, Direct2DElementEventArgs& args){
// 							auto window = sender->GetRelatedGraphicsHost()->GetWindow();
// 							if (window)
// 							{
// 								GetStorage()->GetDirect2DProvider()->GetBindedRenderTarget(window)
// 									->CreateDirect2DBrush(Gdiplus::Color::Firebrick);
// 							}
// 						});
						element->Rendering.AttachLambda([](PassRefPtr<Composition> sender, Direct2DElementEventArgs& args){
							RefPtr<IWindow> window = sender->GetRelatedGraphicsHost()->GetWindow();
							if (window)
							{
								RefPtr<ID2DRenderTarget> renterTarget = GetStorage()->GetDirect2DProvider()->GetBindedRenderTarget(window);
								auto brush = renterTarget->CreateDirect2DBrush(Gdiplus::Color::Gray);
								auto brush1 = renterTarget->CreateDirect2DBrush(Gdiplus::Color::Blue);
								auto rect = D2D1::RectF(
									(FLOAT)args.bounds.left,
									(FLOAT)args.bounds.top,
									(FLOAT)args.bounds.right,
									(FLOAT)args.bounds.bottom);
								args.renterTarget->FillRectangle(rect, brush);

								{
									Font defaultFont;
									defaultFont.size = 16;
									defaultFont.fontFamily = _T("Microsoft Yahei");

									RefPtr<D2DTextFormatPackage> package = GetStorage()->GetDirect2DResourceManager()->CreateDirect2DTextFormat(defaultFont);
									package->textFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
									package->textFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER);

									wstringstream ss;
									auto t = system_clock::to_time_t(chrono::system_clock::now());
									tm m;
									localtime_s(&m, &t);
									ss << put_time(&m, _T("%Y/%m/%d %H:%M:%S"));
									auto time = ss.str();
									args.renterTarget->DrawText(time.c_str(), time.size(), package->textFormat, rect, brush1);
								}
							}
						});

						RefPtr<BoundsComposition> composition = adoptRef(new BoundsComposition);
						composition->SetAlignmentToParent(CRect(1, 1, 1 ,1));
						composition->SetOwnedElement(element);
						element->BeforeRenderTargetChanged.SetAssociatedComposition(composition);
						element->AfterRenderTargetChanged.SetAssociatedComposition(composition);
						element->Rendering.SetAssociatedComposition(composition);

						cell->AddChild(composition);
					}
					{
						RefPtr<TableCellComposition> tableCell = adoptRef(new TableCellComposition);
						tableCell->SetSite(0, 2, 3, 1);

						table->AddChild(tableCell);

						RefPtr<TableComposition> tableButton = adoptRef(new TableComposition);
						{
							tableButton->SetRowsAndColumns(2, 2);
							tableButton->SetRowOption(0, CellOption::PercentageOption(0.5));
							tableButton->SetRowOption(1, CellOption::PercentageOption(0.5));
							tableButton->SetColumnOption(0, CellOption::PercentageOption(0.5));
							tableButton->SetColumnOption(1, CellOption::PercentageOption(0.5));
							tableButton->SetAlignmentToParent(CRect(4, 4, 4, 4));
							tableButton->SetCellPadding(6);
							tableCell->AddChild(tableButton);
						}
						{
							{
								RefPtr<TableCellComposition> cell = adoptRef(new TableCellComposition);
								tableButton->AddChild(cell);
								cell->SetSite(0, 0, 1, 2);

								RefPtr<Button> buttonTarget = cc::global::ControlFactory::NewButton();
								buttonTarget->SetText(L"Target");
								buttonTarget->SetFont(font);
								buttonTarget->GetBoundsComposition()->SetAlignmentToParent(CRect());
								cell->AddChild(buttonTarget->GetBoundsComposition());
							}
							{
								RefPtr<TableCellComposition> cell = adoptRef(new TableCellComposition);
								tableButton->AddChild(cell);
								cell->SetSite(1, 0, 1, 1);

								RefPtr<Button> buttonEnable = cc::global::ControlFactory::NewButton();
								buttonEnable->SetText(L"Enable");
								buttonEnable->SetFont(font);
								buttonEnable->GetBoundsComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
								buttonEnable->GetBoundsComposition()->SetAlignmentToParent(CRect());
								cell->AddChild(buttonEnable->GetBoundsComposition());
							}
							{
								RefPtr<TableCellComposition> cell = adoptRef(new TableCellComposition);
								tableButton->AddChild(cell);
								cell->SetSite(1, 1, 1, 1);

								RefPtr<Button> buttonDisable = cc::global::ControlFactory::NewButton();
								buttonDisable->SetText(L"Disable");
								buttonDisable->SetFont(font);
								buttonDisable->GetBoundsComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
								buttonDisable->GetBoundsComposition()->SetAlignmentToParent(CRect());
								cell->AddChild(buttonDisable->GetBoundsComposition());
							}
						}
					}
					{
						RefPtr<TableCellComposition> tableCell = adoptRef(new TableCellComposition);
						tableCell->SetSite(3, 0, 1, 3);

						table->AddChild(tableCell);

						RefPtr<TableComposition> tableButton = adoptRef(new TableComposition);
						{
							tableButton->SetRowsAndColumns(1, 3);
							tableButton->SetRowOption(0, CellOption::PercentageOption(1));
							tableButton->SetColumnOption(0, CellOption::PercentageOption(0.3));
							tableButton->SetColumnOption(1, CellOption::PercentageOption(0.3));
							tableButton->SetColumnOption(2, CellOption::PercentageOption(0.3));
							tableButton->SetAlignmentToParent(CRect(4, 4, 4, 4));
							tableButton->SetCellPadding(6);
							tableCell->AddChild(tableButton);
						}
						{
							{
								RefPtr<TableCellComposition> cell = adoptRef(new TableCellComposition);
								tableButton->AddChild(cell);
								cell->SetSite(0, 0, 1, 1);

								RefPtr<Control> groupBox = cc::global::ControlFactory::NewGroupBox();
								groupBox->GetBoundsComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
								groupBox->GetContainerComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
								groupBox->GetContainerComposition()->SetInternalMargin(CRect(10, 10, 10, 10));
								groupBox->GetBoundsComposition()->SetAlignmentToParent(CRect());
								groupBox->SetText(L"group ck");
								groupBox->SetFont(font1);
								cell->AddChild(groupBox->GetBoundsComposition());

								RefPtr<StackComposition> stack = adoptRef(new StackComposition);
								stack->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
								stack->SetDirection(StackComposition::Vertical);
								stack->SetAlignmentToParent(CRect());
								stack->SetPadding(6);
								groupBox->GetContainerComposition()->AddChild(stack);

								CString name;
								for (int i = 0; i < 3; i++)
								{
									RefPtr<SelectableButton> button = cc::global::ControlFactory::NewCheckBox();
									name.Format(L"Option %d", i+1);
									button->SetText(name);
									button->SetFont(font1);
									button->GetBoundsComposition()->SetAlignmentToParent(CRect());

									RefPtr<StackItemComposition> stackItem = adoptRef(new StackItemComposition);
									stack->AddChild(stackItem);
									stackItem->AddChild(button->GetBoundsComposition());
								}
							}
							{
								RefPtr<TableCellComposition> cell = adoptRef(new TableCellComposition);
								tableButton->AddChild(cell);
								cell->SetSite(0, 1, 1, 1);

								RefPtr<Control> groupBox = cc::global::ControlFactory::NewGroupBox();
								groupBox->GetBoundsComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
								groupBox->GetContainerComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
								groupBox->GetContainerComposition()->SetInternalMargin(CRect(10, 10, 10, 10));
								groupBox->GetBoundsComposition()->SetAlignmentToParent(CRect());
								groupBox->SetText(L"group rd");
								groupBox->SetFont(font1);
								cell->AddChild(groupBox->GetBoundsComposition());

								RefPtr<StackComposition> stack = adoptRef(new StackComposition);
								stack->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
								stack->SetDirection(StackComposition::Vertical);
								stack->SetAlignmentToParent(CRect());
								stack->SetPadding(6);
								groupBox->GetContainerComposition()->AddChild(stack);

								RefPtr<GroupController> groupController = adoptRef(new MutexGroupController);
								window->AddComponent(groupController);

								CString name;
								for (int i = 0; i < 3; i++)
								{
									RefPtr<SelectableButton> button = cc::global::ControlFactory::NewRadioButton();
									name.Format(L"Option %d", i + 1);
									button->SetText(name);
									button->SetFont(font1);
									button->SetGroupController(groupController);
									button->GetBoundsComposition()->SetAlignmentToParent(CRect());

									RefPtr<StackItemComposition> stackItem = adoptRef(new StackItemComposition);
									stack->AddChild(stackItem);
									stackItem->AddChild(button->GetBoundsComposition());
								}
							}
							{
								RefPtr<TableCellComposition> cell = adoptRef(new TableCellComposition);
								tableButton->AddChild(cell);
								cell->SetSite(0, 2, 1, 1);

								RefPtr<Button> buttonDisable = cc::global::ControlFactory::NewButton();
								buttonDisable->SetText(L"Disable");
								buttonDisable->SetFont(font);
								buttonDisable->GetBoundsComposition()->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
								buttonDisable->GetBoundsComposition()->SetAlignmentToParent(CRect());
								cell->AddChild(buttonDisable->GetBoundsComposition());
							}
						}
					}

					window->ForceCalculateSizeImmediately();
					window->MoveToScreenCenter();
				}
				pStorage->GetApplication()->Run(window);
			}
			pStorage->SetDirect2DResourceManager(nullptr);
			pStorage->SetGraphicsResourceManager(nullptr);
		}
		callbackService->UninstallListener(pStorage->GetApplication());
		callbackService->UninstallListener(listener);
	}
	pStorage->Destroy();
}
