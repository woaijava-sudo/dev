#include "stdafx.h"
#include "cc_commonctrls.h"
#include "cc_presentation.h"

using namespace cc::presentation::windows;
using namespace cc::presentation::element;

namespace cc
{
	namespace global
	{
		PassRefPtr<Window> ControlFactory::NewWindow()
		{
			return adoptRef(new Window(GetStorage()->GetTheme()->CreateWindowStyle()));
		}

		PassRefPtr<Label> ControlFactory::NewLabel()
		{
			return adoptRef(new Label(GetStorage()->GetTheme()->CreateLabelStyle()));
		}

		PassRefPtr<Button> ControlFactory::NewButton()
		{
			return adoptRef(new Button(GetStorage()->GetTheme()->CreateButtonStyle()));
		}

		PassRefPtr<SelectableButton> ControlFactory::NewCheckBox()
		{
			return adoptRef(new SelectableButton(GetStorage()->GetTheme()->CreateCheckBoxStyle()));
		}

		PassRefPtr<SelectableButton> ControlFactory::NewRadioButton()
		{
			return adoptRef(new SelectableButton(GetStorage()->GetTheme()->CreateRadioButtonStyle()));
		}

		PassRefPtr<Control> ControlFactory::NewGroupBox()
		{
			return adoptRef(new Control(GetStorage()->GetTheme()->CreateGroupBoxStyle()));
		}
	}

	namespace presentation
	{
		namespace control
		{
			namespace style
			{
				GroupController::GroupController()
				{

				}

				GroupController::~GroupController()
				{
					while (!buttons.empty())
					{
						auto button = buttons.begin();
						(*button)->SetGroupController(nullptr);
					}
				}

				void GroupController::Attach(SelectableButton* button)
				{
					buttons.insert(button);
				}

				void GroupController::Detach(SelectableButton* button)
				{
					buttons.erase(button);
				}

				MutexGroupController::MutexGroupController()
					: suppress(false)
				{

				}

				MutexGroupController::~MutexGroupController()
				{

				}

				void MutexGroupController::OnSelectedChanged(PassRefPtr<SelectableButton> button)
				{
					if (!suppress)
					{
						suppress = true;
						for (auto & _button : buttons)
						{
							_button->SetSelected(_button == button);
						}
						suppress = false;
					}
				}
			}
		}
	}

	namespace presentation
	{
		namespace control
		{
			namespace helper
			{
				BYTE IntToColor(cint color)
				{
					return color < 0 ?
						0 : color > 0xFF
						? 0xFF : (BYTE)color;
				}

				CColor BlendColor(CColor c1, CColor c2, cint currentPosition, cint totalLength)
				{
					return CColor(
						IntToColor((c2.r*currentPosition + c1.r*(totalLength - currentPosition)) / totalLength),
						IntToColor((c2.g*currentPosition + c1.g*(totalLength - currentPosition)) / totalLength),
						IntToColor((c2.b*currentPosition + c1.b*(totalLength - currentPosition)) / totalLength),
						IntToColor((c2.a*currentPosition + c1.a*(totalLength - currentPosition)) / totalLength)
						);
				}
			}
		}

		namespace control
		{
			namespace style
			{
				using namespace helper;

				bool Win8ButtonColors::operator!=(const Win8ButtonColors& colors)
				{
					return !(*this == colors);
				}

				bool Win8ButtonColors::operator==(const Win8ButtonColors& colors)
				{
					return
						borderColor == colors.borderColor &&
						g1 == colors.g1 &&
						g2 == colors.g2 &&
						textColor == colors.textColor &&
						bullet == colors.bullet;
				}

				void Win8ButtonColors::SetAlphaWithoutText(unsigned char a)
				{
					borderColor.a = a;
					g1.a = a;
					g2.a = a;
				}

				Win8ButtonColors Win8ButtonColors::Blend(const Win8ButtonColors& c1, const Win8ButtonColors& c2, cint ratio, cint total)
				{
					if (ratio<0) ratio = 0;
					else if (ratio>total) ratio = total;

					Win8ButtonColors result;
					result.borderColor = BlendColor(c1.borderColor, c2.borderColor, ratio, total);
					result.g1 = BlendColor(c1.g1, c2.g1, ratio, total);
					result.g2 = BlendColor(c1.g2, c2.g2, ratio, total);
					result.textColor = BlendColor(c1.textColor, c2.textColor, ratio, total);
					result.bullet = BlendColor(c1.bullet, c2.bullet, ratio, total);
					return result;
				}

				Win8ButtonColors Win8ButtonColors::ButtonNormal()
				{
					Win8ButtonColors colors =
					{
						CColor(172, 172, 172),
						CColor(239, 239, 239),
						CColor(229, 229, 229),
						Win8WindowStyle::GetSystemTextColor(true),
					};
					return colors;
				}

				Win8ButtonColors Win8ButtonColors::ButtonActive()
				{
					Win8ButtonColors colors =
					{
						CColor(126, 180, 234),
						CColor(235, 244, 252),
						CColor(220, 236, 252),
						Win8WindowStyle::GetSystemTextColor(true),
					};
					return colors;
				}

				Win8ButtonColors Win8ButtonColors::ButtonPressed()
				{
					Win8ButtonColors colors =
					{
						CColor(86, 157, 229),
						CColor(218, 236, 252),
						CColor(196, 224, 252),
						Win8WindowStyle::GetSystemTextColor(true),
					};
					return colors;
				}

				Win8ButtonColors Win8ButtonColors::ButtonDisabled()
				{
					Win8ButtonColors colors =
					{
						CColor(173, 178, 181),
						CColor(252, 252, 252),
						CColor(252, 252, 252),
						Win8WindowStyle::GetSystemTextColor(false),
					};
					return colors;
				}

				Win8ButtonColors Win8ButtonColors::ItemNormal()
				{
					Win8ButtonColors colors =
					{
						CColor(112, 192, 231, 0),
						CColor(229, 243, 251, 0),
						CColor(229, 243, 251, 0),
						Win8WindowStyle::GetSystemTextColor(true),
					};
					return colors;
				}

				Win8ButtonColors Win8ButtonColors::ItemActive()
				{
					Win8ButtonColors colors =
					{
						CColor(112, 192, 231),
						CColor(229, 243, 251),
						CColor(229, 243, 251),
						Win8WindowStyle::GetSystemTextColor(true),
					};
					return colors;
				}

				Win8ButtonColors Win8ButtonColors::ItemSelected()
				{
					Win8ButtonColors colors =
					{
						CColor(102, 167, 232),
						CColor(209, 232, 255),
						CColor(209, 232, 255),
						Win8WindowStyle::GetSystemTextColor(true),
					};
					return colors;
				}

				Win8ButtonColors Win8ButtonColors::ItemDisabled()
				{
					Win8ButtonColors colors =
					{
						CColor(112, 192, 231, 0),
						CColor(229, 243, 251, 0),
						CColor(229, 243, 251, 0),
						Win8WindowStyle::GetSystemTextColor(false),
					};
					return colors;
				}

				Win8ButtonColors Win8ButtonColors::CheckedNormal(bool selected)
				{
					Win8ButtonColors colors =
					{
						CColor(112, 112, 112),
						CColor(255, 255, 255),
						CColor(255, 255, 255),
						Win8WindowStyle::GetSystemTextColor(true),
						CColor(0, 0, 0),
					};
					if (!selected)
					{
						colors.bullet.a = 0;
					}
					return colors;
				}

				Win8ButtonColors Win8ButtonColors::CheckedActive(bool selected)
				{
					Win8ButtonColors colors =
					{
						CColor(51, 153, 255),
						CColor(243, 249, 255),
						CColor(243, 249, 255),
						Win8WindowStyle::GetSystemTextColor(true),
						CColor(33, 33, 33),
					};
					if (!selected)
					{
						colors.bullet.a = 0;
					}
					return colors;
				}

				Win8ButtonColors Win8ButtonColors::CheckedPressed(bool selected)
				{
					Win8ButtonColors colors =
					{
						CColor(0, 124, 222),
						CColor(217, 236, 255),
						CColor(217, 236, 255),
						Win8WindowStyle::GetSystemTextColor(true),
						CColor(0, 0, 0),
					};
					if (!selected)
					{
						colors.bullet.a = 0;
					}
					return colors;
				}

				Win8ButtonColors Win8ButtonColors::CheckedDisabled(bool selected)
				{
					Win8ButtonColors colors =
					{
						CColor(188, 188, 188),
						CColor(230, 230, 230),
						CColor(230, 230, 230),
						Win8WindowStyle::GetSystemTextColor(false),
						CColor(112, 112, 112),
					};
					if (!selected)
					{
						colors.bullet.a = 0;
					}
					return colors;
				}

				Win8ButtonElements Win8ButtonElements::Create(Alignment horizontal /*= Alignment::StringAlignmentCenter*/, Alignment vertical /*= Alignment::StringAlignmentCenter*/)
				{
					Win8ButtonElements button;
					{
						button.mainComposition = adoptRef(new BoundsComposition);
						button.mainComposition->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
					}
					{
						RefPtr<SolidBorderElement> element = SolidBorderElement::Create();
						button.rectBorderElement = element;

						RefPtr<BoundsComposition> composition = adoptRef(new BoundsComposition);
						button.mainComposition->AddChild(composition);
						composition->SetAlignmentToParent(CRect());
						composition->SetOwnedElement(element);
					}
					{
						RefPtr<GradientBackgroundElement> element = GradientBackgroundElement::Create();
						button.backgroundElement = element;
						element->SetDirection(GradientBackgroundElement::Vertical);
						element->SetShape(ElementShape::Rectangle);

						RefPtr<BoundsComposition> composition = adoptRef(new BoundsComposition);
						button.backgroundComposition = composition;
						button.mainComposition->AddChild(composition);
						composition->SetAlignmentToParent(CRect(1, 1, 1, 1));
						composition->SetOwnedElement(element);
					}
					{
						button.textElement = SolidLabelElement::Create();
						button.textElement->SetAlignments(horizontal, vertical);
						button.textComposition = adoptRef(new BoundsComposition);
						button.textComposition->SetOwnedElement(button.textElement);
						button.textComposition->SetMargin(CRect());
						button.textComposition->SetMinSizeLimitation(Composition::LimitToElement);
						button.textComposition->SetAlignmentToParent(CRect());
						button.mainComposition->AddChild(button.textComposition);
					}
					return button;
				}

				void Win8ButtonElements::Apply(const Win8ButtonColors& colors)
				{
					if (rectBorderElement)
					{
						rectBorderElement->SetColor(colors.borderColor);
					}
					backgroundElement->SetColors(colors.g1, colors.g2);
					textElement->SetColor(colors.textColor);
				}

				Win8CheckedButtonElements Win8CheckedButtonElements::Create(ElementShape shape, bool backgroundVisible)
				{
					const cint checkSize = 13;
					const cint checkPadding = 2;

					Win8CheckedButtonElements button;
					{
						button.mainComposition = adoptRef(new BoundsComposition);
						button.mainComposition->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
					}
					{
						RefPtr<TableComposition> mainTable = adoptRef(new TableComposition);
						button.mainComposition->AddChild(mainTable);
						if (backgroundVisible)
						{
							RefPtr<SolidBackgroundElement> element = SolidBackgroundElement::Create();
							element->SetColor(Win8WindowStyle::GetSystemWindowColor());
							mainTable->SetOwnedElement(element);
						}
						mainTable->SetRowsAndColumns(1, 2);
						mainTable->SetAlignmentToParent(CRect());
						mainTable->SetRowOption(0, CellOption::PercentageOption(1.0));
						mainTable->SetColumnOption(0, CellOption::AbsoluteOption(checkSize + 2 * checkPadding));
						mainTable->SetColumnOption(1, CellOption::PercentageOption(1.0));

						{
							RefPtr<TableCellComposition> cell = adoptRef(new TableCellComposition);
							mainTable->AddChild(cell);
							cell->SetSite(0, 0, 1, 1);

							RefPtr<TableComposition> table = adoptRef(new TableComposition);
							cell->AddChild(table);
							table->SetRowsAndColumns(3, 1);
							table->SetAlignmentToParent(CRect());
							table->SetRowOption(0, CellOption::PercentageOption(0.5));
							table->SetRowOption(1, CellOption::MinSizeOption());
							table->SetRowOption(2, CellOption::PercentageOption(0.5));

							{
								RefPtr<TableCellComposition> checkCell = adoptRef(new TableCellComposition);
								table->AddChild(checkCell);
								checkCell->SetSite(1, 0, 1, 1);
								{
									RefPtr<BoundsComposition> borderBounds = adoptRef(new BoundsComposition);
									checkCell->AddChild(borderBounds);
									borderBounds->SetAlignmentToParent(CRect(checkPadding, -1, checkPadding, -1));
									borderBounds->SetMinSizeLimitation(Composition::LimitToElementAndChildren);
									{
										RefPtr<SolidBorderElement> element = SolidBorderElement::Create();
										button.bulletBorderElement = element;
										element->SetShape(shape);

										RefPtr<BoundsComposition> bounds = adoptRef(new BoundsComposition);
										borderBounds->AddChild(bounds);
										bounds->SetOwnedElement(element);
										bounds->SetAlignmentToParent(CRect());
										bounds->SetBounds(CRect(CPoint(), CSize(checkSize, checkSize)));
									}
									{
										RefPtr<GradientBackgroundElement> element = GradientBackgroundElement::Create();
										button.bulletBackgroundElement = element;
										element->SetShape(shape);
										element->SetDirection(GradientBackgroundElement::Vertical);

										RefPtr<BoundsComposition> bounds = adoptRef(new BoundsComposition);
										borderBounds->AddChild(bounds);
										bounds->SetOwnedElement(element);
										bounds->SetAlignmentToParent(CRect(1, 1, 1, 1));
									}
								}

								button.bulletCheckElement = nullptr;
								button.bulletRadioElement = nullptr;
								if (shape == ElementShape::Rectangle)
								{
									button.bulletCheckElement = SolidLabelElement::Create();
									{
										Font font;
										font.fontFamily = _T("Webdings");
										font.size = 16;
										font.bold = true;
										button.bulletCheckElement->SetFont(font);
									}
									button.bulletCheckElement->SetText(_T("a"));
									button.bulletCheckElement->SetAlignments(Alignment::StringAlignmentCenter, Alignment::StringAlignmentCenter);

									RefPtr<BoundsComposition> composition = adoptRef(new BoundsComposition);
									composition->SetOwnedElement(button.bulletCheckElement);
									composition->SetAlignmentToParent(CRect());
									checkCell->AddChild(composition);
								}
								else
								{
									button.bulletRadioElement = SolidBackgroundElement::Create();
									button.bulletRadioElement->SetShape(ElementShape::Ellipse);

									RefPtr<BoundsComposition> composition = adoptRef(new BoundsComposition);
									composition->SetOwnedElement(button.bulletRadioElement);
									composition->SetAlignmentToParent(CRect(checkPadding + 3, 3, checkPadding + 3, 3));
									checkCell->AddChild(composition);
								}
							}
						}
						{
							RefPtr<TableCellComposition> textCell = adoptRef(new TableCellComposition);
							mainTable->AddChild(textCell);
							textCell->SetSite(0, 1, 1, 1);
							{
								button.textElement = SolidLabelElement::Create();
								button.textElement->SetAlignments(Alignment::StringAlignmentNear, Alignment::StringAlignmentCenter);
								button.textComposition = adoptRef(new BoundsComposition);
								button.textComposition->SetOwnedElement(button.textElement);
								button.textComposition->SetMargin(CRect());
								button.textComposition->SetMinSizeLimitation(Composition::LimitToElement);
								button.textComposition->SetAlignmentToParent(CRect());
								textCell->AddChild(button.textComposition);
							}
						}
					}
					return button;
				}

				void Win8CheckedButtonElements::Apply(const Win8ButtonColors& colors)
				{
					bulletBorderElement->SetColor(colors.borderColor);
					bulletBackgroundElement->SetColors(colors.g1, colors.g2);
					textElement->SetColor(colors.textColor);
					if (bulletCheckElement)
					{
						bulletCheckElement->SetColor(colors.bullet);
					}
					if (bulletRadioElement)
					{
						bulletRadioElement->SetColor(colors.bullet);
					}
				}
			}
		}
	}
}