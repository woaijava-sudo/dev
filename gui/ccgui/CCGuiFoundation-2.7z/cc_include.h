#ifndef CC_INCLUDE
#define CC_INCLUDE

#include "stdafx.h"

extern "C" CCGUI_API int SetupCCGuiFoundation();

#endif