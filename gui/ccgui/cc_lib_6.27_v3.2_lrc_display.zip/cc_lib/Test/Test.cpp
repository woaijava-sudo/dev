// Test.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include <iostream>
#include "../cc_lib/cc_Include.h"

using namespace std;
using namespace cc::Strings;
using namespace cc::Collections;
using namespace cc::Collections::Enumerator;
using namespace cc::Ptr;
using namespace cc::Threading;
using namespace cc::Regex;

SpinLock lock;

void ThreadProc1(Thread* pthread, void* param)
{
	int i=0;
	while(i<10)
	{
		lock.Enter();
		wcout<<pthread->GetName()<<":"<<i++<<endl;
		lock.Leave();
	}
}

bool where1(int value)
{
	return (value%2==1);
}

int _tmain(int argc, _TCHAR* argv[])
{
    wcout.imbue(std::locale("chs"));
#define TEST_ASSERT ASSERT
	// ���Գ���

	// regex
	cout<<"regex"<<endl;

    List<String> kk;
    kk.Add(L"555type");
    kk.Clear();

    {
        //Regex t(L"/[(<a>/d{2}):(<b>/d{2})/.(<c>/d{2})/](<d>/.*?)/n",true);
        //Regex t(L"(/d+)");
        Regex t(L"/[(<a>/d{2}):(<b>/d{2})/.(<c>/d{2})/](<d>/.*?)/n", true);
        auto hh=L"[01:59.75]derek��tr������Ҥ����ǧ�������\r\n"
            L"[02:04.18]rthrth��ϸ�������廨�����\n";
        RegexMatch::MatchList ml;
        t.Search(hh,ml);

//         t.Search(L"[01:59.75]��������Ҥ����ǧ�������\r\n"
//             L"[02:04.18]��ϸ�������廨�����",ll);
//         for (int k=0;k<ll->Groups().Wrap().CreateEnumerator();k++)
        if (ml.Count()>0)
        {
            auto en=ml.Wrap().CreateEnumerator();

            while(en->Next())
            {
                const RegexMatch::CaptureGroup& dd = en->Current()->Groups();
                wcout<<L"a:"<<dd[L"a"].Get(0).Value().Buffer()<<endl;
                wcout<<L"b:"<<dd[L"b"].Get(0).Value().Buffer()<<endl;
                wcout<<L"c:"<<dd[L"c"].Get(0).Value().Buffer()<<endl;
                wcout<<L"d:"<<dd[L"d"].Get(0).Value().Buffer()<<endl;
            }
            delete en;
            //wcout<<ll->Captures().Get(0).Value().Buffer();
        }
    }
    cout<<endl;

	// Strings
	String a,b("b"),c('c'),d('d',2);
	String e=a+b+c+d;

	wcout<<(LPCTSTR)e;

    e.Format(_T("%f"),4.4);
    wcout<<(LPCTSTR)e;

	// Collections
	List<int> g;
	g.Add(4); g.Add(7); g.Add(3);
	cout<<g.Contains(4);
	cout<<g.IndexOf(3);
// 	cout<<g.Wrap().CreateEnumerator()->Current();
	cout<<": "<<g.Count();
	cout<<endl;

	cc::Collections::Array<int> ar;
	ar.Resize(3);
	ar.Set(0,1);
	ar.Set(1,10);
	ar.Set(2,100);

	cout<<ar.Get(1);
	cout<<": "<<ar.Count();
	cout<<endl;

// 	Dictionary<int,int> KK;
// 	KK.Add(3,6);
// 	cout<<"dict: "<<KK.Get(3)<<endl;
	Dictionary<String,int,LPCTSTR> KK;
	KK.Add(_T("646"),6);
	cout<<"dict: "<<KK[_T("646")]<<endl;
	Group<int,String,int,LPCTSTR> GG;
	GG.Add(3, _T("t"));
	wcout<<L"group: "<<(LPCTSTR)GG[3].Get(0)<<endl;

	// Enumerator
	DistinctEnumerator<int> dd(g.Wrap().CreateEnumerator());
	DistinctEnumerator<int> de(dd);
	cout<<"---"<<de.Current()<<endl;
 	while(de.Next())
	{
		cout<<de.Current()<<",";
	}
	cout<<endl;

	WhereEnumerator<int> we(g.Wrap().CreateEnumerator(),where1);
	while(we.Next())
	{
		cout<<we.Current()<<",";
	}
	cout<<"uhahaha"<<endl;

    //remove
    List<int> t;
    t.Add(3);t.Add(7);t.Add(3);t.Add(7);t.Add(3);t.Add(3);
    int counts = t.Count();
    for (int i = counts - 1; i >= 0; i--)
    {
        int cnt = 0;
        while (i >= 0 && t[i]==3)
        {
            i--; cnt++;
        }

        if (cnt > 0)
        {
            cout<<i+1<<" , "<<cnt<<endl;
            t.RemoveRange(i+1, cnt);
        }

        for (int j=0;j<t.Count();j++)
        {
            cout<<t[j]<<" ";
        }cout<<endl;
    }
    
    cout<<endl<<"e"<<endl;

	// Ptr
	AutoPtr<String> p = new String;
	p->Format(L"555%d",6);
	wcout<<p.Obj()->GetBuffer(0)<<endl;
	AutoPtr<String> q=p;
	wcout<<p.Reference()<<endl;

	// Threading

// 	Thread::CreateAndStart(ThreadProc1, L"hello");
// 
// 	{
// 		int i=0;
// 		while(i<10)
// 		{
// 			if (lock.TryEnter())
// 			{
// 				cout<<"main:"<<i++<<endl;
// 				lock.Leave();
// 			}
// 		}
// 	}

	// gdi
	XSize sz(45,6);//wcout<<(LPCTSTR)sz.ToString();

	Sleep(1000);

	return 0;
}

