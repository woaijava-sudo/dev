/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Function.h

Include:
File:../core/cc_Macro.h

***********************************************************************/

#ifndef _CC_CORE_FTUNCTION_H
#define _CC_CORE_FTUNCTION_H

#include "cc_Ptr.h"
#include "cc_Macro.h"

CC_BEGIN_NAMESPACE
namespace Function
{
	//////////////////////////////////////////////////////////////////////////
	//
	//		���ú꣬���ؼ��ٴ�����:)
	//		����ί��ģ��Ҳ�ǰ�װ�࣬�����������������̰߳�ȫ
	//
	//////////////////////////////////////////////////////////////////////////
	using namespace cc::Ptr;

	//////////////////////////////////////////////////////////////////////////
	// 
	// Class: cc::Function::Func<>
	//
	template<typename T> class Func {};

#pragma region Class: cc::Function::Func<T(*)> - ����ί��ģ��
	//////////////////////////////////////////////////////////////////////////
	// 
	// Class: cc::Function::Func<T(*)> - ����ί��ģ��
	//
	CC_IMPL_FUNC_T_TN_ADV(_);
	CC_IMPL_FUNC_T_TN_ADV(0);
	CC_IMPL_FUNC_T_TN_ADV(1);
	CC_IMPL_FUNC_T_TN_ADV(2);
	CC_IMPL_FUNC_T_TN_ADV(3);
	CC_IMPL_FUNC_T_TN_ADV(4);
	CC_IMPL_FUNC_T_TN_ADV(5);
	CC_IMPL_FUNC_T_TN_ADV(6);
	CC_IMPL_FUNC_T_TN_ADV(7);
	CC_IMPL_FUNC_T_TN_ADV(8);
	CC_IMPL_FUNC_T_TN_ADV(9);
#pragma endregion

#pragma region Class: cc::Function::Func<void(*)> - ����ί��ģ��
	//////////////////////////////////////////////////////////////////////////
	// 
	// Class: cc::Function::Func<void(*)> - ����ί��ģ��
	//
	CC_IMPL_FUNC_V_TN_ADV(_);
	CC_IMPL_FUNC_V_TN_ADV(0);
	CC_IMPL_FUNC_V_TN_ADV(1);
	CC_IMPL_FUNC_V_TN_ADV(2);
	CC_IMPL_FUNC_V_TN_ADV(3);
	CC_IMPL_FUNC_V_TN_ADV(4);
	CC_IMPL_FUNC_V_TN_ADV(5);
	CC_IMPL_FUNC_V_TN_ADV(6);
	CC_IMPL_FUNC_V_TN_ADV(7);
	CC_IMPL_FUNC_V_TN_ADV(8);
	CC_IMPL_FUNC_V_TN_ADV(9);
#pragma endregion

	namespace Binding
	{
		//////////////////////////////////////////////////////////////////////////
		// 
		// Struct: cc::Function::Binding::Binding<>
		//
		template<typename T> struct Binding {};

		// Binding Type
		// void const ref
		template<typename T> struct VCR				{ typedef const T&	_Type; };
		template<typename T> struct VCR<T&>			{ typedef T&		_Type; };
		template<typename T> struct VCR<const T>	{ typedef const T&	_Type; };
		template<typename T> struct VCR<const T&>	{ typedef const T&	_Type; };

		// ref const ref
		template<typename T> struct RCR				{ typedef T			_Type; };
		template<typename T> struct RCR<T&>			{ typedef T&		_Type; };
		template<typename T> struct RCR<const T>	{ typedef T			_Type; };
		template<typename T> struct RCR<const T&>	{ typedef T			_Type; };

#pragma region Struct: cc::Function::Binding::Binding<T(*)> - ������ģ��
		//////////////////////////////////////////////////////////////////////////
		// 
		// Struct: cc::Function::Binding::Binding<T(*)> - ������ģ��
		//
		CC_IMPL_BIND_T_TN_ADV(0);
		CC_IMPL_BIND_T_TN_ADV(1);
		CC_IMPL_BIND_T_TN_ADV(2);
		CC_IMPL_BIND_T_TN_ADV(3);
		CC_IMPL_BIND_T_TN_ADV(4);
		CC_IMPL_BIND_T_TN_ADV(5);
		CC_IMPL_BIND_T_TN_ADV(6);
		CC_IMPL_BIND_T_TN_ADV(7);
		CC_IMPL_BIND_T_TN_ADV(8);
		CC_IMPL_BIND_T_TN_ADV(9);
#pragma endregion

#pragma region Struct: cc::BINDtion::Binding::Binding<void(*)> - ������ģ��
		//////////////////////////////////////////////////////////////////////////
		// 
		// Struct: cc::BINDtion::Binding::Binding<void(*)> - ������ģ��
		//
		CC_IMPL_BIND_V_TN_ADV(0);
		CC_IMPL_BIND_V_TN_ADV(1);
		CC_IMPL_BIND_V_TN_ADV(2);
		CC_IMPL_BIND_V_TN_ADV(3);
		CC_IMPL_BIND_V_TN_ADV(4);
		CC_IMPL_BIND_V_TN_ADV(5);
		CC_IMPL_BIND_V_TN_ADV(6);
		CC_IMPL_BIND_V_TN_ADV(7);
		CC_IMPL_BIND_V_TN_ADV(8);
		CC_IMPL_BIND_V_TN_ADV(9);
#pragma endregion
	}

	namespace Combining
	{
		//////////////////////////////////////////////////////////////////////////
		// 
		// Class: cc::Function::Combining::Combining<>
		//
		template<typename R1, typename R2, typename T> class Combining {};

#pragma region Class: cc::Function::Combining::Combining<> - �������ģ��
		//////////////////////////////////////////////////////////////////////////
		// 
		// Class: cc::Function::Combining::Combining<> - �������ģ��
		//
		CC_IMPL_COMB_T_TN_ADV(_);
		CC_IMPL_COMB_T_TN_ADV(0);
		CC_IMPL_COMB_T_TN_ADV(1);
		CC_IMPL_COMB_T_TN_ADV(2);
		CC_IMPL_COMB_T_TN_ADV(3);
		CC_IMPL_COMB_T_TN_ADV(4);
		CC_IMPL_COMB_T_TN_ADV(5);
		CC_IMPL_COMB_T_TN_ADV(6);
		CC_IMPL_COMB_T_TN_ADV(7);
		CC_IMPL_COMB_T_TN_ADV(8);
		CC_IMPL_COMB_T_TN_ADV(9);
#pragma endregion
	}
}
CC_END_NAMESPACE

#endif