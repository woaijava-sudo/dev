/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Exception.h

Impl:
File:../core/cc_Exception.cpp

Include:
File:../core/cc_Exception.h

Class:

***********************************************************************/

#include "stdafx.h"
#include "cc_Exception.h"

CC_BEGIN_NAMESPACE

//////////////////////////////////////////////////////////////////////////

Exception::Exception()
{

}

Exception::Exception( LPCTSTR pstrMessage )
{
	m_Message = pstrMessage;
}

LPCTSTR Exception::GetMessage() const
{
	return m_Message;
}

/***********************************************************************
RegexException
***********************************************************************/

RegexException::RegexException()
{
}

RegexException::RegexException(LPCTSTR _message):Exception(_message)
{
}

CC_END_NAMESPACE