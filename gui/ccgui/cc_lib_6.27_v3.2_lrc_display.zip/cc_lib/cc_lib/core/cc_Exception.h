/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Exception.h

Impl:
File:../core/cc_Exception.cpp

Include:
File:../core/cc_Base.cpp
File:../core/cc_String.cpp

Class:
	Exception									���쳣����
	ArgumentException							�������쳣
	ParsingException							�������쳣

***********************************************************************/

#ifndef _CC_CORE_EXCEPTION_H
#define _CC_CORE_EXCEPTION_H

#include "cc_Base.h"
#include "cc_String.h"

CC_BEGIN_NAMESPACE
using namespace cc::Strings;

//////////////////////////////////////////////////////////////////////////
// 
// Class: cc::Exception - �쳣
//
class CL_API Exception
{
public:
	Exception();
	Exception(LPCTSTR _message);

	LPCTSTR GetMessage() const;

protected:
	String	m_Message;
};

//////////////////////////////////////////////////////////////////////////
// 
// Class: cc::RegexException
//
class CL_API RegexException : public Exception
{
public:
	RegexException();
	RegexException(LPCTSTR _message);
};

CC_END_NAMESPACE

#endif
