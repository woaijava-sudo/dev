/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Thread.h

Impl:
File:../core/cc_Thread.cpp

Include:
File:../core/cc_Base.h
File:../core/cc_Thread.h
File:../core/cc_String.h
File:../collections/cc_Interface.h
File:../collections/cc_List.h

***********************************************************************/

#include "stdafx.h"
#include <Windows.h>
#include "cc_Base.h"
#include "cc_String.h"
#include "cc_Thread.h"
#include "../collections/cc_Interface.h"
#include "../collections/cc_List.h"

CC_BEGIN_NAMESPACE
namespace Threading
{
	using namespace Internal;
	using namespace Collections;
	using namespace Strings;

	namespace Internal
	{
		//////////////////////////////////////////////////////////////////////////
		// 
		// struct: cc::Thread::Internal::WaitableData
		//
		struct WaitableData
		{
			HANDLE handle; String name;
			WaitableData(HANDLE _handle): handle(_handle) {}
		};
	}

	//////////////////////////////////////////////////////////////////////////
	// 
	// class: cc::Thread::WaitableObject
	//
	WaitableObject::WaitableObject(): _waitableData(NULL) {}

	void WaitableObject::SetData(Internal::WaitableData* data)
	{
		_waitableData = data;
	}

	LPCTSTR WaitableObject::GetName() const
	{
		return _waitableData->name;
	}

    void WaitableObject::SetName(LPCTSTR pstrName)
    {
        _waitableData->name = pstrName;
    }

	BOOL WaitableObject::IsCreated() const
	{
		return _waitableData != NULL;
	}

	BOOL WaitableObject::Wait()
	{
		return WaitForTime(INFINITE);
	}

	BOOL WaitableObject::WaitForTime(int ms)
	{
		if(IsCreated())
		{
			if(::WaitForSingleObject(_waitableData->handle, (DWORD)ms)==WAIT_OBJECT_0)
			{
				return true;
			}
		}
		return false;
	}

	BOOL WaitableObject::WaitAll(WaitableObject** objects, int count)
	{
		Array<HANDLE> handles(count);
		for(int i = 0; i < count; i++)
		{
			handles[i] = objects[i]->_waitableData->handle;
		}
		DWORD result = ::WaitForMultipleObjects((DWORD)count, &handles[0], TRUE, INFINITE);
		return result == WAIT_OBJECT_0 || result == WAIT_ABANDONED_0;
	}

	BOOL WaitableObject::WaitAllForTime(WaitableObject** objects, int count, int ms)
	{
		Array<HANDLE> handles(count);
		for(int i = 0; i < count; i++)
		{
			handles[i] = objects[i]->_waitableData->handle;
		}
		DWORD result = ::WaitForMultipleObjects((DWORD)count, &handles[0], TRUE, (DWORD)ms);
		return result == WAIT_OBJECT_0 || result == WAIT_ABANDONED_0;
	}

	int WaitableObject::WaitAny(WaitableObject** objects, int count, BOOL* abandoned)
	{
		Array<HANDLE> handles(count);
		for(int i = 0; i < count; i++)
		{
			handles[i] = objects[i]->_waitableData->handle;
		}
		DWORD result = ::WaitForMultipleObjects((DWORD)count, &handles[0], FALSE, INFINITE);
		if(WAIT_OBJECT_0 <= result && result < WAIT_OBJECT_0 + count)
		{
			*abandoned = false;
			return result - WAIT_OBJECT_0;
		}
		else if(WAIT_ABANDONED_0 <= result && result < WAIT_ABANDONED_0 + count)
		{
			*abandoned = true;
			return result - WAIT_ABANDONED_0;
		}
		return -1;
	}

	int WaitableObject::WaitAnyForTime(WaitableObject** objects, int count, int ms, BOOL* abandoned)
	{
		Array<HANDLE> handles(count);
		for(int i = 0; i < count; i++)
		{
			handles[i] = objects[i]->_waitableData->handle;
		}
		DWORD result = ::WaitForMultipleObjects((DWORD)count, &handles[0], FALSE, (DWORD)ms);
		if(WAIT_OBJECT_0 <= result && result < WAIT_OBJECT_0 + count)
		{
			*abandoned = false;
			return result - WAIT_OBJECT_0;
		}
		else if(WAIT_ABANDONED_0 <= result && result < WAIT_ABANDONED_0 + count)
		{
			*abandoned = true;
			return result - WAIT_ABANDONED_0;
		}
		return -1;
	}

	namespace Internal
	{
		//////////////////////////////////////////////////////////////////////////
		// 
		// struct: cc::Thread::Internal::ThreadData
		//
		struct ThreadData : public WaitableData
		{
			DWORD tid;
			ThreadData(): WaitableData(NULL), tid(-1) {}
		};

		//////////////////////////////////////////////////////////////////////////
		// 
		// class: cc::Thread::Internal::ProceduredThread
		//
		class ProceduredThread : public Thread
		{
		protected:
			void Run()
			{
				procedure(this, argument);
				if(deleteAfterStopped) delete this;
			}

		public:
			ProceduredThread(Thread::ThreadProcedure _procedure, LPCTSTR _thread_name, void* _argument, BOOL _deleteAfterStopped):
				Thread(_thread_name), procedure(_procedure), argument(_argument), deleteAfterStopped(_deleteAfterStopped) {}

		private:
			Thread::ThreadProcedure		procedure;
			void*						argument;
			BOOL						deleteAfterStopped;
		};
	}

	void InternalThreadProc(Thread* thread)
	{
		thread->Run();
		thread->_threadState = Thread::Dead;
	}

	DWORD WINAPI InternalThreadProcWrapper(LPVOID lpParameter)
	{
		InternalThreadProc((Thread*)lpParameter);
		return 0;
	}

	Thread::Thread(LPCTSTR thread_name /*= NULL*/)
	{
		_internalData = new ThreadData;
		_internalData->handle = ::CreateThread(NULL, 0, InternalThreadProcWrapper, this,
			CREATE_SUSPENDED, &_internalData->tid);
		if (thread_name != NULL)
			_internalData->name = thread_name;
		_threadState=Thread::New;
		SetData(_internalData);
	}

	Thread::~Thread()
	{
		Stop();
		::CloseHandle(_internalData->handle);
		delete _internalData;
	}

	Thread* Thread::CreateAndStart(ThreadProcedure procedure,  LPCTSTR thread_name, void* argument, BOOL deleteAfterStopped)
	{
		if(procedure)
		{
			Thread* thread = new ProceduredThread(procedure, thread_name, argument, deleteAfterStopped);
			if(thread->Start())
			{
				return thread;
			}
			else if(deleteAfterStopped)
			{
				delete thread;
			}
		}
		return NULL;
	}

	void Thread::Sleep(int ms)
	{
		::Sleep((DWORD)ms);
	}

	int Thread::GetCPUCount()
	{
		SYSTEM_INFO info;
		::GetSystemInfo(&info);
		return info.dwNumberOfProcessors;
	}

	int Thread::GetCurrentThreadId()
	{
		return (int)::GetCurrentThreadId();
	}

	BOOL Thread::Start()
	{
		if(_threadState == Thread::New && _internalData->handle != NULL)
		{
			if(::ResumeThread(_internalData->handle) != -1)
			{
				_threadState = Thread::Running;
				return true;
			}
		}
		return false;
	}

	BOOL Thread::Pause()
	{
		if(_threadState == Thread::Running)
		{
			if(::SuspendThread(_internalData->handle) != -1)
			{
				_threadState = Thread::Paused;
				return true;
			}
		}
		return false;
	}

	BOOL Thread::Resume()
	{
		if(_threadState == Thread::Paused)
		{
			if(::ResumeThread(_internalData->handle) != -1)
			{
				_threadState = Thread::Running;
				return true;
			}
		}
		return false;
	}

	BOOL Thread::Stop()
	{
		if(_internalData->handle != NULL)
		{
			Pause();
			_threadState = Thread::Dead;
			return true;
		}
		return false;
	}

	Thread::ThreadState Thread::GetState() const
	{
		return _threadState;
	}

	void Thread::SetCPU(int index)
	{
		::SetThreadAffinityMask(_internalData->handle, (1<<index));
	}

	namespace Internal
	{
		//////////////////////////////////////////////////////////////////////////
		// 
		// struct: cc::Thread::Internal::MutexData
		//
		struct MutexData : public WaitableData
		{
			MutexData(HANDLE _handle): WaitableData(_handle) {}
		};
	}

	//////////////////////////////////////////////////////////////////////////
	// 
	// class: cc::Thread::Mutex
	//
	Mutex::Mutex(): _internalData(NULL) {}

	Mutex::~Mutex()
	{
		if(_internalData)
		{
			::CloseHandle(_internalData->handle);
			delete _internalData;
		}
	}

	BOOL Mutex::Create(BOOL owned, LPCTSTR name)
	{
		if(IsCreated()) return false;
		HANDLE handle = ::CreateMutex(NULL, owned, name);
		if(handle)
		{
			_internalData = new MutexData(handle);
			SetData(_internalData);
		}
		return IsCreated();
	}

	BOOL Mutex::Open(BOOL inheritable, LPCTSTR name)
	{
		if(IsCreated()) return false;
		HANDLE handle = ::OpenMutex(SYNCHRONIZE, inheritable, name);
		if(handle)
		{
			_internalData = new MutexData(handle);
			SetData(_internalData);
		}
		return IsCreated();
	}

	BOOL Mutex::Release()
	{
		if(IsCreated())
		{
			return ::ReleaseMutex(_internalData->handle);
		}
		return false;
	}

	namespace Internal
	{
		//////////////////////////////////////////////////////////////////////////
		// 
		// struct: cc::Thread::Internal::SemaphoreData
		//
		struct SemaphoreData : public WaitableData
		{
			SemaphoreData(HANDLE _handle): WaitableData(_handle) {}
		};
	}

	//////////////////////////////////////////////////////////////////////////
	// 
	// class: cc::Thread::Semaphore
	//
	Semaphore::Semaphore(): _internalData(NULL) {}

	Semaphore::~Semaphore()
	{
		if(_internalData)
		{
			::CloseHandle(_internalData->handle);
			delete _internalData;
		}
	}

	BOOL Semaphore::Create(int initialCount, int maxCount, LPCTSTR name)
	{
		if(IsCreated()) return false;
		HANDLE handle = ::CreateSemaphore(NULL, (LONG)initialCount, (LONG)maxCount, name);
		if(handle)
		{
			_internalData = new SemaphoreData(handle);
			SetData(_internalData);
		}
		return IsCreated();
	}

	BOOL Semaphore::Open(BOOL inheritable, LPCTSTR name)
	{
		if(IsCreated()) return false;
		HANDLE handle = ::OpenSemaphore(SYNCHRONIZE, inheritable, name);
		if(handle)
		{
			_internalData = new SemaphoreData(handle);
			SetData(_internalData);
		}
		return IsCreated();
	}

	BOOL Semaphore::Release()
	{
		if(IsCreated())
		{
			return Release(1) != -1;
		}
		return false;
	}

	int Semaphore::Release(int count)
	{
		if(IsCreated())
		{
			LONG previous = -1;
			if(::ReleaseSemaphore(_internalData->handle, (LONG)count, &previous))
			{
				return (int)previous;
			}
		}
		return -1;
	}

	namespace Internal
	{
		//////////////////////////////////////////////////////////////////////////
		// 
		// struct: cc::Thread::Internal::EventData
		//
		struct EventData : public WaitableData
		{
			EventData(HANDLE _handle): WaitableData(_handle) {}
		};
	}

	Event::Event(): _internalData(NULL) {}

	Event::~Event()
	{
		if(_internalData)
		{
			::CloseHandle(_internalData->handle);
			delete _internalData;
		}
	}

	BOOL Event::CreateAutoUnsignal(BOOL signaled, LPCTSTR name)
	{
		if(IsCreated()) return false;
		HANDLE handle = ::CreateEvent(NULL, FALSE, signaled, name);
		if(handle)
		{
			_internalData = new EventData(handle);
			SetData(_internalData);
		}
		return IsCreated();
	}

	BOOL Event::CreateManualUnsignal(BOOL signaled, LPCTSTR name)
	{
		if(IsCreated()) return false;
		HANDLE handle = ::CreateEvent(NULL, TRUE, signaled, name);
		if(handle)
		{
			_internalData = new EventData(handle);
			SetData(_internalData);
		}
		return IsCreated();
	}

	BOOL Event::Open(BOOL inheritable, LPCTSTR name)
	{
		if(IsCreated()) return false;
		HANDLE handle = ::OpenEvent(SYNCHRONIZE, inheritable, name);
		if(handle)
		{
			_internalData = new EventData(handle);
			SetData(_internalData);
		}
		return IsCreated();
	}

	BOOL Event::Signal()
	{
		if(IsCreated())
		{
			return ::SetEvent(_internalData->handle);
		}
		return false;
	}

	BOOL Event::Unsignal()
	{
		if(IsCreated())
		{
			return ::ResetEvent(_internalData->handle);
		}
		return false;
	}

	namespace Internal
	{
		//////////////////////////////////////////////////////////////////////////
		// 
		// struct: cc::Thread::Internal::ThreadPoolQueueProcArgument
		//
		struct ThreadPoolQueueProcArgument
		{
			void(*proc)(void*);
			void* argument;
		};
	}

	DWORD WINAPI ThreadPoolQueueProc(void* argument)
	{
		ThreadPoolQueueProcArgument* proc = (ThreadPoolQueueProcArgument*)argument;
		proc->proc(proc->argument);
		delete proc;
		return 0;
	}

	DWORD WINAPI ThreadPoolQueueFunc(void* argument)
	{
		Func<void()>* proc = (Func<void()>*)argument;
		(*proc)();
		delete proc;
		return 0;
	}

	ThreadPool::ThreadPool() {}
	ThreadPool::~ThreadPool() {}

	BOOL ThreadPool::Queue(void(*proc)(void*), void* argument)
	{
		ThreadPoolQueueProcArgument* p = new ThreadPoolQueueProcArgument;
		p->proc = proc;
		p->argument = argument;
		if(QueueUserWorkItem(&ThreadPoolQueueProc, p, WT_EXECUTEDEFAULT))
		{
			return true;
		}
		else
		{
			delete p;
			return false;
		}
	}

	BOOL ThreadPool::Queue(const Func<void()>& proc)
	{
		Func<void()>* p = new Func<void()>(proc);
		if(QueueUserWorkItem(&ThreadPoolQueueFunc, p, WT_EXECUTEDEFAULT))
		{
			return true;
		}
		else
		{
			delete p;
			return false;
		}
	}

	namespace Internal
	{
		//////////////////////////////////////////////////////////////////////////
		// 
		// struct: cc::Thread::Internal::CriticalSectionData
		//
		struct CriticalSectionData
		{
			CRITICAL_SECTION	criticalSection;
		};
	}

	//////////////////////////////////////////////////////////////////////////
	// 
	// class: cc::Thread::CriticalSection::Scope
	//
	CriticalSection::Scope::Scope(CriticalSection& criticalSection):
	_criticalSection(&criticalSection)
	{
		_criticalSection->Enter();
	}

	CriticalSection::Scope::~Scope()
	{
		_criticalSection->Leave();
	}

	//////////////////////////////////////////////////////////////////////////
	// 
	// class: cc::Thread::CriticalSection
	//
	CriticalSection::CriticalSection()
	{
		_internalData = new CriticalSectionData;
		::InitializeCriticalSection(&_internalData->criticalSection);
	}

	CriticalSection::~CriticalSection()
	{
		::DeleteCriticalSection(&_internalData->criticalSection);
		delete _internalData;
	}

	BOOL CriticalSection::TryEnter()
	{
		return TryEnterCriticalSection(&_internalData->criticalSection)!=0;
	}

	void CriticalSection::Enter()
	{
		::EnterCriticalSection(&_internalData->criticalSection);
	}

	void CriticalSection::Leave()
	{
		::LeaveCriticalSection(&_internalData->criticalSection);
	}

	namespace Internal
	{
		//////////////////////////////////////////////////////////////////////////
		// 
		// struct: cc::Thread::Internal::ReaderWriterLockData
		//
		struct ReaderWriterLockData
		{
			SRWLOCK		lock;
		};
	}

	//////////////////////////////////////////////////////////////////////////
	// 
	// class: cc::Thread::ReaderWriterLock::ReaderScope
	//
	ReaderWriterLock::ReaderScope::ReaderScope(ReaderWriterLock& lock)
		:_lock(&lock)
	{
		_lock->EnterReader();
	}

	ReaderWriterLock::ReaderScope::~ReaderScope()
	{
		_lock->LeaveReader();
	}

	//////////////////////////////////////////////////////////////////////////
	// 
	// class: cc::Thread::ReaderWriterLock::WriterScope
	//
	ReaderWriterLock::WriterScope::WriterScope(ReaderWriterLock& lock)
		:_lock(&lock)
	{
		_lock->EnterWriter();
	}

	ReaderWriterLock::WriterScope::~WriterScope()
	{
		_lock->LeaveWriter();
	}

	//////////////////////////////////////////////////////////////////////////
	// 
	// class: cc::Thread::ReaderWriterLock
	//
	ReaderWriterLock::ReaderWriterLock():
	_internalData(new ReaderWriterLockData)
	{
		::InitializeSRWLock(&_internalData->lock);
	}

	ReaderWriterLock::~ReaderWriterLock()
	{
		delete _internalData;
	}

	BOOL ReaderWriterLock::TryEnterReader()
	{
		return ::TryAcquireSRWLockShared(&_internalData->lock);
	}

	void ReaderWriterLock::EnterReader()
	{
		::AcquireSRWLockShared(&_internalData->lock);
	}

	void ReaderWriterLock::LeaveReader()
	{
		::ReleaseSRWLockShared(&_internalData->lock);
	}

	BOOL ReaderWriterLock::TryEnterWriter()
	{
		return ::TryAcquireSRWLockExclusive(&_internalData->lock);
	}

	void ReaderWriterLock::EnterWriter()
	{
		::AcquireSRWLockExclusive(&_internalData->lock);
	}

	void ReaderWriterLock::LeaveWriter()
	{
		::ReleaseSRWLockExclusive(&_internalData->lock);
	}

	namespace Internal
	{
		//////////////////////////////////////////////////////////////////////////
		// 
		// struct: cc::Thread::Internal::ConditionVariableData
		//
		struct ConditionVariableData
		{
			CONDITION_VARIABLE			variable;
		};
	}

	//////////////////////////////////////////////////////////////////////////
	// 
	// class: cc::Thread::ConditionVariable
	//
	ConditionVariable::ConditionVariable(): _internalData(new ConditionVariableData)
	{
		::InitializeConditionVariable(&_internalData->variable);
	}

	ConditionVariable::~ConditionVariable()
	{
		delete _internalData;
	}

	BOOL ConditionVariable::SleepWith(CriticalSection& cs)
	{
		return ::SleepConditionVariableCS(&_internalData->variable, &cs._internalData->criticalSection, INFINITE);
	}

	BOOL ConditionVariable::SleepWithForTime(CriticalSection& cs, int ms)
	{
		return ::SleepConditionVariableCS(&_internalData->variable, &cs._internalData->criticalSection, (DWORD)ms);
	}

	BOOL ConditionVariable::SleepWithReader(ReaderWriterLock& lock)
	{
		return ::SleepConditionVariableSRW(&_internalData->variable, &lock._internalData->lock, INFINITE, CONDITION_VARIABLE_LOCKMODE_SHARED);
	}

	BOOL ConditionVariable::SleepWithReaderForTime(ReaderWriterLock& lock, int ms)
	{
		return ::SleepConditionVariableSRW(&_internalData->variable, &lock._internalData->lock, (DWORD)ms, CONDITION_VARIABLE_LOCKMODE_SHARED);
	}

	BOOL ConditionVariable::SleepWithWriter(ReaderWriterLock& lock)
	{
		return ::SleepConditionVariableSRW(&_internalData->variable, &lock._internalData->lock, INFINITE, 0);
	}

	BOOL ConditionVariable::SleepWithWriterForTime(ReaderWriterLock& lock, int ms)
	{
		return ::SleepConditionVariableSRW(&_internalData->variable, &lock._internalData->lock, (DWORD)ms, 0);
	}

	void ConditionVariable::WakeOnePending()
	{
		::WakeConditionVariable(&_internalData->variable);
	}

	void ConditionVariable::WakeAllPendings()
	{
		::WakeAllConditionVariable(&_internalData->variable);
	}

	//////////////////////////////////////////////////////////////////////////
	// 
	// class: cc::Thread::SpinLock::Scope
	//
	SpinLock::Scope::Scope(SpinLock& spinLock): _spinLock(&spinLock)
	{
		_spinLock->Enter();
	}

	SpinLock::Scope::~Scope()
	{
		_spinLock->Leave();
	}

	//////////////////////////////////////////////////////////////////////////
	// 
	// class: cc::Thread::SpinLock
	//
	SpinLock::SpinLock(): _token(0) {}
	SpinLock::~SpinLock() {}

	BOOL SpinLock::TryEnter()
	{
		return ::InterlockedExchange(&_token, 1) == 0;
	}

	void SpinLock::Enter()
	{
		while(::InterlockedCompareExchange(&_token, 1, 0) != 0)
		{
			while(_token != 0) ::_mm_pause();
		}
	}

	void SpinLock::Leave()
	{
		::InterlockedExchange(&_token, 0);
	}
}
CC_END_NAMESPACE