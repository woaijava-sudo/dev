/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Base.h

Impl:
File:../core/cc_Base.cpp

Include:

Class:
	TextReader									���ַ����Ķ���
	TextWriter									���ַ�����д��
	StreamReader								�����Ķ���
	StreamWriter								������д��
	EncoderStream								��������
	DecoderStream								��������
	MemoryStream								���ڴ���
	MemoryWrapperStream							���ڴ������
	BroadcastStream								���㲥��
	CacheStream									��������
	FileStream									���ļ���
	RecorderStream								��������

	CharEncoder									���ַ�������������
	CharDecoder									���ַ�������������
	MbcsEncoder									��Mbcs������
	MbcsDecoder									��Mbcs������
	Utf16Encoder								��Utf16������
	Utf16Decoder								��Utf16������
	Utf16BEEncoder								��Utf16 Big Endian������
	Utf16BEDecoder								��Utf16 Big Endian������
	Utf8Encoder									��Utf8������
	Utf8Decoder									��Utf8������
	BomEncoder									��BOM��ر�����
	BomDecoder									��BOM��ؽ�����

***********************************************************************/

#include "stdafx.h"

CC_BEGIN_NAMESPACE

namespace Stream
{
	using namespace Collections;
	using namespace Strings;

	/***********************************************************************
	TextReader
	***********************************************************************/

	String TextReader::ReadString(int length)
	{
		TCHAR* buffer=new TCHAR[length+1];
		int i=0;
		for(;i<length;i++)
		{
			if((buffer[i]=ReadChar())==_T('\0'))
			{
				break;
			}
		}
		buffer[i]=_T('\0');
		String result(buffer);
		delete[] buffer;
		return result;
	}

	String TextReader::ReadLine()
	{
		String result;
		TCHAR buffer[65537];
		buffer[0]=_T('\0');
		int i=0;
		while(true)
		{
			TCHAR c=ReadChar();
			if(c==_T('\n') || c==_T('\0'))
			{
				buffer[i]=_T('\0');
				result+=buffer;
				buffer[0]=_T('\0');
				i=0;
				break;
			}
			else
			{
				if(i==65536)
				{
					buffer[i]=_T('\0');
					result+=buffer;
					buffer[0]=_T('\0');
					i=0;
				}
				buffer[i++]=c;
			}
		}
		result+=buffer;
		if(result.Length()>0 && result[result.Length()-1]==_T('\r'))
		{
			return result.Left(result.Length()-1);
		}
		else
		{
			return result;
		}
	}

	String TextReader::ReadToEnd()
	{
		String result;
		TCHAR buffer[65537];
		buffer[0]=_T('\0');
		int i=0;
		while(true)
		{
			TCHAR c=ReadChar();
			if(c==_T('\0'))
			{
				buffer[i]=_T('\0');
				result+=buffer;
				buffer[0]=_T('\0');
				i=0;
				break;
			}
			else
			{
				if(i==65536)
				{
					buffer[i]=_T('\0');
					result+=buffer;
					buffer[0]=_T('\0');
					i=0;
				}
				buffer[i++]=c;
			}
		}
		result+=buffer;
		return result;
	}

	/***********************************************************************
	TextWriter
	***********************************************************************/

	void TextWriter::WriteString(const TCHAR* string, int charCount)
	{
		while(*string)
		{
			WriteChar(*string++);
		}
	}

	void TextWriter::WriteString(const TCHAR* string)
	{
		WriteString(string, (int)wcslen(string));
	}

	void TextWriter::WriteString(const String& string)
	{
		if(string.Length())
		{
			WriteString(string.Buffer(), string.Length());
		}
	}

	void TextWriter::WriteLine(const TCHAR* string, int charCount)
	{
		WriteString(string, charCount);
		WriteString(_T("\r\n"), 2);
	}

	void TextWriter::WriteLine(const TCHAR* string)
	{
		WriteString(string);
		WriteString(_T("\r\n"), 2);
	}

	void TextWriter::WriteLine(const String& string)
	{
		WriteString(string);
		WriteString(_T("\r\n"), 2);
	}

	namespace monospace_tabling
	{
		void WriteBorderLine(TextWriter& writer, Array<int>& columnWidths, int columns)
		{
			writer.WriteChar(_T('+'));
			for(int i=0;i<columns;i++)
			{
				int c=columnWidths[i];
				for(int j=0;j<c;j++)
				{
					writer.WriteChar(_T('-'));
				}
				writer.WriteChar(_T('+'));
			}
			writer.WriteLine(_T(""));
		}

		void WriteContentLine(TextWriter& writer, Array<int>& columnWidths, int rowHeight, int columns, Array<String>& tableByRow, int startRow)
		{
			int cellStart=startRow*columns;
			for(int r=0;r<rowHeight;r++)
			{
				writer.WriteChar(_T('|'));
				for(int c=0;c<columns;c++)
				{
					const TCHAR* cell=tableByRow[cellStart+c].Buffer();
					for(int i=0;i<r;i++)
					{
						if(cell) cell=wcsstr(cell, _T("\r\n"));
						if(cell) cell+=2;
					}

					writer.WriteChar(_T(' '));
					int length=0;
					if(cell)
					{
						const TCHAR* end=wcsstr(cell, _T("\r\n"));
						length=end?end-cell:(int)wcslen(cell);
						writer.WriteString(cell, length);
					}

					for(int i=columnWidths[c]-2;i>=length;i--)
					{
						writer.WriteChar(_T(' '));
					}
					writer.WriteChar(_T('|'));
				}
				writer.WriteLine(_T(""));
			}
		}
	}
	using namespace monospace_tabling;

	void TextWriter::WriteMonospacedEnglishTable(Array<String>& tableByRow, int rows, int columns)
	{
		Array<int> rowHeights(rows);
		Array<int> columnWidths(columns);
		for(int i=0;i<rows;i++) rowHeights[i]=0;
		for(int j=0;j<columns;j++) columnWidths[j]=0;

		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<columns;j++)
			{
				String text=tableByRow[i*columns+j];
				const TCHAR* reading=text.Buffer();
				int width=0;
				int height=0;

				while(reading)
				{
					height++;
					const TCHAR* crlf=wcsstr(reading, _T("\r\n"));
					if(crlf)
					{
						int length=crlf-reading+2;
						if(width<length) width=length;
						reading=crlf+2;
					}
					else
					{
						int length=(int)wcslen(reading)+2;
						if(width<length) width=length;
						reading=0;
					}
				}

				if(rowHeights[i]<height) rowHeights[i]=height;
				if(columnWidths[j]<width) columnWidths[j]=width;
			}
		}

		WriteBorderLine(*this, columnWidths, columns);
		for(int i=0;i<rows;i++)
		{
			WriteContentLine(*this, columnWidths, rowHeights[i], columns, tableByRow, i);
			WriteBorderLine(*this, columnWidths, columns);
		}
	}

	/***********************************************************************
	StringReader
	***********************************************************************/

	void StringReader::PrepareIfLastCallIsReadLine()
	{
		if(lastCallIsReadLine)
		{
			lastCallIsReadLine=false;
			if(current<string.Length() && string[current]==_T('\r')) current++;
			if(current<string.Length() && string[current]==_T('\n')) current++;
		}
	}

	StringReader::StringReader(const String& _string)
		:string(_string)
		,current(0)
		,lastCallIsReadLine(false)
	{
	}

	bool StringReader::IsEnd()
	{
		return current==string.Length();
	}

	TCHAR StringReader::ReadChar()
	{
		PrepareIfLastCallIsReadLine();
		if(IsEnd())
		{
			return _T('\0');
		}
		else
		{
			return string[current++];
		}
	}

	String StringReader::ReadString(int length)
	{
		PrepareIfLastCallIsReadLine();
		if(IsEnd())
		{
			return _T("");
		}
		else
		{
			int remain=string.Length()-current;
			if(length>remain) length=remain;
			String result=string.Mid(current, length);
			current+=length;
			return result;
		}
	}

	String StringReader::ReadLine()
	{
		PrepareIfLastCallIsReadLine();
		if(IsEnd())
		{
			return _T("");
		}
		else
		{
			int lineEnd=current;
			while(lineEnd<string.Length())
			{
				TCHAR c=string[lineEnd];
				if(c==_T('\r') || c==_T('\n')) break;
				lineEnd++;
			}
			String result=string.Mid(current, lineEnd-current);
			current=lineEnd;
			lastCallIsReadLine=true;
			return result;
		}
	}

	String StringReader::ReadToEnd()
	{
		return ReadString(string.Length()-current);
	}

	/***********************************************************************
	StreamReader
	***********************************************************************/

	StreamReader::StreamReader(IStream& _stream)
		:stream(&_stream)
	{
	}

	bool StreamReader::IsEnd()
	{
		return stream==0;
	}

	TCHAR StreamReader::ReadChar()
	{
		if(stream)
		{
			TCHAR buffer=0;
			if(stream->Read(&buffer, sizeof(buffer))==0)
			{
				stream=0;
				return 0;
			}
			else
			{
				return buffer;
			}
		}
		else
		{
			return _T('\0');
		}
	}

	/***********************************************************************
	StreamWriter
	***********************************************************************/

	StreamWriter::StreamWriter(IStream& _stream)
		:stream(&_stream)
	{
	}

	void StreamWriter::WriteChar(TCHAR c)
	{
		stream->Write(&c, sizeof(c));
	}

	void StreamWriter::WriteString(const TCHAR* string, int charCount)
	{
		stream->Write((void*)string, charCount*sizeof(*string));
	}

	/***********************************************************************
	EncoderStream
	***********************************************************************/

	EncoderStream::EncoderStream(IStream& _stream, IEncoder& _encoder)
		:stream(&_stream)
		,encoder(&_encoder)
		,position(0)
	{
		encoder->Setup(stream);
	}

	EncoderStream::~EncoderStream()
	{
		Close();
	}

	bool EncoderStream::CanRead()const
	{
		return false;
	}

	bool EncoderStream::CanWrite()const
	{
		return IsAvailable();
	}

	bool EncoderStream::CanSeek()const
	{
		return false;
	}

	bool EncoderStream::CanPeek()const
	{
		return false;
	}

	bool EncoderStream::IsLimited()const
	{
		return stream!=0 && stream->IsLimited();
	}

	bool EncoderStream::IsAvailable()const
	{
		return stream!=0 && stream->IsAvailable();
	}

	void EncoderStream::Close()
	{
		encoder->Close();
		stream=0;
	}

	fpos_t EncoderStream::Position()const
	{
		return IsAvailable()?position:-1;
	}

	fpos_t EncoderStream::Size()const
	{
		return -1;
	}

	void EncoderStream::Seek(fpos_t _size)
	{
		ASSERT(NULL);
	}

	void EncoderStream::SeekFromBegin(fpos_t _size)
	{
		ASSERT(NULL);
	}

	void EncoderStream::SeekFromEnd(fpos_t _size)
	{
		ASSERT(NULL);
	}

	int EncoderStream::Read(void* _buffer, int _size)
	{
		ASSERT(NULL);
		return 0;
	}

	int EncoderStream::Write(void* _buffer, int _size)
	{
		int result=encoder->Write(_buffer, _size);
		if(result>=0)
		{
			position+=result;
		}
		return result;
	}

	int EncoderStream::Peek(void* _buffer, int _size)
	{
		ASSERT(NULL);
		return 0;
	}

	/***********************************************************************
	DecoderStream
	***********************************************************************/

	DecoderStream::DecoderStream(IStream& _stream, IDecoder& _decoder)
		:stream(&_stream)
		,decoder(&_decoder)
		,position(0)
	{
		decoder->Setup(stream);
	}

	DecoderStream::~DecoderStream()
	{
		Close();
	}

	bool DecoderStream::CanRead()const
	{
		return IsAvailable();
	}

	bool DecoderStream::CanWrite()const
	{
		return false;
	}

	bool DecoderStream::CanSeek()const
	{
		return false;
	}

	bool DecoderStream::CanPeek()const
	{
		return false;
	}

	bool DecoderStream::IsLimited()const
	{
		return stream!=0 && stream->IsLimited();
	}

	bool DecoderStream::IsAvailable()const
	{
		return stream!=0 && stream->IsAvailable();
	}

	void DecoderStream::Close()
	{
		decoder->Close();
		stream=0;
	}

	fpos_t DecoderStream::Position()const
	{
		return IsAvailable()?position:-1;
	}

	fpos_t DecoderStream::Size()const
	{
		return -1;
	}

	void DecoderStream::Seek(fpos_t _size)
	{
		ASSERT(NULL);
	}

	void DecoderStream::SeekFromBegin(fpos_t _size)
	{
		ASSERT(NULL);
	}

	void DecoderStream::SeekFromEnd(fpos_t _size)
	{
		ASSERT(NULL);
	}

	int DecoderStream::Read(void* _buffer, int _size)
	{
		int result=decoder->Read(_buffer, _size);
		if(result>=0)
		{
			position+=result;
		}
		return result;
	}

	int DecoderStream::Write(void* _buffer, int _size)
	{
		ASSERT(NULL);
		return 0;
	}

	int DecoderStream::Peek(void* _buffer, int _size)
	{
		ASSERT(NULL);
		return 0;
	}

	/***********************************************************************
	BroadcastStream
	***********************************************************************/

	BroadcastStream::BroadcastStream()
		:closed(false)
		,position(0)
	{
	}

	BroadcastStream::~BroadcastStream()
	{
	}

	BroadcastStream::StreamList& BroadcastStream::Targets()
	{
		return streams;
	}

	bool BroadcastStream::CanRead()const
	{
		return false;
	}

	bool BroadcastStream::CanWrite()const
	{
		return !closed;
	}

	bool BroadcastStream::CanSeek()const
	{
		return false;
	}

	bool BroadcastStream::CanPeek()const
	{
		return false;
	}

	bool BroadcastStream::IsLimited()const
	{
		return false;
	}

	bool BroadcastStream::IsAvailable()const
	{
		return !closed;
	}

	void BroadcastStream::Close()
	{
		closed=true;
		position=-1;
	}

	fpos_t BroadcastStream::Position()const
	{
		return position;
	}

	fpos_t BroadcastStream::Size()const
	{
		return position;
	}

	void BroadcastStream::Seek(fpos_t _size)
	{
		ASSERT(NULL);
	}

	void BroadcastStream::SeekFromBegin(fpos_t _size)
	{
		ASSERT(NULL);
	}

	void BroadcastStream::SeekFromEnd(fpos_t _size)
	{
		ASSERT(NULL);
	}

	int BroadcastStream::Read(void* _buffer, int _size)
	{
		ASSERT(NULL);
		return 0;
	}

	int BroadcastStream::Write(void* _buffer, int _size)
	{
		for(int i=0;i<streams.Count();i++)
		{
			streams[i]->Write(_buffer, _size);
		}
		position+=_size;
		return _size;
	}

	int BroadcastStream::Peek(void* _buffer, int _size)
	{
		ASSERT(NULL);
		return 0;
	}

	/***********************************************************************
	CacheStream
	***********************************************************************/

	void CacheStream::Flush()
	{
		if(dirtyLength>0)
		{
			if(target->Position()!=start+dirtyStart)
			{
				target->SeekFromBegin(start+dirtyStart);
			}
			target->Write(buffer+dirtyStart, dirtyLength);
		}
		dirtyStart=0;
		dirtyLength=0;
		availableLength=0;
	}

	void CacheStream::Load(fpos_t _position)
	{
		if(target->Position()!=_position)
		{
			target->SeekFromBegin(_position);
		}
		start=_position;
		if(target->CanRead())
		{
			availableLength=target->Read(buffer, block);
		}
	}

	int CacheStream::InternalRead(void* _buffer, int _size)
	{
		int readed=0;
		if(position>=start && position<start+availableLength)
		{
			int bufferMax=(int)(start+availableLength-position);
			int min=bufferMax<_size?bufferMax:_size;
			memcpy(_buffer, buffer+(position-start), min);
			readed+=min;
			_buffer=(char*)_buffer+min;
		}

		if(_size>readed)
		{
			Flush();
			if(_size-readed>=block)
			{
				if(CanSeek())
				{
					target->SeekFromBegin(position+readed);
				}
				int additional=target->Read(_buffer, _size-readed);
				if(additional!=-1)
				{
					readed+=additional;
				}
			}
			else
			{
				Load(position+readed);
				int remain=_size-readed;
				int min=availableLength<remain?availableLength:remain;
				memcpy(_buffer, buffer, min);
				readed+=min;
			}
		}
		return readed;
	}

	int CacheStream::InternalWrite(void* _buffer, int _size)
	{
		int written=0;
		if(position>=start && position<start+block)
		{
			int bufferMax=(int)(start+block-position);
			int writeLength=bufferMax<_size?bufferMax:_size;
			int writeStart=(int)(position-start);

			memcpy(buffer+writeStart, _buffer, writeLength);
			written+=writeLength;
			_buffer=(char*)_buffer+writeLength;

			if(dirtyLength==0)
			{
				dirtyStart=writeStart;
				dirtyLength=writeLength;
			}
			else
			{
				dirtyLength=writeStart+writeLength-dirtyStart;
			}

			int availableOffset=writeStart+writeLength-availableLength;
			if(availableOffset>0)
			{
				availableLength+=availableOffset;
			}
		}

		if(_size>written)
		{
			Flush();
			if(_size-written>=block)
			{
				if(CanSeek())
				{
					target->SeekFromBegin(position+written);
				}
				int additional=target->Write(_buffer, _size-written);
				if(additional!=-1)
				{
					written+=additional;
				}
			}
			else
			{
				Load(position+written);
				dirtyLength=_size-written;
				memcpy(buffer, _buffer, dirtyLength);
				written+=dirtyLength;
			}
		}
		return written;
	}

	CacheStream::CacheStream(IStream& _target, int _block)
		:target(&_target)
		,block(_block)
		,start(0)
		,position(0)
		,dirtyStart(0)
		,dirtyLength(0)
		,availableLength(0)
		,operatedSize(0)
	{
		if(block<=0)
		{
			block=65536;
		}
		buffer=new char[block];
	}

	CacheStream::~CacheStream()
	{
		Close();
	}

	bool CacheStream::CanRead()const
	{
		return target!=0 && target->CanRead();
	}

	bool CacheStream::CanWrite()const
	{
		return target!=0 && target->CanWrite();
	}

	bool CacheStream::CanSeek()const
	{
		return target!=0 && target->CanSeek();
	}

	bool CacheStream::CanPeek()const
	{
		return target!=0 && target->CanPeek();
	}

	bool CacheStream::IsLimited()const
	{
		return target!=0 && target->IsLimited();
	}

	bool CacheStream::IsAvailable()const
	{
		return target!=0 && target->IsAvailable();
	}

	void CacheStream::Close()
	{
		Flush();
		target=0;
		delete[] buffer;
		buffer=0;
		position=-1;
		dirtyStart=0;
		dirtyLength=0;
		availableLength=0;
		operatedSize=-1;
	}

	fpos_t CacheStream::Position()const
	{
		return position;
	}

	fpos_t CacheStream::Size()const
	{
		if(target!=0)
		{
			if(IsLimited())
			{
				return target->Size();
			}
			else
			{
				return operatedSize;
			}
		}
		else
		{
			return -1;
		}
	}

	void CacheStream::Seek(fpos_t _size)
	{
		SeekFromBegin(position+_size);
	}

	void CacheStream::SeekFromBegin(fpos_t _size)
	{
		if(CanSeek())
		{
			if(_size<0)
			{
				position=0;
			}
			else if(_size>Size())
			{
				position=Size();
			}
			else
			{
				position=_size;
			}
		}
	}

	void CacheStream::SeekFromEnd(fpos_t _size)
	{
		SeekFromBegin(Size()-_size);
	}

	int CacheStream::Read(void* _buffer, int _size)
	{
		ASSERT(CanRead());
		ASSERT(_size>=0);

		_size=InternalRead(_buffer, _size);
		position+=_size;
		if(operatedSize<position)
		{
			operatedSize=position;
		}
		return _size;
	}

	int CacheStream::Write(void* _buffer, int _size)
	{
		ASSERT(CanWrite());
		ASSERT(_size>=0);

		if(IsLimited())
		{
			fpos_t size=Size();
			if(size!=-1)
			{
				int remain=(int)(size-(position+_size));
				if(remain<0)
				{
					_size-=remain;
				}
			}
		}

		_size=InternalWrite(_buffer, _size);
		position+=_size;
		if(operatedSize<position)
		{
			operatedSize=position;
		}
		return _size;
	}

	int CacheStream::Peek(void* _buffer, int _size)
	{
		ASSERT(CanPeek());
		ASSERT(_size>=0);

		return InternalRead(_buffer, _size);
	}

	/***********************************************************************
	CharEncoder
	***********************************************************************/

	CharEncoder::CharEncoder()
		:stream(0)
		,cacheSize(0)
	{
	}

	void CharEncoder::Setup(IStream* _stream)
	{
		stream=_stream;
	}

	void CharEncoder::Close()
	{
	}

	int CharEncoder::Write(void* _buffer, int _size)
	{
		const int all=cacheSize+_size;
		const int chars=all/sizeof(TCHAR);
		const int bytes=chars*sizeof(TCHAR);
		TCHAR* unicode=0;
		bool needToFree=false;
		int result=0;

		if(chars)
		{
			if(cacheSize>0)
			{
				unicode=new TCHAR[chars];
				memcpy(unicode, cacheBuffer, cacheSize);
				memcpy(((cuint8_t*)unicode)+cacheSize, _buffer, bytes-cacheSize);
				needToFree=true;
			}
			else
			{
				unicode=(TCHAR*)_buffer;
			}
			result=WriteString(unicode, chars)*sizeof(TCHAR)-cacheSize;
			cacheSize=0;
		}

		if(needToFree)
		{
			delete[] unicode;
		}
		if(all-bytes>0)
		{
			cacheSize=all-bytes;
			memcpy(cacheBuffer, (cuint8_t*)_buffer+_size-cacheSize, cacheSize);
			result+=cacheSize;
		}
		return result;
	}

	/***********************************************************************
	CharDecoder
	***********************************************************************/

	CharDecoder::CharDecoder()
		:stream(0)
		,cacheSize(0)
	{
	}

	void CharDecoder::Setup(IStream* _stream)
	{
		stream=_stream;
	}

	void CharDecoder::Close()
	{
	}

	int CharDecoder::Read(void* _buffer, int _size)
	{
		cuint8_t* unicode=(cuint8_t*)_buffer;
		int result=0;
		{
			int index=0;
			while(cacheSize>0 && _size>0)
			{
				*unicode++=cacheBuffer[index]++;
				cacheSize--;
				_size--;
				result++;
			}
		}

		const int chars=_size/sizeof(TCHAR);
		int bytes=ReadString((TCHAR*)unicode, chars)*sizeof(TCHAR);
		result+=bytes;
		_size-=bytes;
		unicode+=bytes;

		if(_size>0)
		{
			TCHAR c;
			if(ReadString(&c, 1)==1)
			{
				cacheSize=sizeof(TCHAR)-_size;
				memcpy(unicode, &c, _size);
				memcpy(cacheBuffer, (cuint8_t*)c+_size, cacheSize);
				result+=_size;
			}
		}
		return result;
	}

	/***********************************************************************
	Mbcs
	***********************************************************************/

	int MbcsEncoder::WriteString(TCHAR* _buffer, int chars)
	{
		int length=WideCharToMultiByte(CP_THREAD_ACP, 0, _buffer, (int)chars, NULL, NULL, NULL, NULL);
		char* mbcs=new char[length];
		WideCharToMultiByte(CP_THREAD_ACP, 0, _buffer, (int)chars, mbcs, (int)length, NULL, NULL);
		int result=stream->Write(mbcs, length);
		delete[] mbcs;
		if(result==length)
		{
			return chars;
		}
		else
		{
			Close();
			return 0;
		}
	}

	int MbcsDecoder::ReadString(TCHAR* _buffer, int chars)
	{
		char* source=new char[chars*2];
		char* reading=source;
		int readed=0;
		while(readed<chars)
		{
			if(stream->Read(reading, 1)!=1)
			{
				break;
			}
			if(IsDBCSLeadByte(*reading))
			{
				if(stream->Read(reading+1, 1)!=1)
				{
					break;
				}
				reading+=2;
			}
			else
			{
				reading++;
			}
			readed++;
		}
		MultiByteToWideChar(CP_THREAD_ACP, 0, source, (int)(reading-source), _buffer, (int)chars);
		delete[] source;
		return readed;
	}

	/***********************************************************************
	Utf-16
	***********************************************************************/

	int Utf16Encoder::WriteString(TCHAR* _buffer, int chars)
	{
		return stream->Write(_buffer, chars*sizeof(TCHAR))/sizeof(TCHAR);
	}

	int Utf16Decoder::ReadString(TCHAR* _buffer, int chars)
	{
		return stream->Read(_buffer, chars*sizeof(TCHAR))/sizeof(TCHAR);
	}

	/***********************************************************************
	Utf-16-be
	***********************************************************************/

	int Utf16BEEncoder::WriteString(TCHAR* _buffer, int chars)
	{
		int writed=0;
		while(writed<chars)
		{
			if(stream->Write(((unsigned char*)_buffer)+1, 1)!=1)
			{
				break;
			}
			if(stream->Write(_buffer, 1)!=1)
			{
				break;
			}
			_buffer++;
			writed++;
		}
		if(writed!=chars)
		{
			Close();
		}
		return writed;
	}

	int Utf16BEDecoder::ReadString(TCHAR* _buffer, int chars)
	{
		chars=stream->Read(_buffer, chars*sizeof(TCHAR))/sizeof(TCHAR);
		unsigned char* unicode=(unsigned char*)_buffer;
		for(int i=0;i<chars;i++)
		{
			unsigned char t=unicode[0];
			unicode[0]=unicode[1];
			unicode[1]=t;
			unicode++;
		}
		return chars;
	}

	/***********************************************************************
	Utf8
	***********************************************************************/

	int Utf8Encoder::WriteString(TCHAR* _buffer, int chars)
	{
		int length=WideCharToMultiByte(CP_UTF8, 0, _buffer, (int)chars, NULL, NULL, NULL, NULL);
		char* mbcs=new char[length];
		WideCharToMultiByte(CP_UTF8, 0, _buffer, (int)chars, mbcs, (int)length, NULL, NULL);
		int result=stream->Write(mbcs, length);
		delete[] mbcs;
		if(result==length)
		{
			return chars;
		}
		else
		{
			Close();
			return 0;
		}
	}

	Utf8Decoder::Utf8Decoder()
		:cache(0)
		,cacheAvailable(false)
	{
	}

	int Utf8Decoder::ReadString(TCHAR* _buffer, int chars)
	{
		cuint8_t source[4];
		TCHAR target[2];
		TCHAR* writing=_buffer;
		int readed=0;
		int sourceCount=0;

		while(readed<chars)
		{
			if(cacheAvailable)
			{
				*writing++=cache;
				cache=0;
				cacheAvailable=false;
			}
			else
			{
				if(stream->Read(source, 1)!=1)
				{
					break;
				}
				if((*source & 0xF0) == 0xF0)
				{
					if(stream->Read(source+1, 3)!=3)
					{
						break;
					}
					sourceCount=4;
				}
				else if((*source & 0xE0) == 0xE0)
				{
					if(stream->Read(source+1, 2)!=2)
					{
						break;
					}
					sourceCount=3;
				}
				else if((*source & 0xC0) == 0xC0)
				{
					if(stream->Read(source+1, 1)!=1)
					{
						break;
					}
					sourceCount=2;
				}
				else
				{
					sourceCount=1;
				}
				int targetCount=MultiByteToWideChar(CP_UTF8, 0, (char*)source, (int)sourceCount, target, 2);
				if(targetCount==1)
				{
					*writing++=target[0];
				}
				else if(targetCount==2)
				{
					*writing++=target[0];
					cache=target[1];
					cacheAvailable=true;
				}
				else
				{
					break;
				}
			}
			readed++;
		}
		return readed;
	}

	/***********************************************************************
	BomEncoder
	***********************************************************************/

	BomEncoder::BomEncoder(Encoding _encoding)
		:encoding(_encoding)
		,encoder(0)
	{
		switch(encoding)
		{
		case Mbcs:
			encoder=new MbcsEncoder;
			break;
		case Utf8:
			encoder=new Utf8Encoder;
			break;
		case Utf16:
			encoder=new Utf16Encoder;
			break;
		case Utf16BE:
			encoder=new Utf16BEEncoder;
			break;
		}
	}

	BomEncoder::~BomEncoder()
	{
		Close();
	}

	void BomEncoder::Setup(IStream* _stream)
	{
		switch(encoding)
		{
		case Mbcs:
			break;
		case Utf8:
			_stream->Write((void*)"\xEF\xBB\xBF", 3);
			break;
		case Utf16:
			_stream->Write((void*)"\xFF\xFE", 2);
			break;
		case Utf16BE:
			_stream->Write((void*)"\xFE\xFF", 2);
			break;
		}
		encoder->Setup(_stream);
	}

	void BomEncoder::Close()
	{
		if(encoder)
		{
			encoder->Close();
			delete encoder;
			encoder=0;
		}
	}

	int BomEncoder::Write(void* _buffer, int _size)
	{
		return encoder->Write(_buffer, _size);
	}

	/***********************************************************************
	BomDecoder
	***********************************************************************/

	BomDecoder::BomStream::BomStream(IStream* _stream, char* _bom, int _bomLength)
		:stream(_stream)
		,bomPosition(0)
		,bomLength(_bomLength)
	{
		memcpy(bom, _bom, bomLength);
	}

	bool BomDecoder::BomStream::CanRead()const
	{
		return IsAvailable();
	}

	bool BomDecoder::BomStream::CanWrite()const
	{
		return false;
	}

	bool BomDecoder::BomStream::CanSeek()const
	{
		return false;
	}

	bool BomDecoder::BomStream::CanPeek()const
	{
		return false;
	}

	bool BomDecoder::BomStream::IsLimited()const
	{
		return stream!=0 && stream->IsLimited();
	}

	bool BomDecoder::BomStream::IsAvailable()const
	{
		return stream!=0 && stream->IsAvailable();
	}

	void BomDecoder::BomStream::Close()
	{
		stream=0;
	}

	fpos_t BomDecoder::BomStream::Position()const
	{
		return IsAvailable()?bomPosition+stream->Position():-1;
	}

	fpos_t BomDecoder::BomStream::Size()const
	{
		return -1;
	}

	void BomDecoder::BomStream::Seek(fpos_t _size)
	{
		ASSERT(NULL);
	}

	void BomDecoder::BomStream::SeekFromBegin(fpos_t _size)
	{
		ASSERT(NULL);
	}

	void BomDecoder::BomStream::SeekFromEnd(fpos_t _size)
	{
		ASSERT(NULL);
	}

	int BomDecoder::BomStream::Read(void* _buffer, int _size)
	{
		int result=0;
		unsigned char* buffer=(unsigned char*)_buffer;
		if(bomPosition<bomLength)
		{
			int remain=bomLength-bomPosition;
			result=remain<_size?remain:_size;
			memcpy(buffer, bom+bomPosition, result);
			buffer+=result;
			bomPosition+=result;
			_size-=result;
		}
		if(_size)
		{
			result+=stream->Read(buffer, _size);
		}
		return result;
	}

	int BomDecoder::BomStream::Write(void* _buffer, int _size)
	{
		ASSERT(NULL);
		return 0;
	}

	int BomDecoder::BomStream::Peek(void* _buffer, int _size)
	{
		ASSERT(NULL);
		return 0;
	}

	BomDecoder::BomDecoder()
		:decoder(0)
	{
	}

	BomDecoder::~BomDecoder()
	{
		Close();
	}

	void BomDecoder::Setup(IStream* _stream)
	{
		char bom[3]={0};
		int length=_stream->Read(bom, sizeof(bom));
		if(strncmp(bom, "\xEF\xBB\xBF", 3)==0)
		{
			decoder=new Utf8Decoder;
			stream=new BomStream(_stream, bom+3, 0);
		}
		else if(strncmp(bom, "\xFF\xFE", 2)==0)
		{
			decoder=new Utf16Decoder;
			stream=new BomStream(_stream, bom+2, 1);
		}
		else if(strncmp(bom, "\xFE\xFF", 2)==0)
		{
			decoder=new Utf16BEDecoder;
			stream=new BomStream(_stream, bom+2, 1);
		}
		else
		{
			decoder=new MbcsDecoder;
			stream=new BomStream(_stream, bom, 3);
		}
		decoder->Setup(stream);
	}

	void BomDecoder::Close()
	{
		if(decoder)
		{
			decoder->Close();
			delete decoder;
			decoder=0;
			stream->Close();
			delete stream;
			stream=0;
		}
	}

	int BomDecoder::Read(void* _buffer, int _size)
	{
		return decoder->Read(_buffer, _size);
	}

	/***********************************************************************
	CharEncoder
	***********************************************************************/

	bool CanBeMbcs(unsigned char* buffer, int size)
	{
		bool needTrail=false;
		for(int i=0;i<size;i++)
		{
			if(buffer[i]==0) return false;
			if(needTrail)
			{
				needTrail=false;
			}
			else if(buffer[i]>=128)
			{
				needTrail=true;
			}
		}
		return !needTrail;
	}

	bool CanBeUtf8(unsigned char* buffer, int size)
	{
		for(int i=0;i<size;i++)
		{
			unsigned char c=(unsigned char)buffer[i];
			if(c==0)
			{
				return false;
			}
			else
			{
				int count10xxxxxx=0;
				if((c&0x80)==0x00) /* 0x0xxxxxxx */ count10xxxxxx=0;
				else if((c&0xE0)==0xC0) /* 0x110xxxxx */ count10xxxxxx=1;
				else if((c&0xF0)==0xE0) /* 0x1110xxxx */ count10xxxxxx=2;
				else if((c&0xF8)==0xF0) /* 0x11110xxx */ count10xxxxxx=3;
				else if((c&0xFC)==0xF8) /* 0x111110xx */ count10xxxxxx=4;
				else if((c&0xFE)==0xFC) /* 0x1111110x */ count10xxxxxx=5;

				if(size<=i+count10xxxxxx)
				{
					return false;
				}
				else
				{
					for(int j=0;j<count10xxxxxx;j++)
					{
						c=(unsigned char)buffer[i+j+1];
						if((c&0xC0)!=0x80) /* 0x10xxxxxx */ return false;
					}
				}
				i+=count10xxxxxx;
			}
		}
		return true;
	}

	bool CanBeUtf16(unsigned char* buffer, int size)
	{
		if(size%2!=0) return false;
		bool needTrail=false;
		for(int i=0;i<size;i+=2)
		{
			if(buffer[i]>=128 && buffer[i+1]==0) return false;
			cuint16_t c=buffer[i]+(buffer[i+1]<<8);
			if(c==0xFFFF) return false;
			int type=0;
			if(0xD800<=c && c<=0xDBFF) type=1;
			else if(0xDC00<=c && c<=0xDFFF) type=2;
			if(needTrail)
			{
				if(type==2)
				{
					needTrail=false;
				}
				else
				{
					return false;
				}
			}
			else
			{
				if(type==1)
				{
					needTrail=true;
				}
				else if(type!=0)
				{
					return false;
				}
			}
		}
		return !needTrail;
	}

	bool CanBeUtf16BE(unsigned char* buffer, int size)
	{
		if(size%2!=0) return false;
		bool needTrail=false;
		for(int i=0;i<size;i+=2)
		{
			if(buffer[i+1]>=128 && buffer[i]==0) return false;
			cuint16_t c=buffer[i+1]+(buffer[i]<<8);
			if(c==0xFFFF) return false;
			int type=0;
			if(0xD800<=c && c<=0xDBFF) type=1;
			else if(0xDC00<=c && c<=0xDFFF) type=2;
			if(needTrail)
			{
				if(type==2)
				{
					needTrail=false;
				}
				else
				{
					return false;
				}
			}
			else
			{
				if(type==1)
				{
					needTrail=true;
				}
				else if(type!=0)
				{
					return false;
				}
			}
		}
		return !needTrail;
	}

	template<int Count>
	bool GetEncodingResult(int (&tests)[Count], bool(&results)[Count], int test)
	{
		for(int i=0;i<Count;i++)
		{
			if(tests[i]&test)
			{
				if(results[i]) return true;
			}
		}
		return false;
	}

	void TestEncoding(unsigned char* buffer, int size, BomEncoder::Encoding& encoding, bool& containsBom)
	{
		if(size>=3 && strncmp((char*)buffer, "\xEF\xBB\xBF", 3)==0)
		{
			encoding=BomEncoder::Utf8;
			containsBom=true;
		}
		else if(size>=2 && strncmp((char*)buffer, "\xFF\xFE", 2)==0)
		{
			encoding=BomEncoder::Utf16;
			containsBom=true;
		}
		else if(size>=2 && strncmp((char*)buffer, "\xFE\xFF", 2)==0)
		{
			encoding=BomEncoder::Utf16BE;
			containsBom=true;
		}
		else
		{
			encoding=BomEncoder::Mbcs;
			containsBom=true;

			bool roughMbcs=CanBeMbcs(buffer, size);
			bool roughUtf8=CanBeUtf8(buffer, size);
			bool roughUtf16=CanBeUtf16(buffer, size);
			bool roughUtf16BE=CanBeUtf16BE(buffer, size);
			int roughCount=(roughMbcs?1:0)+(roughUtf8?1:0)+(roughUtf16?1:0)+(roughUtf16BE?1:0);
			if(roughCount==1)
			{
				if(roughUtf8) encoding=BomEncoder::Utf8;
				if(roughUtf16) encoding=BomEncoder::Utf16;
				if(roughUtf16BE) encoding=BomEncoder::Utf16BE;
			}
			else if(roughCount>1)
			{
				int tests[]=
				{
					IS_TEXT_UNICODE_REVERSE_ASCII16,
					IS_TEXT_UNICODE_REVERSE_STATISTICS,
					IS_TEXT_UNICODE_REVERSE_CONTROLS,

					IS_TEXT_UNICODE_ASCII16,
					IS_TEXT_UNICODE_STATISTICS,
					IS_TEXT_UNICODE_CONTROLS,

					IS_TEXT_UNICODE_ILLEGAL_CHARS,
					IS_TEXT_UNICODE_ODD_LENGTH,
					IS_TEXT_UNICODE_NULL_BYTES,
				};

				const int TestCount=sizeof(tests)/sizeof(*tests);
				bool results[TestCount];
				for(int i=0;i<TestCount;i++)
				{
					int test=tests[i];
					results[i]=IsTextUnicode(buffer, (int)size, &test)!=0;
				}

				if(size%2==0
					&& !GetEncodingResult(tests, results, IS_TEXT_UNICODE_REVERSE_ASCII16)
					&& !GetEncodingResult(tests, results, IS_TEXT_UNICODE_REVERSE_STATISTICS)
					&& !GetEncodingResult(tests, results, IS_TEXT_UNICODE_REVERSE_CONTROLS)
					)
				{
					for(int i=0;i<size;i+=2)
					{
						unsigned char c=buffer[i];
						buffer[i]=buffer[i+1];
						buffer[i+1]=c;
					}
					// 3 = (count of reverse group) = (count of unicode group)
					for(int i=0;i<3;i++)
					{
						int test=tests[i+3];
						results[i]=IsTextUnicode(buffer, (int)size, &test)!=0;
					}
					for(int i=0;i<size;i+=2)
					{
						unsigned char c=buffer[i];
						buffer[i]=buffer[i+1];
						buffer[i+1]=c;
					}
				}

				if(GetEncodingResult(tests, results, IS_TEXT_UNICODE_NOT_UNICODE_MASK))
				{
					if(GetEncodingResult(tests, results, IS_TEXT_UNICODE_NOT_ASCII_MASK))
					{
						encoding=BomEncoder::Utf8;
					}
					else if(roughUtf8||!roughMbcs)
					{
						encoding=BomEncoder::Utf8;
					}
				}
				else if(GetEncodingResult(tests, results, IS_TEXT_UNICODE_ASCII16))
				{
					encoding=BomEncoder::Utf16;
				}
				else if(GetEncodingResult(tests, results, IS_TEXT_UNICODE_REVERSE_ASCII16))
				{
					encoding=BomEncoder::Utf16BE;
				}
				else if(GetEncodingResult(tests, results, IS_TEXT_UNICODE_CONTROLS))
				{
					encoding=BomEncoder::Utf16;
				}
				else if(GetEncodingResult(tests, results, IS_TEXT_UNICODE_REVERSE_CONTROLS))
				{
					encoding=BomEncoder::Utf16BE;
				}
				else
				{
					if(!roughUtf8)
					{
						if(GetEncodingResult(tests, results, IS_TEXT_UNICODE_STATISTICS))
						{
							encoding=BomEncoder::Utf16;
						}
						else if(GetEncodingResult(tests, results, IS_TEXT_UNICODE_STATISTICS))
						{
							encoding=BomEncoder::Utf16BE;
						}
					}
					else if(GetEncodingResult(tests, results, IS_TEXT_UNICODE_NOT_UNICODE_MASK))
					{
						encoding=BomEncoder::Utf8;
					}
					else if(roughUtf8||!roughMbcs)
					{
						encoding=BomEncoder::Utf8;
					}
				}
			}
			containsBom=encoding==BomEncoder::Mbcs;
		}
	}

	/***********************************************************************
	FileStream
	***********************************************************************/

	FileStream::FileStream(const String& fileName, AccessRight _accessRight)
		:accessRight(_accessRight)
	{
		const TCHAR* mode=_T("rb");
		switch(accessRight)
		{
		case ReadOnly:
			mode=_T("rb");
			break;
		case WriteOnly:
			mode=_T("wb");
			break;
		case ReadWrite:
			mode=_T("w+b");
			break;
		}

		if(_wfopen_s(&file, fileName.Buffer(), mode)!=0)
		{
			file=0;
		}
	}

	FileStream::~FileStream()
	{
		Close();
	}

	bool FileStream::CanRead()const
	{
		return file!=0 && (accessRight==ReadOnly || accessRight==ReadWrite);
	}

	bool FileStream::CanWrite()const
	{
		return file!=0 && (accessRight==WriteOnly || accessRight==ReadWrite);
	}

	bool FileStream::CanSeek()const
	{
		return file!=0;
	}

	bool FileStream::CanPeek()const
	{
		return file!=0 && (accessRight==ReadOnly || accessRight==ReadWrite);
	}

	bool FileStream::IsLimited()const
	{
		return file!=0 && accessRight==ReadOnly;
	}

	bool FileStream::IsAvailable()const
	{
		return file!=0;
	}

	void FileStream::Close()
	{
		if(file!=0)
		{
			fclose(file);
			file=0;
		}
	}

	fpos_t FileStream::Position()const
	{
		if(file!=0)
		{
			fpos_t position=0;
			if(fgetpos(file, &position)==0)
			{
				return position;
			}
		}
		return -1;
	}

	fpos_t FileStream::Size()const
	{
		if(file!=0)
		{
			fpos_t position=0;
			if(fgetpos(file, &position)==0)
			{
				if(fseek(file, 0, SEEK_END)==0)
				{
					fpos_t size=Position();
					if(fsetpos(file, &position)==0)
					{
						return size;
					}
				}
			}
		}
		return -1;
	}

	void FileStream::Seek(fpos_t _size)
	{
		if(Position()+_size>Size())
		{
			_fseeki64(file, 0, SEEK_END);
		}
		else if(Position()+_size<0)
		{
			_fseeki64(file, 0, SEEK_SET);
		}
		else
		{
			_fseeki64(file, _size, SEEK_CUR);
		}
	}

	void FileStream::SeekFromBegin(fpos_t _size)
	{
		if(_size>Size())
		{
			_fseeki64(file, 0, SEEK_END);
		}
		else if(_size<0)
		{
			_fseeki64(file, 0, SEEK_SET);
		}
		else
		{
			_fseeki64(file, _size, SEEK_SET);
		}
	}

	void FileStream::SeekFromEnd(fpos_t _size)
	{
		if(_size<0)
		{
			_fseeki64(file, 0, SEEK_END);
		}
		else if(_size>Size())
		{
			_fseeki64(file, 0, SEEK_SET);
		}
		else
		{
			_fseeki64(file, -_size, SEEK_END);
		}
	}

	int FileStream::Read(void* _buffer, int _size)
	{
		ASSERT(file!=0);
		ASSERT(_size>=0);
		return fread(_buffer, 1, _size, file);
	}

	int FileStream::Write(void* _buffer, int _size)
	{
		ASSERT(file!=0);
		ASSERT(_size>=0);
		return fwrite(_buffer, 1, _size, file);
	}

	int FileStream::Peek(void* _buffer, int _size)
	{
		ASSERT(file!=0);
		ASSERT(_size>=0);
		fpos_t position=0;
		if(fgetpos(file, &position)==0)
		{
			size_t count=fread(_buffer, 1, _size, file);
			if(fsetpos(file, &position)==0)
			{
				return count;
			}
		}
		return -1;
	}

	/***********************************************************************
	MemoryStream
	***********************************************************************/

	void MemoryStream::PrepareSpace(int totalSpace)
	{
		if(totalSpace>capacity)
		{
			totalSpace=(totalSpace/block+1)*block;
			char* newBuffer=new char[totalSpace];
			if(buffer)
			{
				memcpy(newBuffer, buffer, size);
				delete[] buffer;
			}
			buffer=newBuffer;
			capacity=totalSpace;
		}
	}

	MemoryStream::MemoryStream(int _block)
		:block(_block)
		,buffer(0)
		,size(0)
		,position(0)
		,capacity(0)
	{
		if(block<=0)
		{
			block=65536;
		}
	}

	MemoryStream::~MemoryStream()
	{
		Close();
	}

	bool MemoryStream::CanRead()const
	{
		return block!=0;
	}

	bool MemoryStream::CanWrite()const
	{
		return block!=0;
	}

	bool MemoryStream::CanSeek()const
	{
		return block!=0;
	}

	bool MemoryStream::CanPeek()const
	{
		return block!=0;
	}

	bool MemoryStream::IsLimited()const
	{
		return false;
	}

	bool MemoryStream::IsAvailable()const
	{
		return block!=0;
	}

	void MemoryStream::Close()
	{
		if(buffer)
		{
			delete[] buffer;
		}
		block=0;
		buffer=0;
		size=-1;
		position=-1;
		capacity=0;
	}

	fpos_t MemoryStream::Position()const
	{
		return position;
	}

	fpos_t MemoryStream::Size()const
	{
		return size;
	}

	void MemoryStream::Seek(fpos_t _size)
	{
		SeekFromBegin(position+_size);
	}

	void MemoryStream::SeekFromBegin(fpos_t _size)
	{
		ASSERT(block!=0);
		int expected=(int)_size;
		if(expected<0)
		{
			position=0;
		}
		else if(expected>=size)
		{
			position=size;
		}
		else
		{
			position=expected;
		}
	}

	void MemoryStream::SeekFromEnd(fpos_t _size)
	{
		SeekFromBegin(size-_size);
	}

	int MemoryStream::Read(void* _buffer, int _size)
	{
		ASSERT(block!=0);
		ASSERT(_size>=0);
		int max=size-position;
		if(_size>max)
		{
			_size=max;
		}
		memmove(_buffer, buffer+position, _size);
		position+=_size;
		return _size;
	}

	int MemoryStream::Write(void* _buffer, int _size)
	{
		ASSERT(block!=0);
		ASSERT(_size>=0);
		PrepareSpace(size+_size);
		memmove(buffer+position, _buffer, _size);
		position+=_size;
		if(size<position)
		{
			size=position;
		}
		return _size;
	}

	int MemoryStream::Peek(void* _buffer, int _size)
	{
		ASSERT(block!=0);
		ASSERT(_size>=0);
		int max=size-position;
		if(_size>max)
		{
			_size=max;
		}
		memmove(_buffer, buffer+position, _size);
		return _size;
	}

	void* MemoryStream::GetInternalBuffer()
	{
		return buffer;
	}

	/***********************************************************************
	MemoryWrapperStream
	***********************************************************************/

	MemoryWrapperStream::MemoryWrapperStream(void* _buffer, int _size)
		:buffer((char*)_buffer)
		,size(_size)
		,position(0)
	{
		if(size<=0)
		{
			buffer=0;
			size=0;
		}
	}

	MemoryWrapperStream::~MemoryWrapperStream()
	{
	}

	bool MemoryWrapperStream::CanRead()const
	{
		return buffer!=0;
	}

	bool MemoryWrapperStream::CanWrite()const
	{
		return buffer!=0;
	}

	bool MemoryWrapperStream::CanSeek()const
	{
		return buffer!=0;
	}

	bool MemoryWrapperStream::CanPeek()const
	{
		return buffer!=0;
	}

	bool MemoryWrapperStream::IsLimited()const
	{
		return buffer!=0;
	}

	bool MemoryWrapperStream::IsAvailable()const
	{
		return buffer!=0;
	}

	void MemoryWrapperStream::Close()
	{
		buffer=0;
		size=-1;
		position=-1;
	}

	fpos_t MemoryWrapperStream::Position()const
	{
		return position;
	}

	fpos_t MemoryWrapperStream::Size()const
	{
		return size;
	}

	void MemoryWrapperStream::Seek(fpos_t _size)
	{
		SeekFromBegin(position+_size);
	}

	void MemoryWrapperStream::SeekFromBegin(fpos_t _size)
	{
		ASSERT(buffer!=0);
		int expected=(int)_size;
		if(expected<0)
		{
			position=0;
		}
		else if(expected>=size)
		{
			position=size;
		}
		else
		{
			position=expected;
		}
	}

	void MemoryWrapperStream::SeekFromEnd(fpos_t _size)
	{
		SeekFromBegin(size-_size);
	}

	int MemoryWrapperStream::Read(void* _buffer, int _size)
	{
		ASSERT(buffer!=0);
		ASSERT(_size>=0);
		int max=size-position;
		if(_size>max)
		{
			_size=max;
		}
		memmove(_buffer, buffer+position, _size);
		position+=_size;
		return _size;
	}

	int MemoryWrapperStream::Write(void* _buffer, int _size)
	{
		ASSERT(buffer!=0);
		ASSERT(_size>=0);
		int max=size-position;
		if(_size>max)
		{
			_size=max;
		}
		memmove(buffer+position, _buffer, _size);
		position+=_size;
		return _size;
	}

	int MemoryWrapperStream::Peek(void* _buffer, int _size)
	{
		ASSERT(buffer!=0);
		ASSERT(_size>=0);
		int max=size-position;
		if(_size>max)
		{
			_size=max;
		}
		memmove(_buffer, buffer+position, _size);
		return _size;
	}

	/***********************************************************************
	RecorderStream
	***********************************************************************/

	RecorderStream::RecorderStream(IStream& _in, IStream& _out)
		:in(&_in)
		,out(&_out)
	{
	}

	RecorderStream::~RecorderStream()
	{
	}

	bool RecorderStream::CanRead()const
	{
		return IsAvailable() && in->CanRead();
	}

	bool RecorderStream::CanWrite()const
	{
		return false;
	}

	bool RecorderStream::CanSeek()const
	{
		return false;
	}

	bool RecorderStream::CanPeek()const
	{
		return false;
	}

	bool RecorderStream::IsLimited()const
	{
		return IsAvailable() && in->IsLimited();
	}

	bool RecorderStream::IsAvailable()const
	{
		return in!=0 && out!=0 && in->IsAvailable() && out->IsAvailable();
	}

	void RecorderStream::Close()
	{
		in=0;
		out=0;
	}

	fpos_t RecorderStream::Position()const
	{
		return IsAvailable()?in->Position():-1;
	}

	fpos_t RecorderStream::Size()const
	{
		return IsAvailable()?in->Size():-1;
	}

	void RecorderStream::Seek(fpos_t _size)
	{
		ASSERT(NULL);
	}

	void RecorderStream::SeekFromBegin(fpos_t _size)
	{
		ASSERT(NULL);
	}

	void RecorderStream::SeekFromEnd(fpos_t _size)
	{
		ASSERT(NULL);
	}

	int RecorderStream::Read(void* _buffer, int _size)
	{
		_size=in->Read(_buffer, _size);
		out->Write(_buffer, _size);
		return _size;
	}

	int RecorderStream::Write(void* _buffer, int _size)
	{
		ASSERT(NULL);
		return 0;
	}

	int RecorderStream::Peek(void* _buffer, int _size)
	{
		ASSERT(NULL);
		return 0;
	}
}

CC_END_NAMESPACE
