/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Lazy.h

Include:
File:../core/cc_Function.h

Class:
	Lazy										�����Զ���

***********************************************************************/

#ifndef _CC_CORE_LAZY_H
#define _CC_CORE_LAZY_H

#include "cc_Function.h"

CC_BEGIN_NAMESPACE
namespace Lazy
{
	using namespace cc::Function;

	template<typename T>
	class Lazy : public Object
	{
		typedef const Func<T()>& _FUNC;
		typedef const Lazy<T()>& _LAZY;
	protected:
		struct Internal
		{
			bool				_bEval;
			Func<T()>			_fnEval;
			T					_Value;
		};

		AutoPtr<Internal>		_internal;

	public:
		Lazy() {}
		Lazy(_LAZY t): _internal(t._internal) {}

		Lazy(_FUNC lpfn)
		{
			_internal = new Internal;
			_internal->_bEval = false;
			_internal->_fnEval = lpfn;
		}

		Lazy(const T& t)
		{
			_internal = new Internal;
			_internal->_bEval = true;
			_internal->_fnEval = t;
		}

		Lazy<T>& operator = (_FUNC lpfn)
		{
			_internal = new Internal;
			_internal->_bEval = false;
			_internal->_fnEval = lpfn;
			return *this;
		}

		Lazy<T>& operator = (const T& t)
		{
			_internal = new Internal;
			_internal->_bEval = true;
			_internal->_fnEval = t;
			return *this;
		}

		Lazy<T>& operator = ( _LAZY t)
		{
			_internal = t._internal;
			return *this;
		}

		const T& Value() const
		{
			if(!_internal->_bEval)
			{
				_internal->_bEval = true;
				_internal->_Value = _internal->_fnEval();
				_internal->_fnEval = Func<T()>();
			}
			return _internal->Value;
		}

		const bool IsEvaluated() const
		{
			return _internal->_bEval;
		}

		const bool IsAvailable() const
		{
			return _internal != NULL;
		}
	};
}
CC_END_NAMESPACE

#endif