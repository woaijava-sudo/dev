/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Time.h

Impl:
File:../core/cc_Time.cpp

Include:
File:../core/cc_Base.h

Struct:
	DateTime									: ����

***********************************************************************/

#ifndef _CC_CORE_TIME_H
#define _CC_CORE_TIME_H

#include "cc_Base.h"

CC_BEGIN_NAMESPACE
//////////////////////////////////////////////////////////////////////////
// 
// Struct: cc::DateTime - ʱ��
//
struct DateTime
{
	int				year;
	int				month;
	int				dayOfWeek;
	int				day;
	int				hour;
	int				minute;
	int				second;
	int				milliseconds;

	unsigned __int64	totalMilliseconds;
	unsigned __int64	filetime;

	static DateTime		LocalTime();
	static DateTime		UtcTime();

	DateTime			ToLocalTime();
	DateTime			ToUtcTime();
};

namespace Date
{
	DateTime			SystemTimeToDateTime( const SYSTEMTIME& systemTime );
	SYSTEMTIME			DateTimeToSystemTime( const DateTime& dateTime );
}
CC_END_NAMESPACE

#endif