/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Ptr.h

Include:
File:../core/cc_Base.h

***********************************************************************/

#ifndef _CC_CORE_PTR_H
#define _CC_CORE_PTR_H

#include "cc_Base.h"

CC_BEGIN_NAMESPACE
namespace Ptr
{
	//////////////////////////////////////////////////////////////////////////
	// 
	// Class: cc::Ptr::AutoPtr<T> - ����ָ��
	//
	template<typename T>
	class AutoPtr
	{
        typedef volatile unsigned int V;
	public:
		AutoPtr(): _pRef(NULL), _pT(NULL)
		{

		}

		AutoPtr(T* pT): _pRef(NULL), _pT(NULL)
		{
			if(pT)
			{
				_pRef = new V(1);
				_pT = pT;
			}
		}

		AutoPtr(const AutoPtr<T>& t)
		{
			_pRef = t._pRef;
			_pT = t._pT;
			Inc();
		}

		~AutoPtr() { Dec(); }

		template<typename X>
		AutoPtr(const AutoPtr<X>& t)
		{
			T* pObj = t.Obj();
			if(pObj) {
				_pRef = t.Ref();
				_pT = pObj;
				Inc();
			} else {
				Reset();
			}
		}

		template<typename X>
		AutoPtr<X> Cast() const
		{
			X* pX = dynamic_cast<X*>(_pT);
			return AutoPtr<X>((pX == NULL ? _pRef : 0), pX);
		}

		AutoPtr<T>& operator = (T* pT)
		{
			Dec();
			if(pT) {
				_pRef = new unsigned int(1);
				_pT = pT;
			} else {
				Reset();
			}
			return *this;
		}

		AutoPtr<T>& operator = (const AutoPtr<T>& t)
		{
			if(this != &t)
			{
				Dec();
				_pRef = t._pRef;
				_pT = t._pT;
				Inc();
			}
			return *this;
		}

		template<typename X>
		AutoPtr<T>& operator = (const AutoPtr<X>& t)
		{
			T* pT = t.Obj();
			Dec();
			if(pT) {
				_pRef = t.Ref();
				_pT = pT;
				Inc();
			} else {
				Reset();
			}
			return *this;
		}

		operator T* () const
		{
			return _pT;
		}

		T* Obj() const
		{
			return _pT;
		}

		int Reference() const
		{
			return *_pRef;
		}

		V* Ref() const
		{
			return _pRef;
		}

		T* operator->() const
		{
			return _pT;
		}

	protected:
		AutoPtr(V* pRef, T* pT): _pRef(pRef), _pT(pT)
		{
			Inc();
		}

		void Inc()
		{
			if(_pRef)
			{
				InterlockedIncrement(_pRef);
			}
		}

		void Dec()
		{
			if(_pRef)
			{
				InterlockedDecrement(_pRef);
				if(*_pRef == 0)
				{
					SAFE_DELETE(_pRef);
					SAFE_DELETE(_pT);
				}
			}
		}

		void Reset()
		{
			InterlockedExchange(_pRef, 0);
			_pT = NULL;
		}

	protected:
		V*	_pRef;
		T*	_pT;
	};

	template<typename T> struct Type<AutoPtr<T>>	{ typedef T* _Type; };
	template<typename T> struct Result<AutoPtr<T>>	{ static const bool _Result = false; };
}
CC_END_NAMESPACE

#endif