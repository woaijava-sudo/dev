/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	c_lib		|
			|	Developer:		>>>	bajdc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Macro.h

Include:
File:../core/cc_Base.h

Macro:
	CC_IMPL_FUNC_T_TN_ADV						: ����ί��ģ��
	CC_IMPL_FUNC_V_TN_ADV						: �޲�ί��ģ��
	CC_IMPL_BIND_T_TN_ADV						: ���ΰ�ģ��
	CC_IMPL_BIND_V_TN_ADV						: �޲ΰ�ģ��
	CC_IMPL_COMB_T_TN_ADV						: ���ν��ģ��

***********************************************************************/

#ifndef _CC_CORE_MACRO_H
#define _CC_CORE_MACRO_H

#include "cc_Base.h"

//////////////////////////////////////////////////////////////////////////
//
//		������
//		CC_TMP_N  - ģ�� - (typename T,T0...)
//		CC_TMP_HN - ģ�� - (typename T0...)
//		CC_TMP_WN - ģ�� - (typename R1,R2,T,T0...)
//		CC_R_P_N  - �β� - (T0...T9)
//		CC_R_P_HN - �β� - (T1...T9)
//		CC_T_P_N  - ʵ�� - (T0 p0...T9 p9)
//		CC_T_P_HN - ʵ�� - (T1 p1...T9 p9)
//		CC_P_P_N  - ���� - (p0...p9)

// CC_R_P_N
#define CC_TMP__ template<typename T>
#define CC_TMP_0 template<typename T, typename T0>
#define CC_TMP_1 template<typename T, typename T0, typename T1>
#define CC_TMP_2 template<typename T, typename T0, typename T1, typename T2>
#define CC_TMP_3 template<typename T, typename T0, typename T1, typename T2, typename T3>
#define CC_TMP_4 template<typename T, typename T0, typename T1, typename T2, typename T3, typename T4>
#define CC_TMP_5 template<typename T, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5>
#define CC_TMP_6 template<typename T, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6>
#define CC_TMP_7 template<typename T, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7>
#define CC_TMP_8 template<typename T, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8>
#define CC_TMP_9 template<typename T, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8, typename T9>

// CC_R_P_HN
#define CC_TMP_H_ template<>
#define CC_TMP_H0 template<typename T0>
#define CC_TMP_H1 template<typename T0, typename T1>
#define CC_TMP_H2 template<typename T0, typename T1, typename T2>
#define CC_TMP_H3 template<typename T0, typename T1, typename T2, typename T3>
#define CC_TMP_H4 template<typename T0, typename T1, typename T2, typename T3, typename T4>
#define CC_TMP_H5 template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5>
#define CC_TMP_H6 template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6>
#define CC_TMP_H7 template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7>
#define CC_TMP_H8 template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8>
#define CC_TMP_H9 template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8, typename T9>

// CC_R_P_WN
#define CC_TMP_W_ template<typename R1, typename R2, typename T>
#define CC_TMP_W0 template<typename R1, typename R2, typename T, typename T0>
#define CC_TMP_W1 template<typename R1, typename R2, typename T, typename T0, typename T1>
#define CC_TMP_W2 template<typename R1, typename R2, typename T, typename T0, typename T1, typename T2>
#define CC_TMP_W3 template<typename R1, typename R2, typename T, typename T0, typename T1, typename T2, typename T3>
#define CC_TMP_W4 template<typename R1, typename R2, typename T, typename T0, typename T1, typename T2, typename T3, typename T4>
#define CC_TMP_W5 template<typename R1, typename R2, typename T, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5>
#define CC_TMP_W6 template<typename R1, typename R2, typename T, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6>
#define CC_TMP_W7 template<typename R1, typename R2, typename T, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7>
#define CC_TMP_W8 template<typename R1, typename R2, typename T, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8>
#define CC_TMP_W9 template<typename R1, typename R2, typename T, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8, typename T9>

// CC_R_P_N
#define CC_R_P__ ()
#define CC_R_P_0 (T0)
#define CC_R_P_1 (T0,T1)
#define CC_R_P_2 (T0,T1,T2)
#define CC_R_P_3 (T0,T1,T2,T3)
#define CC_R_P_4 (T0,T1,T2,T3,T4)
#define CC_R_P_5 (T0,T1,T2,T3,T4,T5)
#define CC_R_P_6 (T0,T1,T2,T3,T4,T5,T6)
#define CC_R_P_7 (T0,T1,T2,T3,T4,T5,T6,T7)
#define CC_R_P_8 (T0,T1,T2,T3,T4,T5,T6,T7,T8)
#define CC_R_P_9 (T0,T1,T2,T3,T4,T5,T6,T7,T8,T9)

// CC_R_P_HN
#define CC_R_P_H_ ()
#define CC_R_P_H0 ()
#define CC_R_P_H1 (T1)
#define CC_R_P_H2 (T1,T2)
#define CC_R_P_H3 (T1,T2,T3)
#define CC_R_P_H4 (T1,T2,T3,T4)
#define CC_R_P_H5 (T1,T2,T3,T4,T5)
#define CC_R_P_H6 (T1,T2,T3,T4,T5,T6)
#define CC_R_P_H7 (T1,T2,T3,T4,T5,T6,T7)
#define CC_R_P_H8 (T1,T2,T3,T4,T5,T6,T7,T8)
#define CC_R_P_H9 (T1,T2,T3,T4,T5,T6,T7,T8,T9)

// CC_T_P_N
#define CC_T_P__ ()
#define CC_T_P_0 (T0 t0)
#define CC_T_P_1 (T0 t0,T1 t1)
#define CC_T_P_2 (T0 t0,T1 t1,T2 t2)
#define CC_T_P_3 (T0 t0,T1 t1,T2 t2,T3 t3)
#define CC_T_P_4 (T0 t0,T1 t1,T2 t2,T3 t3,T4 t4)
#define CC_T_P_5 (T0 t0,T1 t1,T2 t2,T3 t3,T4 t4,T5 t5)
#define CC_T_P_6 (T0 t0,T1 t1,T2 t2,T3 t3,T4 t4,T5 t5,T6 t6)
#define CC_T_P_7 (T0 t0,T1 t1,T2 t2,T3 t3,T4 t4,T5 t5,T6 t6,T7 t7)
#define CC_T_P_8 (T0 t0,T1 t1,T2 t2,T3 t3,T4 t4,T5 t5,T6 t6,T7 t7,T8 t8)
#define CC_T_P_9 (T0 t0,T1 t1,T2 t2,T3 t3,T4 t4,T5 t5,T6 t6,T7 t7,T8 t8,T9 t9)

// CC_T_P_HN
#define CC_T_P_H_ ()
#define CC_T_P_H0 ()
#define CC_T_P_H1 (T1 t1)
#define CC_T_P_H2 (T1 t1,T2 t2)
#define CC_T_P_H3 (T1 t1,T2 t2,T3 t3)
#define CC_T_P_H4 (T1 t1,T2 t2,T3 t3,T4 t4)
#define CC_T_P_H5 (T1 t1,T2 t2,T3 t3,T4 t4,T5 t5)
#define CC_T_P_H6 (T1 t1,T2 t2,T3 t3,T4 t4,T5 t5,T6 t6)
#define CC_T_P_H7 (T1 t1,T2 t2,T3 t3,T4 t4,T5 t5,T6 t6,T7 t7)
#define CC_T_P_H8 (T1 t1,T2 t2,T3 t3,T4 t4,T5 t5,T6 t6,T7 t7,T8 t8)
#define CC_T_P_H9 (T1 t1,T2 t2,T3 t3,T4 t4,T5 t5,T6 t6,T7 t7,T8 t8,T9 t9)

// CC_P_P_N
#define CC_P_P__ ()
#define CC_P_P_0 (t0)
#define CC_P_P_1 (t0,t1)
#define CC_P_P_2 (t0,t1,t2)
#define CC_P_P_3 (t0,t1,t2,t3)
#define CC_P_P_4 (t0,t1,t2,t3,t4)
#define CC_P_P_5 (t0,t1,t2,t3,t4,t5)
#define CC_P_P_6 (t0,t1,t2,t3,t4,t5,t6)
#define CC_P_P_7 (t0,t1,t2,t3,t4,t5,t6,t7)
#define CC_P_P_8 (t0,t1,t2,t3,t4,t5,t6,t7,t8)
#define CC_P_P_9 (t0,t1,t2,t3,t4,t5,t6,t7,t8,t9)

//////////////////////////////////////////////////////////////////////////
//
//		ģ��ʵ��Func<X(T0...T9)>
//		CC_Func_R_Param - �β� - (T0...T9)
//      CC_Func_T_Param - ʵ�� - (T0 p0...T9 p9)
//      CC_Func_P_Param - ���� - (p0...p9)
//		X = void or T

#define CC_IMPL_FUNC_X_TN(T, CC_Func_R_Param, CC_Func_T_Param, CC_Func_P_Param)							\
																										\
class Func<T CC_Func_R_Param> : public Object															\
{																										\
protected:																								\
	static const int BinarySize = sizeof(void*) * 8;													\
																										\
	class IInvoker : public Interface {																	\
	public:																								\
		virtual T				Invoke CC_Func_R_Param = 0;												\
		virtual void			RetriveBinary(char* binary) = 0;										\
	};																									\
																										\
	class StaticInvoker : public IInvoker {																\
	protected:																							\
		T (*_lpfn) CC_Func_R_Param;																		\
	public:																								\
		StaticInvoker(T (*lpfn) CC_Func_R_Param): _lpfn(lpfn) {}										\
		virtual T				Invoke CC_Func_T_Param { return _lpfn CC_Func_P_Param; }				\
		virtual void			RetriveBinary(char* binary)												\
		{																								\
			BinWrapper<T (*) CC_Func_R_Param, BinarySize> wrap;											\
			memset(wrap.binary, 0, BinarySize);															\
			wrap.t = _lpfn;																				\
			memcpy(binary, wrap.binary, BinarySize);													\
		}																								\
	};																									\
																										\
	template<typename X>																				\
	class MemberInvoker : public IInvoker																\
	{																									\
	protected:																							\
		X* _this; T (X::*_lpfn) CC_Func_T_Param;														\
		typedef struct _Content	{																		\
			X* _this;																					\
			T (X::*_lpfn) CC_Func_T_Param;																\
		} Content;																						\
	public:																								\
		MemberInvoker(X* __this, T (X::*lpfn) CC_Func_T_Param): _this(__this), _lpfn(lpfn) {}			\
		virtual T				Invoke CC_Func_T_Param { return (_this->*lpfn) CC_Func_P_Param; }		\
		virtual void			RetriveBinary(char* binary)												\
		{																								\
			BinWrapper<Content, BinarySize> wrap;														\
			memset(wrap.binary, 0, BinarySize);															\
			wrap.t._this = _this;																		\
			wrap.t._lpfn = _lpfn;																		\
			memcpy(binary, wrap.binary, BinarySize);													\
		}																								\
	};																									\
																										\
	template<typename X>																				\
	class PointerInvoker : public IInvoker																\
	{																									\
	protected:																							\
		X* _lpfn;																						\
	public:																								\
		PointerInvoker(X* lpfn): _lpfn(lpfn) {}															\
		virtual T				Invoke CC_Func_T_Param { return _lpfn->operator() CC_Func_P_Param; }	\
		virtual void			RetriveBinary(char* binary)												\
		{																								\
			BinWrapper<X*, BinarySize> wrap;															\
			memset(wrap.binary, 0, BinarySize);															\
			wrap.t = _lpfn;																				\
			memcpy(binary, wrap.binary, BinarySize);													\
		}																								\
	};																									\
																										\
	template<typename X>																				\
	class AutoPtrInvoker : public IInvoker																\
	{																									\
	protected:																							\
		AutoPtr<X> _ptr;																				\
	public:																								\
		AutoPtrInvoker(const AutoPtr<X>& ptr): _ptr(ptr) {}												\
		virtual T				Invoke CC_Func_T_Param { return _ptr->operator() CC_Func_P_Param; }		\
		virtual void			RetriveBinary(char* binary)												\
		{																								\
			BinWrapper<X*, BinarySize> wrap;															\
			memset(wrap.binary, 0, BinarySize);															\
			wrap.t = _ptr.Obj();																		\
			memcpy(binary, wrap.binary, BinarySize);													\
		}																								\
	};																									\
																										\
	template<typename X>																				\
	class ObjectInvoker : public IInvoker																\
	{																									\
	protected:																							\
		X _obj;																							\
	public:																								\
		ObjectInvoker(const X& obj): _obj(obj) {}														\
		virtual T				Invoke CC_Func_T_Param { return _obj CC_Func_P_Param; }					\
		virtual void			RetriveBinary(char* binary)												\
		{																								\
			BinWrapper<X*, BinarySize> wrap;															\
			memset(wrap.binary, 0, BinarySize);															\
			wrap.t = this;																				\
			memcpy(binary, wrap.binary, BinarySize);													\
		}																								\
	};																									\
																										\
protected:																								\
	AutoPtr<IInvoker> _invoker;																			\
																										\
public:																									\
	typedef T FuncType CC_Func_R_Param;																	\
	typedef T ResultType;																				\
	typedef const Func<FuncType>& _FuncType;															\
																										\
public:																									\
	Func() {}																							\
	Func(T (*lpfn) CC_Func_R_Param)										{ _invoker = new StaticInvoker(lpfn); }					\
	template<typename X> Func(X* __this, T (X::*lpfn) CC_Func_R_Param)	{ _invoker = new MemberInvoker<X>(__this, lpfn); }		\
	template<typename X> Func(X* lpfn)									{ _invoker = new PointerInvoker<X>(lpfn); }				\
	template<typename X> Func(const AutoPtr<X>& ptr)					{ _invoker = new AutoPtr<X>(ptr); }						\
	template<typename X> Func(const X& lpfn)							{ _invoker = new ObjectInvoker<X>(lpfn); }				\
																										\
	T operator() CC_Func_T_Param const { return _invoker->Invoke CC_Func_P_Param; }						\
	operator bool() const { return _invoker.Obj() != NULL; }											\
																										\
protected:																								\
	int Compare(_FuncType lpfn) const																	\
	{																									\
		char a[BinarySize]; char b[BinarySize];															\
		_invoker->RetriveBinary(a);																		\
		lpfn._invoker->RetriveBinary(b);																\
		return memcmp(a, b, BinarySize);																\
	}																									\
																										\
public:																									\
	bool operator == (_FuncType lpfn) const { return Compare(lpfn) == 0; }								\
	bool operator != (_FuncType lpfn) const { return Compare(lpfn) != 0; }								\
	bool operator >= (_FuncType lpfn) const { return Compare(lpfn) >= 0; }								\
	bool operator <= (_FuncType lpfn) const { return Compare(lpfn) <= 0; }								\
	bool operator >  (_FuncType lpfn) const { return Compare(lpfn) >  0; }								\
	bool operator <  (_FuncType lpfn) const { return Compare(lpfn) <  0; }								\
};

// Return type = T
#define CC_IMPL_FUNC_T_TN(CC_Template, CC_Func_R_Param, CC_Func_T_Param, CC_Func_P_Param) \
	CC_Template \
	CC_IMPL_FUNC_X_TN(T, CC_Func_R_Param, CC_Func_T_Param, CC_Func_P_Param)
// Return type = void
#define CC_IMPL_FUNC_V_TN(CC_Template, CC_Func_R_Param, CC_Func_T_Param, CC_Func_P_Param) \
	CC_Template \
	CC_IMPL_FUNC_X_TN(void, CC_Func_R_Param, CC_Func_T_Param, CC_Func_P_Param)

// Advance macros
#define CC_IMPL_FUNC_T_TN_ADV(ID) CC_IMPL_FUNC_T_TN(CC_TMP_##ID,  CC_R_P_##ID, CC_T_P_##ID, CC_P_P_##ID)
#define CC_IMPL_FUNC_V_TN_ADV(ID) CC_IMPL_FUNC_V_TN(CC_TMP_H##ID, CC_R_P_##ID, CC_T_P_##ID, CC_P_P_##ID)

//		����
//
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
//
//		ģ��ʵ��Binding<X(T0...T9)>
//		CC_Func_R_Param - �β� - (T0...T9)
//      CC_Func_T_Param - �β� - (T1...T9)
//      CC_Func_P_Param - ���� - (p0...p9)
//      CC_Func_Y_Param - ʵ�� - (T1 p1...T9 p9)
//		X = void or T

#define CC_IMPL_BIND_X_TN(T, CC_Bind_R_Param, CC_Bind_T_Param, CC_Bind_P_Param, CC_Bind_Y_Param)		\
																										\
struct Binding<T CC_Bind_R_Param>																		\
{																										\
	typedef T FuncType		CC_Bind_R_Param;															\
	typedef T CurriedType	CC_Bind_T_Param;															\
	typedef const Func<FuncType>& _FuncType;															\
	typedef T0				ParamType;																	\
	class Binder : public Object {																		\
	protected:																							\
		Func<FuncType>			_Target;																\
		typename RCR<T0>::_Type	p0;																		\
	public:																								\
		Binder(_FuncType target, typename VCR<T0>::_Type _p0): _Target(target), p0(_p0) {}				\
		void operator() CC_Bind_Y_Param const { _Target CC_Bind_P_Param; }								\
	};																									\
	class Currier : public Object {																		\
	protected:																							\
		Func<FuncType>			_Target;																\
	public:																								\
		Currier(_FuncType target): _Target(target) {}													\
		Func<CurriedType> operator()(typename VCR<T0>::_Type argument) const							\
		{																								\
			return Ptr<Binder>(new Binder(_Target, argument));											\
		}																								\
	};																									\
};

// Return type = T
#define CC_IMPL_BIND_T_TN(CC_Template, CC_Bind_R_Param, CC_Bind_T_Param, CC_Bind_P_Param, CC_Bind_Y_Param) \
	CC_Template \
	CC_IMPL_BIND_X_TN(T, CC_Bind_R_Param, CC_Bind_T_Param, CC_Bind_P_Param, CC_Bind_Y_Param)
// Return type = void
#define CC_IMPL_BIND_V_TN(CC_Template, CC_Bind_R_Param, CC_Bind_T_Param, CC_Bind_P_Param, CC_Bind_Y_Param) \
	CC_Template \
	CC_IMPL_BIND_X_TN(void, CC_Bind_R_Param, CC_Bind_T_Param, CC_Bind_P_Param, CC_Bind_Y_Param)

// Advance macros
#define CC_IMPL_BIND_T_TN_ADV(ID) CC_IMPL_BIND_T_TN(CC_TMP_##ID,  CC_R_P_##ID, CC_R_P_H##ID, CC_P_P_##ID, CC_T_P_H##ID)
#define CC_IMPL_BIND_V_TN_ADV(ID) CC_IMPL_BIND_V_TN(CC_TMP_H##ID, CC_R_P_##ID, CC_R_P_H##ID, CC_P_P_##ID, CC_T_P_H##ID)

//		����
//
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
//
//		ģ��ʵ��Combining<X(T0...T9)>
//		CC_Func_R_Param - �β� - (T0...T9)
//      CC_Func_T_Param - �β� - (T0 p0...T9 p9)
//      CC_Func_P_Param - ���� - (p0...p9)
//		X = T

#define CC_IMPL_COMB_X_TN(T, CC_Comb_R_Param, CC_Comb_T_Param, CC_Comb_P_Param)							\
																										\
class Combining<R1 CC_Comb_R_Param, R2 CC_Comb_R_Param, T (R1,R2)> : public Object						\
{																										\
protected:																								\
	Func<R1 CC_Comb_R_Param>			_Func1;															\
	Func<R2 CC_Comb_R_Param>			_Func2;															\
	Func<T (R1,R2)>						_Conv;															\
																										\
public:																									\
	typedef R1 _1stFuncType					CC_Comb_R_Param;											\
	typedef R2 _2ndFuncType					CC_Comb_R_Param;											\
	typedef T _ConvFuncType					CC_Comb_R_Param;											\
	typedef T _FinalFuncType				CC_Comb_R_Param;											\
	typedef const Func<R1 CC_Comb_R_Param>& __FuncR1;													\
	typedef const Func<R2 CC_Comb_R_Param>& __FuncR2;													\
	typedef const Func<T  CC_Comb_R_Param>& __FuncT;													\
	Combining(__FuncR1 f1, __FuncR2 f2, __FuncT conv): _Func1(f1), _Func2(f2), _Conv(conv) {}			\
	T operator() CC_Comb_T_Param const { return _Conv(_Func1 CC_Comb_P_Param, _Func2 CC_Comb_P_Param); {} }	\
}; 

// Return type = T
#define CC_IMPL_COMB_T_TN(CC_Template, CC_Comb_R_Param, CC_Comb_T_Param, CC_Comb_P_Param) \
	CC_Template \
	CC_IMPL_COMB_X_TN(T, CC_Comb_R_Param, CC_Comb_T_Param, CC_Comb_P_Param)

// Advance macros
#define CC_IMPL_COMB_T_TN_ADV(ID) CC_IMPL_COMB_T_TN(CC_TMP_W##ID,  CC_R_P_##ID, CC_R_P_H##ID, CC_P_P_##ID)

//		����
//
//////////////////////////////////////////////////////////////////////////

#endif