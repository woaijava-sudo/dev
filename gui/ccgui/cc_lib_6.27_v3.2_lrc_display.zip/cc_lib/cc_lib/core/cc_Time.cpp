/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Time.h

Impl:
File:../core/cc_Time.cpp

Include:
File:../core/cc_Base.h

Struct:
	DateTime									: ����

***********************************************************************/

#include "stdafx.h"
#include <windows.h>
#include "cc_Time.h"

CC_BEGIN_NAMESPACE
DateTime DateTime::LocalTime()
{
	SYSTEMTIME systemTime;
	::GetLocalTime(&systemTime);
	return Date::SystemTimeToDateTime(systemTime);
}

DateTime DateTime::UtcTime()
{
	SYSTEMTIME utcTime;
	::GetSystemTime(&utcTime);
	return Date::SystemTimeToDateTime(utcTime);
}

DateTime DateTime::ToLocalTime()
{
	SYSTEMTIME utcTime = Date::DateTimeToSystemTime(*this);
	SYSTEMTIME localTime;
	::SystemTimeToTzSpecificLocalTime(NULL, &utcTime, &localTime);
	return Date::SystemTimeToDateTime(localTime);
}

DateTime DateTime::ToUtcTime()
{
	SYSTEMTIME localTime = Date::DateTimeToSystemTime(*this);
	SYSTEMTIME utcTime;
	::TzSpecificLocalTimeToSystemTime(NULL, &localTime, &utcTime);
	return Date::SystemTimeToDateTime(utcTime);
}

namespace Date
{
	DateTime SystemTimeToDateTime( const SYSTEMTIME& systemTime )
	{
		DateTime dateTime;
		dateTime.year				= systemTime.wYear;
		dateTime.month				= systemTime.wMonth;
		dateTime.dayOfWeek			= systemTime.wDayOfWeek;
		dateTime.day				= systemTime.wDay;
		dateTime.hour				= systemTime.wHour;
		dateTime.minute				= systemTime.wMinute;
		dateTime.second				= systemTime.wSecond;
		dateTime.milliseconds		= systemTime.wMilliseconds;

		FILETIME fileTime;
		::SystemTimeToFileTime(&systemTime, &fileTime);
		ULARGE_INTEGER largeInteger;
		largeInteger.HighPart		= fileTime.dwHighDateTime;
		largeInteger.LowPart		= fileTime.dwLowDateTime;
		dateTime.filetime			= largeInteger.QuadPart;
		dateTime.totalMilliseconds	= dateTime.filetime / 10000;

		return dateTime;
	}

	SYSTEMTIME DateTimeToSystemTime( const DateTime& dateTime )
	{
		ULARGE_INTEGER largeInteger;
		largeInteger.QuadPart		= dateTime.filetime;
		FILETIME fileTime;
		fileTime.dwHighDateTime		= largeInteger.HighPart;
		fileTime.dwLowDateTime		= largeInteger.LowPart;

		SYSTEMTIME systemTime;
		::FileTimeToSystemTime(&fileTime, &systemTime);
		return systemTime;
	}
}
CC_END_NAMESPACE