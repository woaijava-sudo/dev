/***********************************************************************

|-----------------------------------|
|									|
|	Project:		>>>	cc_lib		|
|	Developer:		>>>	bajdcc		|
|									|
|-----------------------------------|

Decl:
File:../core/cc_String.h

Impl:
File:../core/cc_String.cpp

Include:
File:../core/cc_String.h
File:../core/cc_Debug.h

Class:
	String										���ַ��� / TCHAR

***********************************************************************/

#include "stdafx.h"
#include "cc_String.h"
#include "cc_Debug.h"

CC_BEGIN_NAMESPACE
namespace Strings
{
	using namespace cc::Debug;

	/////////////////////////////////////////////////////////////////////////////
	// static class data, special inlines

	// afxChNil is left for backward compatibility
	TCHAR _xChNil = '\0';
	LPCTSTR _xPchNA = _T("N/A");

	// For an empty string, m_pchData will point here
	// (note: avoids special case of checking for NULL m_pchData)
	// empty string data (and locked)
	static int _afxInitData[] = { -1, 0, 0, 0 };
	static StringData* _afxDataNil = (StringData*)&_afxInitData;
	LPCTSTR _xPchNil = (LPCTSTR)(((BYTE*)&_afxInitData)+sizeof(StringData));

	//////////////////////////////////////////////////////////////////////////////
	// Construction/Destruction

	String::String(const String& stringSrc)
	{
		ASSERT(stringSrc.GetData()->nRefs != 0);
		if (stringSrc.GetData()->nRefs >= 0)
		{
			ASSERT(stringSrc.GetData() != _afxDataNil);
			m_pchData = stringSrc.m_pchData;
			InterlockedIncrement(&GetData()->nRefs);
		}
		else
		{
			Init();
			*this = stringSrc.m_pchData;
		}
	}

#ifndef _DEBUG

#pragma warning(disable: 4074)
#pragma init_seg(compiler)

#define ROUND(x,y) (((x)+(y-1))&~(y-1))
#define ROUND4(x) ROUND(x, 4)
	AFSTATIC CFixedAlloc _afxAlloc64(ROUND4(65*sizeof(TCHAR)+sizeof(StringData)));
	AFSTATIC CFixedAlloc _afxAlloc128(ROUND4(129*sizeof(TCHAR)+sizeof(StringData)));
	AFSTATIC CFixedAlloc _afxAlloc256(ROUND4(257*sizeof(TCHAR)+sizeof(StringData)));
	AFSTATIC CFixedAlloc _afxAlloc512(ROUND4(513*sizeof(TCHAR)+sizeof(StringData)));

#endif //!_DEBUG

	void String::AllocBuffer(int nLen)
		// always allocate one extra character for '\0' termination
		// assumes [optimistically] that data length will equal allocation length
	{
		ASSERT(nLen >= 0);
		ASSERT(nLen <= INT_MAX-1);    // max size (enough room for 1 extra)

		if (nLen == 0)
			Init();
		else
		{
			StringData* pData;
#ifndef _DEBUG
			if (nLen <= 64)
			{
				pData = (StringData*)_afxAlloc64.Alloc();
				pData->nAllocLength = 64;
			}
			else if (nLen <= 128)
			{
				pData = (StringData*)_afxAlloc128.Alloc();
				pData->nAllocLength = 128;
			}
			else if (nLen <= 256)
			{
				pData = (StringData*)_afxAlloc256.Alloc();
				pData->nAllocLength = 256;
			}
			else if (nLen <= 512)
			{
				pData = (StringData*)_afxAlloc512.Alloc();
				pData->nAllocLength = 512;
			}
			else
#endif
			{
				pData = (StringData*)
					new BYTE[sizeof(StringData) + (nLen+1)*sizeof(TCHAR)];
				pData->nAllocLength = nLen;
			}
			pData->nRefs = 1;
			pData->data()[nLen] = '\0';
			pData->nDataLength = nLen;
			m_pchData = pData->data();
		}
	}

	void __fastcall String::FreeData(StringData* pData)
	{
#ifndef _DEBUG
		int nLen = pData->nAllocLength;
		if (nLen == 64)
			_afxAlloc64.Free(pData);
		else if (nLen == 128)
			_afxAlloc128.Free(pData);
		else if (nLen == 256)
			_afxAlloc256.Free(pData);
		else  if (nLen == 512)
			_afxAlloc512.Free(pData);
		else
		{
			ASSERT(nLen > 512);
			delete[] (BYTE*)pData;
		}
#else
		delete[] (BYTE*)pData;
#endif
	}

	void String::Release()
	{
		if (GetData() != _afxDataNil)
		{
			ASSERT(GetData()->nRefs != 0);
			if (InterlockedDecrement(&GetData()->nRefs) <= 0)
				FreeData(GetData());
			Init();
		}
	}

	void PASCAL String::Release(StringData* pData)
	{
		if (pData != _afxDataNil)
		{
			ASSERT(pData->nRefs != 0);
			if (InterlockedDecrement(&pData->nRefs) <= 0)
				FreeData(pData);
		}
	}

	void String::Empty()
	{
		if (GetData()->nDataLength == 0)
			return;
		if (GetData()->nRefs >= 0)
			Release();
		else
			*this = &_xChNil;
		ASSERT(GetData()->nDataLength == 0);
		ASSERT(GetData()->nRefs < 0 || GetData()->nAllocLength == 0);
	}

	void String::CopyBeforeWrite()
	{
		if (GetData()->nRefs > 1)
		{
			StringData* pData = GetData();
			Release();
			AllocBuffer(pData->nDataLength);
			memcpy(m_pchData, pData->data(), (pData->nDataLength+1)*sizeof(TCHAR));
		}
		ASSERT(GetData()->nRefs <= 1);
	}

	void String::AllocBeforeWrite(int nLen)
	{
		if (GetData()->nRefs > 1 || nLen > GetData()->nAllocLength)
		{
			Release();
			AllocBuffer(nLen);
		}
		ASSERT(GetData()->nRefs <= 1);
	}

	String::~String()
		//  free any attached data
	{
		if (GetData() != _afxDataNil)
		{
			if (InterlockedDecrement(&GetData()->nRefs) <= 0)
				FreeData(GetData());
		}
	}

	//////////////////////////////////////////////////////////////////////////////
	// Helpers for the rest of the implementation

	void String::AllocCopy(String& dest, int nCopyLen, int nCopyIndex,
		int nExtraLen) const
	{
		// will clone the data attached to this string
		// allocating 'nExtraLen' characters
		// Places results in uninitialized string 'dest'
		// Will copy the part or all of original data to start of new string

		int nNewLen = nCopyLen + nExtraLen;
		if (nNewLen == 0)
		{
			dest.Init();
		}
		else
		{
			dest.AllocBuffer(nNewLen);
			memcpy(dest.m_pchData, m_pchData+nCopyIndex, nCopyLen*sizeof(TCHAR));
		}
	}

	//////////////////////////////////////////////////////////////////////////////
	// More sophisticated construction

	String::String(LPCTSTR lpsz)
	{
		Init();
		if (lpsz != NULL && HIWORD(lpsz) == NULL)
		{
			UINT nID = LOWORD((DWORD)lpsz);
			if (!LoadString(nID))
				TRACE("Warning: implicit LoadString(%u) failed", nID);
		}
		else
		{
			int nLen = SafeStrlen(lpsz);
			if (nLen != 0)
			{
				AllocBuffer(nLen);
				memcpy(m_pchData, lpsz, nLen*sizeof(TCHAR));
			}
		}
	}

	/////////////////////////////////////////////////////////////////////////////
	// Special conversion constructors

#ifdef _UNICODE
	String::String(LPCSTR lpsz)
	{
		Init();
		int nSrcLen = lpsz != NULL ? lstrlenA(lpsz) : 0;
		if (nSrcLen != 0)
		{
			AllocBuffer(nSrcLen);
			_mbstowcsz(m_pchData, lpsz, nSrcLen+1);
			ReleaseBuffer();
		}
	}
#else //_UNICODE
	String::String(LPCWSTR lpsz)
	{
		Init();
		int nSrcLen = lpsz != NULL ? wcslen(lpsz) : 0;
		if (nSrcLen != 0)
		{
			AllocBuffer(nSrcLen*2);
			_wcstombsz(m_pchData, lpsz, (nSrcLen*2)+1);
			ReleaseBuffer();
		}
	}
#endif //!_UNICODE

	///////////////////////////////////////////////////////////////////////////////
	// String conversion helpers (these use the current system locale)

	int CDECL _wcstombsz(char* mbstr, const wchar_t* wcstr, size_t count)
	{
		if (count == 0 && mbstr != NULL)
			return 0;

		int result = ::WideCharToMultiByte(CP_ACP, 0, wcstr, -1,
			mbstr, count, NULL, NULL);
		ASSERT(mbstr == NULL || result <= (int)count);
		if (result > 0)
			mbstr[result-1] = 0;
		return result;
	}

#ifndef _UNICODE
	void String::AnsiToOem()
	{
		CopyBeforeWrite();
		::AnsiToOem(m_pchData, m_pchData);
	}
	void String::OemToAnsi()
	{
		CopyBeforeWrite();
		::OemToAnsi(m_pchData, m_pchData);
	}
#endif

	int CDECL _mbstowcsz(wchar_t* wcstr, const char* mbstr, size_t count)
	{
		if (count == 0 && wcstr != NULL)
			return 0;

		int result = ::MultiByteToWideChar(CP_ACP, 0, mbstr, -1,
			wcstr, count);
		ASSERT(wcstr == NULL || result <= (int)count);
		if (result > 0)
			wcstr[result-1] = 0;
		return result;
	}

	//////////////////////////////////////////////////////////////////////////////
	// Assignment operators
	//  All assign a new value to the string
	//      (a) first see if the buffer is big enough
	//      (b) if enough room, copy on top of old buffer, set size and type
	//      (c) otherwise free old string data, and create a new one
	//
	//  All routines return the new string (but as a 'const String&' so that
	//      assigning it again will cause a copy, eg: s1 = s2 = "hi there".
	//

	void String::AssignCopy(int nSrcLen, LPCTSTR lpszSrcData)
	{
		AllocBeforeWrite(nSrcLen);
		memcpy(m_pchData, lpszSrcData, nSrcLen*sizeof(TCHAR));
		GetData()->nDataLength = nSrcLen;
		m_pchData[nSrcLen] = '\0';
	}

	const String& String::operator=(const String& stringSrc)
	{
		if (m_pchData != stringSrc.m_pchData)
		{
			if ((GetData()->nRefs < 0 && GetData() != _afxDataNil) ||
				stringSrc.GetData()->nRefs < 0)
			{
				// actual copy necessary since one of the strings is locked
				AssignCopy(stringSrc.GetData()->nDataLength, stringSrc.m_pchData);
			}
			else
			{
				// can just copy references around
				Release();
				ASSERT(stringSrc.GetData() != _afxDataNil);
				m_pchData = stringSrc.m_pchData;
				InterlockedIncrement(&GetData()->nRefs);
			}
		}
		return *this;
	}

	const String& String::operator=(LPCTSTR lpsz)
	{
		ASSERT(lpsz == NULL || IsValidString(lpsz));
		AssignCopy(SafeStrlen(lpsz), lpsz);
		return *this;
	}

	/////////////////////////////////////////////////////////////////////////////
	// Special conversion assignment

#ifdef _UNICODE
	const String& String::operator=(LPCSTR lpsz)
	{
		int nSrcLen = lpsz != NULL ? lstrlenA(lpsz) : 0;
		AllocBeforeWrite(nSrcLen);
		_mbstowcsz(m_pchData, lpsz, nSrcLen+1);
		ReleaseBuffer();
		return *this;
	}
#else //!_UNICODE
	const String& String::operator=(LPCWSTR lpsz)
	{
		int nSrcLen = lpsz != NULL ? wcslen(lpsz) : 0;
		AllocBeforeWrite(nSrcLen*2);
		_wcstombsz(m_pchData, lpsz, (nSrcLen*2)+1);
		ReleaseBuffer();
		return *this;
	}
#endif  //!_UNICODE

	//////////////////////////////////////////////////////////////////////////////
	// concatenation

	// NOTE: "operator+" is done as friend functions for simplicity
	//      There are three variants:
	//          String + String
	// and for ? = TCHAR, LPCTSTR
	//          String + ?
	//          ? + String

	void String::ConcatCopy(int nSrc1Len, LPCTSTR lpszSrc1Data,
		int nSrc2Len, LPCTSTR lpszSrc2Data)
	{
		// -- master concatenation routine
		// Concatenate two sources
		// -- assume that 'this' is a new String object

		int nNewLen = nSrc1Len + nSrc2Len;
		if (nNewLen != 0)
		{
			AllocBuffer(nNewLen);
			memcpy(m_pchData, lpszSrc1Data, nSrc1Len*sizeof(TCHAR));
			memcpy(m_pchData+nSrc1Len, lpszSrc2Data, nSrc2Len*sizeof(TCHAR));
		}
	}

	String operator+(const String& string1, const String& string2)
	{
		String s;
		s.ConcatCopy(string1.GetData()->nDataLength, string1.m_pchData,
			string2.GetData()->nDataLength, string2.m_pchData);
		return s;
	}

	String operator+(const String& string, LPCTSTR lpsz)
	{
		ASSERT(lpsz == NULL || IsValidString(lpsz));
		String s;
		s.ConcatCopy(string.GetData()->nDataLength, string.m_pchData,
			String::SafeStrlen(lpsz), lpsz);
		return s;
	}

	String operator+(LPCTSTR lpsz, const String& string)
	{
		ASSERT(lpsz == NULL || IsValidString(lpsz));
		String s;
		s.ConcatCopy(String::SafeStrlen(lpsz), lpsz, string.GetData()->nDataLength,
			string.m_pchData);
		return s;
	}

	//////////////////////////////////////////////////////////////////////////////
	// concatenate in place

	void String::ConcatInPlace(int nSrcLen, LPCTSTR lpszSrcData)
	{
		//  -- the main routine for += operators

		// concatenating an empty string is a no-op!
		if (nSrcLen == 0)
			return;

		// if the buffer is too small, or we have a width mis-match, just
		//   allocate a new buffer (slow but sure)
		if (GetData()->nRefs > 1 || GetData()->nDataLength + nSrcLen > GetData()->nAllocLength)
		{
			// we have to grow the buffer, use the ConcatCopy routine
			StringData* pOldData = GetData();
			ConcatCopy(GetData()->nDataLength, m_pchData, nSrcLen, lpszSrcData);
			ASSERT(pOldData != NULL);
			String::Release(pOldData);
		}
		else
		{
			// fast concatenation when buffer big enough
			memcpy(m_pchData+GetData()->nDataLength, lpszSrcData, nSrcLen*sizeof(TCHAR));
			GetData()->nDataLength += nSrcLen;
			ASSERT(GetData()->nDataLength <= GetData()->nAllocLength);
			m_pchData[GetData()->nDataLength] = '\0';
		}
	}

	const String& String::operator+=(LPCTSTR lpsz)
	{
		ASSERT(lpsz == NULL || IsValidString(lpsz));
		ConcatInPlace(SafeStrlen(lpsz), lpsz);
		return *this;
	}

	const String& String::operator+=(TCHAR ch)
	{
		ConcatInPlace(1, &ch);
		return *this;
	}

	const String& String::operator+=(const String& string)
	{
		ConcatInPlace(string.GetData()->nDataLength, string.m_pchData);
		return *this;
	}

	///////////////////////////////////////////////////////////////////////////////
	// Advanced direct buffer access

	LPTSTR String::Buffer() const
	{
		return m_pchData;;
	}

	LPTSTR String::GetBuffer(int nMinBufLength)
	{
		ASSERT(nMinBufLength >= 0);

		if (GetData()->nRefs > 1 || nMinBufLength > GetData()->nAllocLength)
		{
#ifdef _DEBUG
			// give a warning in case locked string becomes unlocked
			if (GetData() != _afxDataNil && GetData()->nRefs < 0)
				TRACE("Warning: GetBuffer on locked String creates unlocked String!");
#endif
			// we have to grow the buffer
			StringData* pOldData = GetData();
			int nOldLen = GetData()->nDataLength;   // AllocBuffer will tromp it
			if (nMinBufLength < nOldLen)
				nMinBufLength = nOldLen;
			AllocBuffer(nMinBufLength);
			memcpy(m_pchData, pOldData->data(), (nOldLen+1)*sizeof(TCHAR));
			GetData()->nDataLength = nOldLen;
			String::Release(pOldData);
		}
		ASSERT(GetData()->nRefs <= 1);

		// return a pointer to the character storage for this string
		ASSERT(m_pchData != NULL);
		return m_pchData;
	}

	void String::ReleaseBuffer(int nNewLength)
	{
		CopyBeforeWrite();  // just in case GetBuffer was not called

		if (nNewLength == -1)
			nNewLength = lstrlen(m_pchData); // zero terminated

		ASSERT(nNewLength <= GetData()->nAllocLength);
		GetData()->nDataLength = nNewLength;
		m_pchData[nNewLength] = '\0';
	}

	LPTSTR String::GetBufferSetLength(int nNewLength)
	{
		ASSERT(nNewLength >= 0);

		GetBuffer(nNewLength);
		GetData()->nDataLength = nNewLength;
		m_pchData[nNewLength] = '\0';
		return m_pchData;
	}

	void String::FreeExtra()
	{
		ASSERT(GetData()->nDataLength <= GetData()->nAllocLength);
		if (GetData()->nDataLength != GetData()->nAllocLength)
		{
			StringData* pOldData = GetData();
			AllocBuffer(GetData()->nDataLength);
			memcpy(m_pchData, pOldData->data(), pOldData->nDataLength*sizeof(TCHAR));
			ASSERT(m_pchData[GetData()->nDataLength] == '\0');
			String::Release(pOldData);
		}
		ASSERT(GetData() != NULL);
	}

	LPTSTR String::LockBuffer()
	{
		LPTSTR lpsz = GetBuffer(0);
		GetData()->nRefs = -1;
		return lpsz;
	}

	void String::UnlockBuffer()
	{
		ASSERT(GetData()->nRefs == -1);
		if (GetData() != _afxDataNil)
			GetData()->nRefs = 1;
	}

	///////////////////////////////////////////////////////////////////////////////
	// Commonly used routines (rarely used routines in STREX.CPP)

	int String::Find(TCHAR ch) const
	{
		return Find(ch, 0);
	}

	int String::Find(TCHAR ch, int nStart) const
	{
		int nLength = GetData()->nDataLength;
		if (nStart >= nLength)
			return -1;

		// find first single character
		LPTSTR lpsz = _tcschr(m_pchData + nStart, (_TUCHAR)ch);

		// return -1 if not found and index otherwise
		return (lpsz == NULL) ? -1 : (int)(lpsz - m_pchData);
	}

	int String::FindOneOf(LPCTSTR lpszCharSet) const
	{
		ASSERT(IsValidString(lpszCharSet));
		LPTSTR lpsz = _tcspbrk(m_pchData, lpszCharSet);
		return (lpsz == NULL) ? -1 : (int)(lpsz - m_pchData);
	}

	void String::MakeUpper()
	{
		CopyBeforeWrite();
		_tcsupr_s(m_pchData, MABUFFER_LEN);
	}

	void String::MakeLower()
	{
		CopyBeforeWrite();
		_tcslwr_s(m_pchData, MABUFFER_LEN);
	}

	void String::MakeReverse()
	{
		CopyBeforeWrite();
		_tcsrev(m_pchData);
	}

	void String::SetAt(int nIndex, TCHAR ch)
	{
		ASSERT(nIndex >= 0);
		ASSERT(nIndex < GetData()->nDataLength);

		CopyBeforeWrite();
		m_pchData[nIndex] = ch;
	}

	// String
	StringData* String::GetData() const
	{ ASSERT(m_pchData != NULL); return ((StringData*)m_pchData)-1; }
	void String::Init()
	{ m_pchData = EmptyString.m_pchData; }
	String::String()
	{ m_pchData = EmptyString.m_pchData; }
	String::String(const unsigned char* lpsz)
	{ Init(); *this = (LPCSTR)lpsz; }
	const String& String::operator=(const unsigned char* lpsz)
	{ *this = (LPCSTR)lpsz; return *this; }
#ifdef _UNICODE
	const String& String::operator+=(char ch)
	{ *this += (TCHAR)ch; return *this; }
	const String& String::operator=(char ch)
	{ *this = (TCHAR)ch; return *this; }
	String operator+(const String& string, char ch)
	{ return string + (TCHAR)ch; }
	String operator+(char ch, const String& string)
	{ return (TCHAR)ch + string; }
#endif

	int String::GetLength() const
	{ return GetData()->nDataLength; }
	int String::Length() const
	{ return GetData()->nDataLength; }
	int String::GetAllocLength() const
	{ return GetData()->nAllocLength; }
	BOOL String::IsEmpty() const
	{ return GetData()->nDataLength == 0; }
	String::operator LPCTSTR() const
	{ return m_pchData; }
	int PASCAL String::SafeStrlen(LPCTSTR lpsz)
	{ return (lpsz == NULL) ? 0 : lstrlen(lpsz); }

	// String support (windows specific)
	int String::Compare(LPCTSTR lpsz) const
	{ ASSERT(IsValidString(lpsz)); return _tcscmp(m_pchData, lpsz); }    // MBCS/Unicode aware
	int String::CompareNoCase(LPCTSTR lpsz) const
	{ ASSERT(IsValidString(lpsz)); return _tcsicmp(m_pchData, lpsz); }   // MBCS/Unicode aware
	// String::Collate is often slower than Compare but is MBSC/Unicode
	//  aware as well as locale-sensitive with respect to sort order.
	int String::Collate(LPCTSTR lpsz) const
	{ ASSERT(IsValidString(lpsz)); return _tcscoll(m_pchData, lpsz); }   // locale sensitive
	int String::CollateNoCase(LPCTSTR lpsz) const
	{ ASSERT(IsValidString(lpsz)); return _tcsicoll(m_pchData, lpsz); }   // locale sensitive

	TCHAR String::GetAt(int nIndex) const
	{
		ASSERT(nIndex >= 0);
		ASSERT(nIndex < GetData()->nDataLength);
		return m_pchData[nIndex];
	}
	TCHAR String::operator[](int nIndex) const
	{
		// same as GetAt
		ASSERT(nIndex >= 0);
		ASSERT(nIndex < GetData()->nDataLength);
		return m_pchData[nIndex];
	}

	//////////////////////////////////////////////////////////////////////////
	// Compare helperes
	bool operator==(const String& s1, const String& s2)
	{ return s1.Compare(s2) == 0; }
	bool operator==(const String& s1, LPCTSTR s2)
	{ return s1.Compare(s2) == 0; }
	bool operator==(LPCTSTR s1, const String& s2)
	{ return s2.Compare(s1) == 0; }
	bool operator!=(const String& s1, const String& s2)
	{ return s1.Compare(s2) != 0; }
	bool operator!=(const String& s1, LPCTSTR s2)
	{ return s1.Compare(s2) != 0; }
	bool operator!=(LPCTSTR s1, const String& s2)
	{ return s2.Compare(s1) != 0; }
	bool operator<(const String& s1, const String& s2)
	{ return s1.Compare(s2) < 0; }
	bool operator<(const String& s1, LPCTSTR s2)
	{ return s1.Compare(s2) < 0; }
	bool operator<(LPCTSTR s1, const String& s2)
	{ return s2.Compare(s1) > 0; }
	bool operator>(const String& s1, const String& s2)
	{ return s1.Compare(s2) > 0; }
	bool operator>(const String& s1, LPCTSTR s2)
	{ return s1.Compare(s2) > 0; }
	bool operator>(LPCTSTR s1, const String& s2)
	{ return s2.Compare(s1) < 0; }
	bool operator<=(const String& s1, const String& s2)
	{ return s1.Compare(s2) <= 0; }
	bool operator<=(const String& s1, LPCTSTR s2)
	{ return s1.Compare(s2) <= 0; }
	bool operator<=(LPCTSTR s1, const String& s2)
	{ return s2.Compare(s1) >= 0; }
	bool operator>=(const String& s1, const String& s2)
	{ return s1.Compare(s2) >= 0; }
	bool operator>=(const String& s1, LPCTSTR s2)
	{ return s1.Compare(s2) >= 0; }
	bool operator>=(LPCTSTR s1, const String& s2)
	{ return s2.Compare(s1) <= 0; }

#ifdef _UNICODE
#define CHAR_FUDGE 1    // one TCHAR unused is good enough
#else
#define CHAR_FUDGE 2    // two BYTES unused for case of DBC last char
#endif

	BOOL String::LoadString(UINT nID)
	{
		// try fixed buffer first (to avoid wasting space in the heap)
		TCHAR szTemp[256];
		int nLen = LoadStringEx(nID, szTemp, _countof(szTemp));
		if (_countof(szTemp) - nLen > CHAR_FUDGE)
		{
			*this = szTemp;
			return nLen > 0;
		}

		// try buffer size of 512, then larger size until entire string is retrieved
		int nSize = 256;
		do
		{
			nSize += 256;
			nLen = LoadStringEx(nID, GetBuffer(nSize-1), nSize);
		} while (nSize - nLen <= CHAR_FUDGE);
		ReleaseBuffer();

		return nLen > 0;
	}

	int WINAPI LoadStringEx(UINT nID, LPTSTR lpszBuf, UINT nMaxBuf)
	{
		ASSERT(IsValidAddress(lpszBuf, nMaxBuf*sizeof(TCHAR)));
#ifdef _DEBUG
		// LoadString without annoying warning from the Debug kernel if the
		//  segment containing the string is not present
		if (::FindResource(::GetModuleHandle(NULL),
			MAKEINTRESOURCE((nID>>4)+1), RT_STRING) == NULL)
		{
			lpszBuf[0] = '\0';
			return 0; // not found
		}
#endif //_DEBUG
		int nLen = ::LoadString(::GetModuleHandle(NULL), nID, lpszBuf, nMaxBuf);
		if (nLen == 0)
			lpszBuf[0] = '\0';
		return nLen;
	}

	BOOL WINAPI ExtractSubString(String& rString, LPCTSTR lpszFullString,
		int iSubString, TCHAR chSep)
	{
		if (lpszFullString == NULL)
			return FALSE;

		while (iSubString--)
		{
			lpszFullString = _tcschr(lpszFullString, chSep);
			if (lpszFullString == NULL)
			{
				rString.Empty();        // return empty string as well
				return FALSE;
			}
			lpszFullString++;       // point past the separator
		}
		LPCTSTR lpchEnd = _tcschr(lpszFullString, chSep);
		int nLen = (lpchEnd == NULL) ?
			lstrlen(lpszFullString) : (int)(lpchEnd - lpszFullString);
		ASSERT(nLen >= 0);
		memcpy(rString.GetBufferSetLength(nLen), lpszFullString, nLen*sizeof(TCHAR));
		return TRUE;
	}

	//////////////////////////////////////////////////////////////////////////////
	// More sophisticated construction

	String::String(TCHAR ch, int nLength)
	{
		Init();
		if (nLength >= 1)
		{
			AllocBuffer(nLength);
#ifdef _UNICODE
			for (int i = 0; i < nLength; i++)
				m_pchData[i] = ch;
#else
			memset(m_pchData, ch, nLength);
#endif
		}
	}

	String::String(LPCTSTR lpch, int nLength)
	{
		Init();
		if (nLength != 0)
		{
			ASSERT(IsValidAddress(lpch, nLength, FALSE));
			AllocBuffer(nLength);
			memcpy(m_pchData, lpch, nLength*sizeof(TCHAR));
		}
	}

	/////////////////////////////////////////////////////////////////////////////
	// Special conversion constructors

#ifdef _UNICODE
	String::String(LPCSTR lpsz, int nLength)
	{
		Init();
		if (nLength != 0)
		{
			AllocBuffer(nLength);
			int n = ::MultiByteToWideChar(CP_ACP, 0, lpsz, nLength, m_pchData, nLength+1);
			ReleaseBuffer(n >= 0 ? n : -1);
		}
	}
#else //_UNICODE
	String::String(LPCWSTR lpsz, int nLength)
	{
		Init();
		if (nLength != 0)
		{
			AllocBuffer(nLength*2);
			int n = ::WideCharToMultiByte(CP_ACP, 0, lpsz, nLength, m_pchData,
				(nLength*2)+1, NULL, NULL);
			ReleaseBuffer(n >= 0 ? n : -1);
		}
	}
#endif //!_UNICODE

	//////////////////////////////////////////////////////////////////////////////
	// Assignment operators

	const String& String::operator=(TCHAR ch)
	{
		AssignCopy(1, &ch);
		return *this;
	}

	//////////////////////////////////////////////////////////////////////////////
	// less common string expressions

	String operator+(const String& string1, TCHAR ch)
	{
		String s;
		s.ConcatCopy(string1.GetData()->nDataLength, string1.m_pchData, 1, &ch);
		return s;
	}

	String operator+(TCHAR ch, const String& string)
	{
		String s;
		s.ConcatCopy(1, &ch, string.GetData()->nDataLength, string.m_pchData);
		return s;
	}

	//////////////////////////////////////////////////////////////////////////////
	// Advanced manipulation

	int String::Delete(int nIndex, int nCount /* = 1 */)
	{
		if (nIndex < 0)
			nIndex = 0;
		int nNewLength = GetData()->nDataLength;
		if (nCount > 0 && nIndex < nNewLength)
		{
			CopyBeforeWrite();
			int nBytesToCopy = nNewLength - (nIndex + nCount) + 1;

			memcpy(m_pchData + nIndex,
				m_pchData + nIndex + nCount, nBytesToCopy * sizeof(TCHAR));
			GetData()->nDataLength = nNewLength - nCount;
		}

		return nNewLength;
	}

	int String::Insert(int nIndex, TCHAR ch)
	{
		CopyBeforeWrite();

		if (nIndex < 0)
			nIndex = 0;

		int nNewLength = GetData()->nDataLength;
		if (nIndex > nNewLength)
			nIndex = nNewLength;
		nNewLength++;

		if (GetData()->nAllocLength < nNewLength)
		{
			StringData* pOldData = GetData();
			LPTSTR pstr = m_pchData;
			AllocBuffer(nNewLength);
			memcpy(m_pchData, pstr, (pOldData->nDataLength+1)*sizeof(TCHAR));
			String::Release(pOldData);
		}

		// move existing bytes down
		memcpy(m_pchData + nIndex + 1,
			m_pchData + nIndex, (nNewLength-nIndex)*sizeof(TCHAR));
		m_pchData[nIndex] = ch;
		GetData()->nDataLength = nNewLength;

		return nNewLength;
	}

	int String::Insert(int nIndex, LPCTSTR pstr)
	{
		if (nIndex < 0)
			nIndex = 0;

		int nInsertLength = SafeStrlen(pstr);
		int nNewLength = GetData()->nDataLength;
		if (nInsertLength > 0)
		{
			CopyBeforeWrite();
			if (nIndex > nNewLength)
				nIndex = nNewLength;
			nNewLength += nInsertLength;

			if (GetData()->nAllocLength < nNewLength)
			{
				StringData* pOldData = GetData();
				LPTSTR pstr = m_pchData;
				AllocBuffer(nNewLength);
				memcpy(m_pchData, pstr, (pOldData->nDataLength+1)*sizeof(TCHAR));
				String::Release(pOldData);
			}

			// move existing bytes down
			memcpy(m_pchData + nIndex + nInsertLength,
				m_pchData + nIndex,
				(nNewLength-nIndex-nInsertLength+1)*sizeof(TCHAR));
			memcpy(m_pchData + nIndex,
				pstr, nInsertLength*sizeof(TCHAR));
			GetData()->nDataLength = nNewLength;
		}

		return nNewLength;
	}

	int String::Replace(TCHAR chOld, TCHAR chNew)
	{
		int nCount = 0;

		// short-circuit the nop case
		if (chOld != chNew)
		{
			// otherwise modify each character that matches in the string
			CopyBeforeWrite();
			LPTSTR psz = m_pchData;
			LPTSTR pszEnd = psz + GetData()->nDataLength;
			while (psz < pszEnd)
			{
				// replace instances of the specified character only
				if (*psz == chOld)
				{
					*psz = chNew;
					nCount++;
				}
				psz = _tcsinc(psz);
			}
		}
		return nCount;
	}

	int String::Replace(LPCTSTR lpszOld, LPCTSTR lpszNew)
	{
		// can't have empty or NULL lpszOld

		int nSourceLen = SafeStrlen(lpszOld);
		if (nSourceLen == 0)
			return 0;
		int nReplacementLen = SafeStrlen(lpszNew);

		// loop once to figure out the size of the result string
		int nCount = 0;
		LPTSTR lpszStart = m_pchData;
		LPTSTR lpszEnd = m_pchData + GetData()->nDataLength;
		LPTSTR lpszTarget;
		while (lpszStart < lpszEnd)
		{
			while ((lpszTarget = _tcsstr(lpszStart, lpszOld)) != NULL)
			{
				nCount++;
				lpszStart = lpszTarget + nSourceLen;
			}
			lpszStart += lstrlen(lpszStart) + 1;
		}

		// if any changes were made, make them
		if (nCount > 0)
		{
			CopyBeforeWrite();

			// if the buffer is too small, just
			//   allocate a new buffer (slow but sure)
			int nOldLength = GetData()->nDataLength;
			int nNewLength =  nOldLength + (nReplacementLen-nSourceLen)*nCount;
			if (GetData()->nAllocLength < nNewLength || GetData()->nRefs > 1)
			{
				StringData* pOldData = GetData();
				LPTSTR pstr = m_pchData;
				AllocBuffer(nNewLength);
				memcpy(m_pchData, pstr, pOldData->nDataLength*sizeof(TCHAR));
				String::Release(pOldData);
			}
			// else, we just do it in-place
			lpszStart = m_pchData;
			lpszEnd = m_pchData + GetData()->nDataLength;

			// loop again to actually do the work
			while (lpszStart < lpszEnd)
			{
				while ( (lpszTarget = _tcsstr(lpszStart, lpszOld)) != NULL)
				{
					int nBalance = nOldLength - (lpszTarget - m_pchData + nSourceLen);
					memmove(lpszTarget + nReplacementLen, lpszTarget + nSourceLen,
						nBalance * sizeof(TCHAR));
					memcpy(lpszTarget, lpszNew, nReplacementLen*sizeof(TCHAR));
					lpszStart = lpszTarget + nReplacementLen;
					lpszStart[nBalance] = '\0';
					nOldLength += (nReplacementLen - nSourceLen);
				}
				lpszStart += lstrlen(lpszStart) + 1;
			}
			ASSERT(m_pchData[nNewLength] == '\0');
			GetData()->nDataLength = nNewLength;
		}

		return nCount;
	}

	int String::Remove(TCHAR chRemove)
	{
		CopyBeforeWrite();

		LPTSTR pstrSource = m_pchData;
		LPTSTR pstrDest = m_pchData;
		LPTSTR pstrEnd = m_pchData + GetData()->nDataLength;

		while (pstrSource < pstrEnd)
		{
			if (*pstrSource != chRemove)
			{
				*pstrDest = *pstrSource;
				pstrDest = _tcsinc(pstrDest);
			}
			pstrSource = _tcsinc(pstrSource);
		}
		*pstrDest = '\0';
		int nCount = pstrSource - pstrDest;
		GetData()->nDataLength -= nCount;

		return nCount;
	}

	//////////////////////////////////////////////////////////////////////////////
	// Very simple sub-string extraction

	String String::Mid(int nFirst) const
	{
		return Mid(nFirst, GetData()->nDataLength - nFirst);
	}

	String String::Mid(int nFirst, int nCount) const
	{
		// out-of-bounds requests return sensible things
		if (nFirst < 0)
			nFirst = 0;
		if (nCount < 0)
			nCount = 0;

		if (nFirst + nCount > GetData()->nDataLength)
			nCount = GetData()->nDataLength - nFirst;
		if (nFirst > GetData()->nDataLength)
			nCount = 0;

		ASSERT(nFirst >= 0);
		ASSERT(nFirst + nCount <= GetData()->nDataLength);

		// optimize case of returning entire string
		if (nFirst == 0 && nFirst + nCount == GetData()->nDataLength)
			return *this;

		String dest;
		AllocCopy(dest, nCount, nFirst, 0);
		return dest;
	}

	String String::Right(int nCount) const
	{
		if (nCount < 0)
			nCount = 0;
		if (nCount >= GetData()->nDataLength)
			return *this;

		String dest;
		AllocCopy(dest, nCount, GetData()->nDataLength-nCount, 0);
		return dest;
	}

	String String::Left(int nCount) const
	{
		if (nCount < 0)
			nCount = 0;
		if (nCount >= GetData()->nDataLength)
			return *this;

		String dest;
		AllocCopy(dest, nCount, 0, 0);
		return dest;
	}

	// strspn equivalent
	String String::SpanIncluding(LPCTSTR lpszCharSet) const
	{
		ASSERT(IsValidString(lpszCharSet));
		return Left(_tcsspn(m_pchData, lpszCharSet));
	}

	// strcspn equivalent
	String String::SpanExcluding(LPCTSTR lpszCharSet) const
	{
		ASSERT(IsValidString(lpszCharSet));
		return Left(_tcscspn(m_pchData, lpszCharSet));
	}

	//////////////////////////////////////////////////////////////////////////////
	// Finding

	int String::ReverseFind(TCHAR ch) const
	{
		// find last single character
		LPTSTR lpsz = _tcsrchr(m_pchData, (_TUCHAR) ch);

		// return -1 if not found, distance from beginning otherwise
		return (lpsz == NULL) ? -1 : (int)(lpsz - m_pchData);
	}

	// find a sub-string (like strstr)
	int String::Find(LPCTSTR lpszSub) const
	{
		return Find(lpszSub, 0);
	}

	int String::Find(LPCTSTR lpszSub, int nStart) const
	{
		ASSERT(IsValidString(lpszSub));

		int nLength = GetData()->nDataLength;
		if (nStart > nLength)
			return -1;

		// find first matching substring
		LPTSTR lpsz = _tcsstr(m_pchData + nStart, lpszSub);

		// return -1 for not found, distance from beginning otherwise
		return (lpsz == NULL) ? -1 : (int)(lpsz - m_pchData);
	}

	/////////////////////////////////////////////////////////////////////////////
	// String formatting

#define TCHAR_ARG   TCHAR
#define WCHAR_ARG   WCHAR
#define CHAR_ARG    char

#ifdef _X86_
	struct _DOUBLE  { BYTE doubleBits[sizeof(double)]; };
#define DOUBLE_ARG  _DOUBLE
#else
#define DOUBLE_ARG  double
#endif

#define FORCE_ANSI      0x10000
#define FORCE_UNICODE   0x20000
#define FORCE_INT64     0x40000

	void String::FormatV(LPCTSTR lpszFormat, va_list argList)
	{
		ASSERT(IsValidString(lpszFormat));

		va_list argListSave = argList;

		// make a guess at the maximum length of the resulting string
		int nMaxLen = 0;
		for (LPCTSTR lpsz = lpszFormat; *lpsz != _T('\0'); lpsz = _tcsinc(lpsz))
		{
			// handle _T('%') character, but watch out for _T('%%')
			if (*lpsz != _T('%') || *(lpsz = _tcsinc(lpsz)) == _T('%'))
			{
				nMaxLen += _tclen(lpsz);
				continue;
			}

			int nItemLen = 0;

			// handle _T('%') character with format
			int nWidth = 0;
			for (; *lpsz != _T('\0'); lpsz = _tcsinc(lpsz))
			{
				// check for valid flags
				if (*lpsz == _T('#'))
					nMaxLen += 2;   // for _T('0x')
				else if (*lpsz == _T('*'))
					nWidth = va_arg(argList, int);
				else if (*lpsz == _T('-') || *lpsz == _T('+') || *lpsz == _T('0') ||
					*lpsz == _T(' '))
					;
				else // hit non-flag character
					break;
			}
			// get width and skip it
			if (nWidth == 0)
			{
				// width indicated by
				nWidth = _ttoi(lpsz);
				for (; *lpsz != _T('\0') && _istdigit(*lpsz); lpsz = _tcsinc(lpsz))
					;
			}
			ASSERT(nWidth >= 0);

			int nPrecision = 0;
			if (*lpsz == _T('.'))
			{
				// skip past _T('.') separator (width.precision)
				lpsz = _tcsinc(lpsz);

				// get precision and skip it
				if (*lpsz == _T('*'))
				{
					nPrecision = va_arg(argList, int);
					lpsz = _tcsinc(lpsz);
				}
				else
				{
					nPrecision = _ttoi(lpsz);
					for (; *lpsz != _T('\0') && _istdigit(*lpsz); lpsz = _tcsinc(lpsz))
						;
				}
				ASSERT(nPrecision >= 0);
			}

			// should be on type modifier or specifier
			int nModifier = 0;
			if (_tcsncmp(lpsz, _T("I64"), 3) == 0)
			{
				lpsz += 3;
				nModifier = FORCE_INT64;
#if !defined(_X86_) && !defined(_ALPHA_)
				// __int64 is only available on X86 and ALPHA platforms
				ASSERT(FALSE);
#endif
			}
			else
			{
				switch (*lpsz)
				{
					// modifiers that affect size
				case _T('h'):
					nModifier = FORCE_ANSI;
					lpsz = _tcsinc(lpsz);
					break;
				case _T('l'):
					nModifier = FORCE_UNICODE;
					lpsz = _tcsinc(lpsz);
					break;

					// modifiers that do not affect size
				case _T('F'):
				case _T('N'):
				case _T('L'):
					lpsz = _tcsinc(lpsz);
					break;
				}
			}

			// now should be on specifier
			switch (*lpsz | nModifier)
			{
				// single characters
			case _T('c'):
			case _T('C'):
				nItemLen = 2;
				va_arg(argList, TCHAR_ARG);
				break;
			case _T('c')|FORCE_ANSI:
			case _T('C')|FORCE_ANSI:
				nItemLen = 2;
				va_arg(argList, CHAR_ARG);
				break;
			case _T('c')|FORCE_UNICODE:
			case _T('C')|FORCE_UNICODE:
				nItemLen = 2;
				va_arg(argList, WCHAR_ARG);
				break;

				// strings
			case _T('s'):
				{
					LPCTSTR pstrNextArg = va_arg(argList, LPCTSTR);
					if (pstrNextArg == NULL)
						nItemLen = 6;  // "(null)"
					else
					{
						nItemLen = lstrlen(pstrNextArg);
						nItemLen = max(1, nItemLen);
					}
				}
				break;

			case _T('S'):
				{
#ifndef _UNICODE
					LPWSTR pstrNextArg = va_arg(argList, LPWSTR);
					if (pstrNextArg == NULL)
						nItemLen = 6;  // "(null)"
					else
					{
						nItemLen = wcslen(pstrNextArg);
						nItemLen = max(1, nItemLen);
					}
#else
					LPCSTR pstrNextArg = va_arg(argList, LPCSTR);
					if (pstrNextArg == NULL)
						nItemLen = 6; // "(null)"
					else
					{
						nItemLen = lstrlenA(pstrNextArg);
						nItemLen = max(1, nItemLen);
					}
#endif
				}
				break;

			case _T('s')|FORCE_ANSI:
			case _T('S')|FORCE_ANSI:
				{
					LPCSTR pstrNextArg = va_arg(argList, LPCSTR);
					if (pstrNextArg == NULL)
						nItemLen = 6; // "(null)"
					else
					{
						nItemLen = lstrlenA(pstrNextArg);
						nItemLen = max(1, nItemLen);
					}
				}
				break;

			case _T('s')|FORCE_UNICODE:
			case _T('S')|FORCE_UNICODE:
				{
					LPWSTR pstrNextArg = va_arg(argList, LPWSTR);
					if (pstrNextArg == NULL)
						nItemLen = 6; // "(null)"
					else
					{
						nItemLen = wcslen(pstrNextArg);
						nItemLen = max(1, nItemLen);
					}
				}
				break;
			}

			// adjust nItemLen for strings
			if (nItemLen != 0)
			{
				if (nPrecision != 0)
					nItemLen = min(nItemLen, nPrecision);
				nItemLen = max(nItemLen, nWidth);
			}
			else
			{
				switch (*lpsz)
				{
					// integers
				case _T('d'):
				case _T('i'):
				case _T('u'):
				case _T('x'):
				case _T('X'):
				case _T('o'):
					if (nModifier & FORCE_INT64)
						va_arg(argList, __int64);
					else
						va_arg(argList, int);
					nItemLen = 32;
					nItemLen = max(nItemLen, nWidth+nPrecision);
					break;

				case _T('e'):
				case _T('g'):
				case _T('G'):
					va_arg(argList, DOUBLE_ARG);
					nItemLen = 128;
					nItemLen = max(nItemLen, nWidth+nPrecision);
					break;

				case _T('f'):
					{
						double f;
						LPTSTR pszTemp;

						// 312 == strlen("-1+(309 zeroes).")
						// 309 zeroes == max precision of a double
						// 6 == adjustment in case precision is not specified,
						//   which means that the precision defaults to 6
						pszTemp = (LPTSTR)malloc(sizeof(TCHAR)*max(nWidth, 312+nPrecision+6));

						f = va_arg(argList, double);
						_tprintf( pszTemp, _T( "%*.*f" ), nWidth, nPrecision+6, f );
						nItemLen = _tcslen(pszTemp);

						free(pszTemp);
					}
					break;

				case _T('p'):
					va_arg(argList, void*);
					nItemLen = 32;
					nItemLen = max(nItemLen, nWidth+nPrecision);
					break;

					// no output
				case _T('n'):
					va_arg(argList, int*);
					break;

				default:
					ASSERT(FALSE);  // unknown formatting option
				}
			}

			// adjust nMaxLen for output nItemLen
			nMaxLen += nItemLen;
		}

		GetBuffer(nMaxLen);
		VERIFY(_vstprintf_s(m_pchData, nMaxLen, lpszFormat, argListSave) <= GetAllocLength());
		ReleaseBuffer();

		/*
		*		�����Buffer too small���������Formatû�д����ⲻ���Ρ�
		*/

		va_end(argListSave);
	}

	// static function
	String String::XFormat( LPCTSTR lpszFormat, ... )
	{
		String str;

		va_list argList;
		va_start(argList, lpszFormat);
		str.FormatV(lpszFormat, argList);
		va_end(argList);

		return str;
	}

	// formatting (using wsprintf style formatting)
	void CDECL String::Format(LPCTSTR lpszFormat, ...)
	{
		ASSERT(IsValidString(lpszFormat));

		va_list argList;
		va_start(argList, lpszFormat);
		FormatV(lpszFormat, argList);
		va_end(argList);
	}

	void CDECL String::Format(UINT nFormatID, ...)
	{
		String strFormat;
		VERIFY(strFormat.LoadString(nFormatID) != 0);

		va_list argList;
		va_start(argList, nFormatID);
		FormatV(strFormat, argList);
		va_end(argList);
	}

	// formatting (using FormatMessage style formatting)
	void CDECL String::FormatMessage(LPCTSTR lpszFormat, ...)
	{
		// format message into temporary buffer lpszTemp
		va_list argList;
		va_start(argList, lpszFormat);
		LPTSTR lpszTemp;

		if (::FormatMessage(FORMAT_MESSAGE_FROM_STRING|FORMAT_MESSAGE_ALLOCATE_BUFFER,
			lpszFormat, 0, 0, (LPTSTR)&lpszTemp, 0, &argList) == 0 ||
			lpszTemp == NULL)
		{
			VERIFY(!"Memory overflow.");
		}

		// assign lpszTemp into the resulting string and free the temporary
		*this = lpszTemp;
		LocalFree(lpszTemp);
		va_end(argList);
	}

	void CDECL String::FormatMessage(UINT nFormatID, ...)
	{
		// get format string from string table
		String strFormat;
		VERIFY(strFormat.LoadString(nFormatID) != 0);

		// format message into temporary buffer lpszTemp
		va_list argList;
		va_start(argList, nFormatID);
		LPTSTR lpszTemp;
		if (::FormatMessage(FORMAT_MESSAGE_FROM_STRING|FORMAT_MESSAGE_ALLOCATE_BUFFER,
			strFormat, 0, 0, (LPTSTR)&lpszTemp, 0, &argList) == 0 ||
			lpszTemp == NULL)
		{
			VERIFY(!"Memory overflow.");
		}

		// assign lpszTemp into the resulting string and free lpszTemp
		*this = lpszTemp;
		LocalFree(lpszTemp);
		va_end(argList);
	}

	void String::TrimRight(LPCTSTR lpszTargetList)
	{
		// find beginning of trailing matches
		// by starting at beginning (DBCS aware)

		CopyBeforeWrite();
		LPTSTR lpsz = m_pchData;
		LPTSTR lpszLast = NULL;

		while (*lpsz != '\0')
		{
			if (_tcschr(lpszTargetList, *lpsz) != NULL)
			{
				if (lpszLast == NULL)
					lpszLast = lpsz;
			}
			else
				lpszLast = NULL;
			lpsz = _tcsinc(lpsz);
		}

		if (lpszLast != NULL)
		{
			// truncate at left-most matching character
			*lpszLast = '\0';
			GetData()->nDataLength = lpszLast - m_pchData;
		}
	}

	void String::TrimRight(TCHAR chTarget)
	{
		// find beginning of trailing matches
		// by starting at beginning (DBCS aware)

		CopyBeforeWrite();
		LPTSTR lpsz = m_pchData;
		LPTSTR lpszLast = NULL;

		while (*lpsz != '\0')
		{
			if (*lpsz == chTarget)
			{
				if (lpszLast == NULL)
					lpszLast = lpsz;
			}
			else
				lpszLast = NULL;
			lpsz = _tcsinc(lpsz);
		}

		if (lpszLast != NULL)
		{
			// truncate at left-most matching character
			*lpszLast = '\0';
			GetData()->nDataLength = lpszLast - m_pchData;
		}
	}

	void String::TrimRight()
	{
		// find beginning of trailing spaces by starting at beginning (DBCS aware)

		CopyBeforeWrite();
		LPTSTR lpsz = m_pchData;
		LPTSTR lpszLast = NULL;

		while (*lpsz != '\0')
		{
			if (_istspace(*lpsz))
			{
				if (lpszLast == NULL)
					lpszLast = lpsz;
			}
			else
				lpszLast = NULL;
			lpsz = _tcsinc(lpsz);
		}

		if (lpszLast != NULL)
		{
			// truncate at trailing space start
			*lpszLast = '\0';
			GetData()->nDataLength = lpszLast - m_pchData;
		}
	}

	void String::TrimLeft(LPCTSTR lpszTargets)
	{
		// if we're not trimming anything, we're not doing any work
		if (SafeStrlen(lpszTargets) == 0)
			return;

		CopyBeforeWrite();
		LPCTSTR lpsz = m_pchData;

		while (*lpsz != '\0')
		{
			if (_tcschr(lpszTargets, *lpsz) == NULL)
				break;
			lpsz = _tcsinc(lpsz);
		}

		if (lpsz != m_pchData)
		{
			// fix up data and length
			int nDataLength = GetData()->nDataLength - (lpsz - m_pchData);
			memmove(m_pchData, lpsz, (nDataLength+1)*sizeof(TCHAR));
			GetData()->nDataLength = nDataLength;
		}
	}

	void String::TrimLeft(TCHAR chTarget)
	{
		// find first non-matching character

		CopyBeforeWrite();
		LPCTSTR lpsz = m_pchData;

		while (chTarget == *lpsz)
			lpsz = _tcsinc(lpsz);

		if (lpsz != m_pchData)
		{
			// fix up data and length
			int nDataLength = GetData()->nDataLength - (lpsz - m_pchData);
			memmove(m_pchData, lpsz, (nDataLength+1)*sizeof(TCHAR));
			GetData()->nDataLength = nDataLength;
		}
	}

	void String::TrimLeft()
	{
		// find first non-space character

		CopyBeforeWrite();
		LPCTSTR lpsz = m_pchData;

		while (_istspace(*lpsz))
			lpsz = _tcsinc(lpsz);

		if (lpsz != m_pchData)
		{
			// fix up data and length
			int nDataLength = GetData()->nDataLength - (lpsz - m_pchData);
			memmove(m_pchData, lpsz, (nDataLength+1)*sizeof(TCHAR));
			GetData()->nDataLength = nDataLength;
		}
	}

	void String::FormatTime(const time_t& time, LPCTSTR szFormat)
	{
		tm _tm = {0};
		const int TIME_STRING_LENGTH = 200;
		GetBuffer(TIME_STRING_LENGTH);
		localtime_s(&_tm, &time);
		_tcsftime(m_pchData, TIME_STRING_LENGTH, szFormat, &_tm);
	}
}
CC_END_NAMESPACE