/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Debug.h

Impl:
File:../core/cc_Debug.cpp

Include:
File:../core/cc_Debug.h

Function:
	_Trace										���������
	AssertFailedLine							�����Ժ���
	IsValidString								������Ϸ��ַ���
	IsValidAddress								������Ϸ���ַ

Macro:
	TRACE										: �������
	TRACE_T										: ��ϸ�������
	ASSERT										: ����
	VERIFY										: ��֤

***********************************************************************/

#include "stdafx.h"
#include "cc_Debug.h"

CC_BEGIN_NAMESPACE
namespace Debug
{
	using namespace cc::UI;

#ifdef _DEBUG

#define MAX_BUF_L 1024

	BOOL IsValidAddress( const void* lp, UINT nBytes, BOOL bReadWrite /*= TRUE*/ )
	{
		return (lp != NULL && !IsBadReadPtr(lp, nBytes) && (!bReadWrite || !IsBadWritePtr((LPVOID)lp, nBytes)));
	}

	BOOL IsValidString( LPCTSTR lpsz, int nLength /*= -1*/ )
	{
		if (lpsz == NULL) return FALSE;
		return ::IsBadStringPtr(lpsz, nLength) == 0;
	}

	BOOL AssertFailedLine( LPCSTR lpszFileName, int nLine )
	{
		MSG msg;
		BOOL bQuit = PeekMessage(&msg, NULL, WM_QUIT, WM_QUIT, PM_REMOVE);
		BOOL bResult = _CrtDbgReport(_CRT_ASSERT, lpszFileName, nLine, NULL, NULL);
		if (bQuit) PostQuitMessage(msg.wParam);
		return bResult;
	}

	void AssertValidObject( const XObject* pOb, LPCSTR lpszFileName, int nLine )
	{
		if (pOb == NULL)
		{
			TRACE("ASSERT_VALID fails with NULL pointer.");
			if (AssertFailedLine(lpszFileName, nLine))
				_CrtDbgBreak();
			return;
		}
		if (!IsValidAddress(pOb, sizeof(XObject)))
		{
			TRACE("ASSERT_VALID fails with illegal pointer.");
			if (AssertFailedLine(lpszFileName, nLine))
				_CrtDbgBreak();
			return;
		}

		ASSERT(sizeof(XObject) == sizeof(void*));
		if (!IsValidAddress(*(void**)pOb, sizeof(void*), FALSE))
		{
			TRACE("ASSERT_VALID fails with illegal vtable pointer.");
			if (AssertFailedLine(lpszFileName, nLine))
				_CrtDbgBreak();
			return;
		}

		if (!IsValidAddress(pOb, pOb->GetClass()->m_nObjectSize, FALSE))
		{
			TRACE("ASSERT_VALID fails with illegal pointer.");
			if (AssertFailedLine(lpszFileName, nLine))
				_CrtDbgBreak();
			return;
		}
		pOb->AssertValid();
	}

	void _TraceMsg( const TCHAR *_Filename, int _Linenumber, LPCTSTR lpszPrefix, const MSG* pMsg, const XObject* pOb /*= NULL*/ )
	{
		ASSERT(lpszPrefix != NULL);
		ASSERT(pMsg != NULL);

		LPCTSTR lpszClassname = NAString;

		if (pOb)
		{
			ASSERT(pOb);
			ASSERT_VALID(pOb);
			lpszClassname = pOb->GetClass()->m_lpszClassName;
		}

		if (pMsg->message == WM_MOUSEMOVE || pMsg->message == WM_NCMOUSEMOVE ||
			pMsg->message == WM_NCHITTEST || pMsg->message == WM_SETCURSOR ||
			pMsg->message == 0x0118)    // WM_SYSTIMER (caret blink)
		{
			// don't report very frequently sent messages
			return;
		}

		LPCTSTR lpszMsgName = NAString;
		TCHAR szBuf[80];

		do
		{
			// find message name
			if (pMsg->message >= 0xC000)
			{
				// Window message registered with 'RegisterWindowMessage'
				//  (actually a USER atom)
				if (::GetClipboardFormatName(pMsg->message, szBuf, _countof(szBuf)))
					lpszMsgName = szBuf;
			}
			else
			{
				BOOL bFind = FALSE;
				// a system windows message
				const X_MAP_MESSAGE* pMapMsg = allMessages;
				for (/*null*/; pMapMsg->lpszMsg != NULL; pMapMsg++)
				{
					if (pMapMsg->nMsg == pMsg->message)
					{
						lpszMsgName = pMapMsg->lpszMsg;
						bFind = TRUE;
						break;
					}
				}

				if (!bFind)
				{
					// User message
					const TCHAR* pstrUser = _T("WM_USER+0x%04X");
#ifdef _UNICODE
					swprintf_s(szBuf, 79, pstrUser, pMsg->message);
#else
					sprintf_s(szBuf, 79, pstrUser, pMsg->message);
#endif
					lpszMsgName = szBuf;
				}
			}
		} while (0);

		if (lpszMsgName != NULL)
		{
			TRACE_T(_Filename, _Linenumber, "['%s' - 0x%X] ==> %s ==> [HWND - 0x%04X] ==> [ '%s' ] ( WP - 0x%04X, LP - 0x%08lX )",
				lpszClassname, pOb, lpszPrefix, (UINT)pMsg->hwnd, lpszMsgName,
				pMsg->wParam, pMsg->lParam);
		}
		else
		{
			TRACE_T(_Filename, _Linenumber, "['%s' - 0x%X] ==> %s ==> [HWND - 0x%04X] ==> [ '0x%04X' ] ( WP - 0x%04X, LP - 0x%08lX )",
				lpszClassname, pOb, lpszPrefix, (UINT)pMsg->hwnd, (UINT)pMsg->message,
				pMsg->wParam, pMsg->lParam);
		}
	}

	LPCTSTR GetMsgName( UINT uMsg )
	{
		LPCTSTR lpszMsgName = NULL;

		// find message name
		if (uMsg < WM_USER)
		{
			// a system windows message
			const X_MAP_MESSAGE* pMapMsg = allMessages;
			for (/*null*/; pMapMsg->lpszMsg != NULL; pMapMsg++)
			{
				if (pMapMsg->nMsg == uMsg)
				{
					lpszMsgName = pMapMsg->lpszMsg;
					break;
				}
			}
		}

		return lpszMsgName;
	}

#endif

	void _Trace( const TCHAR *_Filename, int _Linenumber, const TCHAR *lpszFormat, ... )
	{
		static TCHAR lpszBuffer[MAX_BUF_L];
		memset(lpszBuffer, 0, MAX_BUF_L*sizeof(TCHAR));
		va_list args;
		va_start(args, lpszFormat);
#ifdef _UNICODE
		_vsnwprintf_s(lpszBuffer, (MAX_BUF_L-1), lpszFormat, args);
		_CrtDbgReportW(_CRT_WARN, _Filename, _Linenumber, NULL, lpszBuffer, NULL);
#else
		_vsnprintf_s(lpszBuffer, (MAX_BUF_L-1), lpszFormat, args);
		_CrtDbgReport(_CRT_WARN, _Filename, _Linenumber, NULL, lpszBuffer, NULL);
#endif
		va_end(args);
	}
}
CC_END_NAMESPACE