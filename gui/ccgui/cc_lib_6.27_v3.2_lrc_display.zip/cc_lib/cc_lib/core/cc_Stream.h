/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Base.h

Impl:
File:../core/cc_Base.cpp

Include:

Class:
	TextReader									���ַ����Ķ���
	TextWriter									���ַ�����д��
	StreamReader								�����Ķ���
	StreamWriter								������д��
	EncoderStream								��������
	DecoderStream								��������
	MemoryStream								���ڴ���
	MemoryWrapperStream							���ڴ������
	BroadcastStream								���㲥��
	CacheStream									��������
	FileStream									���ļ���
	RecorderStream								��������

	CharEncoder									���ַ�������������
	CharDecoder									���ַ�������������
	MbcsEncoder									��Mbcs������
	MbcsDecoder									��Mbcs������
	Utf16Encoder								��Utf16������
	Utf16Decoder								��Utf16������
	Utf16BEEncoder								��Utf16 Big Endian������
	Utf16BEDecoder								��Utf16 Big Endian������
	Utf8Encoder									��Utf8������
	Utf8Decoder									��Utf8������
	BomEncoder									��BOM��ر�����
	BomDecoder									��BOM��ؽ�����

***********************************************************************/

#ifndef _CC_CORE_STREAM_H
#define _CC_CORE_STREAM_H

#include "cc_Base.h"
#include "..\collections\cc_List.h"

#define DEF_CORE_LIST_TEMPLATE(T) \
	template class CLT_API ::cc::Collections::Wrap::ListWrapper<::cc::Collections::List<T>,T,T>; \
	template class CLT_API ::cc::Collections::List<T>; 

CC_BEGIN_NAMESPACE

//////////////////////////////////////////////////////////////////////////

namespace Stream
{
	using namespace Collections;

	class CL_API IStream : public virtual Interface
	{
	public:
		virtual bool					CanRead() const = 0;
		virtual bool					CanWrite() const = 0;
		virtual bool					CanSeek() const = 0;
		virtual bool					CanPeek() const = 0;
		virtual bool					IsLimited() const = 0;
		virtual bool					IsAvailable() const = 0;
		virtual void					Close() = 0;
		virtual fpos_t					Position() const = 0;
		virtual fpos_t					Size() const = 0;
		virtual void					Seek(fpos_t _size) = 0;
		virtual void					SeekFromBegin(fpos_t _size) = 0;
		virtual void					SeekFromEnd(fpos_t _size) = 0;
		virtual int						Read(void* _buffer, int _size) = 0;
		virtual int						Write(void* _buffer, int _size) = 0;
		virtual int						Peek(void* _buffer, int _size) = 0;
	};

	class CL_API IEncoder : public Interface
	{
	public:
		virtual void					Setup(IStream* _stream) = 0;
		virtual	void					Close() = 0;
		virtual int						Write(void* _buffer, int _size) = 0;
	};

	class CL_API IDecoder : public Interface
	{
	public:
		virtual void					Setup(IStream* _stream) = 0;
		virtual	void					Close() = 0;
		virtual int						Read(void* _buffer, int _size) = 0;
	};

	DEF_CORE_LIST_TEMPLATE(IStream*);
	DEF_CORE_LIST_TEMPLATE(IEncoder*);
	DEF_CORE_LIST_TEMPLATE(IDecoder*);

	/***********************************************************************
	��������
	***********************************************************************/

	class CL_API TextReader : public NotCopyable
	{
	public:
		virtual bool				IsEnd() = 0;
		virtual TCHAR				ReadChar() = 0;
		virtual String				ReadString(int length);
		virtual String				ReadLine();
		virtual String				ReadToEnd();
	};

	class CL_API TextWriter : public NotCopyable
	{
	public:
		virtual void				WriteChar(TCHAR c) = 0;
		virtual void				WriteString(const TCHAR* string, int charCount);
		virtual void				WriteString(const TCHAR* string);
		virtual void				WriteString(const String& string);
		virtual void				WriteLine(const TCHAR* string, int charCount);
		virtual void				WriteLine(const TCHAR* string);
		virtual void				WriteLine(const String& string);
		virtual void				WriteMonospacedEnglishTable(Array<String>& tableByRow, int rows, int columns);
	};

	class CL_API StringReader : public TextReader
	{
	protected:
		String						string;
		int						    current;
		bool						lastCallIsReadLine;

		void						PrepareIfLastCallIsReadLine();
	public:
		StringReader(const String& _string);

		bool						IsEnd();
		TCHAR						ReadChar();
		String						ReadString(int length);
		String						ReadLine();
		String						ReadToEnd();
	};

	class CL_API StreamReader : public TextReader
	{
	protected:
		IStream*					stream;
	public:
		StreamReader(IStream& _stream);

		bool						IsEnd();
		TCHAR						ReadChar();
	};

	class CL_API StreamWriter : public TextWriter
	{
	protected:
		IStream*					stream;
	public:
		StreamWriter(IStream& _stream);
		using TextWriter::WriteString;

		void						WriteChar(TCHAR c);
		void						WriteString(const TCHAR* string, int charCount);
	};

	/***********************************************************************
	�������
	***********************************************************************/

	class CL_API EncoderStream : public virtual IStream
	{
	protected:
		IStream*					stream;
		IEncoder*					encoder;
		fpos_t						position;

	public:
		EncoderStream(IStream& _stream, IEncoder& _encoder);
		~EncoderStream();

		bool						CanRead() const;
		bool						CanWrite() const;
		bool						CanSeek() const;
		bool						CanPeek() const;
		bool						IsLimited() const;
		bool						IsAvailable() const;
		void						Close();
		fpos_t						Position() const;
		fpos_t						Size() const;
		void						Seek(fpos_t _size);
		void						SeekFromBegin(fpos_t _size);
		void						SeekFromEnd(fpos_t _size);
		int							Read(void* _buffer, int _size);
		int							Write(void* _buffer, int _size);
		int							Peek(void* _buffer, int _size);
	};

	class CL_API DecoderStream : public virtual IStream
	{
	protected:
		IStream*					stream;
		IDecoder*					decoder;
		fpos_t						position;

	public:
		DecoderStream(IStream& _stream, IDecoder& _decoder);
		~DecoderStream();

		bool						CanRead() const;
		bool						CanWrite() const;
		bool						CanSeek() const;
		bool						CanPeek() const;
		bool						IsLimited() const;
		bool						IsAvailable() const;
		void						Close();
		fpos_t						Position() const;
		fpos_t						Size() const;
		void						Seek(fpos_t _size);
		void						SeekFromBegin(fpos_t _size);
		void						SeekFromEnd(fpos_t _size);
		int							Read(void* _buffer, int _size);
		int							Write(void* _buffer, int _size);
		int							Peek(void* _buffer, int _size);
	};

	/***********************************************************************
	�ڴ���
	***********************************************************************/

	class CL_API MemoryStream : public Object, public virtual IStream
	{
	protected:
		int					block;
		char*				buffer;
		int					size;
		int					position;
		int					capacity;

		void					PrepareSpace(int totalSpace);
	public:
		MemoryStream(int _block=65536);
		~MemoryStream();

		bool					CanRead() const;
		bool					CanWrite() const;
		bool					CanSeek() const;
		bool					CanPeek() const;
		bool					IsLimited() const;
		bool					IsAvailable() const;
		void					Close();
		fpos_t					Position() const;
		fpos_t					Size() const;
		void					Seek(fpos_t _size);
		void					SeekFromBegin(fpos_t _size);
		void					SeekFromEnd(fpos_t _size);
		int						Read(void* _buffer, int _size);
		int						Write(void* _buffer, int _size);
		int						Peek(void* _buffer, int _size);
		void*					GetInternalBuffer();
	};

	/***********************************************************************
	�ڴ������
	***********************************************************************/

	class CL_API MemoryWrapperStream : public Object, public virtual IStream
	{
	protected:
		char*					buffer;
		int						size;
		int						position;
	public:
		MemoryWrapperStream(void* _buffer, int _size);
		~MemoryWrapperStream();

		bool					CanRead() const;
		bool					CanWrite() const;
		bool					CanSeek() const;
		bool					CanPeek() const;
		bool					IsLimited() const;
		bool					IsAvailable() const;
		void					Close();
		fpos_t					Position() const;
		fpos_t					Size() const;
		void					Seek(fpos_t _size);
		void					SeekFromBegin(fpos_t _size);
		void					SeekFromEnd(fpos_t _size);
		int						Read(void* _buffer, int _size);
		int						Write(void* _buffer, int _size);
		int						Peek(void* _buffer, int _size);
	};

	/***********************************************************************
	�㲥��
	***********************************************************************/

	class CL_API BroadcastStream : public Object, public virtual IStream
	{
		typedef List<IStream*>		StreamList;
	protected:
		bool					closed;
		fpos_t					position;
		StreamList				streams;
	public:
		BroadcastStream();
		~BroadcastStream();

		StreamList&				Targets();
		bool					CanRead() const;
		bool					CanWrite() const;
		bool					CanSeek() const;
		bool					CanPeek() const;
		bool					IsLimited() const;
		bool					IsAvailable() const;
		void					Close();
		fpos_t					Position() const;
		fpos_t					Size() const;
		void					Seek(fpos_t _size);
		void					SeekFromBegin(fpos_t _size);
		void					SeekFromEnd(fpos_t _size);
		int						Read(void* _buffer, int _size);
		int						Write(void* _buffer, int _size);
		int						Peek(void* _buffer, int _size);
	};

	/***********************************************************************
	������
	***********************************************************************/

	class CL_API CacheStream : public Object, public virtual IStream
	{
	protected:
		IStream*				target;
		int						block;
		fpos_t					start;
		fpos_t					position;

		char*					buffer;
		int						dirtyStart;
		int						dirtyLength;
		int						availableLength;
		fpos_t					operatedSize;

		void					Flush();
		void					Load(fpos_t _position);
		int						InternalRead(void* _buffer, int _size);
		int						InternalWrite(void* _buffer, int _size);
	public:
		CacheStream(IStream& _target, int _block=65536);
		~CacheStream();

		bool					CanRead() const;
		bool					CanWrite() const;
		bool					CanSeek() const;
		bool					CanPeek() const;
		bool					IsLimited() const;
		bool					IsAvailable() const;
		void					Close();
		fpos_t					Position() const;
		fpos_t					Size() const;
		void					Seek(fpos_t _size);
		void					SeekFromBegin(fpos_t _size);
		void					SeekFromEnd(fpos_t _size);
		int						Read(void* _buffer, int _size);
		int						Write(void* _buffer, int _size);
		int						Peek(void* _buffer, int _size);
	};

	/***********************************************************************
	�ļ���
	***********************************************************************/

	class CL_API FileStream : public Object, public virtual IStream
	{
	public:
		enum AccessRight
		{
			ReadOnly,
			WriteOnly,
			ReadWrite
		};
	protected:
		AccessRight				accessRight;
		FILE*					file;
	public:
		FileStream(const String& fileName, AccessRight _accessRight);
		~FileStream();

		bool					CanRead() const;
		bool					CanWrite() const;
		bool					CanSeek() const;
		bool					CanPeek() const;
		bool					IsLimited() const;
		bool					IsAvailable() const;
		void					Close();
		fpos_t					Position() const;
		fpos_t					Size() const;
		void					Seek(fpos_t _size);
		void					SeekFromBegin(fpos_t _size);
		void					SeekFromEnd(fpos_t _size);
		int						Read(void* _buffer, int _size);
		int						Write(void* _buffer, int _size);
		int						Peek(void* _buffer, int _size);
	};

	
	/***********************************************************************
	������
	***********************************************************************/

	class CL_API RecorderStream : public Object, public virtual IStream
	{
	protected:
		IStream*				in;
		IStream*				out;
	public:
		RecorderStream(IStream& _in, IStream& _out);
		~RecorderStream();

		bool					CanRead() const;
		bool					CanWrite() const;
		bool					CanSeek() const;
		bool					CanPeek() const;
		bool					IsLimited() const;
		bool					IsAvailable() const;
		void					Close();
		fpos_t					Position() const;
		fpos_t					Size() const;
		void					Seek(fpos_t _size);
		void					SeekFromBegin(fpos_t _size);
		void					SeekFromEnd(fpos_t _size);
		int						Read(void* _buffer, int _size);
		int						Write(void* _buffer, int _size);
		int						Peek(void* _buffer, int _size);
	};

	/***********************************************************************
	�ַ��������
	***********************************************************************/

	/*
	��������
		UCS-4��UTF-8�Ķ�Ӧ��ϵ:
		U-00000000 - U-0000007F:  0xxxxxxx
		U-00000080 - U-000007FF:  110xxxxx 10xxxxxx
		U-00000800 - U-0000FFFF:  1110xxxx 10xxxxxx 10xxxxxx
		U-00010000 - U-001FFFFF:  11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
		U-00200000 - U-03FFFFFF:  111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
		U-04000000 - U-7FFFFFFF:  1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
		BOM:
		FFFE	=Unicode			(vceUtf16)
		FEFF	=Unicode Big Endian	(vceUtf16_be)
		EFBBBF	=UTF-8				(vceUtf8)
		other	=MBCS(GBK)			(vceMbcs)
	*/

	/***********************************************************************
	�ַ�������������
	***********************************************************************/

	class CL_API CharEncoder : public Object, public IEncoder
	{
	protected:
		IStream*						stream;
		cuint8_t						cacheBuffer[sizeof(TCHAR)];
		int								cacheSize;

		virtual int						WriteString(TCHAR* _buffer, int chars) = 0;
	public:
		CharEncoder();

		void							Setup(IStream* _stream);
		void							Close();
		int								Write(void* _buffer, int _size);
	};

	class CL_API CharDecoder : public Object, public IDecoder
	{
	protected:
		IStream*						stream;
		cuint8_t						cacheBuffer[sizeof(TCHAR)];
		int								cacheSize;

		virtual int						ReadString(TCHAR* _buffer, int chars) = 0;
	public:
		CharDecoder();

		void							Setup(IStream* _stream);
		void							Close();
		int								Read(void* _buffer, int _size);
	};

	/***********************************************************************
	Mbcs
	***********************************************************************/

	class CL_API MbcsEncoder : public CharEncoder
	{
	protected:
		int							WriteString(TCHAR* _buffer, int chars);
	};

	class CL_API MbcsDecoder : public CharDecoder
	{
	protected:
		int							ReadString(TCHAR* _buffer, int chars);
	};

	/***********************************************************************
	Utf-16
	***********************************************************************/

	class CL_API Utf16Encoder : public CharEncoder
	{
	protected:
		int							WriteString(TCHAR* _buffer, int chars);
	};

	class CL_API Utf16Decoder : public CharDecoder
	{
	protected:
		int							ReadString(TCHAR* _buffer, int chars);
	};

	/***********************************************************************
	Utf-16-be
	***********************************************************************/

	class CL_API Utf16BEEncoder : public CharEncoder
	{
	protected:
		int							WriteString(TCHAR* _buffer, int chars);
	};

	class CL_API Utf16BEDecoder : public CharDecoder
	{
	protected:
		int							ReadString(TCHAR* _buffer, int chars);
	};

	/***********************************************************************
	Utf-8
	***********************************************************************/

	class CL_API Utf8Encoder : public CharEncoder
	{
	protected:
		int							WriteString(TCHAR* _buffer, int chars);
	};

	class CL_API Utf8Decoder : public CharDecoder
	{
	protected:
		TCHAR							cache;
		bool							cacheAvailable;
		int								ReadString(TCHAR* _buffer, int chars);
	public:
		Utf8Decoder();
	};

	/***********************************************************************
	Bom
	***********************************************************************/

	class CL_API BomEncoder : public Object, public IEncoder
	{
	public:
		enum Encoding
		{
			Mbcs,
			Utf8,
			Utf16,
			Utf16BE
		};
	protected:
		Encoding						encoding;
		IEncoder*						encoder;
	public:
		BomEncoder(Encoding _encoding);
		~BomEncoder();

		void							Setup(IStream* _stream);
		void							Close();
		int								Write(void* _buffer, int _size);
	};

	class CL_API BomDecoder : public Object, public IDecoder
	{
	private:
		class CL_API BomStream : public Object, public IStream
		{
		protected:
			IStream*					stream;
			char						bom[3];
			int							bomLength;
			int							bomPosition;
		public:
			BomStream(IStream* _stream, char* _bom, int _bomLength);

			bool						CanRead() const;
			bool						CanWrite() const;
			bool						CanSeek() const;
			bool						CanPeek() const;
			bool						IsLimited() const;
			bool						IsAvailable() const;
			void						Close();
			fpos_t						Position() const;
			fpos_t						Size() const;
			void						Seek(fpos_t _size);
			void						SeekFromBegin(fpos_t _size);
			void						SeekFromEnd(fpos_t _size);
			int							Read(void* _buffer, int _size);
			int							Write(void* _buffer, int _size);
			int							Peek(void* _buffer, int _size);
		};
	protected:
		IDecoder*						decoder;
		IStream*						stream;

	public:
		BomDecoder();
		~BomDecoder();

		void							Setup(IStream* _stream);
		void							Close();
		int								Read(void* _buffer, int _size);
	};
}

CC_END_NAMESPACE

#endif