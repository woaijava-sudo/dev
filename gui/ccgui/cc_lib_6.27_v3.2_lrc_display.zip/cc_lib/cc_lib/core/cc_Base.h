/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Base.h

Impl:
File:../core/cc_Base.cpp

Include:

Class:
	Object										���������
	ObjectWrapper								����������װ
	NotCopyableProp								�����ɸ��ƶ�������
	NotCopyable									�����ɸ��ƶ���
	Interface									���ӿ�

Struct:
	Result										: ģ���ػ�Ԥ��
	Type										: ����

Union:
	BinWrapper									: �����Ʋ���

***********************************************************************/

#ifndef _CC_CORE_BASE_H
#define _CC_CORE_BASE_H

#ifndef CL_API
#error "����� cc_Include.h"
#endif

#ifndef max
#define max(a,b) ((a)>(b)?(a):(b))
#endif

#if defined _WIN64 || __x86_64_
#define CC_64
#endif

#if defined _MSC_VER
#define CC_MSVC
#else
#error "Only supported msvc"
#endif

#ifdef CC_64
#define ITOA_S		_i64toa_s
#define ITOW_S		_i64tow_s
#define I64TOA_S	_i64toa_s
#define I64TOW_S	_i64tow_s
#define UITOA_S		_ui64toa_s
#define UITOW_S		_ui64tow_s
#define UI64TOA_S	_ui64toa_s
#define UI64TOW_S	_ui64tow_s
#else
#define ITOA_S		_itoa_s
#define ITOW_S		_itow_s
#define I64TOA_S	_i64toa_s
#define I64TOW_S	_i64tow_s
#define UITOA_S		_ui64toa_s
#define UITOW_S		_ui64tow_s
#define UI64TOA_S	_ui64toa_s
#define UI64TOW_S	_ui64tow_s
#endif

#if defined CC_MSVC
typedef signed __int8			cint8_t;
typedef unsigned __int8			cuint8_t;
typedef signed __int16			cint16_t;
typedef unsigned __int16		cuint16_t;
typedef signed __int32			cint32_t;
typedef unsigned __int32		cuint32_t;
typedef signed __int64			cint64_t;
typedef unsigned __int64		cuint64_t;
#endif

#ifdef CC_64
typedef cint64_t				cint;
typedef cint64_t				csint;
typedef cuint64_t				cuint;
#else
typedef cint32_t				cint;
typedef cint32_t				csint;
typedef cuint32_t				cuint;
#endif

typedef ULONG pos_t;

CC_BEGIN_NAMESPACE
//////////////////////////////////////////////////////////////////////////
// 
// Class: cc::Object - һ�ж���Ļ���
//
class CL_API Object
{
public:
	virtual ~Object();
};

//////////////////////////////////////////////////////////////////////////
// 
// Class: cc::NotCopyableProp - ��ֹ���ƶ�������
//
class CL_API NotCopyableProp
{
public:
	NotCopyableProp();
private:
	// ��ֹ��������
	NotCopyableProp( const NotCopyableProp& );
	// ��ֹ��ֵ
	NotCopyableProp& operator = ( const NotCopyableProp& );
};

//////////////////////////////////////////////////////////////////////////
// 
// Class: cc::NotCopyable - ��ֹ���ƶ���
//
class CL_API NotCopyable : public Object, public NotCopyableProp {};

//////////////////////////////////////////////////////////////////////////
// 
// Class: cc::ObjectWrapper - ����İ�װ��
//
template<typename T>
class ObjectWrapper : public Object
{
public:
	ObjectWrapper( const T& obj ): o(obj)
	{
		// ����ʹ����ĸ�ֵ���أ����Դ��಻֧����NotCopyable���Ե���
	}

	const T& UnWrap()
	{
		return o;
	}

private:
	T o;
};

//////////////////////////////////////////////////////////////////////////
// 
// Union: cc::BinWrapper - �����Ʋ���
//
template<typename T, size_t size>
union BinWrapper
{
	T t;
	char binary[ max(sizeof(T), size) ];
};

//////////////////////////////////////////////////////////////////////////
// 
// Struct: cc::Type - ����
//
template<typename T>
struct Type
{
public:
	typedef T _Type;
};

//////////////////////////////////////////////////////////////////////////
// 
// Class: cc::Interface - �ӿ�
//
class CL_API Interface : public NotCopyableProp
{
public:
	virtual ~Interface();
};

//////////////////////////////////////////////////////////////////////////
// 
// Struct: cc::Result - ģ�����ͷ���ֵ
//
template<typename T>
struct Result
{
	static const bool _Result = false;
};

//////////////////////////////////////////////////////////////////////////
//
// cc::Result - ģ��ƫ�ػ�
//
#define IMPL_TEMPLATE_RESULT(TYPE) \
template<> struct Result<TYPE> { static const bool _Result = true; }

IMPL_TEMPLATE_RESULT(bool);
IMPL_TEMPLATE_RESULT(unsigned __int8);
IMPL_TEMPLATE_RESULT(__int8);
IMPL_TEMPLATE_RESULT(unsigned __int16);
IMPL_TEMPLATE_RESULT(__int16);
IMPL_TEMPLATE_RESULT(unsigned __int32);
IMPL_TEMPLATE_RESULT(__int32);
IMPL_TEMPLATE_RESULT(unsigned __int64);
IMPL_TEMPLATE_RESULT(__int64);
IMPL_TEMPLATE_RESULT(wchar_t);
//
template<typename T>					struct Result<T*>					{ static const bool _Result = true; };
template<typename T>					struct Result<T&>					{ static const bool _Result = true; };
template<typename T, typename _class>	struct Result<T _class::*>			{ static const bool _Result = true; };
template<typename T, int size>			struct Result<T[size]>				{ static const bool _Result = Result<T>::_Result; };
template<typename T>					struct Result<const T>				{ static const bool _Result = Result<T>::_Result; };
template<typename T>					struct Result<volatile T>			{ static const bool _Result = Result<T>::_Result; };
template<typename T>					struct Result<const volatile T>		{ static const bool _Result = Result<T>::_Result; };
#undef IMPL_TEMPLATE_RESULT
// Result Template End

CC_END_NAMESPACE
//////////////////////////////////////////////////////////////////////////

#define SAFE_DELETE(p) {do{if(p){delete(p);p=NULL;}}while(0);}
#define SAFE_DELETE_ARRAY(p) {do{if(p){delete[](p);p=NULL;}}while(0);}

#endif