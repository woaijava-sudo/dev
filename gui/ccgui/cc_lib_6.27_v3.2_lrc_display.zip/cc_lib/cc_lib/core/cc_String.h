/***********************************************************************

|-----------------------------------|
|									|
|	Project:		>>>	cc_lib		|
|	Developer:		>>>	bajdcc		|
|									|
|-----------------------------------|

Decl:
File:../core/cc_String.h

Impl:
File:../core/cc_String.cpp

Include:
File:../core/cc_Base.h

Class:
	String										���ַ��� / TCHAR
	TString										���ַ���ģ��
	AString										��ANSI
	WString										��UNICODE

***********************************************************************/

#ifndef _CC_CORE_STRING_H
#define _CC_CORE_STRING_H

#include "cc_Base.h"

CC_BEGIN_NAMESPACE
namespace Strings
{
	/////////////////////////////////////////////////////////////////////////////
	// StringData
	struct StringData
	{
		long nRefs;             // reference count
		int nDataLength;        // length of data (including terminator)
		int nAllocLength;       // length of allocation
		// TCHAR data[nAllocLength]

		TCHAR* data()           // TCHAR* to managed data
		{ return (TCHAR*)(this+1); }
	};

	/////////////////////////////////////////////////////////////////////////////
	// String
	class CL_API String
	{
	public:
		enum _L { MABUFFER_LEN = 512 };

	public:
		// Constructors

		// constructs empty CString
		String();
		// copy constructor
		String(const String& stringSrc);
		// from a single character
		String(TCHAR ch, int nRepeat = 1);
		// from an ANSI string (converts to TCHAR)
		String(LPCSTR lpsz);
		// from a UNICODE string (converts to TCHAR)
		String(LPCWSTR lpsz);
		// subset of characters from an ANSI string (converts to TCHAR)
		String(LPCSTR lpch, int nLength);
		// subset of characters from a UNICODE string (converts to TCHAR)
		String(LPCWSTR lpch, int nLength);
		// from unsigned characters
		String(const unsigned char* psz);

		// Attributes & Operations

		// get data length
		int GetLength() const;
		int Length() const;
		// TRUE if zero length
		BOOL IsEmpty() const;
		// clear contents to empty
		void Empty();

		// return single character at zero-based index
		TCHAR GetAt(int nIndex) const;
		// return single character at zero-based index
		TCHAR operator[](int nIndex) const;
		// set a single character at zero-based index
		void SetAt(int nIndex, TCHAR ch);
		// return pointer to const string
		operator LPCTSTR() const;

		// overloaded assignment

		// ref-counted copy from another CString
		const String& operator=(const String& stringSrc);
		// set string content to single character
		const String& operator=(TCHAR ch);
#ifdef _UNICODE
		const String& operator=(char ch);
#endif
		// copy string content from ANSI string (converts to TCHAR)
		const String& operator=(LPCSTR lpsz);
		// copy string content from UNICODE string (converts to TCHAR)
		const String& operator=(LPCWSTR lpsz);
		// copy string content from unsigned chars
		const String& operator=(const unsigned char* psz);

		// string concatenation

		// concatenate from another CString
		const String& operator+=(const String& string);

		// concatenate a single character
		const String& operator+=(TCHAR ch);
#ifdef _UNICODE
		// concatenate an ANSI character after converting it to TCHAR
		const String& operator+=(char ch);
#endif
		// concatenate a UNICODE character after converting it to TCHAR
		const String& operator+=(LPCTSTR lpsz);

		friend CL_API String operator+(const String& string1, const String& string2);
		friend CL_API String operator+(const String& string, TCHAR ch);
		friend CL_API String operator+(TCHAR ch, const String& string);
		friend CL_API String operator+(const String& string, LPCTSTR lpsz);
		friend CL_API String operator+(LPCTSTR lpsz, const String& string);

		// string comparison

		// straight character comparison
		int Compare(LPCTSTR lpsz) const;
		// compare ignoring case
		int CompareNoCase(LPCTSTR lpsz) const;
		// NLS aware comparison, case sensitive
		int Collate(LPCTSTR lpsz) const;
		// NLS aware comparison, case insensitive
		int CollateNoCase(LPCTSTR lpsz) const;

		// simple sub-string extraction

		// return nCount characters starting at zero-based nFirst
		String Mid(int nFirst, int nCount) const;
		// return all characters starting at zero-based nFirst
		String Mid(int nFirst) const;
		// return first nCount characters in string
		String Left(int nCount) const;
		// return nCount characters from end of string
		String Right(int nCount) const;

		//  characters from beginning that are also in passed string
		String SpanIncluding(LPCTSTR lpszCharSet) const;
		// characters from beginning that are not also in passed string
		String SpanExcluding(LPCTSTR lpszCharSet) const;

		// upper/lower/reverse conversion

		// NLS aware conversion to uppercase
		void MakeUpper();
		// NLS aware conversion to lowercase
		void MakeLower();
		// reverse string right-to-left
		void MakeReverse();

		// trimming whitespace (either side)

		// remove whitespace starting from right edge
		void TrimRight();
		// remove whitespace starting from left side
		void TrimLeft();

		// trimming anything (either side)

		// remove continuous occurrences of chTarget starting from right
		void TrimRight(TCHAR chTarget);
		// remove continuous occcurrences of characters in passed string,
		// starting from right
		void TrimRight(LPCTSTR lpszTargets);
		// remove continuous occurrences of chTarget starting from left
		void TrimLeft(TCHAR chTarget);
		// remove continuous occcurrences of characters in
		// passed string, starting from left
		void TrimLeft(LPCTSTR lpszTargets);

		// advanced manipulation

		// replace occurrences of chOld with chNew
		int Replace(TCHAR chOld, TCHAR chNew);
		// replace occurrences of substring lpszOld with lpszNew;
		// empty lpszNew removes instances of lpszOld
		int Replace(LPCTSTR lpszOld, LPCTSTR lpszNew);
		// remove occurrences of chRemove
		int Remove(TCHAR chRemove);
		// insert character at zero-based index; concatenates
		// if index is past end of string
		int Insert(int nIndex, TCHAR ch);
		// insert substring at zero-based index; concatenates
		// if index is past end of string
		int Insert(int nIndex, LPCTSTR pstr);
		// delete nCount characters starting at zero-based index
		int Delete(int nIndex, int nCount = 1);

		// searching

		// find character starting at left, -1 if not found
		int Find(TCHAR ch) const;
		// find character starting at right
		int ReverseFind(TCHAR ch) const;
		// find character starting at zero-based index and going right
		int Find(TCHAR ch, int nStart) const;
		// find first instance of any character in passed string
		int FindOneOf(LPCTSTR lpszCharSet) const;
		// find first instance of substring
		int Find(LPCTSTR lpszSub) const;
		// find first instance of substring starting at zero-based index
		int Find(LPCTSTR lpszSub, int nStart) const;

		// simple formatting

		// printf-like formatting using passed string
		static String XFormat(LPCTSTR lpszFormat, ...);
		// printf-like formatting using passed string
		void CDECL Format(LPCTSTR lpszFormat, ...);
		// printf-like formatting using referenced string resource
		void CDECL Format(UINT nFormatID, ...);
		// printf-like formatting using variable arguments parameter
		void FormatV(LPCTSTR lpszFormat, va_list argList);

		// formatting for localization (uses FormatMessage API)

		// format using FormatMessage API on passed string
		void CDECL FormatMessage(LPCTSTR lpszFormat, ...);
		// format using FormatMessage API on referenced string resource
		void CDECL FormatMessage(UINT nFormatID, ...);

		// load from string resource
		BOOL LoadString(UINT nID);

#ifndef _UNICODE
		// ANSI <-> OEM support (convert string in place)

		// convert string from ANSI to OEM in-place
		void AnsiToOem();
		// convert string from OEM to ANSI in-place
		void OemToAnsi();
#endif

		// Access to string implementation buffer as "C" character array

		// get pointer to modifiable buffer at least as long as nMinBufLength
		LPTSTR Buffer() const;
		LPTSTR GetBuffer(int nMinBufLength);
		// release buffer, setting length to nNewLength (or to first nul if -1)
		void ReleaseBuffer(int nNewLength = -1);
		// get pointer to modifiable buffer exactly as long as nNewLength
		LPTSTR GetBufferSetLength(int nNewLength);
		// release memory allocated to but unused by string
		void FreeExtra();

		// Use LockBuffer/UnlockBuffer to turn refcounting off

		// turn refcounting back on
		LPTSTR LockBuffer();
		// turn refcounting off
		void UnlockBuffer();

		// Another helpers

		// time helpers, szFormat is usually "%c"
		void FormatTime(const time_t& time, LPCTSTR szFormat);

		// Implementation
	public:
		~String();
		int GetAllocLength() const;

	protected:
		LPTSTR m_pchData;   // pointer to ref counted string data

		// implementation helpers
		StringData* GetData() const;
		void Init();
		void AllocCopy(String& dest, int nCopyLen, int nCopyIndex, int nExtraLen) const;
		void AllocBuffer(int nLen);
		void AssignCopy(int nSrcLen, LPCTSTR lpszSrcData);
		void ConcatCopy(int nSrc1Len, LPCTSTR lpszSrc1Data, int nSrc2Len, LPCTSTR lpszSrc2Data);
		void ConcatInPlace(int nSrcLen, LPCTSTR lpszSrcData);
		void CopyBeforeWrite();
		void AllocBeforeWrite(int nLen);
		void Release();
		static void PASCAL Release(StringData* pData);
		static int PASCAL SafeStrlen(LPCTSTR lpsz);
		static void __fastcall FreeData(StringData* pData);
	};

	// Compare helpers
	bool CL_API operator==(const String& s1, const String& s2);
	bool CL_API operator==(const String& s1, LPCTSTR s2);
	bool CL_API operator==(LPCTSTR s1, const String& s2);
	bool CL_API operator!=(const String& s1, const String& s2);
	bool CL_API operator!=(const String& s1, LPCTSTR s2);
	bool CL_API operator!=(LPCTSTR s1, const String& s2);
	bool CL_API operator<(const String& s1, const String& s2);
	bool CL_API operator<(const String& s1, LPCTSTR s2);
	bool CL_API operator<(LPCTSTR s1, const String& s2);
	bool CL_API operator>(const String& s1, const String& s2);
	bool CL_API operator>(const String& s1, LPCTSTR s2);
	bool CL_API operator>(LPCTSTR s1, const String& s2);
	bool CL_API operator<=(const String& s1, const String& s2);
	bool CL_API operator<=(const String& s1, LPCTSTR s2);
	bool CL_API operator<=(LPCTSTR s1, const String& s2);
	bool CL_API operator>=(const String& s1, const String& s2);
	bool CL_API operator>=(const String& s1, LPCTSTR s2);
	bool CL_API operator>=(LPCTSTR s1, const String& s2);

	// Conversion helpers
	int CDECL _wcstombsz(char* mbstr, const wchar_t* wcstr, size_t count);
	int CDECL _mbstowcsz(wchar_t* wcstr, const char* mbstr, size_t count);

	// Globals
	extern LPCTSTR _xPchNil;
	extern LPCTSTR _xPchNA;
#define EmptyString ((String&)*(String*)&_xPchNil)
#define NAString ((LPCTSTR)_xPchNA)
	int WINAPI LoadStringEx(UINT nID, LPTSTR lpszBuf, UINT nMaxBuf);
	BOOL WINAPI ExtractSubString(String& rString, LPCTSTR lpszFullString,
		int iSubString, TCHAR chSep);

	typedef String XString;
}

namespace Strings
{
	template<typename T>
	class TString : public Object
	{
	public:
		static TString<T> Empty;

		TString()
		{
			buffer=(T*)&zero;
			counter=0;
			start=0;
			length=0;
			realLength=0;
		}

		TString(const T& _char)
		{
			counter=new cuint(1);
			start=0;
			length=1;
			buffer=new T[2];
			buffer[0]=_char;
			buffer[1]=0;
			realLength=length;
		}

		TString(const T* _buffer, cint _length)
		{
			if(_length<=0)
			{
				buffer=(T*)&zero;
				counter=0;
				start=0;
				length=0;
				realLength=0;
			}
			else
			{
				buffer=new T[_length+1];
				memcpy(buffer, _buffer, _length*sizeof(T));
				buffer[_length]=0;
				counter=new cuint(1);
				start=0;
				length=_length;
				realLength=_length;
			}
		}

		TString(const T* _buffer, bool copy = true)
		{
			ASSERT(_buffer!=0);
			if(copy)
			{
				counter=new cuint(1);
				start=0;
				length=CalculateLength(_buffer);
				buffer=new T[length+1];
				memcpy(buffer, _buffer, sizeof(T)*(length+1));
				realLength=length;
			}
			else
			{
				buffer=(T*)_buffer;
				counter=0;
				start=0;
				length=CalculateLength(_buffer);
				realLength=length;
			}
		}

		TString(const TString<T>& string)
		{
			buffer=string.buffer;
			counter=string.counter;
			start=string.start;
			length=string.length;
			realLength=string.realLength;
			Inc();
		}

		TString(TString<T>&& string)
		{
			buffer=string.buffer;
			counter=string.counter;
			start=string.start;
			length=string.length;
			realLength=string.realLength;
			
			string.buffer=(T*)&zero;
			string.counter=0;
			string.start=0;
			string.length=0;
			string.realLength=0;
		}

		~TString()
		{
			Dec();
		}

	private:
		TString(const TString<T>& string, cint _start, cint _length)
		{
			if(_length<=0)
			{
				buffer=(T*)&zero;
				counter=0;
				start=0;
				length=0;
				realLength=0;
			}
			else
			{
				buffer=string.buffer;
				counter=string.counter;
				start=string.start+_start;
				length=_length;
				realLength=string.realLength;
				Inc();
			}
		}

		TString(const TString<T>& dest, const TString<T>& source, cint index, cint count)
		{
			if(index==0 && count==dest.length && source.length==0)
			{
				buffer=(T*)&zero;
				counter=0;
				start=0;
				length=0;
				realLength=0;
			}
			else
			{
				counter=new cuint(1);
				start=0;
				length=dest.length-count+source.length;
				realLength=length;
				buffer=new T[length+1];
				memcpy(buffer, dest.buffer+dest.start, sizeof(T)*index);
				memcpy(buffer+index, source.buffer+source.start, sizeof(T)*source.length);
				memcpy(buffer+index+source.length, (dest.buffer+dest.start+index+count), sizeof(T)*(dest.length-index-count));
				buffer[length]=0;
			}
		}

	public:
		const T* Buffer()const
		{
			if(start+length!=realLength)
			{
				T* newBuffer=new T[length+1];
				memcpy(newBuffer, buffer+start, sizeof(T)*length);
				newBuffer[length]=0;
				Dec();
				buffer=newBuffer;
				counter=new cuint(1);
				start=0;
				realLength=length;
			}
			return buffer+start;
		}

		TString<T>& operator=(const TString<T>& string)
		{
			if(this!=&string)
			{
				Dec();
				buffer=string.buffer;
				counter=string.counter;
				start=string.start;
				length=string.length;
				realLength=string.realLength;
				Inc();
			}
			return *this;
		}

		TString<T>& operator=(TString<T>&& string)
		{
			if(this!=&string)
			{
				Dec();
				buffer=string.buffer;
				counter=string.counter;
				start=string.start;
				length=string.length;
				realLength=string.realLength;
			
				string.buffer=(T*)&zero;
				string.counter=0;
				string.start=0;
				string.length=0;
				string.realLength=0;
			}
			return *this;
		}

		TString<T>& operator+=(const TString<T>& string)
		{
			return *this=*this+string;
		}

		TString<T> operator+(const TString<T>& string)const
		{
			return TString<T>(*this, string, length, 0);
		}

		bool operator==(const TString<T>& string)const
		{
			return Compare(*this, string)==0;
		}

		bool operator!=(const TString<T>& string)const
		{
			return Compare(*this, string)!=0;
		}

		bool operator>(const TString<T>& string)const
		{
			return Compare(*this, string)>0;
		}

		bool operator>=(const TString<T>& string)const
		{
			return Compare(*this, string)>=0;
		}

		bool operator<(const TString<T>& string)const
		{
			return Compare(*this, string)<0;
		}

		bool operator<=(const TString<T>& string)const
		{
			return Compare(*this, string)<=0;
		}

		bool operator==(const T* buffer)const
		{
			return Compare(buffer, *this)==0;
		}

		bool operator!=(const T* buffer)const
		{
			return Compare(buffer, *this)!=0;
		}

		bool operator>(const T* buffer)const
		{
			return Compare(buffer, *this)<0;
		}

		bool operator>=(const T* buffer)const
		{
			return Compare(buffer, *this)<=0;
		}

		bool operator<(const T* buffer)const
		{
			return Compare(buffer, *this)>0;
		}

		bool operator<=(const T* buffer)const
		{
			return Compare(buffer, *this)>=0;
		}

		T operator[](cint index)const
		{
			ASSERT(index>=0 && index<length);
			return buffer[start+index];
		}

		cint Length()const
		{
			return length;
		}

		cint IndexOf(T c)const
		{
			const T* reading=buffer+start;
			for(cint i=0;i<length;i++)
			{
				if(reading[i]==c)
					return i;
			}
			return -1;
		}

		TString<T> Left(cint count)const
		{
			ASSERT(count>=0 && count<=length);
			return TString<T>(*this, 0, count);
		}

		TString<T> Right(cint count)const
		{
			ASSERT(count>=0 && count<=length);
			return TString<T>(*this, length-count, count);
		}

		TString<T> Sub(cint index, cint count)const
		{
			ASSERT(index>=0 && index<=length);
			ASSERT(index+count>=0 && index+count<=length);
			return TString<T>(*this, index, count);
		}

		TString<T> Remove(cint index, cint count)const
		{
			ASSERT(index>=0 && index<length);
			ASSERT(index+count>=0 && index+count<=length);
			return TString<T>(*this, TString<T>(), index, count);
		}

		TString<T> Insert(cint index, const TString<T>& string)const
		{
			ASSERT(index>=0 && index<=length);
			return TString<T>(*this, string, index, 0);
		}

		friend bool operator<(const T* left, const TString<T>& right)
		{
			return Compare(left, right)<0;
		}

		friend bool operator<=(const T* left, const TString<T>& right)
		{
			return Compare(left, right)<=0;
		}

		friend bool operator>(const T* left, const TString<T>& right)
		{
			return Compare(left, right)>0;
		}

		friend bool operator>=(const T* left, const TString<T>& right)
		{
			return Compare(left, right)>=0;
		}

		friend bool operator==(const T* left, const TString<T>& right)
		{
			return Compare(left, right)==0;
		}

		friend bool operator!=(const T* left, const TString<T>& right)
		{
			return Compare(left, right)!=0;
		}

		friend TString<T> operator+(const T* left, const TString<T>& right)
		{
			return TString<T>(left, false)+right;
		}

	public:
		static cint Compare(const TString<T>& strA, const TString<T>& strB)
		{
			const T* bufA=strA.buffer+strA.start;
			const T* bufB=strB.buffer+strB.start;
			cint length=strA.length<strB.length?strA.length:strB.length;
			while(length--)
			{
				cint diff=*bufA++-*bufB++;
				if(diff!=0)
				{
					return diff;
				}
			};
			return strA.length-strB.length;
		}

	private:

		void Inc()const
		{
			if(counter)
			{
				InterlockedIncrement(counter);
			}
		}

		void Dec()const
		{
			if(counter)
			{
				if(InterlockedDecrement(counter)==0)
				{
					delete[] buffer;
					delete counter;
				}
			}
		}

	private:
		static cint CalculateLength(const T* buffer)
		{
			cint result=0;
			while(*buffer++)result++;
			return result;
		}

		static cint Compare(const T* bufA, const TString<T>& strB)
		{
			const T* bufB=strB.buffer+strB.start;
			const T* bufAOld=bufA;
			cint length=strB.length;
			while(length-- && *bufA)
			{
				cint diff=*bufA++-*bufB++;
				if(diff!=0)
				{
					return diff;
				}
			};
			return CalculateLength(bufAOld)-strB.length;
		}

	private:
		static const T				zero;

		mutable T*					buffer;
		mutable volatile cuint*		counter;
		mutable cint				start;
		mutable cint				length;
		mutable cint				realLength;
	};

	template<typename T> TString<T> TString<T>::Empty = TString<T>();
	template<typename T> const T TString<T>::zero = 0;

	template class CL_API TString<char>;
	template class CL_API TString<wchar_t>;

	typedef TString<char>		AString;
#ifdef _UNICODE
	typedef TString<wchar_t>	WString;
#endif // _UNICODE
}
CC_END_NAMESPACE

#endif