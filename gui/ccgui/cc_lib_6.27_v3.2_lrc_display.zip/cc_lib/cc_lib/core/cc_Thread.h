/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	c_lib		|
			|	Developer:		>>>	bajdc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Thread.h

Impl:
File:../core/cc_Thread.cpp

Include:
File:../core/cc_Base.h
File:../core/cc_Function.h

Class:
	Thread										���߳�
	CriticalSection								���ٽ���
	Mutex										��������
	Semaphore									���ź���
	Event										���¼�
	ThreadPool									���̳߳�
	ReadWriteLock								����д��
	SpinLock									��������

Struct:

***********************************************************************/

#ifndef _CC_CORE_THREAD_H
#define _CC_CORE_THREAD_H

#include "cc_Base.h"
#include "cc_Function.h"

CC_BEGIN_NAMESPACE
namespace Threading
{
	using namespace cc::Function;

	//////////////////////////////////////////////////////////////////////////
	// 
	// namespace: cc::Threading::Internal - �ں˶���
	//
	namespace Internal
	{
		struct WaitableData;
		struct ThreadData;

		struct CriticalSectionData;
		struct EventData;
		struct MutexData;
		struct SemaphoreData;

		struct ReaderWriterLockData;
		struct ConditionVariableData;
	}

	//////////////////////////////////////////////////////////////////////////
	// 
	// Class: cc::Threading::WaitableObject - �ɵȴ�����
	//
	class CL_API WaitableObject : public NotCopyable
	{
	protected:
		WaitableObject();
		void										SetData(Internal::WaitableData* data);

	public:
        LPCTSTR										GetName() const;
        void										SetName(LPCTSTR pstrName);

		BOOL										IsCreated() const;
		BOOL										Wait();
		BOOL										WaitForTime(int milliSeconds);

		static BOOL									WaitAll(WaitableObject** objects, int count);
		static BOOL									WaitAllForTime(WaitableObject** objects, int count, int milliSeconds);
		static int									WaitAny(WaitableObject** objects, int count, BOOL* abandoned);
		static int									WaitAnyForTime(WaitableObject** objects, int count, int milliSeconds, BOOL* abandoned);

	private:
		Internal::WaitableData*						_waitableData;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Class: cc::Threading::Thread - �̶߳���
	//
	class CL_API Thread : public WaitableObject
	{
	public:
		Thread(LPCTSTR thread_name = NULL);
		~Thread();

		typedef void (*ThreadProcedure)(Thread*, void*);
		enum ThreadState
		{
			New, // δ��ʼ��
			Running,
			Paused,
			Dead,
		};

		static Thread*								CreateAndStart(ThreadProcedure procedure, LPCTSTR thread_name = NULL, void* argument = NULL, BOOL autoDestroy = true);
		static void									Sleep(int ms);
		static int									GetCPUCount();
		static int									GetCurrentThreadId();

		BOOL										Start();
		BOOL										Pause();
		BOOL										Resume();
		BOOL										Stop();
		ThreadState									GetState() const;
		void										SetCPU(int index);

	protected:
		virtual void								Run() = 0;

	private:
		friend void									InternalThreadProc(Thread* thread);

		Internal::ThreadData*						_internalData;
		volatile ThreadState						_threadState;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Class: cc::Threading::CriticalSection - �ٽ�������
	//
	class CL_API CriticalSection : public NotCopyable
	{
		friend class ConditionVariable;
	public:
		CriticalSection();
		~CriticalSection();

		BOOL										TryEnter(); // ע�⣡ʹ�ô˺�����Ҫ����Leave()
		void										Enter();
		void										Leave();

		class Scope : public NotCopyable
		{
		public:
			Scope(CriticalSection& criticalSection);
			~Scope();

		private:
			CriticalSection*						_criticalSection;
		};

	private:
		Internal::CriticalSectionData*				_internalData;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Class: cc::Threading::Event - �¼�����
	//
	class CL_API Event : public WaitableObject
	{
	public:
		Event();
		~Event();

		BOOL										CreateAutoUnsignal(BOOL signaled, LPCTSTR name);
		BOOL										CreateManualUnsignal(BOOL signaled, LPCTSTR name);
		BOOL										Open(BOOL inheritable, LPCTSTR name);

		BOOL										Signal();
		BOOL										Unsignal();

	private:
		Internal::EventData*						_internalData;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Class: cc::Threading::WaitableObject - �ɵȴ�����
	//
	class CL_API Mutex : public WaitableObject
	{
	public:
		Mutex();
		~Mutex();

		BOOL										Create(BOOL owned, LPCTSTR name);
		BOOL										Open(BOOL inheritable, LPCTSTR name);

		BOOL										Release();

	private:
		Internal::MutexData*						_internalData;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Class: cc::Threading::Semaphore - �ź�������
	//
	class CL_API Semaphore : public WaitableObject
	{
	public:
		Semaphore();
		~Semaphore();

		BOOL										Create(int initialCount, int maxCount, LPCTSTR name);
		BOOL										Open(BOOL inheritable, LPCTSTR name);

		BOOL										Release();
		int											Release(int count);

	private:
		Internal::SemaphoreData*					_internalData;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Class: cc::Threading::ThreadPool - �̳߳ض���
	//
	class CL_API ThreadPool : public Object
	{
	private:
		ThreadPool();
		~ThreadPool();

	public:
		static BOOL									Queue(void(*lpfn)(void*), void* argument);
		static BOOL									Queue(const Func<void()>& proc);

		template<typename T>
		static void QueueLambda(const T& lpfn)
		{
			Queue(Func<void()>(lpfn));
		}
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Class: cc::Threading::ReaderWriterLock - ��д������
	//
	class CL_API ReaderWriterLock : public NotCopyable
	{
	public:
		ReaderWriterLock();
		~ReaderWriterLock();

		BOOL										TryEnterReader();  // ע�⣡ʹ�ô˺�����Ҫ����Leave()
		void										EnterReader();
		void										LeaveReader();
		BOOL										TryEnterWriter();  // ע�⣡ʹ�ô˺�����Ҫ����Leave()
		void										EnterWriter();
		void										LeaveWriter();

	public:
		class ReaderScope : public NotCopyable
		{
		public:
			ReaderScope(ReaderWriterLock& lock);
			~ReaderScope();

		private:
			ReaderWriterLock*						_lock;
		};

		class WriterScope : public NotCopyable
		{
		public:
			WriterScope(ReaderWriterLock& lock);
			~WriterScope();

		private:
			ReaderWriterLock*						_lock;
		};

	private:
		friend class ConditionVariable;
		Internal::ReaderWriterLockData*				_internalData;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Class: cc::Threading::ConditionVariable - ״̬����
	//
	class CL_API ConditionVariable : public NotCopyable
	{
	public:
		ConditionVariable();
		~ConditionVariable();

		BOOL										SleepWith(CriticalSection& cs);
		BOOL										SleepWithForTime(CriticalSection& cs, int milliSeconds);
		BOOL										SleepWithReader(ReaderWriterLock& lock);
		BOOL										SleepWithReaderForTime(ReaderWriterLock& lock, int milliSeconds);
		BOOL										SleepWithWriter(ReaderWriterLock& lock);
		BOOL										SleepWithWriterForTime(ReaderWriterLock& lock, int milliSeconds);
		void										WakeOnePending();
		void										WakeAllPendings();

	private:
		Internal::ConditionVariableData*			_internalData;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Class: cc::Threading::SpinLock - ����������
	//
	class CL_API SpinLock : public NotCopyable
	{
	protected:
		typedef long LockedInt;
		volatile LockedInt							_token;
	public:
		SpinLock();
		~SpinLock();

		BOOL										TryEnter();  // ע�⣡ʹ�ô˺�����Ҫ����Leave()
		void										Enter();
		void										Leave();

	public:
		class Scope : public NotCopyable
		{
		private:
			SpinLock*								_spinLock;
		public:
			Scope(SpinLock& spinLock);
			~Scope();
		};
	};
}
CC_END_NAMESPACE

#endif