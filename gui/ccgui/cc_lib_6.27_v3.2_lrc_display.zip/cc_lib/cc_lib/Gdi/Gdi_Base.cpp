#include "StdAfx.h"

#define X_INLINE inline

namespace cc
{
    namespace Gdi
    {
        // XSize
        X_INLINE XSize::XSize()
        { cx = cy = 0; }
        X_INLINE XSize::XSize(int initCX, int initCY)
        { cx = initCX; cy = initCY; }
        X_INLINE XSize::XSize(SIZE initSize)
        { *(SIZE*)this = initSize; }
        X_INLINE XSize::XSize(POINT initPt)
        { *(POINT*)this = initPt; }
        X_INLINE XSize::XSize(DWORD dwSize)
        {
            cx = (short)LOWORD(dwSize);
            cy = (short)HIWORD(dwSize);
        }
        X_INLINE BOOL XSize::operator==(SIZE size) const
        { return (cx == size.cx && cy == size.cy); }
        X_INLINE BOOL XSize::operator!=(SIZE size) const
        { return (cx != size.cx || cy != size.cy); }
        X_INLINE void XSize::operator+=(SIZE size)
        { cx += size.cx; cy += size.cy; }
        X_INLINE void XSize::operator-=(SIZE size)
        { cx -= size.cx; cy -= size.cy; }
        X_INLINE XSize XSize::operator+(SIZE size) const
        { return XSize(cx + size.cx, cy + size.cy); }
        X_INLINE XSize XSize::operator-(SIZE size) const
        { return XSize(cx - size.cx, cy - size.cy); }
        X_INLINE XSize XSize::operator-() const
        { return XSize(-cx, -cy); }
        X_INLINE XPoint XSize::operator+(POINT point) const
        { return XPoint(cx + point.x, cy + point.y); }
        X_INLINE XPoint XSize::operator-(POINT point) const
        { return XPoint(cx - point.x, cy - point.y); }
        X_INLINE XRect XSize::operator+(const RECT* lpRect) const
        { return XRect(lpRect) + *this; }
        X_INLINE XRect XSize::operator-(const RECT* lpRect) const
        { return XRect(lpRect) - *this; }

        XString XSize::ToString()
        {
            return XString::XFormat(_T("Size(%d, %d)"), cx, cy);
        }

        // XPoint
        X_INLINE XPoint::XPoint()
        { x = y = 0; }
        X_INLINE XPoint::XPoint(int initX, int initY)
        { x = initX; y = initY; }
#if !defined(_AFX_CORE_IMPL) || !defined(_AFXDLL) || defined(_DEBUG)
        X_INLINE XPoint::XPoint(POINT initPt)
        { *(POINT*)this = initPt; }
#endif
        X_INLINE XPoint::XPoint(SIZE initSize)
        { *(SIZE*)this = initSize; }
        X_INLINE XPoint::XPoint(DWORD dwPoint)
        {
            x = (short)LOWORD(dwPoint);
            y = (short)HIWORD(dwPoint);
        }
        X_INLINE void XPoint::Offset(int xOffset, int yOffset)
        { x += xOffset; y += yOffset; }
        X_INLINE void XPoint::Offset(POINT point)
        { x += point.x; y += point.y; }
        X_INLINE void XPoint::Offset(SIZE size)
        { x += size.cx; y += size.cy; }
        X_INLINE BOOL XPoint::operator==(POINT point) const
        { return (x == point.x && y == point.y); }
        X_INLINE BOOL XPoint::operator!=(POINT point) const
        { return (x != point.x || y != point.y); }
        X_INLINE void XPoint::operator+=(SIZE size)
        { x += size.cx; y += size.cy; }
        X_INLINE void XPoint::operator-=(SIZE size)
        { x -= size.cx; y -= size.cy; }
        X_INLINE void XPoint::operator+=(POINT point)
        { x += point.x; y += point.y; }
        X_INLINE void XPoint::operator-=(POINT point)
        { x -= point.x; y -= point.y; }
        X_INLINE XPoint XPoint::operator+(SIZE size) const
        { return XPoint(x + size.cx, y + size.cy); }
        X_INLINE XPoint XPoint::operator-(SIZE size) const
        { return XPoint(x - size.cx, y - size.cy); }
        X_INLINE XPoint XPoint::operator-() const
        { return XPoint(-x, -y); }
        X_INLINE XPoint XPoint::operator+(POINT point) const
        { return XPoint(x + point.x, y + point.y); }
        X_INLINE XSize XPoint::operator-(POINT point) const
        { return XSize(x - point.x, y - point.y); }
        X_INLINE XRect XPoint::operator+(const RECT* lpRect) const
        { return XRect(lpRect) + *this; }
        X_INLINE XRect XPoint::operator-(const RECT* lpRect) const
        { return XRect(lpRect) - *this; }

        XString XPoint::ToString()
        {
            return XString::XFormat(_T("Point(%d, %d)"), x, y);
        }

        // XRect
        X_INLINE XRect::XRect()
        { left = top = right = bottom = 0; }
        X_INLINE XRect::XRect(int l, int t, int r, int b)
        { left = l; top = t; right = r; bottom = b; }
        X_INLINE XRect::XRect(const RECT& srXRect)
        { ::CopyRect(this, &srXRect); }
        X_INLINE XRect::XRect(LPCRECT lpSrcRect)
        { ::CopyRect(this, lpSrcRect); }
        X_INLINE XRect::XRect(POINT point, SIZE size)
        { right = (left = point.x) + size.cx; bottom = (top = point.y) + size.cy; }
        X_INLINE XRect::XRect(POINT topLeft, POINT bottomRight)
        { left = topLeft.x; top = topLeft.y;
        right = bottomRight.x; bottom = bottomRight.y; }
        X_INLINE int XRect::Width() const
        { return right - left; }
        X_INLINE int XRect::Height() const
        { return bottom - top; }
        X_INLINE XSize XRect::Size() const
        { return XSize(right - left, bottom - top); }
        X_INLINE XPoint& XRect::TopLeft()
        { return *((XPoint*)this); }
        X_INLINE XPoint& XRect::BottomRight()
        { return *((XPoint*)this+1); }
        X_INLINE const XPoint& XRect::TopLeft() const
        { return *((XPoint*)this); }
        X_INLINE const XPoint& XRect::BottomRight() const
        { return *((XPoint*)this+1); }
        X_INLINE XPoint XRect::CenterPoint() const
        { return XPoint((left+right)/2, (top+bottom)/2); }
        X_INLINE void XRect::SwapLeftRight()
        { SwapLeftRight(LPRECT(this)); }
        X_INLINE void XRect::SwapLeftRight(LPRECT lpRect)
        { LONG temp = lpRect->left; lpRect->left = lpRect->right; lpRect->right = temp; }
        X_INLINE XRect::operator LPRECT()
        { return this; }
        X_INLINE XRect::operator LPCRECT() const
        { return this; }
        X_INLINE BOOL XRect::IsRectEmpty() const
        { return ::IsRectEmpty(this); }
        X_INLINE BOOL XRect::IsRectNull() const
        { return (left == 0 && right == 0 && top == 0 && bottom == 0); }
        X_INLINE BOOL XRect::PtInRect(POINT point) const
        { return ::PtInRect(this, point); }
        X_INLINE void XRect::SetRect(int x1, int y1, int x2, int y2)
        { ::SetRect(this, x1, y1, x2, y2); }
        X_INLINE void XRect::SetRect(POINT topLeft, POINT bottomRight)
        { ::SetRect(this, topLeft.x, topLeft.y, bottomRight.x, bottomRight.y); }
        X_INLINE void XRect::SetRectEmpty()
        { ::SetRectEmpty(this); }
        X_INLINE void XRect::CopyRect(LPCRECT lpSrcRect)
        { ::CopyRect(this, lpSrcRect); }
        X_INLINE BOOL XRect::EqualRect(LPCRECT lpRect) const
        { return ::EqualRect(this, lpRect); }
        X_INLINE void XRect::InflateRect(int x, int y)
        { ::InflateRect(this, x, y); }
        X_INLINE void XRect::InflateRect(SIZE size)
        { ::InflateRect(this, size.cx, size.cy); }
        X_INLINE void XRect::DeflateRect(int x, int y)
        { ::InflateRect(this, -x, -y); }
        X_INLINE void XRect::DeflateRect(SIZE size)
        { ::InflateRect(this, -size.cx, -size.cy); }
        X_INLINE void XRect::OffsetRect(int x, int y)
        { ::OffsetRect(this, x, y); }
        X_INLINE void XRect::OffsetRect(POINT point)
        { ::OffsetRect(this, point.x, point.y); }
        X_INLINE void XRect::OffsetRect(SIZE size)
        { ::OffsetRect(this, size.cx, size.cy); }
        X_INLINE BOOL XRect::IntersectRect(LPCRECT lpRect1, LPCRECT lpRect2)
        { return ::IntersectRect(this, lpRect1, lpRect2);}
        X_INLINE BOOL XRect::UnionRect(LPCRECT lpRect1, LPCRECT lpRect2)
        { return ::UnionRect(this, lpRect1, lpRect2); }
        X_INLINE void XRect::operator=(const RECT& srXRect)
        { ::CopyRect(this, &srXRect); }
        X_INLINE BOOL XRect::operator==(const RECT& rect) const
        { return ::EqualRect(this, &rect); }
        X_INLINE BOOL XRect::operator!=(const RECT& rect) const
        { return !::EqualRect(this, &rect); }
        X_INLINE void XRect::operator+=(POINT point)
        { ::OffsetRect(this, point.x, point.y); }
        X_INLINE void XRect::operator+=(SIZE size)
        { ::OffsetRect(this, size.cx, size.cy); }
        X_INLINE void XRect::operator+=(LPCRECT lpRect)
        { InflateRect(lpRect); }
        X_INLINE void XRect::operator-=(POINT point)
        { ::OffsetRect(this, -point.x, -point.y); }
        X_INLINE void XRect::operator-=(SIZE size)
        { ::OffsetRect(this, -size.cx, -size.cy); }
        X_INLINE void XRect::operator-=(LPCRECT lpRect)
        { DeflateRect(lpRect); }
        X_INLINE void XRect::operator&=(const RECT& rect)
        { ::IntersectRect(this, this, &rect); }
        X_INLINE void XRect::operator|=(const RECT& rect)
        { ::UnionRect(this, this, &rect); }
        X_INLINE XRect XRect::operator+(POINT pt) const
        { XRect rect(*this); ::OffsetRect(&rect, pt.x, pt.y); return rect; }
        X_INLINE XRect XRect::operator-(POINT pt) const
        { XRect rect(*this); ::OffsetRect(&rect, -pt.x, -pt.y); return rect; }
        X_INLINE XRect XRect::operator+(SIZE size) const
        { XRect rect(*this); ::OffsetRect(&rect, size.cx, size.cy); return rect; }
        X_INLINE XRect XRect::operator-(SIZE size) const
        { XRect rect(*this); ::OffsetRect(&rect, -size.cx, -size.cy); return rect; }
        X_INLINE XRect XRect::operator+(LPCRECT lpRect) const
        { XRect rect(this); rect.InflateRect(lpRect); return rect; }
        X_INLINE XRect XRect::operator-(LPCRECT lpRect) const
        { XRect rect(this); rect.DeflateRect(lpRect); return rect; }
        X_INLINE XRect XRect::operator&(const RECT& rect2) const
        { XRect rect; ::IntersectRect(&rect, this, &rect2);
        return rect; }
        X_INLINE XRect XRect::operator|(const RECT& rect2) const
        { XRect rect; ::UnionRect(&rect, this, &rect2);
        return rect; }
        X_INLINE BOOL XRect::SubtractRect(LPCRECT lpRectSrc1, LPCRECT lpRectSrc2)
        { return ::SubtractRect(this, lpRectSrc1, lpRectSrc2); }

        void XRect::InflateRect(LPCRECT lpRect)
        {
            left -= lpRect->left;
            top -= lpRect->top;
            right += lpRect->right;
            bottom += lpRect->bottom;
        }

        void XRect::DeflateRect(LPCRECT lpRect)
        {
            left += lpRect->left;
            top += lpRect->top;
            right -= lpRect->right;
            bottom -= lpRect->bottom;
        }

        void XRect::InsetRect( const RECT& srcRect )
        {
            left += srcRect.left;
            top += srcRect.top;
            right -= srcRect.right;
            bottom -= srcRect.bottom;
        }

        BOOL XRect::RestrictRect( const RECT& srcRect )
        {
            XSize offset;

            UINT bFitness = 0;

            if (left < srcRect.left) {
                offset.cx = srcRect.left - left;
            } else if (right > srcRect.right) {
                offset.cx = srcRect.right - right;
            } else {
                bFitness |= 0x000F;
            }

            if (top < srcRect.top) {
                offset.cy = srcRect.top - top;
            } else if (bottom > srcRect.bottom) {
                offset.cy = srcRect.bottom - bottom;
            } else {
                bFitness |= 0x00F0;
            }

            OffsetRect(offset);

            return bFitness == 0x00FF ? TRUE : FALSE;
        }

        XString XRect::ToString()
        {
            return XString::XFormat(_T("Rect(%d, %d, %d, %d)"), left, top, right, bottom);
        }
    }
}
