#include "StdAfx.h"

GDI_BEGIN_NAMESPACE
XAnimTask::XAnimTask( const XAnimTask& ani )
{
    *this = ani;
}

XAnimTask::XAnimTask( XTAnim AnimType, DWORD dwStartTick, DWORD dwDuration, COLORREF clrBack,
    COLORREF clrKey, XRect rcFrom, int xtrans, int ytrans, int ztrans, int alpha, float zrot /*= 0.0f*/, bool bLinear /*= FALSE*/ )
{
    this->AnimType         = AnimType;          // ��������
    this->dwStartTick      = dwStartTick;       // ��ʼʱ�䣨�ӳ���������ʼ��
    this->dwDuration       = dwDuration;        // ��Ⱦʱ��
    this->iBufferStart     = 0;
    this->iBufferEnd       = 0;
    plot.clrBack           = clrBack;           // �任��ı�����ɫ����֧��ALPHA
    plot.clrKey            = clrKey;
    plot.rcFrom            = rcFrom;            // �任��ԭ����
    plot.mFrom.xtrans      = xtrans;            // ˮƽλ�ƣ���:(+X, 0) ==> (0, 0); ��:(-X, 0) ==> (0, 0)��
    plot.mFrom.ytrans      = ytrans;            // ��ֱλ�ƣ���:(+Y, 0) ==> (0, 0); ��:(-Y, 0) ==> (0, 0)��
    plot.mFrom.ztrans      = ztrans;            // ���ţ���:�Ӵ�С; ��:��С����
    plot.mFrom.alpha       = alpha;             // ALPHAͨ���� -255 ~ 255 �����䵭���������
    plot.mFrom.zrot        = zrot;              // ��ת�Ƕȣ� ��λΪ���ȣ���������ʱ��
    plot.iInterpolate      = bLinear ? INTERPOLATE_LINEAR : INTERPOLATE_COS;
}

XAnimation::XAnimation():
    m_hwnd(NULL),
    m_bIsAnimating(false),
    m_bIsInitialized(false),
    m_pD3D(NULL),
    m_p3DDevice(NULL),
    m_p3DBackSurface(NULL),
    m_nBuffers(0)
{
    ::ZeroMemory(m_p3DVertices, sizeof(m_p3DVertices));
    ::ZeroMemory(m_p3DTextures, sizeof(m_p3DTextures));
}

XAnimation::~XAnimation()
{
    Terminate();
}

bool XAnimation::Init( HWND hwnd )
{
    ASSERT(::IsWindow(hwnd));
    if( m_bIsInitialized ) return true;

    m_hwnd = hwnd;

    XRect rcWindow;
    ::GetWindowRect(hwnd, &rcWindow);
    if( rcWindow.IsRectEmpty() ) return false;

    HWND hWndFocus = hwnd;
    while( ::GetParent(hWndFocus) != NULL ) hWndFocus = ::GetParent(hWndFocus);

    HMODULE hMod = ::LoadLibrary(_T("D3D9.DLL"));
    if( hMod == NULL ) return false;
    ::FreeLibrary(hMod);
    hMod = NULL;

    if( m_pD3D != NULL ) m_pD3D->Release();
    m_pD3D = ::Direct3DCreate9(D3D_SDK_VERSION);
    if( m_pD3D == NULL ) return false;
    HRESULT hr;
    D3DDISPLAYMODE d3ddm = { 0 };
    hr = m_pD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &d3ddm);
    if( FAILED(hr) ) return false;
    m_ColorFormat = d3ddm.Format;
    hr = m_pD3D->CheckDeviceType(D3DADAPTER_DEFAULT,
        D3DDEVTYPE_HAL,
        m_ColorFormat,
        m_ColorFormat,
        TRUE);
    if( FAILED(hr) ) return false;
    D3DPRESENT_PARAMETERS d3dpp = { 0 };
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;; //D3DSWAPEFFECT_FLIP
    d3dpp.Windowed = TRUE;
    d3dpp.hDeviceWindow = hwnd;
    d3dpp.BackBufferCount = 1;
    d3dpp.BackBufferFormat = m_ColorFormat;
    d3dpp.EnableAutoDepthStencil = FALSE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
    d3dpp.PresentationInterval   = D3DPRESENT_INTERVAL_IMMEDIATE;
    hr = m_pD3D->CreateDevice(D3DADAPTER_DEFAULT,
        D3DDEVTYPE_HAL,
        hWndFocus,
        D3DCREATE_SOFTWARE_VERTEXPROCESSING,
        &d3dpp,
        &m_p3DDevice);
    if( FAILED(hr) ) return false;       

    D3DCAPS9 caps;
    hr = m_p3DDevice->GetDeviceCaps(&caps);
    if( caps.MaxTextureWidth < 128 ) return false;
    if( (caps.Caps3 & D3DCAPS3_COPY_TO_VIDMEM) == 0 ) return false;
    if( FAILED(hr) ) return false;

    D3DVIEWPORT9 vp;
    vp.X = vp.Y = 0;
    vp.Width = rcWindow.Width();
    vp.Height = rcWindow.Height();
    vp.MinZ = 0.0;
    vp.MaxZ = 1.0;
    hr = m_p3DDevice->SetViewport(&vp);
    if( FAILED(hr) ) return false;

    m_p3DDevice->SetRenderState(D3DRS_COLORVERTEX, TRUE);
    m_p3DDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    m_p3DDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
    m_p3DDevice->SetRenderState(D3DRS_ZENABLE, TRUE);
    m_p3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    m_p3DDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    m_p3DDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    m_p3DDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
    m_p3DDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    m_p3DDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
    m_p3DDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
    m_p3DDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
    m_p3DDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
    m_p3DDevice->SetVertexShader(NULL);

    m_bIsInitialized = true;
    return true;
}

bool XAnimation::PrepareAnimation( HWND hwnd )
{
    if( !m_bIsInitialized ) return false;

    if( m_p3DBackSurface != NULL ) m_p3DBackSurface->Release();
    m_p3DBackSurface= NULL;

    XRect rcClient;
    ::GetClientRect(m_hwnd, &rcClient);
    int cx = rcClient.Width();
    int cy = rcClient.Height();
    HRESULT hr = m_p3DDevice->CreateOffscreenPlainSurface(cx, cy, m_ColorFormat, D3DPOOL_SYSTEMMEM, &m_p3DBackSurface, NULL);
    if( FAILED(hr) ) return false;

    HDC hDC = NULL;
    hr = m_p3DBackSurface->GetDC(&hDC);
    if( FAILED(hr) ) return false;
    ::SendMessage(hwnd, WM_PRINTCLIENT, (WPARAM) hDC, PRF_CHECKVISIBLE | PRF_CLIENT | PRF_ERASEBKGND | PRF_CHILDREN);
    m_p3DBackSurface->ReleaseDC(hDC);

    for( int i = 0; i < m_aTasks.GetSize(); i++ )
    {
        XAnimTask* pTask = m_aTasks[i];
        switch( pTask->AnimType )
        {
        case XANIMTYPE_FLAT:
            if( !PrepareTask_Flat(pTask) ) return false;
            break;
        }
    }

    DWORD dwTick = ::timeGetTime();
    for( int j = 0; j < m_aTasks.GetSize(); j++ )
    {
        XAnimTask* pTask = m_aTasks[j];
        pTask->dwStartTick += dwTick;
    }
    m_bIsAnimating = true;
    return true;
}

void XAnimation::CancelTasks()
{
    Terminate();
}

bool XAnimation::Render()
{
    if( !m_bIsAnimating ) return false;
    if( !m_bIsInitialized ) return false;

    HRESULT hr;
    LPDIRECT3DSURFACE9 p3DTargetSurface;
    hr = m_p3DDevice->GetRenderTarget(0, &p3DTargetSurface);
    if( FAILED(hr) ) return false;
    XRelease<IDirect3DSurface9> RefTargetSurface(p3DTargetSurface);
    
    hr = m_p3DDevice->Clear(0, NULL, D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0, 0, 255), 1.0f, 0L);
    hr = m_p3DDevice->UpdateSurface(m_p3DBackSurface, NULL, p3DTargetSurface, NULL);

    hr = m_p3DDevice->BeginScene();
    if( FAILED(hr) ) return false;
    int nAnimated = 0;
    DWORD dwTick = ::timeGetTime();
    for( int i = 0; i < m_aTasks.GetSize(); i++ )
    {
        const XAnimTask* pTask = m_aTasks[i];
        if( dwTick < pTask->dwStartTick ) continue;
        DWORD dwTickNow = __min(dwTick, pTask->dwStartTick + pTask->dwDuration);
        switch( pTask->AnimType )
        {
        case XANIMTYPE_FLAT:
            RenderTask_Flat(pTask, p3DTargetSurface, dwTickNow);
            break;
        }
        if( dwTick < pTask->dwStartTick + pTask->dwDuration ) nAnimated++;
    }
    hr = m_p3DDevice->EndScene();
    hr = m_p3DDevice->Present(NULL, NULL, NULL, NULL);

    if( nAnimated == 0 ) Terminate();
    return true;
}

bool XAnimation::IsAnimating() const
{
    return m_bIsAnimating;
}

bool XAnimation::IsTaskScheduled() const
{
    return m_aTasks.GetSize() > 0 && !m_bIsAnimating;
}

int XAnimation::AddTask( const XAnimTask* pTask )
{
    return m_aTasks.Add((XAnimTask*)pTask);
}

void XAnimation::Terminate()
{
    for( int i = 0; i < m_aTasks.GetSize(); i++ ) delete m_aTasks[i];
    m_aTasks.Clear();

    for( int i = 0; i < m_nBuffers; i++ ) {
        m_p3DVertices[i]->Release();
        m_p3DTextures[i]->Release();
    }
    m_nBuffers = 0;

    if( m_p3DBackSurface != NULL ) m_p3DBackSurface->Release();
    m_p3DBackSurface = NULL;
    if( m_p3DDevice != NULL ) m_p3DDevice->Release();
    m_p3DDevice = NULL;
    if( m_pD3D != NULL ) m_pD3D->Release();
    m_pD3D = NULL;

    m_bIsAnimating = false;
    m_bIsInitialized = false;
}

COLORREF XAnimation::TranslateColor( LPDIRECT3DSURFACE9 pSurface, COLORREF clr ) const
{
    ASSERT(pSurface != NULL);
    if( clr == CLR_INVALID ) return clr;

    HDC hDC = NULL;
    HRESULT hr = pSurface->GetDC(&hDC);
    if( FAILED(hr) ) return false;
    COLORREF clrOld = ::GetPixel(hDC, 0, 0);
    ::SetPixel(hDC, 0, 0, clr);
    clr = ::GetPixel(hDC, 0,0);
    ::SetPixel(hDC, 0, 0, clrOld);
    pSurface->ReleaseDC(hDC);
    return clr;
}

bool XAnimation::SetColorKey( LPDIRECT3DTEXTURE9 pTexture, LPDIRECT3DSURFACE9 pSurface, int iTexSize, COLORREF clrColorKey )
{
    ASSERT(pTexture != NULL);
    ASSERT(pSurface != NULL);

    if( clrColorKey == CLR_INVALID ) return true;

    DWORD r = GetRValue(clrColorKey);
    DWORD g = GetGValue(clrColorKey);
    DWORD b = GetBValue(clrColorKey);
    DWORD dwColorKey = D3DCOLOR_ARGB(255,r,g,b);

    HRESULT Hr;
    LPDIRECT3DTEXTURE9 pTex = NULL;
    Hr = m_p3DDevice->CreateTexture(iTexSize, iTexSize, 1, D3DUSAGE_DYNAMIC, D3DFMT_A8R8G8B8, D3DPOOL_SYSTEMMEM, &pTex, NULL);
    if( FAILED(Hr) ) return false;
    XRelease<IDirect3DTexture9> RefTex(pTexture);
    LPDIRECT3DSURFACE9 pTexSurf = NULL;
    Hr = pTex->GetSurfaceLevel(0, &pTexSurf);
    if( FAILED(Hr) ) return false;
    XRelease<IDirect3DSurface9> RefTexSurf(pTexSurf);
    Hr = m_p3DDevice->GetRenderTargetData(pSurface, pTexSurf);
    if( FAILED(Hr) ) return false;

    D3DLOCKED_RECT d3dlr;
    Hr = pTex->LockRect(0, &d3dlr, 0, 0);
    if( FAILED(Hr) ) return false;
    DWORD* pBits = static_cast<DWORD*>(d3dlr.pBits);
    for( int y = 0; y < iTexSize; y++ )
    {
        for( int x = 0; x < iTexSize; x++ )
        {
            if( pBits[x] == dwColorKey ) pBits[x] = D3DCOLOR_RGBA(0, 0, 0, 0);
            else pBits[x] |= D3DCOLOR_RGBA(0, 0, 0, 0xff);
        }
        pBits += d3dlr.Pitch / sizeof(DWORD);
    }
    pTex->UnlockRect(0);

    POINT pt = { 0, 0 };
    RECT rcDest = { 0, 0, iTexSize, iTexSize };
    Hr = m_p3DDevice->UpdateSurface(pTexSurf, &rcDest, pSurface, &pt);

    return true;
}

bool XAnimation::PrepareTask_Flat( XAnimTask* pTask )
{
    pTask->plot.clrKey = TranslateColor(m_p3DBackSurface, pTask->plot.clrKey);

    HRESULT hr;
    RECT rc = pTask->plot.rcFrom;
    int cx = rc.right - rc.left;
    int cy = rc.bottom - rc.left;
    FLOAT z = 0.1f;
    FLOAT rhw = 1.0f / (z * 990.0f + 10.0f);
    D3DCOLOR col = D3DCOLOR_RGBA(255, 255, 255, 255);

    int iTexSize = 128;
    if( cx < 64 ) iTexSize = 64;
    if( cx < 32 ) iTexSize = 32;
    FLOAT fTexSize = (FLOAT) iTexSize;

    pTask->iBufferStart = m_nBuffers;
    for( int x = rc.left; x < rc.right; x += iTexSize )
    {
        for( int y = rc.top; y < rc.bottom; y += iTexSize )
        {
            RECT rcTile = { x, y, __min(rc.right, x + iTexSize), __min(rc.bottom, y + iTexSize) };

            FLOAT tcoordx = (iTexSize - (x + fTexSize - rc.right)) / fTexSize;
            FLOAT tcoordy = (iTexSize - (y + fTexSize - rc.bottom)) / fTexSize;
            if( tcoordx > 1.0f ) tcoordx = 1.0f;
            if( tcoordy > 1.0f ) tcoordy = 1.0f;

            CUSTOMFAN verts = 
            {
                { rcTile.left - 0.5f,  rcTile.top - 0.5f,    z, rhw, col, 0.0f,     0.0f },
                { rcTile.right - 0.5f, rcTile.top - 0.5f,    z, rhw, col, tcoordx,  0.0f },
                { rcTile.right - 0.5f, rcTile.bottom - 0.5f, z, rhw, col, tcoordx,  tcoordy },
                { rcTile.left - 0.5f,  rcTile.bottom - 0.5f, z, rhw, col, 0.0f,     tcoordy }
            };
            LPDIRECT3DVERTEXBUFFER9 pVertex = NULL;
            hr = m_p3DDevice->CreateVertexBuffer(4 * sizeof(CUSTOMVERTEX),
                D3DUSAGE_WRITEONLY, D3DFVF_CUSTOMVERTEX, D3DPOOL_DEFAULT, &pVertex, NULL);
            if( FAILED(hr) ) return false;
            XRelease<IDirect3DVertexBuffer9> RefVertex(pVertex);
            memcpy_s(m_fans[m_nBuffers], sizeof(verts), verts, sizeof(verts));

            LPDIRECT3DTEXTURE9 pTex1 = NULL;
            hr = m_p3DDevice->CreateTexture(iTexSize, iTexSize, 1, 0, m_ColorFormat, D3DPOOL_DEFAULT, &pTex1, NULL);
            if( FAILED(hr) ) return false;
            XRelease<IDirect3DTexture9> RefTex1(pTex1);
            LPDIRECT3DSURFACE9 pTexSurf1 = NULL;
            hr = pTex1->GetSurfaceLevel(0, &pTexSurf1);
            if( FAILED(hr) ) return false;
            XRelease<IDirect3DSurface9> RefTexSurf1(pTexSurf1);
            POINT pt = { 0, 0 };
            hr = m_p3DDevice->UpdateSurface(m_p3DBackSurface, &rcTile, pTexSurf1, &pt);
            if( FAILED(hr) ) return false;
            LPDIRECT3DTEXTURE9 pTex2 = NULL;
            RECT rcDest = { 0, 0, rcTile.right - rcTile.left, rcTile.bottom - rcTile.top };
            hr = m_p3DDevice->CreateTexture(iTexSize, iTexSize, 1, D3DUSAGE_RENDERTARGET,
                D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &pTex2, NULL);
            if( FAILED(hr) ) return false;
            XRelease<IDirect3DTexture9> RefTex2(pTex2);
            LPDIRECT3DSURFACE9 pTexSurf2 = NULL;
            hr = pTex2->GetSurfaceLevel(0, &pTexSurf2);
            if( FAILED(hr) ) return false;
            XRelease<IDirect3DSurface9> RefTexSurf2(pTexSurf2);
            hr = m_p3DDevice->StretchRect(pTexSurf1, &rcDest, pTexSurf2, &rcDest, D3DTEXF_NONE);
            if( FAILED(hr) ) return false;

            SetColorKey(pTex2, pTexSurf2, iTexSize, pTask->plot.clrKey);

            m_p3DTextures[m_nBuffers] = RefTex2.Detach();
            m_p3DVertices[m_nBuffers] = RefVertex.Detach();
            m_nBuffers++;
        }
    }

    pTask->iBufferEnd = m_nBuffers;
    ASSERT(m_nBuffers < MAX_BUFFERS);

    COLORREF clrBack = pTask->plot.clrBack;
    if( clrBack != CLR_INVALID)
    {
        HDC hDC = NULL;
        hr = m_p3DBackSurface->GetDC(&hDC);
        if( FAILED(hr) ) return false;
        HBRUSH hBrush = ::CreateSolidBrush(clrBack);
        ::FillRect(hDC, &rc, hBrush);
        ::DeleteObject(hBrush);
        m_p3DBackSurface->ReleaseDC(hDC);
    }
    return true;
}

bool XAnimation::RenderTask_Flat( const XAnimTask* pTask, LPDIRECT3DSURFACE9 pSurface, DWORD dwTick )
{
    RECT rc = pTask->plot.rcFrom;
    FLOAT mu = (FLOAT)(pTask->dwStartTick + pTask->dwDuration - dwTick) / (FLOAT) pTask->dwDuration;
    FLOAT scale1 = 0.0;
    if( pTask->plot.iInterpolate == XAnimTask::INTERPOLATE_LINEAR )
        scale1 = (FLOAT) LinearInterpolate(0.0, 1.0, mu);
    if( pTask->plot.iInterpolate == XAnimTask::INTERPOLATE_COS )
        scale1 = (FLOAT) CosineInterpolate(0.0, 1.0, mu);
    FLOAT scale2 = 1.0f - scale1;
    D3DVECTOR ptCenter = { rc.left + ((rc.right - rc.left) / 2.0f), rc.top + ((rc.bottom - rc.top) / 2.0f) };
    FLOAT xtrans = (FLOAT) pTask->plot.mFrom.xtrans * scale1;
    FLOAT ytrans = (FLOAT) pTask->plot.mFrom.ytrans * scale1;
    FLOAT ztrans = 1.0f + ((FLOAT) abs(pTask->plot.mFrom.ztrans) * (pTask->plot.mFrom.ztrans >= 0.0 ? scale1 : scale2));
    FLOAT fSin = (FLOAT) sin(pTask->plot.mFrom.zrot * scale1);
    FLOAT fCos = (FLOAT) cos(pTask->plot.mFrom.zrot * scale1);
    DWORD clrAlpha = ((DWORD)(0xFF - (FLOAT) abs(pTask->plot.mFrom.alpha) * (pTask->plot.mFrom.alpha >= 0 ? scale1 : scale2)) << 24) | D3DCOLOR_RGBA(255, 255, 255, 0);
    HRESULT hr = 0;
    for( int iBuffer = pTask->iBufferStart; iBuffer < pTask->iBufferEnd; iBuffer++ )
    {
        LPDIRECT3DVERTEXBUFFER9 pVBuffer = m_p3DVertices[iBuffer];
        LPVOID pVertices = NULL;
        hr = pVBuffer->Lock(0, sizeof(CUSTOMFAN), &pVertices, 0);
        if( FAILED(hr) ) return false;
        CUSTOMFAN verts;
        memcpy(verts, m_fans[iBuffer], sizeof(CUSTOMFAN));
        for( int i = 0; i < sizeof(CUSTOMFAN) / sizeof(CUSTOMVERTEX); i++ )
        {
            verts[i].x -= ptCenter.x;
            verts[i].y -= ptCenter.y;
            verts[i].x += xtrans;                         // ƽ��
            verts[i].y += ytrans;
            verts[i].x = verts[i].x * ztrans;             // ����
            verts[i].y = verts[i].y * ztrans;
            FLOAT x = verts[i].x; FLOAT y = verts[i].y;   // ��ת
            verts[i].x = x * fCos - y * fSin;
            verts[i].y = x * fSin + y * fCos;
            verts[i].x += ptCenter.x;
            verts[i].y += ptCenter.y;
            verts[i].color = clrAlpha;
        }
        memcpy_s(pVertices, sizeof(CUSTOMFAN), verts, sizeof(CUSTOMFAN));
        pVBuffer->Unlock();

        hr = m_p3DDevice->SetStreamSource(0, pVBuffer, 0, sizeof(CUSTOMVERTEX));
        hr = m_p3DDevice->SetFVF(D3DFVF_CUSTOMVERTEX);
        hr = m_p3DDevice->SetTexture(0, m_p3DTextures[iBuffer]);
        hr = m_p3DDevice->DrawPrimitive(D3DPT_TRIANGLEFAN, 0, 2);
    }
    return true;
}

inline double XAnimation::LinearInterpolate( double y1, double y2, double mu )
{
    return y1 * (1.0 - mu) + y2 * mu;
}

inline double XAnimation::CosineInterpolate( double y1, double y2, double mu )
{
    double mu2 = (1.0 - cos(mu * D3D_PI)) / 2.0;
    return y1 * (1.0 - mu2) + y2 * mu2;
}
GDI_END_NAMESPACE