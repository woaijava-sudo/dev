#ifndef _CC_GDI_INCLUDE_H
#define _CC_GDI_INCLUDE_H

#pragma once

#define GDI_BEGIN_NAMESPACE namespace cc { namespace Gdi {
#define GDI_END_NAMESPACE } }
#include "Gdi_Base.h"

#endif