#ifndef _CC_UI_ANIMATION_H
#define _CC_UI_ANIMATION_H

#pragma once

#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1 )

#ifndef D3D_PI
#ifdef _X64
#define D3D_PI (3.1415926535897932384626433832795029L)
#else
#define D3D_PI (3.1415926f)
#endif
#endif

GDI_BEGIN_NAMESPACE

using namespace UI;
enum XTAnim
{
    XANIMTYPE_FLAT,
    XANIMTYPE_SWIPE,
};

class CL_API XAnimTask
{
public:
    enum INTERPOLATETYPE
    {
        INTERPOLATE_LINEAR,
        INTERPOLATE_COS,
    };

    struct PLOTMATRIX
    {
        int xtrans;
        int ytrans;
        int ztrans;
        int alpha;
        float zrot;
    };

public:
    XAnimTask( const XAnimTask& ani );
    explicit XAnimTask( XTAnim AnimType, DWORD dwStartTick, DWORD dwDuration,
        COLORREF clrBack, COLORREF clrKey, XRect rcFrom, int xtrans, int ytrans,
        int ztrans, int alpha, float zrot = 0.0f, bool bLinear = FALSE);

public:
    XTAnim          AnimType;
    DWORD           dwStartTick;
    DWORD           dwDuration;
    int             iBufferStart;
    int             iBufferEnd;

    struct
    {
        COLORREF            clrBack;
        COLORREF            clrKey;
        XRect               rcFrom;
        PLOTMATRIX          mFrom;
        INTERPOLATETYPE     iInterpolate;
    } plot;
};

DEF_LIST_TEMPLATE1(XAnimTask*);
class CL_API XAnimation
{
public:
    enum { MAX_BUFFERS = 40 };

public:
    XAnimation();
    ~XAnimation();

    bool Init( HWND hwnd );
    bool PrepareAnimation( HWND hwnd );
    void CancelTasks();
    bool Render();

    bool IsAnimating() const;
    bool IsTaskScheduled() const;
    int  AddTask( const XAnimTask* pTask );

protected:
    void Terminate();

    COLORREF TranslateColor( LPDIRECT3DSURFACE9 pSurface, COLORREF clr ) const;
    bool SetColorKey( LPDIRECT3DTEXTURE9 pTexture, LPDIRECT3DSURFACE9 pSurface, int iTexSize, COLORREF clrColorKey );

    bool PrepareTask_Flat( XAnimTask* pTask );
    bool RenderTask_Flat( const XAnimTask* pTask, LPDIRECT3DSURFACE9 pSurface, DWORD dwTick );

public:
    static inline double LinearInterpolate( double y1, double y2, double mu );
    static inline double CosineInterpolate( double y1, double y2, double mu );

protected:
    struct CUSTOMVERTEX 
    {
        FLOAT x, y, z;
        FLOAT rhw;
        DWORD color;
        FLOAT tu, tv;
    };
    typedef CUSTOMVERTEX CUSTOMFAN[4];

    HWND                        m_hwnd;
    int                         m_nBuffers;
    bool                        m_bIsAnimating;
    bool                        m_bIsInitialized;
    List<XAnimTask*>            m_aTasks;
    D3DFORMAT                   m_ColorFormat;
    LPDIRECT3D9                 m_pD3D;
    LPDIRECT3DDEVICE9           m_p3DDevice;
    LPDIRECT3DSURFACE9          m_p3DBackSurface;
    LPDIRECT3DVERTEXBUFFER9     m_p3DVertices[MAX_BUFFERS];
    LPDIRECT3DTEXTURE9          m_p3DTextures[MAX_BUFFERS];
    CUSTOMFAN                   m_fans[MAX_BUFFERS];
};

GDI_END_NAMESPACE
#endif