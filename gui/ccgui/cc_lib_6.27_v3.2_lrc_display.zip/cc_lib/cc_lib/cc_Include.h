/***********************************************************************

            |-----------------------------------|
            |                                   |
            |    Project:      >>>    cc_lib    |
            |    Developer:    >>>    bajdcc    |
            |                                   |
            |-----------------------------------|

***********************************************************************/

#ifndef _CC_INCLUDE_H
#define _CC_INCLUDE_H

#ifndef CL_API
#ifdef CC_LIB_EXPORTS
#define CL_API __declspec(dllexport)
#define CLT_API __declspec(dllexport)
#else
#define CL_API __declspec(dllimport)
#define CLT_API __declspec(dllimport)
#endif
#endif

#include <windows.h>
#include <stdlib.h>
#include <crtdbg.h>
#include <tchar.h>
#include <limits.h>
#include <time.h>
#include <intrin.h>
#include <OleCtl.h>
#include <CommCtrl.h>
#include <MMSystem.h>
#include <d3d9.h>
#include <d3d9types.h>
#include <strsafe.h>
#include <math.h>

//////////////////////////////////////////////////////////////////////////

// Namespace
#define CC_BEGIN_NAMESPACE namespace cc {
#define CC_END_NAMESPACE }
#define COLLECTIONS_BEGIN_NAMESPACE namespace cc { namespace Collections {
#define COLLECTIONS_END_NAMESPACE } }
#define REGEX_BEGIN_NAMESPACE namespace cc { namespace Regex {
#define REGEX_END_NAMESPACE } }

// base
#include "core/cc_Debug.h"
#include "core/cc_Base.h"
#include "core/cc_Time.h"
#include "core/cc_Ptr.h"
#include "core/cc_Macro.h"
#include "core/cc_Function.h"
#include "core/cc_Lazy.h"
#include "core/cc_String.h"
#include "core/cc_Thread.h"
#include "core/cc_Exception.h"
#include "core/cc_Stream.h"

// collections
#include "collections/cc_Pair.h"
#include "collections/cc_Interface.h"
#include "collections/cc_ListWrap.h"
#include "collections/cc_List.h"
#include "collections/cc_DictionaryWrap.h"
#include "collections/cc_Dictionary.h"
#include "collections/cc_Enumerator.h"
#include "collections/cc_Tree.h"

#define DEF_AUTO_PTR(T) \
	template class CLT_API AutoPtr<T>;

#define DEF_SORT_LIST2(T,K) \
	template class CLT_API CollectionWrapper<SortedList<T,K>,T,K>; \
	template class CLT_API SortedList<T,K>; \

#define DEF_SORT_LIST1(T) \
	DEF_SORT_LIST2(T,T);

#define DEF_LIST_TEMPLATE2(T,K) \
	template class CLT_API Wrap::ListWrapper<List<T,K>,T,K>; \
	template class CLT_API List<T,K>; 

#define DEF_LIST_TEMPLATE1(T) \
	DEF_LIST_TEMPLATE2(T,typename Type<T>::_Type);

#define DEF_ARRAY_TEMPLATE2(T,K) \
	template class CLT_API ArrayWrapper<Array<T,K>,T,K>; \
	template class CLT_API Array<T,K>;

#define DEF_ARRAY_TEMPLATE1(T) \
	DEF_ARRAY_TEMPLATE2(T,typename Type<T>::_Type);

#define DEF_DICT_TEMPLATE4(KT,VT,KK,VK) \
	template class CLT_API CollectionWrapper<SortedList<KT,KK>,KT,KK>; \
	template class CLT_API SortedList<KT,KK>; \
	template class CLT_API ListWrapper<List<VT,VK>,VT,VK>; \
	template class CLT_API List<VT,VK>; \
	template class CLT_API DictionaryWrapper<Dictionary<KT,VT,KK,VK>,KT,VT,KK,VK>; \
	template class CLT_API Dictionary<KT,VT,KK,VK>;

#define DEF_DICT_TEMPLATE3(KT,VT,KK) \
	DEF_DICT_TEMPLATE4(KT,VT,KK,typename Type<VT>::_Type);

#define DEF_DICT_TEMPLATE2(KT,VT) \
	DEF_DICT_TEMPLATE3(KT,VT,typename Type<KT>::_Type);

#define DEF_GROUP_TEMPLATE4(KT,VT,KK,VK) \
	template class CLT_API CollectionWrapper<SortedList<KT,KK>,KT,KK>; \
	template class CLT_API SortedList<KT,KK>; \
	template class CLT_API ListWrapper<List<VT,VK>,VT,VK>; \
	template class CLT_API List<VT,VK>; \
	template class CLT_API Wrap::ListWrapper<List<List<VT,VK>*,List<VT,VK>*>,List<VT,VK>*,List<VT,VK>*>; \
	template class CLT_API List<List<VT,VK>*,List<VT,VK>*>; \
	template class CLT_API GroupWrapper<Group<KT,VT,KK,VK>,KT,VT,KK,VK>; \
	template class CLT_API Group<KT,VT,KK,VK>;

#define DEF_GROUP_TEMPLATE3(KT,VT,KK) \
	DEF_GROUP_TEMPLATE4(KT,VT,KK,typename Type<VT>::_Type);

#define DEF_GROUP_TEMPLATE2(KT,VT) \
	DEF_GROUP_TEMPLATE3(KT,VT,typename Type<KT>::_Type);

#define DEF_AUTO_PTR(T) \
	template class CLT_API AutoPtr<T>;

// regex
#include "regex/cc_Regex.h"
#include "regex/cc_RegexData.h"
#include "regex/cc_RegexAutomaton.h"
#include "regex/cc_RegexExpression.h"
#include "regex/cc_RegexPure.h"
#include "regex/cc_RegexRich.h"
#include "regex/cc_RegexWriter.h"

// Gdi
#include "Gdi/Include.h"

// UI
#include "UI/Include.h"

#endif