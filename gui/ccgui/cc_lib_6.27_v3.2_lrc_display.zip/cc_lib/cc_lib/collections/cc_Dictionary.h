/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../collections/cc_Dictionary.h

Class:
	Dictionary									��ӳ��
	Group										������ӳ��

***********************************************************************/

#ifndef _CC_COLLECTIONS_DICTIONARY_H
#define _CC_COLLECTIONS_DICTIONARY_H

#include "../core/cc_Base.h"
#include "cc_Interface.h"
#include "cc_List.h"
#include "cc_DictionaryWrap.h"

COLLECTIONS_BEGIN_NAMESPACE
using namespace Wrap;

template
	<
	typename KT,
	typename VT,
	typename KK = typename Type<KT>::_Type, 
	typename VK = typename Type<VT>::_Type,
	typename ValueContainer = List<VT, VK>
	>
class Dictionary : public NotCopyable
{
public:
	typedef DictionaryWrapper<Dictionary<KT, VT, KK, VK, ValueContainer>, KT, VT, KK, VK> _WRAPPER;

	Dictionary()
	{
		_Wrapper.SetContainer(this);
	}

	void SetLessMemoryMode(bool mode)
	{
		_Keys.SetLessMemoryMode(mode);
		_Values.SetLessMemoryMode(mode);
	}

	template<typename T> void CopyKeysToCollection(T& dst, bool bAppend = false) const	{ CopyToCollection(dst, _Keys, bAppend); }
	template<typename T> void CopyKeysToArray(T& dst, bool bAppend = false) const			{ CopyToArray(dst, _Keys, bAppend); }
	template<typename T> void CopyValuesToCollection(T& dst, bool bAppend = false) const	{ CopyToCollection(dst, _Keys, bAppend); }
	template<typename T> void CopyValuesToArray(T& dst, bool bAppend = false) const		{ CopyToArray(dst, _Keys, bAppend); }

	const IReadonlyList<KT, KK>& Keys() const
	{
		return _Keys.Wrap();
	}

	const IReadonlyList<VT, VK>& Values() const
	{
		return _Values.Wrap();
	}

	int Count() const
	{
		return _Keys.Count();
	}

	bool IsEmpty() const
	{
		return _Keys.Count() == 0;
	}

	const VT& Get(const KK& key) const
	{
		return operator[](key);
	}

	const VT& operator[](const KK& key) const
	{
		return _Values.Get(_Keys.IndexOf(key));
	}

	bool Lookup(const KK& key, VK& value) const
	{
		int index = _Keys.IndexOf(key);
		if (index != -1)
		{
			value = _Values.Get(index);
			return true;
		}
		return false;
	}

	bool Clear()
	{
		_Keys.Clear();
		_Values.Clear();
		return true;
	}

	IDictionary<KT, VT, KK, VK>& Wrap() const
	{
		return _Wrapper;
	}

	bool Set(const KK& key, const VT& value)
	{
		int index = _Keys.IndexOf(key);
		if(index == -1)
		{
			index = _Keys.Add(key);
			_Values.Insert(index, value);
		}
		else
		{
			_Values[index] = value;
		}
		return true;
	}

	bool Add(const KT& key, const VT& value)
	{
		ASSERT(!_Keys.Contains(key));
		int index = _Keys.Add(key);
		_Values.Insert(index, value);
		return true;
	}

	bool Remove(const KK& key)
	{
		int index = _Keys.IndexOf(key);
		if(index != -1)
		{
			_Keys.RemoveAt(index);
			_Values.RemoveAt(index);
			return true;
		}
		else
		{
			return false;
		}
	}

protected:
	SortedList<KT, KK>					_Keys;
	ValueContainer						_Values;
	mutable _WRAPPER					_Wrapper;
};

template
	<
	typename KT,
	typename VT,
	typename KK = typename Type<KT>::_Type, 
	typename VK = typename Type<VT>::_Type,
	typename ValueContainer = List<VT, VK>
	>
class Group : public NotCopyable
{
public:
	typedef GroupWrapper<Group<KT, VT, KK, VK, ValueContainer>, KT, VT, KK, VK> _WRAPPER;

	Group()
	{
		_Wrapper.SetContainer(this);
	}

	~Group()
	{
		Clear();
	}

	template<typename T>
	void CopyKeysToCollection(T& dst, bool bAppend = false) const
	{
		CopyToCollection(dst, _Keys, bAppend);
	}

	template<typename T>
	void CopyKeysToArray(T& dst, bool bAppend = false) const
	{
		CopyToArray(dst, _Keys, bAppend);
	}

	template<typename T>
	void CopyValuesToCollection(int index, T& dst, bool bAppend = false) const
	{
		CopyToCollection(dst, *(_Values.Get(index)), bAppend);
	}

	template<typename T>
	void CopyValuesToArray(int index, T& dst, bool bAppend = false) const
	{
		CopyToArray(dst, *(_Values.Get(index)), bAppend);
	}

	const IReadonlyList<KT, KK>& Keys() const
	{
		return _Keys.Wrap();
	}

	int Count() const
	{
		return _Keys.Count();
	}

	const IReadonlyList<VT, VK>& Get(const KK& key) const
	{
		return operator[](key);
	}

	const IReadonlyList<VT, VK>& GetByIndex(int index) const
	{
		return _Values.Get(index)->Wrap();
	}

	const IReadonlyList<VT, VK>& operator[](const KK& key) const
	{
		return _Values.Get(_Keys.IndexOf(key))->Wrap();
	}

	bool Contains(const KK& key) const
	{
		return _Keys.Contains(key);
	}

	IGroup<KT, VT, KK, VK>& Wrap()const
	{
		return _Wrapper;
	}

	bool Contains(const KK& key, const VK& value) const
	{
		int index = _Keys.IndexOf(key);
		if(index != -1)
		{
			return _Values.Get(index)->Contains(value);
		}
		else
		{
			return false;
		}
	}

	bool Add(const KT& key, const VT& value)
	{
		ValueContainer* target = 0;
		int index = _Keys.IndexOf(key);
		if(index == -1)
		{
			target = new ValueContainer;
			_Values.Insert(_Keys.Add(key), target);
		}
		else
		{
			target = _Values[index];
		}
		target->Add(value);
		return true;
	}

	bool Remove(const KK& key)
	{
		int index = _Keys.IndexOf(key);
		if(index != -1)
		{
			_Keys.RemoveAt(index);
			List<VT, VK>* target = _Values[index];
			_Values.RemoveAt(index);
			delete target;
			return true;
		}
		else
		{
			return false;
		}
	}

	bool Remove(const KK& key, const VK& value)
	{
		int index = _Keys.IndexOf(key);
		if(index != -1)
		{
			List<VT, VK>* target = _Values[index];
			target->Remove(value);
			if(target->Count() == 0)
			{
				_Keys.RemoveAt(index);
				_Values.RemoveAt(index);
				delete target;
			}
			return true;
		}
		else
		{
			return false;
		}
	}

	bool Clear()
	{
		for(int i = 0; i < _Values.Count(); i++)
		{
			delete _Values[i];
		}
		_Keys.Clear();
		_Values.Clear();
		return true;
	}

protected:
	SortedList<KT, KK>				_Keys;
	List<ValueContainer*>			_Values;
	mutable _WRAPPER				_Wrapper;
};
COLLECTIONS_END_NAMESPACE

#endif