/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../collections/cc_Interface.h

Interface:
	IEnumerator<T>									��ö����
	IEnumerable<T>									����ö�ٶ���
	IReadonlyList<T>								��ֻ���б�
	IArray<T>										������
	ICollection<T>									������
	IList<T>										���б�
	IReadonlyDictionary<K,V>						��ֻ��ӳ��
	IDictionary<K,V>								��ӳ��
	IReadonlyGroup<K,V>								��ֻ������ӳ��
	IGroup<K,V>										������ӳ��

***********************************************************************/

#ifndef _CC_COLLECTIONS_INTERFACE_H
#define _CC_COLLECTIONS_INTERFACE_H

#include "cc_Pair.h"

COLLECTIONS_BEGIN_NAMESPACE
namespace Interfaces
{
	using namespace Wrap;

	//////////////////////////////////////////////////////////////////////////
	//
	//  ** IEnumerator usage: 	auto foo = bar.CreateEnumerator(); delete foo;
	//
	//
	//////////////////////////////////////////////////////////////////////////

	template<typename T>
	class IEnumerator : public virtual Interface
	{
	public:
		typedef T									ElementType;
		virtual IEnumerator<T>*						Clone() const = 0;
		virtual const T&							Current() const = 0;
		virtual int									Index() const = 0;
		virtual bool								Next() = 0;
		virtual bool								Available() const { ASSERT(NULL); return false; };
		virtual void								Reset() = 0;
		virtual bool								Evaluated() const { ASSERT(NULL); return false; };
	};

	template<typename T>
	class IEnumerable : public virtual Interface
	{
	public:
		typedef T									ElementType;
		virtual IEnumerator<T>*						CreateEnumerator() const = 0;
	};

	template<typename T, typename K = typename Type<T>::_Type>
	class IReadonlyList : public virtual IEnumerable<T>
	{
	public:
		virtual bool								Contains(const K& item) const = 0;
		virtual int									Count() const = 0;
		virtual const T&							Get(int index) const = 0;
		virtual const T&							operator[](int index) const = 0;
		virtual int									IndexOf(const K& item) const = 0;
	};

	template<typename T, typename K = typename Type<T>::_Type>
	class IArray : public virtual IReadonlyList<T, K>
	{
	public:
		virtual void								Set(int index, const T& item) = 0;
		virtual void								Resize(int size) = 0;
	};

	template<typename T, typename K = typename Type<T>::_Type>
	class ICollection : public virtual IReadonlyList<T, K>
	{
	public:
		virtual int									Add(const T& item) = 0;
		virtual bool								Remove(const K& item) = 0;
		virtual bool								RemoveAt(int index) = 0;
		virtual bool								RemoveRange(int index, int count) = 0;
		virtual bool								Clear() = 0;
	};

	template<typename T, typename K = typename Type<T>::_Type>
	class IList : public virtual ICollection<T, K>
	{
	public:
		virtual int									Insert(int index, const T& item) = 0;
		virtual bool								Set(int index, const T& item) = 0;
	};

	template<typename KT, typename VT, typename KK = typename Type<KT>::_Type, typename VK = typename Type<VT>::_Type>
	class IReadonlyDictionary : public virtual IEnumerable<Pair<KT, VT>>
	{
	public:
		virtual const IReadonlyList<KT, KK>&		Keys() const = 0;
		virtual const IReadonlyList<VT, VK>&		Values() const = 0;
		virtual int									Count() const = 0;
		virtual const VT&							Get(const KK& key) const = 0;
		virtual const VT&							operator[](const KK& key) const = 0;
	};

	template<typename KT, typename VT, typename KK = typename Type<KT>::_Type, typename VK = typename Type<VT>::_Type>
	class IDictionary : public virtual IReadonlyDictionary<KT, VT, KK, VK>
	{
	public:
		virtual bool								Set(const KK& key, const VT& value) = 0;
		virtual bool								Add(const KT& key, const VT& value) = 0;
		virtual bool								Remove(const KK& key) = 0;
		virtual bool								Clear() = 0;
	};

	template<typename KT, typename VT, typename KK = typename Type<KT>::_Type, typename VK = typename Type<VT>::_Type>
	class IReadonlyGroup : public virtual IEnumerable<Pair<KT, VT>>
	{
	public:
		virtual const IReadonlyList<KT, KK>&		Keys() const = 0;
		virtual int									Count() const = 0;
		virtual const IReadonlyList<VT, VK>&		Get(const KK& key) const = 0;
		virtual const IReadonlyList<VT, VK>&		GetByIndex(int index) const = 0;
		virtual const IReadonlyList<VT, VK>&		operator[](const KK& key) const = 0;
		virtual bool								Contains(const KK& key) const = 0;
		virtual bool								Contains(const KK& key, const VK& value) const = 0;
	};

	template<typename KT, typename VT, typename KK = typename Type<KT>::_Type, typename VK = typename Type<VT>::_Type>
	class IGroup: public virtual IReadonlyGroup<KT, VT, KK, VK>
	{
	public:
		virtual bool								Add(const KT& key, const VT& value) = 0;
		virtual bool								Remove(const KK& key) = 0;
		virtual bool								Remove(const KK& key, const VK& value) = 0;
		virtual bool								Clear() = 0;
	};
}
COLLECTIONS_END_NAMESPACE

#endif