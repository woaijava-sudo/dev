/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../collections/cc_Tree.h

Class:
	Tree										��ƽ�������

***********************************************************************/

#ifndef _CC_COLLECTIONS_TREE_H
#define _CC_COLLECTIONS_TREE_H

#include "../core/cc_Base.h"

COLLECTIONS_BEGIN_NAMESPACE

//////////////////////////////////////////////////////////////////////////

#define NODE_DEPTH(n) ((n)?(n)->depth:0)
template<typename T>
struct TreeNode
{
	T						data;
	int						depth;
	TreeNode<T>*			parent;
	TreeNode<T>*			lchild;
	TreeNode<T>*			rchild;
};

template<typename T, typename Node = TreeNode<T>>
class _Tree_Allocator
{
public:
	Node* CreateTreeNode()
	{
		return new Node;
	}

	void DisposeTreeNode(Node* node)
	{
		delete node;
	}
};

template<typename T, typename _Allocator>
class _Tree : public NotCopyable
{
public:
	_Tree(_Allocator* _allocator)
		:allocator(_allocator)
		,root(NULL)
	{
	}

	~_Tree()
	{
		Clear();
	}

	void Clear()
	{
		DisposeTree(root);
		root = NULL;
	}

protected:
	inline TreeNode<T>* CreateTreeNode()
	{
		TreeNode<T>* node = allocator->CreateTreeNode();
		if (node)
		{
			node->parent	= NULL;
			node->lchild	= NULL;
			node->rchild	= NULL;
			node->depth		= NULL;
		}
		return node;
	}

	inline void DisposeTreeNode(TreeNode<T>* node)
	{
		allocator->DisposeTreeNode(node);
	}

	void DisposeTree(TreeNode<T>* node)
	{
		if (node != NULL)
		{
			DisposeTree(node->lchild);
			DisposeTree(node->rchild);
			DisposeTreeNode(node);
		}
	}

	void UpdateDepthWithoutParent(TreeNode<T>* node)
	{
		int lchildDepth = NODE_DEPTH(node->lchild);
		int rchildDepth = NODE_DEPTH(node->rchild);
		node->depth = 1 + (lchildDepth > rchildDepth ? lchildDepth : rchildDepth);
	}

	void UpdateDepth(TreeNode<T>* node)
	{
		while (node != NULL)
		{
			UpdateDepthWithoutParent(node);
			node = node->parent;
		}
	}

	void Balance(TreeNode<T>* node)
	{
		while (node != NULL)
		{
			UpdateDepthWithoutParent(node);
			TreeNode<T>* parent = node->parent;
			TreeNode<T>** parentSlot = NULL; // �޸�parent�ĺ��ӽ��ָ��

			if (parent == NULL)
			{
				parentSlot = &root;
			}
			else if (node == parent->lchild)
			{
				parentSlot = &parent->lchild;
			}
			else
			{
				parentSlot = &parent->rchild;
			}

			int lchildDepth = NODE_DEPTH(node->lchild);
			int rchildDepth = NODE_DEPTH(node->rchild);
			int dDepth = lchildDepth - rchildDepth;

			if (dDepth > 1)
			{
				TreeNode<T>* a = node;
				TreeNode<T>* b = node->lchild;
				lchildDepth = NODE_DEPTH(b->lchild);
				rchildDepth = NODE_DEPTH(b->rchild);
				int dDepth = lchildDepth - rchildDepth;

				if (dDepth >= 0) // LL
				{
					// ǰ
					//                                      A(parent,root),BF(2)
					//                                      |
					//                  B(p),BF(1)__________|_____AR
					//                  |
					//        BL(X)_____|_____BR

					// ��
					//                  B(p,root),BF(0)
					//                  |                 
					//        BL(X)_____|___________________A(parent),BF(0)
					//                                      |
					//                               BR_____|_____AR

					TreeNode<T>* x = b->rchild;
					b->rchild = a;
					a->lchild = x;
					a->parent = b;
					if (x != NULL)
						x->parent = a;

					*parentSlot = b;
					b->parent = parent;
					node = b;
					UpdateDepthWithoutParent(a);
					UpdateDepthWithoutParent(b);
				}
				else // LR
				{
					// ǰ
					//                                      A(parent,root),BF(2)
					//                                      |
					//                  B(p),BF(-1)_________|_____AR
					//                  |
					//           BL_____|_____C(pc),BF(1)
					//                        |
					//             CL(X)______|______CR

					// �󣨼���һ�㣩
					//                                C(pc,root),BF(0)
					//                                |
					//                  B(p),BF(0)____|_____A(parent),BF(-1)
					//                  |                   |
					//           BL_____|_____CL(x)  CR_____|_____AR

					TreeNode<T>* c = b->rchild;
					TreeNode<T>* x = c->lchild;
					TreeNode<T>* y = c->rchild;

					c->lchild = b;
					c->rchild = a;
					b->parent = c;
					a->parent = c;
					b->rchild = x;
					a->lchild = y;
					if (x != NULL)
						x->parent = b;
					if (y != NULL)
						y->parent = a;

					*parentSlot = c;
					c->parent = parent;
					node = c;
					UpdateDepthWithoutParent(a);
					UpdateDepthWithoutParent(b);
					UpdateDepthWithoutParent(c);
				}
			}
			else if (dDepth < -1)
			{
				TreeNode<T>* a = node;
				TreeNode<T>* b = node->rchild;
				lchildDepth = NODE_DEPTH(b->lchild);
				rchildDepth = NODE_DEPTH(b->rchild);
				int dDepth = lchildDepth - rchildDepth;

				if (dDepth <= 0) // RR
				{
					// ǰ
					//                  A(parent,root),BF(-2)
					//                  |                
					//           AL_____|___________________|
					//                                      B(p),BF(-1)
					//                               BL_____|_____BR(X)

					// ��
					//                                      B(p,root),BF(0)
					//                                      |
					//                  A(parent),BF(0)_____|_____BR(X)
					//                  |
					//           AL_____|_____BL

					TreeNode<T>* x = b->lchild;
					b->lchild = a;
					a->rchild = x;
					a->parent = b;
					if (x != NULL)
						x->parent = a;

					*parentSlot = b;
					b->parent = parent;
					node = b;
					UpdateDepthWithoutParent(a);
					UpdateDepthWithoutParent(b);
				}
				else // RL
				{
					// ǰ
					//                  A(parent,root),BF(-2)
					//                  |
					//           AL_____|___________________B(p),BF(1)
					//                                      |
					//                        C(pc),BF(-1)__|______BR
					//                        |
					//                 CL_____|_____CR(X)

					// �󣨼���һ�㣩
					//                                 C(pc,root),BF(0)
					//                                 |
					//                  A(parent),BF(1)|_____B(p),BF(0)
					//                  |                    |
					//           AL_____|_____CL   CR(x)_____|_____BR

					TreeNode<T>* c = b->lchild;
					TreeNode<T>* x = c->rchild;
					TreeNode<T>* y = c->lchild;

					c->rchild = b;
					c->lchild = a;
					b->parent = c;
					a->parent = c;
					b->lchild = x;
					a->rchild = y;
					if (x != NULL)
						x->parent = b;
					if (y != NULL)
						y->parent = a;

					*parentSlot = c;
					c->parent = parent;
					node = c;
					UpdateDepthWithoutParent(a);
					UpdateDepthWithoutParent(b);
					UpdateDepthWithoutParent(c);
				}
			}
			node = parent;
		}
	}

	void InsertTreeNode(TreeNode<T>* node)
	{
		if(root == NULL)
		{
			root = node;
			return;
		}

		// ��λ�������λ��
		TreeNode<T>* current = root;
		while (true)
		{
			if (node->data < current->data)
			{
				if (current->lchild)
				{
					current = current->lchild;
				}
				else
				{
					current->lchild = node;
					node->parent = current;
					break; // ֱ�Ӷ�λ
				}
			}
			else
			{
				if (current->rchild)
				{
					current = current->rchild;
				}
				else
				{
					current->rchild = node;
					node->parent = current;
					break; // ֱ�Ӷ�λ
				}
			}
		}
		UpdateDepth(node);
		Balance(node);
	}

	void RemoveAndDisposeTreeNode(TreeNode<T>* node)
	{
		TreeNode<T>* parent = node->parent;
		TreeNode<T>** parentSlot = NULL;

		if (parent == NULL)
		{
			parentSlot = &root;
		}
		else if (node == parent->lchild)
		{
			parentSlot = &parent->lchild;
		}
		else
		{
			parentSlot = &parent->rchild;
		}

		if (node->rchild == NULL) // ������Ϊ��
		{
			*parentSlot = node->lchild;
			if (node->lchild != NULL)
			{
				node->lchild->parent = parent;
			}
			UpdateDepth(parent);
			Balance(parent);
		}
		else if (node->rchild->lchild == NULL) // ��������Ϊ�գ���û������
		{
			node->rchild->lchild = node->lchild;
			if (node->lchild != NULL)
			{
				node->lchild->parent = node->rchild;
			}

			*parentSlot = node->rchild;
			node->rchild->parent = parent;
			UpdateDepth(node->rchild);
			Balance(node->rchild);
		}
		else // ��������Ϊ�գ���������
		{
			// ��λ�������������ӣ������滻��ǰ���
			TreeNode<T>* current = node->rchild->lchild;
			while (current->lchild != NULL)
			{
				current = current->lchild;
			}
			TreeNode<T>* balancenode = current->parent;

			current->parent->lchild = current->rchild;
			if (current->rchild != NULL)
			{
				current->rchild->parent = current->parent;
			}

			*parentSlot = current;
			current->parent = node->parent;

			current->lchild = node->lchild;
			if (node->lchild != NULL)
			{
				node->lchild->parent = current;
			}

			current->rchild = node->rchild;
			node->rchild->parent = current;

			UpdateDepth(balancenode);
			Balance(balancenode);
		}
		DisposeTreeNode(node);
	}

protected:
	TreeNode<T>*		root;		// �����
	_Allocator*			allocator;	// Ĭ�Ͽռ����
};

template<typename T, typename _Allocator = _Tree_Allocator<T>>
class Tree : public _Tree<T, _Allocator>
{
public:
	Tree():
	  _Tree(&_allocator)
	  {}

	TreeNode<T>* Insert(const T& data)
	{
		TreeNode<T>* node =CreateTreeNode();
		if (node != NULL)
		{
			node->data = data;
			InsertTreeNode(node);
		}
		return node;
	}

	TreeNode<T>* Find(const T& data)
	{
		TreeNode<T>* current = root;
		while (current)
		{
			if (data < current->data)
			{
				current = current->lchild;
			}
			else if (data > current->data)
			{
				current = current->rchild;
			}
			else
			{
				return current;
			}
		}
		return 0;
	}

	bool Remove(const T& data)
	{
		TreeNode<T>* node = Find(data);
		return RemoveTreeNode(node);
	}

	bool RemoveTreeNode(TreeNode<T>* node)
	{
		if (node != NULL)
		{
			RemoveAndDisposeTreeNode(node);
			return true;
		}
		else
		{
			return false;
		}
	}

protected:
	_Allocator _allocator;
};

#undef NODE_DEPTH
COLLECTIONS_END_NAMESPACE

#endif