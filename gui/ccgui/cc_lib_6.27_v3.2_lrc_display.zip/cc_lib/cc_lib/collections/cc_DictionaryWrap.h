/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../collections/cc_DictionaryWrap.h

Class:
	ReadonlyDictionaryWrapper						�� ֻ��ӳ�丨��
	DictionaryWrapper								�� ӳ�丨��
	ReadonlyGroupWrapper							�� ֻ������ӳ�丨��
	GroupWrapper									�� ����ӳ�丨��

***********************************************************************/

#ifndef _CC_COLLECTIONS_DICTIONARYWRAP_H
#define _CC_COLLECTIONS_DICTIONARYWRAP_H

COLLECTIONS_BEGIN_NAMESPACE
namespace Wrap
{
	using namespace Interfaces;

	template<typename C, typename KT, typename VT, typename KK, typename VK>
	class DictionaryWrapper;

	template<typename C, typename KT, typename VT, typename KK, typename VK>
	class GroupWrapper;

	template<typename C, typename KT, typename VT, typename KK = typename Type<KT>::_Type, typename VK = typename Type<VT>::_Type>
	class ReadonlyDictionaryWrapper : public Object, public virtual IReadonlyDictionary<KT, VT, KK, VK>
	{
		friend class DictionaryWrapper<C, KT, VT, KK, VK>;
	private:
		class Enumerator : public Object, public virtual IEnumerator<Pair<KT, VT>>
		{
		public:
			Enumerator(const IReadonlyDictionary* Container, int index = -1)
				: _Container(Container)
				, _Index(index)
			{
				UpdateCurrent();
			}

			IEnumerator<Pair<KT, VT>>* Clone() const
			{
				return new Enumerator(_Container, _Index);
			}

			const Pair<KT, VT>& Current() const
			{
				return _Current;
			}

			int Index() const
			{
				return _Index;
			}

			bool Next()
			{
				_Index++;
				UpdateCurrent();
				return Available();
			}

			bool Available() const
			{
				return _Index >= 0 && _Index < _Container->Count();
			}

			void Reset()
			{
				_Index = 0;
				UpdateCurrent();
			}

		private:
			void UpdateCurrent()
			{
				if(_Index >= 0 && _Index < _Container->Count())
				{
					_Current._K	= _Container->Keys()[_Index];
					_Current._V	= _Container->Values()[_Index];
				}
			}

			typedef const IReadonlyDictionary<KT, VT, KK, VK>* _CONTAINER;
			_CONTAINER			_Container;
			int					_Index;
			Pair<KT, VT>		_Current;
		};

	public:
		ReadonlyDictionaryWrapper(C* container = NULL): _Container(container)
		{

		}

		C* GetContainer()
		{
			return _Container;
		}

		void SetContainer(C* Container)
		{
			_Container = Container;
		}

		IEnumerator<Pair<KT, VT>>* CreateEnumerator() const
		{
			return new Enumerator(this);
		}

		const IReadonlyList<KT, KK>& Keys() const
		{
			return _Container->Keys();
		}

		const IReadonlyList<VT, VK>& Values() const
		{
			return _Container->Values();
		}

		int Count() const
		{
			return _Container->Count();
		}

		const VT& Get(const KK& key) const
		{
			return _Container->Get(key);
		}

		const VT& operator[] (const KK& key) const
		{
			return _Container->operator[](key);
		}

	private:
		C* _Container;
	};

	template<typename C, typename KT, typename VT, typename KK = typename Type<KT>::_Type, typename VK = typename Type<VT>::_Type>
	class DictionaryWrapper : public Object, public virtual IDictionary<KT, VT, KK, VK>
	{
	public:
		DictionaryWrapper(C* Container = NULL): _Container(Container)
		{

		}

		C* GetContainer()
		{
			return _Container;
		}

		void SetContainer(C* Container)
		{
			_Container = Container;
		}

		IEnumerator<Pair<KT, VT>>* CreateEnumerator() const
		{
			return new ReadonlyDictionaryWrapper<C, KT, VT, KK, VK>::Enumerator(this);
		}

		const IReadonlyList<KT, KK>& Keys() const
		{
			return _Container->Keys();
		}

		const IReadonlyList<VT, VK>& Values() const
		{
			return _Container->Values();
		}

		int Count() const
		{
			return _Container->Count();
		}

		const VT& Get(const KK& key) const
		{
			return _Container->Get(key);
		}

		const VT& operator[] (const KK& key) const
		{
			return _Container->operator[](key);
		}

		bool Set(const KK& key, const VT& value)
		{
			return _Container->Set(key, value);
		}

		bool Add(const KT& key, const VT& value)
		{
			return _Container->Add(key, value);
		}

		bool Remove(const KK& key)
		{
			return _Container->Remove(key);
		}

		bool Clear()
		{
			return _Container->Clear();
		}

	private:
		C* _Container;
	};

	template<typename C, typename KT, typename VT, typename KK = typename Type<KT>::_Type, typename VK = typename Type<VT>::_Type>
	class ReadonlyGroupWrapper : public Object, public virtual IReadonlyGroup<KT, VT, KK, VK>
	{
		friend class GroupWrapper<C, KT, VT, KK, VK>;
	private:
		class Enumerator : public Object, public virtual IEnumerator<Pair<KT, VT>>
		{
		public:
			Enumerator(const IReadonlyGroup* container, int keyIndex = -1, int valueIndex = -1)
				: _Container(container)
				, _KeyIndex(keyIndex)
				, _ValueIndex(valueIndex)
			{
				UpdateCurrent();
			}

			IEnumerator<Pair<KT, VT>>* Clone() const
			{
				return new Enumerator(_Container, _KeyIndex, _ValueIndex);
			}

			const Pair<KT, VT>& Current() const
			{
				return _Current;
			}

			void Reset()
			{
				_KeyIndex = 0;
				_ValueIndex = 0;
				UpdateCurrent();
			}

			int Index() const
			{
				if(Available())
				{
					int index = 0;
					for(int i = 0; i < _KeyIndex; i++)
					{
						index += _Container->GetByIndex(i).Count();
					}
					return index + _ValueIndex;
				}
				else
				{
					return -1;
				}
			}

			bool Next()
			{
				if(_KeyIndex < _Container->Count())
				{
					const IReadonlyList<VT, VK>& values = _Container->GetByIndex(_KeyIndex);
					_ValueIndex++;
					if(_ValueIndex < values.Count())
					{
						UpdateCurrent();
						return true;
					}
					else
					{
						_KeyIndex++;
						_ValueIndex = 0;
						UpdateCurrent();
						return _KeyIndex < _Container->Count();
					}
				}
				else
				{
					return false;
				}
			}

			bool Available() const
			{
				if(_KeyIndex < _Container->Count())
				{
					const IReadonlyList<VT, VK>& values = _Container->GetByIndex(_KeyIndex);
					if(_ValueIndex < values.Count())
					{
						return true;
					}
				}
				return false;
			}

		private:
			void UpdateCurrent()
			{
				if(_KeyIndex < _Container->Count())
				{
					const IReadonlyList<VT, VK>& values = _Container->GetByIndex(_KeyIndex);
					if(_ValueIndex < values.Count())
					{
						_Current._K = _Container->Keys()[_KeyIndex];
						_Current._V = values[_ValueIndex];
					}
				}
			}

			typedef const IReadonlyGroup<KT, VT, KK, VK>* _CONTAINER;
			_CONTAINER			_Container;
			int					_KeyIndex;
			int					_ValueIndex;
			Pair<KT, VT>		_Current;
		};

	public:
		ReadonlyGroupWrapper(C* Container = NULL): _Container(Container)
		{

		}

		C* GetContainer()
		{
			return _Container;
		}

		void SetContainer(C* Container)
		{
			_Container = Container;
		}

		IEnumerator<Pair<KT, VT>>* CreateEnumerator() const
		{
			return new Enumerator(this);
		}

		const IReadonlyList<KT, KK>& Keys() const
		{
			return _Container->Keys();
		}

		int Count() const
		{
			return _Container->Count();
		}

		const IReadonlyList<VT, VK>& Get(const KK& key)	const
		{
			return _Container->Get(key);
		}

		const IReadonlyList<VT, VK>& GetByIndex(int index) const
		{
			return _Container->GetByIndex(index);
		}

		const IReadonlyList<VT, VK>& operator[] (const KK& key) const
		{
			return _Container->operator[](key);
		}

		bool Contains(const KK& key) const
		{
			return _Container->Contains(key);
		}

		bool Contains(const KK& key, const VK& value) const
		{
			return _Container->Contains(key, value);
		}

	private:
		C* _Container;
	};

	template<typename C, typename KT, typename VT, typename KK = typename Type<KT>::_Type, typename VK = typename Type<VT>::_Type>
	class GroupWrapper : public Object, public virtual IGroup<KT, VT, KK, VK>
	{
	public:
		GroupWrapper(C* Container = NULL): _Container(Container)
		{

		}

		C* GetContainer()
		{
			return _Container;
		}

		void SetContainer(C* Container)
		{
			_Container = Container;
		}

		IEnumerator<Pair<KT, VT>>* CreateEnumerator() const
		{
			return new ReadonlyGroupWrapper<C, KT, VT, KK, VK>::Enumerator(this);
		}

		const IReadonlyList<KT, KK>& Keys() const
		{
			return _Container->Keys();
		}

		int Count() const
		{
			return _Container->Count();
		}

		const IReadonlyList<VT, VK>& Get(const KK& key) const
		{
			return _Container->Get(key);
		}

		const IReadonlyList<VT, VK>& GetByIndex(int index) const
		{
			return _Container->GetByIndex(index);
		}

		const IReadonlyList<VT, VK>& operator[] (const KK& key) const
		{
			return _Container->operator[](key);
		}

		bool Contains(const KK& key) const
		{
			return _Container->Contains(key);
		}

		bool Contains(const KK& key, const VK& value) const
		{
			return _Container->Contains(key, value);
		}

		bool Add(const KT& key, const VT& value)
		{
			return _Container->Add(key, value);
		}

		bool Remove(const KK& key)
		{
			return _Container->Remove(key);
		}

		bool Remove(const KK& key, const VK& value)
		{
			return _Container->Remove(key, value);
		}

		bool Clear()
		{
			return _Container->Clear();
		}

	private:
		C* _Container;
	};
}
COLLECTIONS_END_NAMESPACE

#endif