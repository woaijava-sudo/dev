/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../collections/cc_Enumerator.h

Interface:
	CopyFrom(TargetContainer, SourceContainer)
	[T]		.Select(T->K) => [K]
	[T]		.SelectMany(T->[K]) => [K]
	[T]		.Where(T->bool) => [T]
	[AutoPtr<T>].Cast<K>() => [AutoPtr<K>]
	[AutoPtr<T>].FindType<K>() => [AutoPtr<K>]
	[T]		.OrderBy(T->T->int) => [T]

	[T]		.Aggregate(T->T->T) => T
	[T]		.Aggregate(T->T->T, T) => T
	[T]		.All(T->bool) => bool
	[T]		.Any(T->bool) => bool
	[T]		.Max() => T
	[T]		.Min() => T
	[T]		.First() => T
	[T]		.FirstOrDefault(T) => T
	[T]		.Last() => T
	[T]		.LastOrDefault(T) => T
	[T]		.Count() => vint
	[T]		.IsEmpty() => bool

	[T]		.Concat([T]) => [T]
	[T]		.Repeat(vint) => [T]
	[T]		.Take(vint) => [T]
	[T]		.Skip(vint) => [T]
	[T]		.Distinct() => [T]
	[T]		.Reverse() => [T]

	[T]		.Pairwise([K]) => [(T,K)]
	[T]		.Intersect([T]) => [T]
	[T]		.Union([T]) => [T]
	[T]		.Except([T]) => [T]

	[T]		.Evaluate() => [T]
	[T]		.GroupBy(T->K) => [(K, [T])]

	From(begin, end) => [T]
	From(array) => [T]
	Range(start, count) => [vint]

	FOREACH(X, a, XList)
	FOREACH_INDEXER(X, a, index, XList)

***********************************************************************/

#ifndef _CC_COLLECTIONS_ENUMERATOR_H
#define _CC_COLLECTIONS_ENUMERATOR_H

#include "cc_Interface.h"
#include "..\core\cc_Ptr.h"
#include "..\core\cc_Function.h"

COLLECTIONS_BEGIN_NAMESPACE
namespace Enumerator
{
	using namespace Ptr;
	using namespace Function;

	//////////////////////////////////////////////////////////////////////////
	// 
	// ��������
	//

	namespace Internal
	{
		//////////////////////////////////////////////////////////////////////////
		// 
		// Internal
		//

		template<typename T>
		struct RandomAccessable
		{
			static const bool							CanRead = false;
			static const bool							CanResize = false;
		};

		template<typename T>
		struct Slice
		{
			const T*	items;
			int			count;
		};

		template<typename T>
		struct RandomAccess
		{
			static int GetCount(const T& t)
			{
				return t.Count();
			}

			static const typename T::ElementType& GetValue(const T& t, int index)
			{
				return t.Get(index);
			}

			static void SetCount(T& t, int count)
			{
				t.Resize(count);
			}

			static void SetValue(T& t, int index, const typename T::ElementType& value)
			{
				t.Set(index, value);
			}

			static void AppendValue(T& t, const typename T::ElementType& value)
			{
				t.Add(value);
			}
		};

		template<typename T>
		struct RandomAccessable<Slice<T>>
		{
			static const bool							CanRead = true;
			static const bool							CanResize = true;
		};

		template<typename T>
		struct RandomAccess<Slice<T>>
		{
			static int GetCount(const Slice<T>& t)
			{
				return t.count;
			}

			static const T& GetValue(const Slice<T>& t, int index)
			{
				return t.items[index];
			}
		};

		template<typename Ds, typename Ss, bool DsRA, bool SsRA>
		struct CopyFromAlgorithm
		{
		};

		template<typename Ds, typename Ss>
		struct CopyFromAlgorithm<Ds, Ss, true, true>
		{
			static void Perform(Ds& ds, const Ss& ss, bool append)
			{
				int copyCount = RandomAccess<Ss>::GetCount(ss);
				int index = (append ? RandomAccess<Ds>::GetCount(ds) : 0);
				int resizeCount = index + copyCount;
				RandomAccess<Ds>::SetCount(ds, resizeCount);
				for(int i = 0; i < copyCount; i++)
				{
					RandomAccess<Ds>::SetValue(ds, index + i, RandomAccess<Ss>::GetValue(ss, i));
				}
			}
		};

		template<typename Ds, typename Ss>
		struct CopyFromAlgorithm<Ds, Ss, false, true>
		{
			static void Perform(Ds& ds, const Ss& ss, bool append)
			{
				if(!append)
				{
					ds.Clear();
				}
				int copyCount = RandomAccess<Ss>::GetCount(ss);
				for(int i = 0; i < copyCount; i++)
				{
					RandomAccess<Ds>::AppendValue(ds, RandomAccess<Ss>::GetValue(ss, i));
				}
			}
		};

		template<typename Ds, typename Ss>
		struct CopyFromAlgorithm<Ds, Ss, true, false>
		{
			static void Perform(Ds& ds, const Ss& ss, bool append)
			{
				int copyCount = 0;

				auto enumerator = ss.CreateEnumerator();
				while(enumerator->Next())
				{
					copyCount++;
				}

				int index = (append ? RandomAccess<Ds>::GetCount(ds) : 0);
				int resizeCount = index + copyCount;
				RandomAccess<Ds>::SetCount(ds, resizeCount);
				delete enumerator;
				enumerator = ss.CreateEnumerator();
				while(enumerator->Next())
				{
					RandomAccess<Ds>::SetValue(ds, index++, enumerator->Current());
				}
				delete enumerator;
			}
		};

		template<typename Ds, typename Ss>
		struct CopyFromAlgorithm<Ds, Ss, false, false>
		{
			static void Perform(Ds& ds, const Ss& ss, bool append)
			{
				if(!append)
				{
					ds.Clear();
				}
				auto enumerator = ss.CreateEnumerator();
				while(enumerator->Next())
				{
					RandomAccess<Ds>::AppendValue(ds, enumerator->Current());
				}
				delete enumerator;
			}
		};

		template<typename Ds, typename Ss>
		void CopyFrom(Ds& ds, const Ss& ss, bool append = false)
		{
			CopyFromAlgorithm<Ds, Ss, RandomAccessable<Ds>::CanResize, RandomAccessable<Ss>::CanRead>
				::Perform(ds, ss, append);
		}

		template<typename Ds, typename S>
		void CopyFrom(Ds& ds, const S* buffer, int count, bool append = false)
		{
			Slice<S> slice = { buffer, count };
			CopyFrom(ds, slice, append);
		}

		template<typename Ds, typename S>
		void CopyFrom(Ds& ds, const S* begin, const S* end, bool append = false)
		{
			Slice<S> slice = {begin, end - begin};
			CopyFrom(ds, slice, append);
		}

		//////////////////////////////////////////////////////////////////////////
		// 
		// Operations
		//

		template<typename T>
		struct SortedListOperations
		{
			static bool Contains(const SortedList<T>& items, const T& item)
			{
				return items.Contains(item);
			}
		};

		template<typename T>
		struct SortedListOperations<AutoPtr<T>>
		{
			static bool Contains(const SortedList<AutoPtr<T>>& items, const AutoPtr<T>& item)
			{
				return items.Contains(item.Obj());
			}
		};

		//////////////////////////////////////////////////////////////////////////
		// 
		// ö�����Ƚ�
		//

		template<typename T, typename U>
		int CompareEnumerable(const IEnumerable<T>& a, const IEnumerable<U>& b)
		{
			AutoPtr<IEnumerator<T>> ator = a.Wrap().CreateEnumerator();
			AutoPtr<IEnumerator<U>> btor = b.Wrap().CreateEnumerator();
			while(true)
			{
				bool a = ator->Next();
				bool b = btor->Next();
				if(a && !b) return 1;
				if(!a && b) return -1;
				if(!a && !b) break;

				const T& ac = ator->Current();
				const U& bc = btor->Current();
				if(ac < bc)
				{
					return -1;
				}
				else if(ac > bc)
				{
					return 1;
				}
				ator->Next();
				btor->Next();
			}
			return 0;
		}
	}

	//////////////////////////////////////////////////////////////////////////

    using namespace Internal;

	//////////////////////////////////////////////////////////////////////////
	// 
	// ��ö����
	//

	template<typename T>
	class EmptyEnumerable : public Object, public IEnumerable<T>
	{
	private:
		class Enumerator : public Object, public virtual IEnumerator<T>
		{
			IEnumerator<T>* Clone() const
			{
				return new Enumerator;
			}

			const T& Current() const
			{
				ASSERT(FALSE);
				return T();
			}

			int Index() const
			{
				return -1;
			}

			bool Next() 
			{
				return false;
			}

			void Reset()
			{

			}

			bool Evaluated() const
			{
				return true;
			}
		};

	public:
		IEnumerator<T>* CreateEnumerator() const
		{
			return new Enumerator;
		}
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// ��������ö����
	//

	template<typename T>
	class RangeEnumerator : public Object, public virtual IEnumerator<T>
	{
	public:
		RangeEnumerator(T _start, T _count, T _current)
			:start(_start)
			,count(_count)
			,current(_current)
		{
		}

		RangeEnumerator(T _start, T _count)
			:start(_start)
			,count(_count)
			,current(_start-1)
		{
		}

		IEnumerator<T>* Clone() const
		{
			return new RangeEnumerator(start, count, current);
		}

		const T& Current() const
		{
			return current;
		}

		T Index() const
		{
			return current - start;
		}

		bool Next()
		{
			if(start - 1 <= current && current < start + count - 1)
			{
				current++;
				return true;
			}
			else
			{
				return false;
			}
		}

		void Reset()
		{
			current = start - 1;
		}

		bool Evaluated() const
		{
			return true;
		}

	protected:
		T			start;
		T			count;
		T			current;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// �԰���ö����
	//

	template<typename T, typename TContainer>
	class ContainerEnumerator : public Object, public virtual IEnumerator<T>
	{
	public:
		ContainerEnumerator(AutoPtr<TContainer> _container, int _index = -1)
		{
			container = _container;
			index = _index;
		}

		IEnumerator<T>* Clone() const
		{
			return new ContainerEnumerator(container, index);
		}

		const T& Current() const
		{
			return container->Get(index);
		}

		int Index() const
		{
			return index;
		}

		bool Next()
		{
			index++;
			return index >= 0 && index < container->Count();
		}

		void Reset()
		{
			index = -1;
		}

		bool Evaluated() const
		{
			return true;
		}

	private:
		AutoPtr<TContainer>			container;
		int						index;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Selectö����
	//

	template<typename T, typename K>
	class SelectEnumerator : public virtual IEnumerator<K>
	{
	public:
		SelectEnumerator(IEnumerator<T>* _enumerator, const Func<K(T)>& _selector, K _current = K())
			:enumerator(_enumerator)
			,selector(_selector)
			,current(_current)
		{
		}

		~SelectEnumerator()
		{
			delete enumerator;
		}

		IEnumerator<K>* Clone() const
		{
			return new SelectEnumerator(enumerator->Clone(), selector, current);
		}

		const K& Current() const
		{
			return current;
		}

		int Index() const
		{
			return enumerator->Index();
		}

		bool Next()
		{
			if(enumerator->Next())
			{
				current = selector(enumerator->Current());
				return true;
			}
			else
			{
				return false;
			}
		}

		void Reset()
		{
			enumerator->Reset();
		}

	protected:
		IEnumerator<T>*			enumerator;
		Func<K(T)>				selector;
		K						current;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Whereö����
	//

	template<typename T>
	class WhereEnumerator : public virtual IEnumerator<T>
	{
	public:
		WhereEnumerator(IEnumerator<T>* _enumerator, const Func<bool(T)>& _selector, int _index = -1)
			:enumerator(_enumerator)
			,selector(_selector)
			,index(_index)
		{
		}

		~WhereEnumerator()
		{
			delete enumerator;
		}

		IEnumerator<T>* Clone() const
		{
			return new WhereEnumerator(enumerator->Clone(), selector, index);
		}

		const T& Current() const
		{
			return enumerator->Current();
		}

		int Index() const
		{
			return index;
		}

		bool Next()
		{
			while(enumerator->Next())
			{
				if(selector(enumerator->Current()))
				{
					index++;
					return true;
				}
			}
			return false;
		}

		void Reset()
		{
			enumerator->Reset();
			index = -1;
		}

	protected:
		IEnumerator<T>*			enumerator;
		Func<bool(T)>			selector;
		int						index;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Concatö����
	//

	template<typename T>
	class ConcatEnumerator : public virtual IEnumerator<T>
	{
	public:
		ConcatEnumerator(IEnumerator<T>* _enumerator1, IEnumerator<T>* _enumerator2, int _index = -1, bool _turned = false)
			:enumerator1(_enumerator1)
			,enumerator2(_enumerator2)
			,index(_index)
			,turned(_turned)
		{
		}

		~ConcatEnumerator()
		{
			delete enumerator1;
			delete enumerator2;
		}

		IEnumerator<T>* Clone() const
		{
			return new ConcatEnumerator(enumerator1->Clone(), enumerator2->Clone(), index, turned);
		}

		const T& Current() const
		{
			if(turned)
			{
				return enumerator2->Current();
			}
			else
			{
				return enumerator1->Current();
			}
		}

		int Index() const
		{
			return index;
		}

		bool Next()
		{
			index++;
			if(turned)
			{
				return enumerator2->Next();
			}
			else
			{
				if(enumerator1->Next())
				{
					return true;
				}
				else
				{
					turned = true;
					return enumerator2->Next();
				}
			}
		}

		void Reset()
		{
			enumerator1->Reset();
			enumerator2->Reset();
			index = -1;
			turned = false;
		}

		bool Evaluated() const
		{
			return enumerator1->Evaluated() && enumerator2->Evaluated();
		}

	protected:
		IEnumerator<T>*					enumerator1;
		IEnumerator<T>*					enumerator2;
		int								index;
		bool							turned;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Takeö����
	//

	template<typename T>
	class TakeEnumerator : public virtual IEnumerator<T>
	{
	public:
		TakeEnumerator(IEnumerator<T>* _enumerator, int _count)
			:enumerator(_enumerator)
			,count(_count)
		{
		}

		~TakeEnumerator()
		{
			delete enumerator;
		}

		IEnumerator<T>* Clone() const
		{
			return new TakeEnumerator(enumerator->Clone(), count);
		}

		const T& Current() const
		{
			return enumerator->Current();
		}

		int Index() const
		{
			return enumerator->Index();
		}

		bool Next()
		{
			if(enumerator->Index() >= count - 1) return false;
			return enumerator->Next();
		}

		void Reset()
		{
			enumerator->Reset();
		}

		bool Evaluated() const
		{
			return enumerator->Evaluated();
		}

	protected:
		IEnumerator<T>*			enumerator;
		int						count;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Skipö����
	//

	template<typename T>
	class SkipEnumerator : public virtual IEnumerator<T>
	{
	public:
		SkipEnumerator(IEnumerator<T>* _enumerator, int _count, bool _skipped = false)
			:enumerator(_enumerator)
			,count(_count)
			,skipped(_skipped)
		{
		}

		~SkipEnumerator()
		{
			delete enumerator;
		}

		IEnumerator<T>* Clone() const
		{
			return new SkipEnumerator(enumerator->Clone(), count, skipped);
		}

		const T& Current() const
		{
			return enumerator->Current();
		}

		int Index() const
		{
			return enumerator->Index()-count;
		}

		bool Next()
		{
			if(!skipped)
			{
				skipped = true;
				for(int i = 0; i < count; i++)
				{
					if(!enumerator->Next())
					{
						return false;
					}
				}
			}
			return enumerator->Next();
		}

		void Reset()
		{
			enumerator->Reset();
			skipped = false;
		}

		bool Evaluated() const
		{
			return enumerator->Evaluated();
		}

	protected:
		IEnumerator<T>*			enumerator;
		int						count;
		bool					skipped;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Repeatö����
	//

	template<typename T>
	class RepeatEnumerator : public virtual IEnumerator<T>
	{
	public:
		RepeatEnumerator(IEnumerator<T>* _enumerator, int _count, int _index = -1, int _repeatedCount = 0)
			:enumerator(_enumerator)
			,count(_count)
			,index(_index)
			,repeatedCount(_repeatedCount)
		{
		}

		~RepeatEnumerator()
		{
			delete enumerator;
		}

		IEnumerator<T>* Clone() const
		{
			return new RepeatEnumerator(enumerator->Clone(), count, index, repeatedCount);
		}

		const T& Current() const
		{
			return enumerator->Current();
		}

		int Index() const
		{
			return index;
		}

		bool Next()
		{
			while(repeatedCount<count)
			{
				if(enumerator->Next())
				{
					index++;
					return true;
				}
				repeatedCount++;
				enumerator->Reset();
			}
			return false;
		}

		void Reset()
		{
			enumerator->Reset();
			index = -1;
			repeatedCount = 0;
		}

		bool Evaluated() const
		{
			return enumerator->Evaluated();
		}

	protected:
		IEnumerator<T>*		enumerator;
		int					count;
		int					index;
		int					repeatedCount;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Distinctö����
	//

	template<typename T>
	class DistinctEnumerator : public virtual IEnumerator<T>
	{
	public:
		DistinctEnumerator(IEnumerator<T>* _enumerator)
			:enumerator(_enumerator)
		{
		}

		DistinctEnumerator(const DistinctEnumerator& _enumerator)
			:lastValue(_enumerator.lastValue)
		{
			enumerator = _enumerator.enumerator->Clone();
			CopyFrom(distinct.Wrap(), _enumerator.distinct.Wrap());
		}

		~DistinctEnumerator()
		{
			delete enumerator;
		}

		IEnumerator<T>* Clone() const
		{
			return new DistinctEnumerator(*this);
		}

		const T& Current() const
		{
			return lastValue;
		}

		int Index() const
		{
			return distinct.Count() - 1;
		}

		bool Next()
		{
			while(enumerator->Available())
			{
				const T& current = enumerator->Current();
				enumerator->Next();
				if(!Internal::SortedListOperations<T>::Contains(distinct, current))
				{
					lastValue = current;
					distinct.Add(current);
					return true;
				}						
			}
			return false;
		}

		void Reset()
		{
			enumerator->Reset();
			distinct.Clear();
		}

	protected:
		IEnumerator<T>*		enumerator;
		SortedList<T>		distinct;
		T					lastValue;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Reverseö����
	//

	template<typename T>
	class ReverseEnumerator : public virtual IEnumerator<T>
	{
	public:
		ReverseEnumerator(const IEnumerable<T>& enumerable)
			:index(-1)
		{
			CopyFrom(cache.Wrap(), enumerable);
		}

		ReverseEnumerator(const ReverseEnumerator& _enumerator)
			:index(_enumerator.index)
		{
			CopyFrom(cache.Wrap(), _enumerator.cache.Wrap());
		}

		~ReverseEnumerator()
		{
		}

		IEnumerator<T>* Clone() const
		{
			return new ReverseEnumerator(*this);
		}

		const T& Current() const
		{
			return cache.Get(cache.Count() - index - 1);
		}

		int Index() const
		{
			return index;
		}

		bool Next()
		{
			index++;
			return index < cache.Count();
		}

		void Reset()
		{
			index = -1;
		}

		bool Evaluated() const
		{
			return true;
		}

	protected:
		List<T>						cache;
		int							index;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Fromö����
	//

	template<typename T, typename I>
	class FromIteratorEnumerable : public Object, public IEnumerable<T>
	{
	private:
		class Enumerator : public Object, public IEnumerator<T>
		{
		private:
			I				begin;
			I				end;
			I				current;

		public:
			Enumerator(I _begin, I _end, I _current)
				:begin(_begin)
				,end(_end)
				,current(_current)
			{
			}

			IEnumerator<T>* Clone() const
			{
				return new Enumerator(begin, end, current);
			}

			const T& Current() const
			{
				return *current;
			}

			int Index() const
			{
				return current - begin;
			}

			bool Next()
			{
				current++;
				return begin <= current && current < end;
			}

			void Reset()
			{
				current = begin - 1;
			}

			bool Evaluated() const
			{
				return true;
			}
		};

	public:
		IEnumerator<T>* CreateEnumerator() const
		{
			return new Enumerator(begin, end, begin - 1);
		}

		FromIteratorEnumerable(I _begin, I _end)
			:begin(_begin)
			,end(_end)
		{
		}

		FromIteratorEnumerable(const FromIteratorEnumerable<T, I>& enumerable)
			:begin(enumerable.begin)
			,end(enumerable.end)
		{
		}

		template<typename T>
		class FromIterator
		{
		public:
			template<typename I>
			static FromIteratorEnumerable<T, I> Wrap(I begin, I end)
			{
				return FromIteratorEnumerable<T, I>(begin, end);
			}
		};

		template<typename T>
		static FromIteratorEnumerable<T, T*> FromPointer(T* begin, T* end)
		{
			return FromIteratorEnumerable<T, T*>(begin, end);
		}

		template<typename T, int size>
		static FromIteratorEnumerable<T, T*> FromArray(T (&items)[size])
		{
			return FromIteratorEnumerable<T, T*>(&items[0], &items[size]);
		}

	private:
		I					begin;
		I					end;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Intersect/Exceptö����
	//

	template<typename T, bool Intersect>
	class IntersectExceptEnumerator : public virtual IEnumerator<T>
	{
	public:
		IntersectExceptEnumerator(IEnumerator<T>* _enumerator, const IEnumerable<T>& _reference)
			:enumerator(_enumerator)
			,index(-1)
		{
			CopyFrom(reference.Wrap(), _reference.Wrap());
		}

		IntersectExceptEnumerator(const IntersectExceptEnumerator& _enumerator)
		{
			enumerator = _enumerator.enumerator->Clone();
			CopyFrom(reference.Wrap(), _enumerator.reference.Wrap());
			index = _enumerator.index;
		}

		~IntersectExceptEnumerator()
		{
			delete enumerator;
		}

		IEnumerator<T>* Clone() const
		{
			return new IntersectExceptEnumerator(*this);
		}

		const T& Current() const
		{
			return enumerator->Current();
		}

		int Index() const
		{
			return index;
		}

		bool Next()
		{
			while(enumerator->Next())
			{
				if(SortedListOperations<T>::Contains(reference, enumerator->Current()) == Intersect)
				{
					index++;
					return true;
				}
			}
			return false;
		}

		void Reset()
		{
			enumerator->Reset();
			index = -1;
		}

	protected:
		IEnumerator<T>*				enumerator;
		SortedList<T>				reference;
		int							index;
	};

	//////////////////////////////////////////////////////////////////////////
	// 
	// Pairwiseö����
	//

	template<typename S, typename T>
	class PairwiseEnumerator : public virtual IEnumerator<Pair<S, T>>
	{
	public:
		PairwiseEnumerator(IEnumerator<S>* _enumerator1, IEnumerator<T>* _enumerator2, Pair<S, T> _current = Pair<S, T>())
			:enumerator1(_enumerator1)
			,enumerator2(_enumerator2)
			,current(_current)
		{
		}

		~PairwiseEnumerator()
		{
			delete enumerator1;
			delete enumerator2;
		}

		IEnumerator<Pair<S, T>>* Clone() const
		{
			return new PairwiseEnumerator(enumerator1->Clone(), enumerator2->Clone(), current);
		}

		const Pair<S, T>& Current() const
		{
			return current;
		}

		int Index() const
		{
			return enumerator1->Index();
		}

		bool Next()
		{
			if(enumerator1->Next() && enumerator2->Next())
			{
				current=Pair<S, T>(enumerator1->Current(), enumerator2->Current());
				return true;
			}
			else
			{
				return false;
			}
		}

		void Reset()
		{
			enumerator1->Reset();
			enumerator2->Reset();
		}

		bool Evaluated() const
		{
			return enumerator1->Evaluated() && enumerator2->Evaluated();
		}

	protected:
		IEnumerator<S>*					enumerator1;
		IEnumerator<T>*					enumerator2;
		Pair<S, T>						current;
	};
}
COLLECTIONS_END_NAMESPACE

#endif