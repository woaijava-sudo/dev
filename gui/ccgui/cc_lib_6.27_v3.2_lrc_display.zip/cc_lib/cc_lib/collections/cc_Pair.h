/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_Pair.h

Class:
	Pair									: ��ֵ��

***********************************************************************/

#ifndef _CC_COLLECTIONS_PAIR_H
#define _CC_COLLECTIONS_PAIR_H

COLLECTIONS_BEGIN_NAMESPACE
namespace Wrap
{
	template<typename K, typename V>
	class Pair
	{
	public:
		typedef const K& __K;
		typedef const V& __V;
		typedef const Pair<K, V>& _PAIR;

		K _K; V _V;

		Pair(){}
		Pair(__K k, __V v): _K(k), _V(v) {}
		Pair(_PAIR p): _K(p._K), _V(p._V) {}

		int CompareTo(_PAIR p) const
		{
			if(_K < p._K)			return -1;
			else if(_K > p._K)		return 1;
			else if(_V < p._V)		return -1;
			else if(_V > p._V)		return 1;
		}

		bool operator == (_PAIR p) const { return CompareTo(p) == 0; }
		bool operator != (_PAIR p) const { return CompareTo(p) != 0; }
		bool operator >= (_PAIR p) const { return CompareTo(p) >= 0; }
		bool operator <= (_PAIR p) const { return CompareTo(p) <= 0; }
		bool operator >  (_PAIR p) const { return CompareTo(p) >  0; }
		bool operator <  (_PAIR p) const { return CompareTo(p) <  0; }
	};

	template<typename K, typename V>
	struct Result<Pair<K, V>>
	{
		static const bool _Result = Result<K>::_Result && Result<V>::_Result;
	};
}
COLLECTIONS_END_NAMESPACE

#endif