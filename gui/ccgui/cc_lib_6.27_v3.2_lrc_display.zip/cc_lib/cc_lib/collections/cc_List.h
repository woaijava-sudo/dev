/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_List.h

Class:
	List										: �б�
	SortedList									: �����б�
	Array										: ����
	Stack										: ջ

Notice:

***********************************************************************/

#ifndef _CC_COLLECTIONS_LIST_H
#define _CC_COLLECTIONS_LIST_H

#include "../core/cc_Base.h"
#include "../core/cc_Debug.h"
#include "cc_Interface.h"
#include "cc_ListWrap.h"

COLLECTIONS_BEGIN_NAMESPACE
using namespace Wrap;

template<typename T, bool ResultType>	class ListStore abstract : public Object {};

template<typename T>
class ListStore<T, false> abstract : public Object
{
protected:
	static void CopyObjects(T* dest, const T* source, int count)
	{
		if(dest < source)
		{
			for(int i = 0; i < count; i++)
			{
				dest[i] = source[i];
			}
		}
		else if(dest > source)
		{
			for(int i = count - 1; i >= 0; i--)
			{
				dest[i] = source[i];
			}
		}
	}

	static void ClearObjects(T* dest, int count)
	{
		for(int i = 0; i < count; i++)
		{
			dest[i] = T();
		}
	}
};

template<typename T>
class ListStore<T, true> abstract : public Object
{
protected:
	static void CopyObjects(T* dest, const T* source, int count)
	{
		if(count)
		{
			memmove(dest, source, sizeof(T) * count);
		}
	}

	static void ClearObjects(T* dest, int count)
	{
		for(int i = 0; i < count; i++)
		{
			dest[i] = T();
		}
	}
};

template<typename T, typename K = typename Type<T>::_Type>
class Array : public ListStore<T,Result<T>::_Result>
{
public:
	typedef ArrayWrapper<Array<T, K>, T, K> _WRAPPER;

	Array(int size = 0)
	{
		_Wrapper.SetContainer(this);
		Create(size);
	}

	Array(const T* buffer, int size)
	{
		_Wrapper.SetContainer(this);
		Create(size);
		CopyObjects(_Buffer, buffer, size);
	}

	~Array()
	{
		Destroy();
	}

	bool Contains(const K& item) const
	{
		return IndexOf(item) != -1;
	}

	int Count() const
	{
		return _Count;
	}

	int GetSize() const
	{
		return _Count;
	}

	const T& Get(int index) const
	{
		return this->operator[](index);
	}

	const T& operator[](int index) const
	{
		AssertIndex(index);
		return _Buffer[index];
	}

	T& operator[](int index)
	{
		AssertIndex(index);
		return _Buffer[index];
	}

	void Set(int index, const T& item)
	{
		AssertIndex(index);
		_Buffer[index] = item;
	}

	void Remove(int index)
	{
		AssertIndex(index);
		CopyObjects(&_Buffer[index], &_Buffer[index+1], _Count - index - 1);
		_Count--;
	}

	IArray<T, K>& Wrap() const
	{
		return _Wrapper;
	}

	int IndexOf(const K& item) const
	{
		for(int i = 0; i < _Count; i++)
		{
			if(_Buffer[i] == item)
			{
				return i;
			}
		}
		return -1;
	}

	void Resize(int size)
	{
		int oldCount = _Count;
		T* oldBuffer = _Buffer;
		Create(size);
		CopyObjects(_Buffer, oldBuffer, (_Count < oldCount ? _Count : oldCount));
		delete[] oldBuffer;
	}

protected:
	void AssertIndex(int index) const
	{
		ASSERT(index >= 0 && index < _Count);
	}

	void Create(int size)
	{
		if(size > 0)
		{
			_Count = size;
			_Buffer = new T[size];
		}
		else
		{
			_Count = 0;
			_Buffer = 0;
		}
	}

	void Destroy()
	{
		_Count = 0;
		SAFE_DELETE_ARRAY(_Buffer);
		_Buffer = 0;
	}

protected:
	int					_Count;
	T*					_Buffer;
	mutable _WRAPPER	_Wrapper;
};

template<typename T, typename K = typename Type<T>::_Type>
class ListBase abstract : public ListStore<T,Result<T>::_Result>
{
public:
	ListBase(): _Capacity(0), _bLessMemoryMode(true)
	{
		_Count = 0;
		_Buffer = NULL;
	}

	~ListBase()
	{
		Destroy();
	}

	void SetLessMemoryMode(bool Mode)
	{
		_bLessMemoryMode = Mode;
	}

	int Count() const
	{
		return _Count;
	}

	int GetSize() const
	{
		return _Count;
	}

	const T& Get(int index) const
	{
		AssertIndex(index);
		return _Buffer[index];
	}
	const T& operator[](int index) const
	{
		AssertIndex(index);
		return _Buffer[index];
	}

	bool RemoveAt(int index)
	{
		AssertIndex(index);
		int previousCount = _Count;
		CopyObjects(_Buffer + index, _Buffer + index + 1, _Count - index - 1);
		_Count--;
		ReleaseUnnecessaryBuffer(previousCount);
		return true;
	}

	bool RemoveRange(int index, int count)
	{
		AssertIndex(index);
		AssertIndex(index + count - 1);
		int previousCount = _Count;
		CopyObjects(_Buffer + index, _Buffer + index + count, _Count - index - count);
		_Count -= count;
		ReleaseUnnecessaryBuffer(previousCount);
		return true;
	}

	bool Clear()
	{
		int previousCount = _Count;
		_Count = 0;
		if(_bLessMemoryMode)	Destroy();
		else					ReleaseUnnecessaryBuffer(previousCount);
		return true;
	}

protected:
	void AssertIndex(int index) const
	{
		ASSERT(index >= 0 && index < _Count);
	}

	void Destroy()
	{
		_Capacity = 0;
		SAFE_DELETE_ARRAY(_Buffer);
		_Buffer = NULL;
	}

	int CalculateCapacity(int expected)
	{
		int result = _Capacity;
		while(result < expected) result = result * 5 / 4 + 1;
		return result;
	}

	void MakeRoom(int index, int count)
	{
		int newCount =  _Count + count;
		if(newCount > _Capacity)
		{
			int newCapacity = CalculateCapacity(newCount);
			T* newBuffer = new T[newCapacity];
			CopyObjects(newBuffer, _Buffer, index);
			CopyObjects(newBuffer + index + count, _Buffer + index, _Count - index);
			delete[] _Buffer;
			_Capacity = newCapacity;
			_Buffer = newBuffer;
		}
		else
		{
			CopyObjects(_Buffer + index + count, _Buffer + index, _Count - index);
		}
		_Count = newCount;
	}

	void ReleaseUnnecessaryBuffer(int previousCount)
	{
		if(_Buffer != NULL && _Count < previousCount)
		{
			ClearObjects(&_Buffer[_Count], previousCount - _Count);
		}
		if(_bLessMemoryMode && _Count <= _Capacity / 2)
		{
			int newCapacity = _Capacity * 5 / 8;
			if(_Count < newCapacity)
			{
				T* newBuffer = new T[newCapacity];
				CopyObjects(newBuffer, _Buffer, _Count);
				delete[] _Buffer;
				_Capacity = newCapacity;
				_Buffer = newBuffer;
			}
		}
	}

protected:
    int						_Count;
    T*						_Buffer;
	int						_Capacity;
	bool					_bLessMemoryMode;
};

template<typename T, typename K = typename Type<T>::_Type>
class List : public ListBase<T, K>, public NotCopyable
{
public:
	typedef ListWrapper<List<T, K>, T, K> _WRAPPER;

	List()
	{
		_Wrapper.SetContainer(this);
	}

	bool Contains(const K& item) const
	{
		return IndexOf(item) != -1;
	}

	template<typename Key>
	int IndexOf(const Key& item) const
	{
		for(int i = 0; i < _Count; i++)
		{
			if(_Buffer[i] == item)
			{
				return i;
			}
		}
		return -1;
	}

	int Add(const T& item)
	{
		MakeRoom(_Count, 1);
		_Buffer[_Count - 1] = item;
		return _Count - 1;
	}

	int Insert(int index, const T& item)
	{
		ASSERT(index >= 0 && index <= _Count);
		MakeRoom(index, 1);
		_Buffer[index] = item;
		return index;
	}

	bool Remove(const K& item)
	{
		int index = IndexOf(item);
		if(index >= 0 && index < _Count)
		{
			RemoveAt(index);
			return true;
		}
		else
		{
			return false;
		}
	}

	bool Set(int index, const T& item)
	{
		AssertIndex(index);
		_Buffer[index] = item;
		return true;
	}

	void Swap(int a, int b)
	{
		AssertIndex(a);
		AssertIndex(b);
		if (a != b)
		{
			T tmp = Get(a);
			Set(a, Get(b));
			Set(b, tmp);
		}
	}

	T& operator[](int index)
	{
		AssertIndex(index);
		return _Buffer[index];
	}

	IList<T, K>& Wrap() const
	{
		return _Wrapper;
	}

protected:
	mutable _WRAPPER _Wrapper;
};

template<typename T, typename K = typename Type<T>::_Type>
class SortedList : public ListBase<T, K>, public NotCopyable
{
public:
	typedef CollectionWrapper<SortedList<T, K>, T, K> _WRAPPER;

	SortedList()
	{
		_Wrapper.SetContainer(this);
	}

	bool Contains(const K& item)const
	{
		return IndexOf(item) != -1;
	}

	template<typename Key>
	int IndexOf(const Key& item) const
	{
		int start = 0;
		int end = _Count - 1;
		while(start <= end)
		{
			int index = (start + end) / 2;
			if(_Buffer[index] == item)				return index;
			else if(_Buffer[index] > item)			end = index - 1;
			else									start = index + 1;
		}
		return -1;
	}

	int IndexOf(const K& item)const
	{
		return IndexOf<K>(item);
	}

	int Add(const T& item)
	{
		if(_Count == 0)
		{
			MakeRoom(0, 1);
			_Buffer[0] = item;
			return 0;
		}
		else
		{
			int start = 0;
			int end = _Count - 1;
			int index = -1;
			while(start <= end)
			{
				index = (start + end) / 2;
				if(_Buffer[index] == item)				goto CC_SORTED_LIST_INSERT;
				else if(_Buffer[index] > item)			end = index - 1;
				else									start = index + 1;
			}
			AssertIndex(index);
			if(_Buffer[index] < item) index++;
CC_SORTED_LIST_INSERT:
			MakeRoom(index, 1);
			_Buffer[index] = item;
			return index;
		}
	}

	bool Remove(const K& item)
	{
		int index = IndexOf(item);
		if(index >= 0 && index < _Count)
		{
			RemoveAt(index);
			return true;
		}
		else
		{
			return false;
		}
	}

	ICollection<T, K>& Wrap()const
	{
		return _Wrapper;
	}

protected:
	mutable _WRAPPER _Wrapper;
};

template<typename A, typename B>
void CopyToCollection(A& dst, const B& src, bool bAppend = false)
{
	if(!bAppend)
	{
		dst.Clear();
	}
	int count = src.Count();
	for(int i = 0; i < count; i++)
	{
		dst.Add(src.Get(i));
	}
}

template<typename A, typename B>
void CopyToArray(A& dst, const B& src, bool bAppend = false)
{
	int start = 0;
	int count = src.Count();
	if(bAppend)
	{
		start = dst.Count();
		dst.Resize(start + count);
	}
	else
	{
		dst.Resize(count);
	}
	for(int i = 0; i < count; i++)
	{
		dst[start + i] = src.Get(i);
	}
}

template<typename T, typename K = typename Type<T>::_Type>
class Stack : public NotCopyable
{
public:
	Stack() {}

	void Push(const T& item)
	{
		list.Insert(0, item);
	}

	T Pop()
	{
		ASSERT(!IsEmpty());
		T t = list[0];
		list.Wrap().RemoveAt(0);
		return t;
	}

	const T& Top() const
	{
		ASSERT(!IsEmpty());
		return list[0];
	}

	int Size() const
	{
		return list.Count();
	}

	bool IsEmpty() const
	{
		return list.Count() == 0;
	}

private:
	List<T, K> list;
};
COLLECTIONS_END_NAMESPACE

#endif