/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../core/cc_ListWrap.h

Class:
	ReadonlyListEnumerator							: ֻ���б�ö��
	ReadonlyListWrapper								: ֻ���б�����
	ArrayWrapper									: ���鸨��
	CollectionWrapper								: ���͸���
	ListWrapper										: �б�����

***********************************************************************/

#ifndef _CC_COLLECTIONS_LISTWRAP_H
#define _CC_COLLECTIONS_LISTWRAP_H

COLLECTIONS_BEGIN_NAMESPACE
namespace Wrap
{
	using namespace Interfaces;

	template<typename T, typename K = typename Type<T>::_Type>
	class ReadonlyListEnumerator : public Object, public virtual IEnumerator<T>
	{
	public:
		typedef const IReadonlyList<T, K>* _IReadonlyList;

		ReadonlyListEnumerator(_IReadonlyList Container, int Index):
		_Container(Container), _Index(Index)
		{

		}

		IEnumerator<T>* Clone() const
		{
			return new ReadonlyListEnumerator<T, K>(_Container, _Index);
		}

		const T& Current() const
		{
			return _Container->Get(_Index);
		}

		int Index() const
		{
			return _Index;
		}

		bool Next()
		{
			_Index++;
			return Available();
		}

		bool Available() const
		{
			return _Index >= 0 && _Index < _Container->Count();
		}

		void Reset()
		{
			_Index = 0;
		}

	private:
		_IReadonlyList			_Container;
		int						_Index;
	};

	template<typename C, typename T, typename K = typename Type<T>::_Type>
	class ReadonlyListWrapper : public Object, public virtual IReadonlyList<T, K>
	{
	public:
		ReadonlyListWrapper(C* Container = NULL): _Container(Container)
		{

		}

		C* GetContainer()
		{
			return _Container;
		}

		void SetContainer(C* Container)
		{
			_Container = Container;
		}

		IEnumerator<T>* CreateEnumerator() const
		{
			return new ReadonlyListEnumerator<T, K>(this, -1);
		}

		bool Contains(const K& item) const
		{
			return _Container->Contains(item);
		}

		int Count() const
		{
			return _Container->Count();
		}

		const T& Get(int index) const
		{
			return _Container->Get(index);
		}

		const T& operator[](int index) const
		{
			return _Container->operator[](index);
		}

		int IndexOf(const K& item) const
		{
			return _Container->IndexOf(item);
		}

	private:
		C* _Container;
	};

	template<typename C, typename T, typename K = typename Type<T>::_Type>
	class ArrayWrapper : public Object, public virtual IArray<T, K>
	{
	public:
		ArrayWrapper(C* Container = NULL): _Container(Container)
		{

		}

		C* GetContainer()
		{
			return _Container;
		}

		void SetContainer(C* Container)
		{
			_Container = Container;
		}

		IEnumerator<T>* CreateEnumerator() const
		{
			return new ReadonlyListEnumerator<T, K>(this, -1);
		}

		bool Contains(const K& item) const
		{
			return _Container->Contains(item);
		}

		int Count() const
		{
			return _Container->Count();
		}

		const T& Get(int index) const
		{
			return _Container->Get(index);
		}

		const T& operator[](int index) const
		{
			return _Container->operator[](index);
		}

		int IndexOf(const K& item) const
		{
			return _Container->IndexOf(item);
		}

		void Set(int index, const T& item)
		{
			_Container->Set(index, item);
		}

		void Resize(int size)
		{
			_Container->Resize(size);
		}

	private:
		C* _Container;
	};

	template<typename C, typename T, typename K = typename Type<T>::_Type>
	class CollectionWrapper : public Object, public virtual ICollection<T, K>
	{
	public:
		CollectionWrapper(C* Container = NULL): _Container(Container)
		{

		}

		C* GetContainer()
		{
			return _Container;
		}

		void SetContainer(C* Container)
		{
			_Container = Container;
		}

		IEnumerator<T>* CreateEnumerator() const
		{
			return new ReadonlyListEnumerator<T, K>(this, -1);
		}

		bool Contains(const K& item) const
		{
			return _Container->Contains(item);
		}

		int Count() const
		{
			return _Container->Count();
		}

		const T& Get(int index) const
		{
			return _Container->Get(index);
		}

		const T& operator[](int index) const
		{
			return _Container->operator[](index);
		}

		int IndexOf(const K& item) const
		{
			return _Container->IndexOf(item);
		}

		int Add(const T& item)
		{
			return _Container->Add(item);
		}

		bool Remove(const K& item)
		{
			return _Container->Remove(item);
		}

		bool RemoveAt(int index)
		{
			return _Container->RemoveAt(index);
		}

		bool RemoveRange(int index, int count)
		{
			return _Container->RemoveRange(index, count);
		}

		bool Clear()
		{
			return _Container->Clear();
		}

	private:
		C* _Container;
	};

	template<typename C, typename T, typename K = typename Type<T>::_Type>
	class ListWrapper : public Object, public virtual IList<T, K>
	{
	public:
		ListWrapper(C* Container = NULL): _Container(Container)
		{

		}

		C* GetContainer()
		{
			return _Container;
		}

		void SetContainer(C* Container)
		{
			_Container = Container;
		}

		IEnumerator<T>* CreateEnumerator() const
		{
			return new ReadonlyListEnumerator<T, K>(this, -1);
		}

		bool Contains(const K& item) const
		{
			return _Container->Contains(item);
		}

		int Count() const
		{
			return _Container->Count();
		}

		const T& Get(int index) const
		{
			return _Container->Get(index);
		}

		const T& operator[](int index) const
		{
			return _Container->operator[](index);
		}

		int IndexOf(const K& item) const
		{
			return _Container->IndexOf(item);
		}

		int Add(const T& item)
		{
			return _Container->Add(item);
		}

		bool Remove(const K& item)
		{
			return _Container->Remove(item);
		}

		bool RemoveAt(int index)
		{
			return _Container->RemoveAt(index);
		}

		bool RemoveRange(int index, int count)
		{
			return _Container->RemoveRange(index, count);
		}

		bool Clear()
		{
			return _Container->Clear();
		}

		int Insert(int index, const T& item)
		{
			return _Container->Insert(index, item);
		}

		bool Set(int index, const T& item)
		{
			return _Container->Set(index, item);
		}

	private:
		C* _Container;
	};

	template<typename C, typename T, typename K = typename Type<T>::_Type>
	class ReadonlyListImplBase : public virtual IReadonlyList<T, K>
	{
	public:
		IEnumerator<T>* CreateEnumerator() const
		{
			return new ReadonlyListEnumerator<T, K>(this, -1);
		}

		bool Contains(const K& item) const
		{
			return IndexOf(item) != -1;
		}

		const T& operator[](int index) const
		{
			return Get(index);
		}

		int IndexOf(const K& item) const
		{
			int count = Count();
			for(int i = 0; i < count; i++) if(Get(i) == item) return i;
			return -1;
		}
	};

	template<typename TS, typename TD, typename KS = typename Type<TS>::_Type, typename KD = typename Type<TD>::_Type>
	class ReadonlyListConverterBase : protected ReadonlyListImplBase<TD, KD>
	{
	protected:
		ReadonlyListConverterBase(): _Container(NULL)
		{

		}

		void SetContainer(IReadonlyList<TS, KS>* Container)
		{
			_Container = Container;
		}

		int Count() const
		{
			return _Container->Count();
		}

		const TD& Get(int index) const
		{
			return Convert(_Container->Get(index));
		}

		virtual const TD& Convert(const TS& value) const = 0;

	private:
		IReadonlyList<TS, KS>* _Container;
	};
}
COLLECTIONS_END_NAMESPACE

#endif