/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../regex/cc_RegexParser.h

Impl:
File:../regex/cc_RegexParser.cpp

***********************************************************************/

#include "stdafx.h"

REGEX_BEGIN_NAMESPACE

//////////////////////////////////////////////////////////////////////////

namespace regex_internal
{

	/***********************************************************************
	��������
	***********************************************************************/

	bool IsChar(const TCHAR*& input, TCHAR c)
	{
		if(*input==c)
		{
			input++;
			return true;
		}
		else
		{
			return false;
		}
	}

	bool IsChars(const TCHAR*& input, TCHAR* chars, TCHAR& c)
	{
		const TCHAR* position=_tcschr(chars, *input);
		if(position)
		{
			c=*input++;
			return true;
		}
		else
		{
			return false;
		}
	}

	bool IsStr(const TCHAR*& input, TCHAR* str)
	{
		size_t len=_tcslen(str);
		if(_tcsncmp(input, str, len)==0)
		{
			input+=len;
			return true;
		}
		else
		{
			return false;
		}
	}

	bool IsChars(const TCHAR*& input, TCHAR* chars)
	{
		TCHAR c;
		return IsChars(input, chars, c);
	}

	bool IsPositiveInteger(const TCHAR*& input, int& number)
	{
		bool readed=false;
		number=0;
		while(_T('0')<=*input && *input<=_T('9'))
		{
			number=number*10+(*input++)-_T('0');
			readed=true;
		}
		return readed;
	}

	bool IsName(const TCHAR*& input, String& name)
	{
		const TCHAR* read=input;
		if((_T('A')<=*read && *read<=_T('Z')) || (_T('a')<=*read && *read<=_T('z')) || *read==_T('_'))
		{
			read++;
			while((_T('A')<=*read && *read<=_T('Z')) || (_T('a')<=*read && *read<=_T('z')) || (_T('0')<=*read && *read<=_T('9')) || *read==_T('_'))
			{
				read++;
			}
		}
		if(input==read)
		{
			return false;
		}
		else
		{
			name=String(input, read-input);
			input=read;
			return true;
		}
	}

	AutoPtr<LoopExpression> ParseLoop(const TCHAR*& input)
	{
		int min=0;
		int max=0;
		if(!*input)
		{
			return 0;
		}
		else if(IsChar(input, _T('+')))
		{
			min=1;
			max=-1;
		}
		else if(IsChar(input, _T('*')))
		{
			min=0;
			max=-1;
		}
		else if(IsChar(input, _T('?')))
		{
			min=0;
			max=1;
		}
		else if(IsChar(input, _T('{')))
		{
			if(IsPositiveInteger(input, min))
			{
				if(IsChar(input, _T(',')))
				{
					if(!IsPositiveInteger(input, max))
					{
						max=-1;
					}
				}
				else
				{
					max=min;
				}
				if(!IsChar(input, _T('}')))
				{
					goto THROW_EXCEPTION;
				}
			}
			else
			{
				goto THROW_EXCEPTION;
			}
		}
		else
		{
			return 0;
		}
		LoopExpression* expression=new LoopExpression;
		expression->min=min;
		expression->max=max;
		expression->preferLong=!IsChar(input, _T('?'));
		return expression;
THROW_EXCEPTION:
		throw RegexException(_T("ѭ����ʽ���Ϸ�"));
	}

	AutoPtr<Expression> ParseCharSet(const TCHAR*& input)
	{
		if(!*input)
		{
			return 0;
		}
		else if(IsChar(input, _T('^')))
		{
			return new BeginExpression;
		}
		else if(IsChar(input, _T('$')))
		{
			return new EndExpression;
		}
		else if(IsChar(input, _T('\\')) || IsChar(input, _T('/')))
		{
			AutoPtr<CharSetExpression> expression=new CharSetExpression;
			expression->reverse=false;
			switch(*input)
			{
			case _T('.'):
				expression->ranges.Add(CharRange(1, 65535));
				break;
			case _T('r'):
				expression->ranges.Add(CharRange(_T('\r'), _T('\r')));
				break;
			case _T('n'):
				expression->ranges.Add(CharRange(_T('\n'), _T('\n')));
				break;
			case _T('t'):
				expression->ranges.Add(CharRange(_T('\t'), _T('\t')));
				break;
			case _T('\\'):case _T('/'):case _T('('):case _T(')'):case _T('+'):case _T('*'):case _T('?'):case _T('|'):
			case _T('{'):case _T('}'):case _T('['):case _T(']'):case _T('<'):case _T('>'):
			case _T('^'):case _T('$'):case _T('!'):case _T('='):
				expression->ranges.Add(CharRange(*input, *input));
				break;
			case _T('S'):
				expression->reverse=true;
			case _T('s'):
				expression->ranges.Add(CharRange(_T(' '), _T(' ')));
				expression->ranges.Add(CharRange(_T('\r'), _T('\r')));
				expression->ranges.Add(CharRange(_T('\n'), _T('\n')));
				expression->ranges.Add(CharRange(_T('\t'), _T('\t')));
				break;
			case _T('D'):
				expression->reverse=true;
			case _T('d'):
				expression->ranges.Add(CharRange(_T('0'), _T('9')));
				break;
			case _T('L'):
				expression->reverse=true;
			case _T('l'):
				expression->ranges.Add(CharRange(_T('_'), _T('_')));
				expression->ranges.Add(CharRange(_T('A'), _T('Z')));
				expression->ranges.Add(CharRange(_T('a'), _T('z')));
				break;
			case _T('W'):
				expression->reverse=true;
			case _T('w'):
				expression->ranges.Add(CharRange(_T('_'), _T('_')));
				expression->ranges.Add(CharRange(_T('0'), _T('9')));
				expression->ranges.Add(CharRange(_T('A'), _T('Z')));
				expression->ranges.Add(CharRange(_T('a'), _T('z')));
				break;
			default:
				throw RegexException(_T("�Ƿ�ת���ַ�"));
			}
			input++;
			return expression;
		}
		else if(IsChar(input, _T('[')))
		{
			AutoPtr<CharSetExpression> expression=new CharSetExpression;
			if(IsChar(input, _T('^')))
			{
				expression->reverse=true;
			}
			else
			{
				expression->reverse=false;
			}
			bool midState=false;
			TCHAR a=_T('\0');
			TCHAR b=_T('\0');
			while(true)
			{
				if(IsChar(input, _T('\\')) || IsChar(input, _T('/')))
				{
					TCHAR c=_T('\0');
					switch(*input)
					{
					case _T('r'):
						c=_T('\r');
						break;
					case _T('n'):
						c=_T('\n');
						break;
					case _T('t'):
						c=_T('\t');
						break;
					case _T('-'):case _T('['):case _T(']'):case _T('\\'):case _T('/'):case _T('^'):case _T('$'):
						c=*input;
						break;
					default:
						throw RegexException(_T("��[]�ڲ���ʹ�õ�ת���ַ�ֻ�У�\"rnt-[]\\/\""));
					}
					input++;
					midState?b=c:a=c;
					midState=!midState;
				}
				else if(IsChars(input, _T("-]")))
				{
					goto THROW_EXCEPTION;
				}
				else if(*input)
				{
					midState?b=*input++:a=*input++;
					midState=!midState;
				}
				else
				{
					goto THROW_EXCEPTION;
				}
				if(IsChar(input, _T(']')))
				{
					if(midState)
					{
						b=a;
					}
					if(!expression->AddRangeWithConflict(CharRange(a, b)))
					{
						goto THROW_EXCEPTION;
					}
					break;
				}
				else if(IsChar(input, _T('-')))
				{
					if(!midState)
					{
						goto THROW_EXCEPTION;
					}
				}
				else
				{
					if(midState)
					{
						b=a;
					}
					if(expression->AddRangeWithConflict(CharRange(a, b)))
					{
						midState=false;
					}
					else
					{
						goto THROW_EXCEPTION;
					}
				}
			}
			return expression;
THROW_EXCEPTION:
			throw RegexException(_T("�ַ�����ʽ���Ϸ�"));
		}
		else if(IsChars(input, _T("()+*?{}|")))
		{
			input--;
			return 0;
		}
		else
		{
			CharSetExpression* expression=new CharSetExpression;
			expression->reverse=false;
			expression->ranges.Add(CharRange(*input, *input));
			input++;
			return expression;
		}
	}

	AutoPtr<Expression> ParseFunction(const TCHAR*& input)
	{
		if(IsStr(input, _T("(=")))
		{
			AutoPtr<Expression> sub=ParseExpression(input);
			if(!IsChar(input, _T(')')))
			{
				goto NEED_RIGHT_BRACKET;
			}
			PositiveExpression* expression=new PositiveExpression;
			expression->expression=sub;
			return expression;
		}
		else if(IsStr(input, _T("(!")))
		{
			AutoPtr<Expression> sub=ParseExpression(input);
			if(!IsChar(input, _T(')')))
			{
				goto NEED_RIGHT_BRACKET;
			}
			NegativeExpression* expression=new NegativeExpression;
			expression->expression=sub;
			return expression;
		}
		else if(IsStr(input, _T("(<&")))
		{
			String name;
			if(!IsName(input, name))
			{
				goto NEED_NAME;
			}
			if(!IsChar(input, _T('>')))
			{
				goto NEED_GREATER;
			}
			if(!IsChar(input, _T(')')))
			{
				goto NEED_RIGHT_BRACKET;
			}
			UsingExpression* expression=new UsingExpression;
			expression->name=name;
			return expression;
		}
		else if(IsStr(input, _T("(<$")))
		{
			String name;
			int index=-1;
			if(IsName(input, name))
			{
				if(IsChar(input, _T(';')))
				{
					if(!IsPositiveInteger(input, index))
					{
						goto NEED_NUMBER;
					}
				}
			}
			else if(!IsPositiveInteger(input, index))
			{
				goto NEED_NUMBER;
			}
			if(!IsChar(input, _T('>')))
			{
				goto NEED_GREATER;
			}
			if(!IsChar(input, _T(')')))
			{
				goto NEED_RIGHT_BRACKET;
			}
			MatchExpression* expression=new MatchExpression;
			expression->name=name;
			expression->index=index;
			return expression;
		}
		else if(IsStr(input, _T("(<")))
		{
			String name;
			if(!IsName(input, name))
			{
				goto NEED_NAME;
			}
			if(!IsChar(input, _T('>')))
			{
				goto NEED_GREATER;
			}
			AutoPtr<Expression> sub=ParseExpression(input);
			if(!IsChar(input, _T(')')))
			{
				goto NEED_RIGHT_BRACKET;
			}
			CaptureExpression* expression=new CaptureExpression;
			expression->name=name;
			expression->expression=sub;
			return expression;
		}
		else if(IsStr(input, _T("(?")))
		{
			AutoPtr<Expression> sub=ParseExpression(input);
			if(!IsChar(input, _T(')')))
			{
				goto NEED_RIGHT_BRACKET;
			}
			CaptureExpression* expression=new CaptureExpression;
			expression->expression=sub;
			return expression;
		}
		else if(IsChar(input, _T('(')))
		{
			AutoPtr<Expression> sub=ParseExpression(input);
			if(!IsChar(input, _T(')')))
			{
				goto NEED_RIGHT_BRACKET;
			}
			return sub;
		}
		else
		{
			return 0;
		}
NEED_RIGHT_BRACKET:
		throw RegexException(_T("ȱ����С����\")\""));
NEED_GREATER:
		throw RegexException(_T("ȱ���Ҽ�����\">\""));
NEED_NAME:
		throw RegexException(_T("ȱ�ٱ�ʶ��"));
NEED_NUMBER:
		throw RegexException(_T("ȱ������"));
	}

	AutoPtr<Expression> ParseUnit(const TCHAR*& input)
	{
		AutoPtr<Expression> unit=ParseCharSet(input);
		if(!unit)
		{
			unit=ParseFunction(input);
		}
		if(!unit)
		{
			return 0;
		}
		AutoPtr<LoopExpression> loop;
		while(loop=ParseLoop(input))
		{
			loop->expression=unit;
			unit=loop;
		}
		return unit;
	}

	AutoPtr<Expression> ParseJoin(const TCHAR*& input)
	{
		AutoPtr<Expression> expression=ParseUnit(input);
		while(true)
		{
			AutoPtr<Expression> right=ParseUnit(input);
			if(right)
			{
				SequenceExpression* sequence=new SequenceExpression;
				sequence->left=expression;
				sequence->right=right;
				expression=sequence;
			}
			else
			{
				break;
			}
		}
		return expression;
	}

	AutoPtr<Expression> ParseAlt(const TCHAR*& input)
	{
		AutoPtr<Expression> expression=ParseJoin(input);
		while(true)
		{
			if(IsChar(input, _T('|')))
			{
				AutoPtr<Expression> right=ParseJoin(input);
				if(right)
				{
					AlternateExpression* alternate=new AlternateExpression;
					alternate->left=expression;
					alternate->right=right;
					expression=alternate;
				}
				else
				{
					throw RegexException(_T("ȱ�ٱ���ʽ"));
				}
			}
			else
			{
				break;
			}
		}
		return expression;
	}

	AutoPtr<Expression> ParseExpression(const TCHAR*& input)
	{
		return ParseAlt(input);
	}

	RegexExpression::Ref ParseRegexExpression(const String& code)
	{
		RegexExpression::Ref regex=new RegexExpression;
		const TCHAR* start=code.Buffer();
		const TCHAR* input=start;
		try
		{
			while(IsStr(input, _T("(<#")))
			{
				String name;
				if(!IsName(input, name))
				{
					throw RegexException(_T("ȱ�ٱ�ʶ��"));
				}
				if(!IsChar(input, _T('>')))
				{
					throw RegexException(_T("ȱ���Ҽ�����\">\""));
				}
				AutoPtr<Expression> sub=ParseExpression(input);
				if(!IsChar(input, _T(')')))
				{
					throw RegexException(_T("ȱ����С����\")\""));
				}
				if(regex->definitions.Keys().Contains(name))
				{
					throw RegexException(_T("�ӱ���ʽ�����ظ�����"));
				}
				else
				{
					regex->definitions.Add(name, sub);
				}
			}
			regex->expression=ParseExpression(input);
			if(!regex->expression)
			{
				throw RegexException(_T("ȱ�ٱ���ʽ"));
			}
			if(*input)
			{
				throw RegexException(_T("��������ķ���"));
			}
			return regex;
		}
		catch(const RegexException& e)
		{
			throw Exception(e);
		}
	}
}

REGEX_END_NAMESPACE