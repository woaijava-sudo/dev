/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../regex/cc_RegexData.h

Impl:
File:../regex/cc_RegexData.cpp

***********************************************************************/

#include "stdafx.h"

REGEX_BEGIN_NAMESPACE

//////////////////////////////////////////////////////////////////////////

namespace regex_internal
{

	/***********************************************************************
	CharRange
	***********************************************************************/

	CharRange::CharRange()
		:begin(_T('\0'))
		,end(_T('\0'))
	{
	}

	CharRange::CharRange(TCHAR _begin, TCHAR _end)
		:begin(_begin)
		,end(_end)
	{
	}

	bool CharRange::operator<(CharRange item)const
	{
		return end<item.begin;
	}

	bool CharRange::operator<=(CharRange item)const
	{
		return *this<item || *this==item;
	}

	bool CharRange::operator>(CharRange item)const
	{
		return item.end<begin;
	}

	bool CharRange::operator>=(CharRange item)const
	{
		return *this>item || *this==item;
	}

	bool CharRange::operator==(CharRange item)const
	{
		return begin==item.begin && end==item.end;
	}

	bool CharRange::operator!=(CharRange item)const
	{
		return begin!=item.begin || item.end!=end;
	}

	bool CharRange::operator<(TCHAR item)const
	{
		return end<item;
	}

	bool CharRange::operator<=(TCHAR item)const
	{
		return begin<=item;
	}

	bool CharRange::operator>(TCHAR item)const
	{
		return item<begin;
	}

	bool CharRange::operator>=(TCHAR item)const
	{
		return item<=end;
	}

	bool CharRange::operator==(TCHAR item)const
	{
		return begin<=item && item<=end;
	}

	bool CharRange::operator!=(TCHAR item)const
	{
		return item<begin || end<item;
	}

}

REGEX_END_NAMESPACE