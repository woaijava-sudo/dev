/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../regex/cc_RegexPure.h

Impl:
File:../regex/cc_RegexPure.cpp

Classes:
	PureInterpretor					���������ʽ��ģ����

***********************************************************************/

#ifndef _CC_REGEX_REGEXPURE_H
#define _CC_REGEX_REGEXPURE_H

REGEX_BEGIN_NAMESPACE

//////////////////////////////////////////////////////////////////////////

namespace regex_internal
{
	class CL_API PureResult
	{
	public:
		int				start;
		int				length;
		int				finalState;
	};

	class CL_API PureInterpretor : public Object
	{
	protected:
		int					charMap[1<<(8*sizeof(TCHAR))];	//char -> char set index
		int**				transition;							//(state * char set index) -> state*
		bool*				finalState;							//state -> bool
		int					stateCount;
		int					charSetCount;
		int					startState;
	public:
		PureInterpretor(Automaton::Ref dfa, CharRange::List& subsets);
		~PureInterpretor();

		bool				MatchHead(const TCHAR* input, const TCHAR* start, PureResult& result);
		bool				Match(const TCHAR* input, const TCHAR* start, PureResult& result);
	};
}

REGEX_END_NAMESPACE

#endif