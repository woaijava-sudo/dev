/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../regex/cc_RegexPure.h

Impl:
File:../regex/cc_RegexPure.cpp

Classes:
	PureInterpretor					���������ʽ��ģ����

***********************************************************************/

#include "stdafx.h"

REGEX_BEGIN_NAMESPACE

//////////////////////////////////////////////////////////////////////////

namespace regex_internal
{

	/***********************************************************************
	PureInterpretor
	***********************************************************************/

	PureInterpretor::PureInterpretor(Automaton::Ref dfa, CharRange::List& subsets)
	{
		stateCount=dfa->states.Count();
		charSetCount=subsets.Count()+1;
		startState=dfa->states.IndexOf(dfa->startState);

		//����ַ�ӳ���
		for(int i=0;i<sizeof(charMap)/sizeof(*charMap);i++)
		{
			charMap[i]=charSetCount-1;
		}
		for(int i=0;i<subsets.Count();i++)
		{
			CharRange range=subsets[i];
			for(int j=range.begin;j<=range.end;j++)
			{
				charMap[j]=i;
			}
		}

		//����״̬ת����
		transition=new int*[stateCount];
		for(int i=0;i<stateCount;i++)
		{
			transition[i]=new int[charSetCount];
			for(int j=0;j<charSetCount;j++)
			{
				transition[i][j]=-1;
			}

			State* state=dfa->states[i].Obj();
			for(int j=0;j<state->transitions.Count();j++)
			{
				Transition* dfaTransition=state->transitions[j];
				switch(dfaTransition->type)
				{
				case Transition::Chars:
					{
						int index=subsets.IndexOf(dfaTransition->range);
						if(index==-1)
						{
							ASSERT(NULL); //ָ�����ַ���ת��û�г��������滯���ַ�������ϡ�
						}
						transition[i][index]=dfa->states.IndexOf(dfaTransition->target);
					}
					break;
				default:
					ASSERT(NULL); //ֻ����Transition::Charsת����;
				}
			}
		}

		//����ս�״̬��
		finalState=new bool[stateCount];
		for(int i=0;i<stateCount;i++)
		{
			finalState[i]=dfa->states[i]->finalState;
		}
	}

	PureInterpretor::~PureInterpretor()
	{
		delete[] finalState;
		for(int i=0;i<stateCount;i++)
		{
			delete[] transition[i];
		}
		delete[] transition;
	}

	bool PureInterpretor::MatchHead(const TCHAR* input, const TCHAR* start, PureResult& result)
	{
		result.start=input-start;
		result.length=-1;
		result.finalState=-1;

		int currentState=startState;
		const TCHAR* read=input;
		while(currentState!=-1)
		{
			if(finalState[currentState])
			{
				result.length=read-input;
				result.finalState=currentState;
			}
			if(!*read)break;
			int charIndex=charMap[*read++];
			currentState=transition[currentState][charIndex];
		}

		return result.finalState!=-1;
	}

	bool PureInterpretor::Match(const TCHAR* input, const TCHAR* start, PureResult& result)
	{
		const TCHAR* read=input;
		while(*read)
		{
			if(MatchHead(read, start, result))
			{
				return true;
			}
			read++;
		}
		return false;
	}
}

REGEX_END_NAMESPACE