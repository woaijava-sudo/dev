/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../regex/cc_RegexAutomaton.h

Impl:
File:../regex/cc_RegexAutomaton.cpp


Classes:
	State						��״̬
	Transition					��ת��
	Automaton					��״̬��

Functions:
	EpsilonNfaToNfa				��ȥEpsilon
	NfaToDfa					��NFAתDFA

***********************************************************************/

#ifndef _CC_REGEX_REGEXAUTOMATON_H
#define _CC_REGEX_REGEXAUTOMATON_H

REGEX_BEGIN_NAMESPACE

//////////////////////////////////////////////////////////////////////////
	
namespace regex_internal
{
	class State;
	class Transition;

	class CL_API Transition
	{
	public:
		enum Type
		{
			Chars,				//rangeΪ�ַ���Χ
			Epsilon,
			BeginString,
			EndString,
			Nop,				//�޶�������������epsilon�������������ȼ���
			Capture,			//captureΪ����Ƶ��
			Match,				//captureΪ����Ƶ����indexΪƥ���λ�ã�-1����ƥ��Ƶ�������������Ŀ
			Positive,			//����ƥ��
			Negative,			//����ƥ��
			NegativeFail,		//����ƥ��ʧ��
			End					//Capture, Position, Negative
		};

		State*					source;
		State*					target;
		CharRange				range;
		Type					type;
		int						capture;
		int						index;
	};

	DEF_AUTO_PTR(State);
	DEF_AUTO_PTR(Transition);

	DEF_LIST_TEMPLATE1(Transition*);
	DEF_LIST_TEMPLATE1(AutoPtr<State>);
	DEF_LIST_TEMPLATE1(AutoPtr<Transition>);

	class CL_API State
	{
	public:
		List<Transition*>		transitions;
		List<Transition*>		inputs;
		bool					finalState;
		void*					userData;
	};

	class CL_API Automaton
	{
	public:
		typedef AutoPtr<Automaton>	Ref;

		List<AutoPtr<State>>		states;
		List<AutoPtr<Transition>>	transitions;
		List<String>			captureNames;
		State*					startState;

		Automaton();

		State*					NewState();
		Transition*				NewTransition(State* start, State* end);
		Transition*				NewChars(State* start, State* end, CharRange range);
		Transition*				NewEpsilon(State* start, State* end);
		Transition*				NewBeginString(State* start, State* end);
		Transition*				NewEndString(State* start, State* end);
		Transition*				NewNop(State* start, State* end);
		Transition*				NewCapture(State* start, State* end, int capture);
		Transition*				NewMatch(State* start, State* end, int capture, int index=-1);
		Transition*				NewPositive(State* start, State* end);
		Transition*				NewNegative(State* start, State* end);
		Transition*				NewNegativeFail(State* start, State* end);
		Transition*				NewEnd(State* start, State* end);
	};

	DEF_AUTO_PTR(Automaton);

	extern bool				CL_API	PureEpsilonChecker(Transition* transition);
	extern bool				CL_API	RichEpsilonChecker(Transition* transition);
	extern bool				CL_API	AreEqual(Transition* transA, Transition* transB);
	extern Automaton::Ref	CL_API	EpsilonNfaToNfa(Automaton::Ref source, bool(*epsilonChecker)(Transition*), Dictionary<State*, State*>& nfaStateMap);
	extern Automaton::Ref	CL_API	NfaToDfa(Automaton::Ref source, Group<State*, State*>& dfaStateMap);
}

REGEX_END_NAMESPACE

#endif