/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../regex/cc_RegexData.h

Impl:
File:../regex/cc_RegexData.cpp

***********************************************************************/

#ifndef _CC_REGEX_REGEXDATA_H
#define _CC_REGEX_REGEXDATA_H

REGEX_BEGIN_NAMESPACE

//////////////////////////////////////////////////////////////////////////

namespace regex_internal
{
	using namespace Collections;

	/***********************************************************************
	�������ݽṹ
	***********************************************************************/

	class CL_API CharRange
	{
	public:
		typedef SortedList<CharRange>			List;

		TCHAR					begin;
		TCHAR					end;

		CharRange();
		CharRange(TCHAR _begin, TCHAR _end);

		bool					operator<(CharRange item)const;
		bool					operator<=(CharRange item)const;
		bool					operator>(CharRange item)const;
		bool					operator>=(CharRange item)const;
		bool					operator==(CharRange item)const;
		bool					operator!=(CharRange item)const;

		bool					operator<(TCHAR item)const;
		bool					operator<=(TCHAR item)const;
		bool					operator>(TCHAR item)const;
		bool					operator>=(TCHAR item)const;
		bool					operator==(TCHAR item)const;
		bool					operator!=(TCHAR item)const;
	};

	DEF_SORT_LIST1(CharRange);
}

REGEX_END_NAMESPACE

#endif