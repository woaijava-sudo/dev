/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../regex/cc_RegexWriter.h

Impl:
File:../regex/cc_RegexWriter.cpp

***********************************************************************/

#include "stdafx.h"

REGEX_BEGIN_NAMESPACE

//////////////////////////////////////////////////////////////////////////

using namespace regex_internal;
using namespace Enumerator::Internal;

/***********************************************************************
RegexNode
***********************************************************************/

RegexNode::RegexNode(regex_internal::Expression::Ref _expression)
	:expression(_expression)
{
}

RegexNode RegexNode::Some()const
{
	return Loop(1, -1);
}

RegexNode RegexNode::Any()const
{
	return Loop(0, -1);
}

RegexNode RegexNode::Opt()const
{
	return Loop(0, 1);
}

RegexNode RegexNode::Loop(int min, int max)const
{
	LoopExpression* target=new LoopExpression;
	target->min=min;
	target->max=max;
	target->preferLong=true;
	target->expression=expression;
	return RegexNode(target);
}

RegexNode RegexNode::AtLeast(int min)const
{
	return Loop(min, -1);
}

RegexNode RegexNode::operator+(const RegexNode& node)const
{
	SequenceExpression* target=new SequenceExpression;
	target->left=expression;
	target->right=node.expression;
	return RegexNode(target);
}

RegexNode RegexNode::operator|(const RegexNode& node)const
{
	AlternateExpression* target=new AlternateExpression;
	target->left=expression;
	target->right=node.expression;
	return RegexNode(target);
}

RegexNode RegexNode::operator+()const
{
	PositiveExpression* target=new PositiveExpression;
	target->expression=expression;
	return RegexNode(target);
}

RegexNode RegexNode::operator-()const
{
	NegativeExpression* target=new NegativeExpression;
	target->expression=expression;
	return RegexNode(target);
}

RegexNode RegexNode::operator!()const
{
	CharSetExpression* source=dynamic_cast<CharSetExpression*>(expression.Obj());
	ASSERT(source); //������ֻ��ʹ�����ַ����ϱ���ʽ�ϡ�
	AutoPtr<CharSetExpression> target=new CharSetExpression;
	CopyFrom(target->ranges.Wrap(), source->ranges.Wrap());
	target->reverse=!source->reverse;
	return RegexNode(target);
}

RegexNode RegexNode::operator%(const RegexNode& node)const
{
	CharSetExpression* left=dynamic_cast<CharSetExpression*>(expression.Obj());
	CharSetExpression* right=dynamic_cast<CharSetExpression*>(node.expression.Obj());
	ASSERT(left && right && !left->reverse && !right->reverse); //�Ƿ�ת�ַ����ϱ���ʽ����ʹ��%���������ӡ�
	AutoPtr<CharSetExpression> target=new CharSetExpression;
	target->reverse=false;
	CopyFrom(target->ranges.Wrap(), left->ranges.Wrap());
	for(int i=0;i<right->ranges.Count();i++)
	{
		if(!target->AddRangeWithConflict(right->ranges[i]))
		{
			ASSERT(NULL); //�ں��ַ�����ʧ��
		}
	}
	return RegexNode(target);
}

/***********************************************************************
�ⲿ����
***********************************************************************/

RegexNode rCapture(const String& name, const RegexNode& node)
{
	CaptureExpression* target=new CaptureExpression;
	target->name=name;
	target->expression=node.expression;
	return RegexNode(target);
}

RegexNode rUsing(const String& name)
{
	UsingExpression* target=new UsingExpression;
	target->name=name;
	return RegexNode(target);
}

RegexNode rMatch(const String& name, int index)
{
	MatchExpression* target=new MatchExpression;
	target->name=name;
	target->index=index;
	return RegexNode(target);
}

RegexNode rMatch(int index)
{
	MatchExpression* target=new MatchExpression;
	target->index=index;
	return RegexNode(target);
}

RegexNode rBegin()
{
	return RegexNode(new BeginExpression);
}

RegexNode rEnd()
{
	return RegexNode(new EndExpression);
}

RegexNode rC(TCHAR a, TCHAR b)
{
	if(!b)b=a;
	CharSetExpression* target=new CharSetExpression;
	target->reverse=false;
	target->AddRangeWithConflict(CharRange(a, b));
	return RegexNode(target);
}

RegexNode r_d()
{
	return rC(_T('0'), _T('9'));
}

RegexNode r_l()
{
	return rC(_T('a'), _T('z'))%rC(_T('A'), _T('Z'))%rC(_T('_'));
}

RegexNode r_w()
{
	return rC(_T('0'), _T('9'))%rC(_T('a'), _T('z'))%rC(_T('A'), _T('Z'))%rC(_T('_'));
}

RegexNode rAnyChar()
{
	return rC(1, 65535);
}

REGEX_END_NAMESPACE