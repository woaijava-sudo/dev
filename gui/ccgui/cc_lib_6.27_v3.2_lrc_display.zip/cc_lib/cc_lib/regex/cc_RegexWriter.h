/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../regex/cc_RegexWriter.h

Impl:
File:../regex/cc_RegexWriter.cpp

***********************************************************************/

#ifndef _CC_REGEX_REGEXWRITER_H
#define _CC_REGEX_REGEXWRITER_H

REGEX_BEGIN_NAMESPACE

//////////////////////////////////////////////////////////////////////////

DEF_AUTO_PTR(Expression);

using namespace regex_internal;

class CL_API RegexNode : public Object
{
public:
	Expression::Ref expression;

	RegexNode(Expression::Ref _expression);

	RegexNode					Some()const;
	RegexNode					Any()const;
	RegexNode					Opt()const;
	RegexNode					Loop(int min, int max)const;
	RegexNode					AtLeast(int min)const;
	RegexNode					operator+(const RegexNode& node)const;
	RegexNode					operator|(const RegexNode& node)const;
	RegexNode					operator+()const;
	RegexNode					operator-()const;
	RegexNode					operator!()const;
	RegexNode					operator%(const RegexNode& node)const;
};

extern RegexNode CL_API				rCapture(const String& name, const RegexNode& node);
extern RegexNode CL_API				rUsing(const String& name);
extern RegexNode CL_API				rMatch(const String& name, int index=-1);
extern RegexNode CL_API				rMatch(int index);
extern RegexNode CL_API				rBegin();
extern RegexNode CL_API				rEnd();
extern RegexNode CL_API				rC(TCHAR a, TCHAR b=_T('\0'));
extern RegexNode CL_API				r_d();
extern RegexNode CL_API				r_l();
extern RegexNode CL_API				r_w();
extern RegexNode CL_API				rAnyChar();

REGEX_END_NAMESPACE

#endif