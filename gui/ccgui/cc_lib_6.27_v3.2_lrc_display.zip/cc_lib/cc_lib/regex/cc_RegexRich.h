/***********************************************************************

			|-----------------------------------|
			|									|
			|	Project:		>>>	cc_lib		|
			|	Developer:		>>>	bajdcc		|
			|									|
			|-----------------------------------|

Decl:
File:../regex/cc_RegexRich.h

Impl:
File:../regex/cc_RegexRich.cpp

Classes:
	RichInterpretor					���������ʽ��ȫģ����

***********************************************************************/

#ifndef _CC_REGEX_REGEXRICH_H
#define _CC_REGEX_REGEXRICH_H

REGEX_BEGIN_NAMESPACE

//////////////////////////////////////////////////////////////////////////

namespace regex_internal
{
	class CL_API CaptureRecord
	{
	public:
		int								capture;
		int								start;
		int								length;

		bool							operator==(const CaptureRecord& record)const;
	};
}

namespace regex_internal
{
	DEF_LIST_TEMPLATE1(CaptureRecord);

	class CL_API RichResult
	{
	public:
		int							start;
		int							length;
		List<CaptureRecord>			captures;
	};

	class CL_API RichInterpretor : public Object
	{
	public:
	protected:
		class UserData
		{
		public:
			bool						NeedKeepState;
		};

		Automaton::Ref					dfa;
		UserData*						datas;
	public:
		RichInterpretor(Automaton::Ref _dfa);
		~RichInterpretor();

		bool							MatchHead(const TCHAR* input, const TCHAR* start, RichResult& result);
		bool							Match(const TCHAR* input, const TCHAR* start, RichResult& result);
		const IReadonlyList<String>&	CaptureNames();
	};
};

REGEX_END_NAMESPACE

#endif