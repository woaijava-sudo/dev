#ifndef _CC_UI_MARKUP_NODE_H
#define _CC_UI_MARKUP_NODE_H

#pragma once

UI_BEGIN_NAMESPACE
class XMarkup;

struct XML_ELEMENT
{
    XML_ELEMENT(): iStart(0UL), iChild(0UL), iNext(0UL), iParent(0UL), iData(0UL) {}
    pos_t iStart;
    pos_t iChild;
    pos_t iNext;
    pos_t iParent;
    pos_t iData;
};

struct XML_ATTRIBUTE
{
    XML_ATTRIBUTE(): iName(0UL), iValue(0UL) {}
    pos_t iName;
    pos_t iValue;
};

DEF_LIST_TEMPLATE1(XML_ELEMENT*);

class XMarkupNode
{
public:
    XMarkupNode( XMarkup* pOwner = NULL, pos_t iPos = 0, List<XML_ELEMENT*>* pList = NULL, LPTSTR pstrText = NULL );
    ~XMarkupNode();

public:
    bool IsValid() const;
    void Release();

    XMarkupNode GetParent();
    XMarkupNode GetSibling();
    XMarkupNode GetChild();
    XMarkupNode GetChild( LPCTSTR pstrName );

    bool        HasSiblings();
    bool        HasChildren();
    XString     GetName();
    XString     GetValue();

    bool        HasAttributes();
    bool        HasAttribute( LPCTSTR pstrName );
    int         GetAttributeCount();
    XString     GetAttributeName( int iIndex );
    XString     GetAttributeValue( int iIndex );
    XString     GetAttributeValue( LPCTSTR pstrName );

    XMarkupNode& operator = (const XMarkupNode& node);

private:
    void                _MapAttributes();
    XML_ATTRIBUTE*      _GetNewAttribute(); // Dynamic create
    void                _ReleaseNewAttribute(); // Dynamic delete latest
    const XML_ELEMENT*  _GetElement();
    const XML_ELEMENT*  _GetElement(int iIndex);

private:
    pos_t                 m_iPos;
    List<XML_ELEMENT*>*   m_pElements;
    List<XML_ATTRIBUTE*>  m_aAttributes; // Array saved new ptr
    XMarkup*            m_pOwner;
    LPTSTR              m_pstrText;
    const XML_ELEMENT*  m_pEle;
};

UI_END_NAMESPACE
#endif