#include "stdafx.h"

CONTROLS_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS_WITH_PARA(XListHeaderItem, XLabel)
X_IMPLEMENT_CLASS_WITH_PARA(XListFooterItem, XLabel)
//////////////////////////////////////////////////////////////////////////

XListHeaderItem::XListHeaderItem( XObject* pOb /*= NULL*/ ): XLabel(pOb), m_uDragState(0)
{
    m_flags |= XFLAG_SETCURSOR;
    m_uTextStyle |= DT_VCENTER;
}

void* XListHeaderItem::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_LIST_HEADER_ITEM: return this;
    }
    return XLabel::GetInterface(hi);
}

void XListHeaderItem::SetText( LPCTSTR pstrText )
{
    XControl::SetText(pstrText);
    Invalidate();
}

void XListHeaderItem::Event( TEvent& event )
{
    ASSERT(m_pWindow);
    switch ( event.msg.message )
    {
    case WM_LBUTTONDOWN:
        if (m_bEnabled)
        {
            XRect rcSeparator = GetThumbRect(m_rcClient);
            if( rcSeparator.PtInRect(event.msg.pt) ) {
                m_uDragState |= XSTATE_CAPTURED;
                m_ptLastMouse = event.msg.pt;
                m_pWindow->SendAsyncNotify(this, (DWORD) _T("HeaderDragging"), TRUE);
            } else {
                m_pWindow->SendAsyncNotify(this, (DWORD) _T("HeaderClick"), TRUE);
            }
        }
        break;
    case WM_LBUTTONUP:
        if( (m_uDragState & XSTATE_CAPTURED) != 0 ) {
            m_uDragState &= ~XSTATE_CAPTURED;
            m_pWindow->SendAsyncNotify(this, (DWORD) _T("HeaderDragged"), TRUE);
            GetParents(2)->NeedUpdate();
        }
        break;
    case WM_MOUSEMOVE:
        if( (m_uDragState & XSTATE_CAPTURED) != 0 ) {
            XRect rc = m_rcClient;
            LONG cxFixed = event.msg.pt.x - m_ptLastMouse.x;
            rc.right += cxFixed;
            if (GetIListHeader(m_pParent)->AllowFixedWidth(cxFixed))
            {
                int width = rc.Width();
                if( width > MIN_DRAGSIZE ) {
                    if (width > CalcSize().cx)
                    {
                        SetRect(rc);
                        m_ptLastMouse = event.msg.pt;
                        SetFixedWidth(width);
                        GetParents(2)->NeedUpdate();
                    }
                }
            }
        }
        break;
    case WM_SETCURSOR:
        if( m_bEnabled && GetThumbRect(m_rcClient).PtInRect(event.msg.pt) ) {
            ::SetCursor(::LoadCursor(NULL, MAKEINTRESOURCE(IDC_SIZEWE)));
            return;
        }
        break;
    }
    XControl::Event(event);
}

XSize XListHeaderItem::CalcSize()
{
    XRect rt;
    Rendering::X_DrawTextCalcRect(m_pWindow, rt, m_szText, m_pWindow->GetFontByHash(m_szFontHash), m_uTextStyle | DT_SINGLELINE);
    XSize sz = rt.Size();
    sz.cx += 14;
    return sz;
}

void XListHeaderItem::SetFixedWidth( int cxFixedWidth )
{
    int fixedWidth = max(cxFixedWidth, CalcSize().cx);
    IFixedWidthImpl::SetFixedWidth(fixedWidth);
}

void XListHeaderItem::Paint( HDC hDC, const XRect& rcPaint )
{
    if ( !m_rcPaint.IntersectRect(&rcPaint, &m_rcClient) ) return;

    XRect rcMessage = m_rcClient;
    rcMessage.left += 6;
    rcMessage.bottom -= 1;

    Rendering::X_DrawText(hDC, m_pWindow, rcMessage, m_szText, XCOLOR_HEADER_TEXT, m_pWindow->GetFontByHash(m_szFontHash), m_uTextStyle | DT_SINGLELINE);

    XPoint ptTemp;
    XRect rcThumb = GetThumbRect(m_rcClient);
    XRect rc1(rcThumb.left + 2, rcThumb.top + 4, rcThumb.left + 2, rcThumb.bottom - 1);
    Rendering::X_DrawLine(hDC, rc1.TopLeft(), rc1.BottomRight(), PS_SOLID, 1, XCOLOR_HEADER_SEPARATOR);
    XRect rc2(rcThumb.left + 3, rcThumb.top + 4, rcThumb.left + 3, rcThumb.bottom - 1);
    Rendering::X_DrawLine(hDC, rc2.TopLeft(), rc2.BottomRight(), PS_SOLID, 1, XCOLOR_STANDARD_WHITE);
}

XRect XListHeaderItem::GetThumbRect( const XRect & rc ) const
{
    return XRect(rc.right - 4, rc.top, rc.right + 4, rc.bottom);
}

XSize XListHeaderItem::EstimateSize( const XSize& )
{
    ASSERT_VALID(m_pWindow);
    return XSize(GetFixedWidth(), 14 + m_pWindow->GetFontInfoByHash(m_szFontHash)->tm.tmHeight);
}

//////////////////////////////////////////////////////////////////////////

XListFooterItem::XListFooterItem( XObject* pOb /*= NULL*/ ): XLabel(pOb)
{
    m_bPrintBk = FALSE;
    m_uTextStyle |= DT_VCENTER;
}

void* XListFooterItem::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_LIST_FOOTER_ITEM: return this;
    }
    return XLabel::GetInterface(hi);
}

void XListFooterItem::SetText( LPCTSTR pstrText )
{
    XControl::SetText(pstrText);
    Invalidate();
}

XSize XListFooterItem::EstimateSize( const XSize& )
{
    ASSERT_VALID(m_pWindow);
    return XSize(GetFixedWidth(), 14 + m_pWindow->GetFontInfoByHash(m_szFontHash)->tm.tmHeight);
}

CONTROLS_END_NAMESPACE