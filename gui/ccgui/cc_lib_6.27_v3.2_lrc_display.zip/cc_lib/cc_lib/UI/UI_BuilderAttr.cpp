#include "stdafx.h"
#include "UI_Builder.h"

#define MAP_TEXT_CONTAINER_BASE 0x2000
#define MAP_TEXT_CONTAINER_KEY  _T("Text")

UI_BEGIN_NAMESPACE
// ��ʼ�����Ա�
void XBuilder::_InitAttrMap()
{
    if (!m_mapAttributes.IsEmpty()) return;

#define MAP_ATTR_INIT(_String, _ID) m_mapAttributes.Set(_T(_String), _ID);

    // Base control attributes
    MAP_ATTR_INIT("Name", 0x100);
    MAP_ATTR_INIT("Text", 0x101);
    MAP_ATTR_INIT("Font", 0x102);
    MAP_ATTR_INIT("Rect", 0x110);
    MAP_ATTR_INIT("Image", 0x111);
    MAP_ATTR_INIT("EnableBK", 0x112);
    MAP_ATTR_INIT("HTML", 0x113);

    // Base control style attributes
    MAP_ATTR_INIT("Enable", 0x115);
    MAP_ATTR_INIT("Visible", 0x116);
    MAP_ATTR_INIT("Mouse", 0x117);
    MAP_ATTR_INIT("Border", 0x118);
    MAP_ATTR_INIT("Float", 0x119);

    MAP_ATTR_INIT("BkColor", 0x120);
    MAP_ATTR_INIT("BkColor1", 0x121);
    MAP_ATTR_INIT("BkColor2", 0x122);
    MAP_ATTR_INIT("Align", 0x150);

    MAP_ATTR_INIT("Width", 0x200);
    MAP_ATTR_INIT("Height", 0x201);

    // Other control attributes
    MAP_ATTR_INIT("HotTrack", 0x300);
    MAP_ATTR_INIT("ForwardColor", 0x301);
    MAP_ATTR_INIT("FocusedTextColor", 0x302);
    MAP_ATTR_INIT("PushedTextColor", 0x303);
    MAP_ATTR_INIT("HotTextColor", 0x304);    

    // Edit attributes
    MAP_ATTR_INIT("EditBkColor", 0x400);
    MAP_ATTR_INIT("EditStyle", 0x401);
    MAP_ATTR_INIT("TextColor", 0x402);
    MAP_ATTR_INIT("TextStyle", 0x403);

    // Text element attributes (IContainer) XLIST_MAX_COLUMNS = 12, so text0 ~ text11
    {
        for (int i = 0; i < XLIST_MAX_COLUMNS; i++)
        {
            XString pstrID = XString::XFormat(_T("%s%d"), MAP_TEXT_CONTAINER_KEY, i);
            // Text0 ~ Text11 - Base 0x2000 ~ 0x2000 + XLIST_MAX_COLUMNS
            m_mapAttributes.Set(pstrID, (MAP_TEXT_CONTAINER_BASE + i));
        }
    }

#undef MAP_ATTR_INIT
}

void XBuilder::_ClearAttrMap()
{
    m_mapAttributes.Clear();
}

UINT XBuilder::_GetIdByAttrName( LPCTSTR pstrName )
{
    ASSERT(pstrName);

    DWORD pVoid = NULL;
    if (m_mapAttributes.Lookup(pstrName, pVoid))
    {
        return pVoid;
    }
    else
    {
        TRACE("Attribute name [ %s ] not found!", pstrName);
        return 0xFFFFFFFF;
    }
}

bool XBuilder::_SetAttribute( XControl* pControl, UINT uID, LPCTSTR pstrValue )
{
    ASSERT_VALID(pControl);
    ASSERT(pstrValue);

    bool bRet = true;

    // Pretranslate ID

    // Text0 ~ TextN
    if (uID >= MAP_TEXT_CONTAINER_BASE && uID < MAP_TEXT_CONTAINER_BASE + XLIST_MAX_COLUMNS)
    {
        int nCol = (int) uID - MAP_TEXT_CONTAINER_BASE;
        GetIListItem(pControl)->SetText(nCol, pstrValue);
        return true;
    }

#define DECLARE_CASE_ATTR(Name, ID) case ID:

    switch (uID)
    {
        DECLARE_CASE_ATTR("Name", 0x100)                pControl->SetName(pstrValue);
        break;
        DECLARE_CASE_ATTR("Text", 0x101)                pControl->SetText(pstrValue);
        break;
        DECLARE_CASE_ATTR("Font", 0x102)                _ParseFont(pControl, pstrValue);
        break;
        DECLARE_CASE_ATTR("Rect", 0x110)                pControl->SetRect(_ParseRect(pstrValue));
        break;
        DECLARE_CASE_ATTR("Image", 0x111)               pControl->SetBkImage(pstrValue);
        break;
        DECLARE_CASE_ATTR("EnableBK", 0x112)            pControl->EnablePrintBk(_ParseBool(pstrValue));
        break;
        DECLARE_CASE_ATTR("HTML", 0x113)                pControl->EnableShowHtml(_ParseBool(pstrValue));
        break;
        DECLARE_CASE_ATTR("Enable", 0x115)              pControl->SetEnable(_ParseBool(pstrValue));
        break;
        DECLARE_CASE_ATTR("Visible", 0x116)             pControl->SetVisible(_ParseBool(pstrValue));
        break;
        DECLARE_CASE_ATTR("Mouse", 0x117)               pControl->SetMouseEnable(_ParseBool(pstrValue));
        break;
        DECLARE_CASE_ATTR("Border", 0x118)              pControl->SetBorder(_ParseSize(pstrValue));
        break;
        DECLARE_CASE_ATTR("Float", 0x119)               pControl->SetDrag(_ParseBool(pstrValue));
        break;
        DECLARE_CASE_ATTR("BkColor", 0x120)             pControl->SetBkColor(_ParseColor(pstrValue));
        break;
        DECLARE_CASE_ATTR("BkColor1", 0x121)            pControl->SetBkColor1(_ParseColor(pstrValue));
        break;
        DECLARE_CASE_ATTR("BkColor2", 0x122)            pControl->SetBkColor2(_ParseColor(pstrValue));
        break;
        DECLARE_CASE_ATTR("Align", 0x150)               pControl->SetCalcPos(_ParseUint(pstrValue));
        break;
        DECLARE_CASE_ATTR("Width", 0x200)               pControl->SetFixedWidth(_ParseInt(pstrValue));
        break;
        DECLARE_CASE_ATTR("Height", 0x201)              pControl->SetFixedHeight(_ParseInt(pstrValue));
        break;
        DECLARE_CASE_ATTR("HotTrack", 0x300)            GetICanvas(pControl)->EnableHotTrack(_ParseBool(pstrValue));
        break;
        DECLARE_CASE_ATTR("ForwardColor", 0x301)        GetICanvas(pControl)->SetForwardColor(_ParseColor(pstrValue));
        break;
        DECLARE_CASE_ATTR("FocusedTextColor", 0x302)    GetIButton(pControl)->SetFocusedTextColor(_ParseColor(pstrValue));
        break;
        DECLARE_CASE_ATTR("PushedTextColor", 0x303)     GetIButton(pControl)->SetPushedTextColor(_ParseColor(pstrValue));
        break;
        DECLARE_CASE_ATTR("HotTextColor", 0x304)        GetIButton(pControl)->SetHotTextColor(_ParseColor(pstrValue));
        break;
        DECLARE_CASE_ATTR("EditBkColor", 0x400)         GetIEdit(pControl)->SetEditBkColor(_ParseColor(pstrValue));
        break;
        DECLARE_CASE_ATTR("EditStyle", 0x401)           GetIEdit(pControl)->SetEditStyle(_ParseUint(pstrValue));
        break;
        DECLARE_CASE_ATTR("TextColor", 0x402)           GetILabel(pControl)->SetTextColor(_ParseColor(pstrValue));
        break;
        DECLARE_CASE_ATTR("TextStyle", 0x403)           GetITextStyle(pControl)->SetTextStyle(_ParseUint(pstrValue));
        break;
    default:
        bRet = false;
    }

    return bRet;
}

UI_END_NAMESPACE

#undef DECLARE_CASE_ATTR
#undef MAP_TEXT_CONTAINER_BASE