#include "StdAfx.h"

CONTROLS_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS_WITH_PARA(XButton, XLabel)

//////////////////////////////////////////////////////////////////////////

XButton::XButton( XObject* pOb /*= NULL*/ ): XLabel(pOb),
m_clrHotTextColor(XCOLOR_BUTTON_TEXT_HOT),
m_clrPushedTextColor(XCOLOR_BUTTON_TEXT_PUSHED),
m_clrFocusedTextColor(XCOLOR_BUTTON_TEXT_FOCUSED)
{

}

XButton::~XButton()
{

}

void* XButton::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_BUTTON: return this;
    }
    return XLabel::GetInterface(hi);
}

BOOL XButton::Activate()
{
    if( !XControl::Activate() ) return FALSE;
    if( m_pWindow != NULL ) m_pWindow->SendAsyncNotify(this, (DWORD) _T("ButtonClick"), TRUE);
    return TRUE;
}

void XButton::Paint( HDC hDC, const XRect& rect )
{
    if ( !m_rcPaint.IntersectRect(&rect, &m_rcClient) ) return;
    if( m_bFocused )  m_uButtonState |= XSTATE_FOCUSED;
    if( !m_bEnabled ) m_uButtonState |= XSTATE_DISABLED;
    Rendering::X_DrawButton(hDC, m_pWindow, m_rcClient, m_szText, m_rcTextPadding, m_uButtonState,
        m_pWindow->GetFontByHash(m_szFontHash), m_uTextStyle | DT_SINGLELINE);
}

DWORD XButton::GetFlags() const
{
    return (m_bEnabled ? XFLAG_SETCURSOR : 0) | XFLAG_TABSTOP | XControl::GetFlags();
}

void XButton::Event( TEvent& event )
{
    if (!m_bMouseEnabled)
    {
        if (OnMouseEvent(event.msg.message))
        {
            if ( m_pParent != NULL )
            {
                event.sender = this;
                event.receiver = m_pParent;
                event.dispatcher->PostEvent(event);
            }
            else
            {
                XLabel::Event(event);
            }
        }
    }
    else
    {
        switch (event.msg.message)
        {
        case WM_SETFOCUS:
            Invalidate();
            break;
        case WM_KILLFOCUS:
            m_uButtonState &= ~XSTATE_FOCUSED;
            Invalidate();
            break;
        case WM_KEYDOWN:
            static TCHAR ch;
            ch = m_pWindow->MapState();
            if ( ch == VK_SPACE || ch == VK_RETURN )
            {
                Activate();
                return;
            }
            break;
        case WM_LBUTTONDOWN:
        case WM_LBUTTONDBLCLK:
            if( m_bEnabled && m_rcClient.PtInRect(event.msg.pt) )
            {
                m_uButtonState |= XSTATE_PUSHED | XSTATE_CAPTURED;
                Invalidate();
            }
            break;
        case WM_MOUSEMOVE:
            if( m_bEnabled && (m_uButtonState & XSTATE_CAPTURED) != 0 )
            {
                if( m_rcClient.PtInRect(event.msg.pt) ) m_uButtonState |= XSTATE_PUSHED;
                else m_uButtonState &= ~XSTATE_PUSHED;
                Invalidate();
            }
            break;
        case  WM_LBUTTONUP:
            if( m_bEnabled && (m_uButtonState & XSTATE_CAPTURED) != 0 )
            {
                if( m_rcClient.PtInRect(event.msg.pt) ) Activate();
                m_uButtonState &= ~(XSTATE_PUSHED | XSTATE_CAPTURED);
                Invalidate();
            }
            break;
        case WM_MOUSEENTER:
            if( m_bEnabled )
            {
                m_uButtonState |= XSTATE_HOT;
                Invalidate();
            }
            return;
        case WM_MOUSELEAVE:
            if( m_bEnabled )
            {
                m_uButtonState &= ~XSTATE_HOT;
                Invalidate();
            }
            return;
        case WM_SETCURSOR:
            ::SetCursor(::LoadCursor(NULL, MAKEINTRESOURCE(IDC_HAND)));
            return;
        }

        XLabel::Event(event);
    }
}

void XButton::SetHotTextColor( COLORREF clrColor )
{
    m_clrHotTextColor = clrColor;
}

COLORREF XButton::GetHotTextColor() const
{
    return m_clrHotTextColor;
}

void XButton::SetPushedTextColor( COLORREF clrColor )
{
    m_clrPushedTextColor = clrColor;
}

COLORREF XButton::GetPushedTextColor() const
{
    return m_clrPushedTextColor;
}

void XButton::SetFocusedTextColor( COLORREF clrColor )
{
    m_clrFocusedTextColor = clrColor;
}

COLORREF XButton::GetFocusedTextColor() const
{
    return m_clrFocusedTextColor;
}

XSize XButton::EstimateSize( const XSize& )
{
    ASSERT_VALID(m_pWindow);
    XSize sz(GetFixedWidth(), max(GetFixedHeight(), 12 + m_pWindow->GetFontInfoByHash(m_szFontHash)->tm.tmHeight));
    sz.cx += m_rcTextPadding.Width() * 2;
    sz.cy += m_rcTextPadding.Height() * 2;
    return sz;
}

CONTROLS_END_NAMESPACE