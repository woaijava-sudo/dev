#include "stdafx.h"

UI_BEGIN_NAMESPACE
XControl* XBuilder::_CreateFromXml( XMarkupNode* pNode, XControl* pParent /*= NULL */ )
{
    XControl* pReturn = NULL;

    for( XMarkupNode _Node = pNode->GetChild(); _Node.IsValid(); _Node = _Node.GetSibling() )
    {
        XString pstrClass = _Node.GetName();

        if (pstrClass == _T("X")) continue; // Default root

        XControl* pControl = NULL;

        // RTTI Create Object
        if (pParent == NULL)
        {
            X_CreateObject_Name_V2(m_IAdvCreate, (LPCTSTR)pstrClass, m_pWindow, (XObject**)&pControl);
            pControl->Register(); // Register (only explicit declared here)
        }
        else
        {
            pControl = pParent->CreateControl(X_GetClass(m_IAdvCreate, (LPCTSTR)pstrClass));
        }

        // Add children
        if( _Node.HasChildren() ) {
            _CreateFromXml(&_Node, pControl);
        }

        // Init default attributes
        if( _Node.HasAttributes() ) {
            int nAttributes = _Node.GetAttributeCount();
            for( int i = 0; i < nAttributes; i++ ) {
                XString pstrName = _Node.GetAttributeName(i);
                XString pstrValue = _Node.GetAttributeValue(i);
                UINT uID = _GetIdByAttrName(pstrName);
                _SetAttribute(pControl, uID, pstrValue);
            }
        }

        // Return first item
        if( pReturn == NULL ) pReturn = pControl;
    }

    return pReturn;
}
UI_END_NAMESPACE