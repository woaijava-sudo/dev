#ifndef _CC_UI_LABEL_H
#define _CC_UI_LABEL_H

#pragma once

#define GetILabel(p) ((XLabel*)(static_cast<XLabel*>((p)->GetInterface(HI_LABEL))))
#define GetITextStyle(p) ((ITextStyleImpl*)(static_cast<ITextStyleImpl*>((p)->GetInterface(HI_TEXT_STYLE))))

CONTROLS_BEGIN_NAMESPACE
class CL_API XLabel : public XControl, public ITextStyleImpl
{
    X_DECLARE_CLASS_WITH_PARA(XLabel)
public:
    XLabel(XObject* pOb = NULL);
    virtual ~XLabel();

    virtual void* GetInterface( HINTERFACE hi );
    void PaintText( HDC hDC );

    void SetTextPadding( XRect& rc );
    XRect GetTextPadding() const;

    void SetTextColor( COLORREF clrColor ); // ����������ɫ
    COLORREF GetTextColor() const;

    void SetDisabledTextColor( COLORREF clrDisabledTextColor );
    COLORREF GetDisabledTextColor() const;

    virtual void Event( TEvent& event );
    virtual XSize EstimateSize( const XSize& );

protected:
    COLORREF    m_clrTextColor; //�ı���ɫ
    COLORREF    m_clrDisabledTextColor; // ����״̬����ɫ
    XRect       m_rcTextPadding; // �ı��ڱ߾�
};

CONTROLS_END_NAMESPACE
#endif