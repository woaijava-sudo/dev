#include "StdAfx.h"

CONTAINER_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS_WITH_PARA(XHorizontalLayout, XContainer)
X_IMPLEMENT_CLASS_WITH_PARA(XVerticalLayout, XContainer)

//////////////////////////////////////////////////////////////////////////

XHorizontalLayout::XHorizontalLayout( XObject* pOb /*= NULL*/ ): XContainer(pOb)
{

}

XHorizontalLayout::~XHorizontalLayout()
{

}

void* XHorizontalLayout::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_HORIZONTAL_LAYOUT: return this;
    }
    return XContainer::GetInterface(hi);
}

void XHorizontalLayout::SetRect( const XRect & rc )
{
    m_rcClient = rc;
    XRect rect(rc);
    // Adjust for inset
    rect.left += m_rcInset.left;
    rect.top += m_rcInset.top;
    rect.right -= m_rcInset.right;
    rect.bottom -= m_rcInset.bottom;
    // Determine the width of elements that are sizeable
    XSize szAvailable = rect.Size();
    LONG nAdjustables = 0;
    LONG cxFixed = 0;
    for( int i = 0; i < m_Items.GetSize(); i++ ) {
        XControl* pControl = m_Items[i];
        if( !pControl->IsVisible() ) continue;
        XSize sz = pControl->EstimateSize(szAvailable);
        if( sz.cx == 0 ) nAdjustables++;
        cxFixed += sz.cx;
    }
    LONG cxExpand = 0;
    if( nAdjustables > 0 ) cxExpand = max(0, (szAvailable.cx - cxFixed) / nAdjustables);
    // Position the elements
    XSize szRemaining = szAvailable;
    LONG iPosX = rc.left;
    LONG iAdjustable = 0;
    for( int i = 0; i < m_Items.GetSize(); i++ ) {
        XControl* pControl = m_Items[i];
        if( !pControl->IsVisible() ) continue;
        XSize sz = pControl->EstimateSize(szRemaining);
        if( sz.cx == 0 ) {
            iAdjustable++;
            sz.cx = cxExpand;
            if( iAdjustable == nAdjustables ) sz.cx += max(0, szAvailable.cx - (cxExpand * nAdjustables) - cxFixed);
        }
        XRect rcCtrl(iPosX, rc.top, iPosX + sz.cx, rc.bottom);
        pControl->SetRect(rcCtrl);
        iPosX += sz.cx;
        szRemaining.cx -= sz.cx;
    }
}

//////////////////////////////////////////////////////////////////////////

XVerticalLayout::XVerticalLayout( XObject* pOb /*= NULL*/ ): XContainer(pOb)
{

}

XVerticalLayout::~XVerticalLayout()
{

}

void* XVerticalLayout::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_VERTICAL_LAYOUT: return this;
    }
    return XContainer::GetInterface(hi);
}

void XVerticalLayout::SetRect( const XRect & rc )
{
    m_rcClient = rc;
    XRect rect(rc);
    // Adjust for inset
    rect.InsetRect(m_rcInset);
    if( m_pChildWindow != NULL && m_pChildWindow->_IsWindow() ) rect.right -= ::GetSystemMetrics(SM_CXVSCROLL);
    // Determine the minimum size
    XSize szAvailable = rc.Size();
    LONG nAdjustables = 0;
    LONG cyFixed = 0;
    for( int i = 0; i < m_Items.GetSize(); i++ ) {
        XControl* pControl = m_Items[i];
        ASSERT_VALID(pControl);
        if( !pControl->IsVisible() ) continue;
        XSize sz = pControl->EstimateSize(szAvailable);
        if( sz.cy == 0 ) nAdjustables++;
        cyFixed += sz.cy;
    }
    // Place elements
    LONG cyNeeded = 0;
    LONG cyExpand = 0;
    if( nAdjustables > 0 ) cyExpand = max(0, (szAvailable.cy - cyFixed) / nAdjustables);
    // Position the elements
    XSize szRemaining = szAvailable;
    LONG iPosY = rc.top - m_iScrollPos;
    LONG iAdjustable = 0;
    for( int i = 0; i < m_Items.GetSize(); i++ ) {
        XControl* pControl = m_Items[i];
        ASSERT_VALID(pControl);
        if( !pControl->IsVisible() ) continue;
        XSize sz = pControl->EstimateSize(szRemaining);
        if( sz.cy == 0 ) {
            iAdjustable++;
            sz.cy = cyExpand;
            // Distribute remaining to last element (usually round-off left-overs)
            if( iAdjustable == nAdjustables ) sz.cy += max(0, szAvailable.cy - (cyExpand * nAdjustables) - cyFixed);
        }
        XRect rcCtrl(rc.left, iPosY, rc.right, iPosY + sz.cy);
        pControl->SetRect(rcCtrl);
        iPosY += sz.cy;
        cyNeeded += sz.cy;
        szRemaining.cy -= sz.cy;
    }
    // Handle overflow with scrollbars
    ProcessScrollbar(rc, cyNeeded);
}
CONTAINER_END_NAMESPACE