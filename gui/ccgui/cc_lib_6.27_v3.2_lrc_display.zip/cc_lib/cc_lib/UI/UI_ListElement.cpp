#include "stdafx.h"

CONTROLS_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS_WITH_PARA(XListElement, XLabel)
X_IMPLEMENT_CLASS_WITH_PARA(XListTextElement, XListElement)
X_IMPLEMENT_CLASS_WITH_PARA(XListLabelElement, XListTextElement)
//////////////////////////////////////////////////////////////////////////

XListElement::XListElement( XObject* pOb /*= NULL*/ ): XLabel(pOb), m_iIndex(-1), m_pOwner(NULL), m_bSelected(false)
{
    m_flags |= XFLAG_WANTRETURN;
}

XListElement::~XListElement()
{

}


void* XListElement::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_LIST_ELEMENT: return this;
    case HI_LIST_ITEM: return static_cast<IListItem*>(this);
    }
    return XLabel::GetInterface(hi);
}

int XListElement::GetIndex() const
{
    return m_iIndex;
}

void XListElement::SetIndex( int iIndex )
{
    m_iIndex = iIndex;
}

void XListElement::SetText( int iIndex, XString strText )
{
    if(iIndex >= m_aString.GetSize() || iIndex < 0) {
        m_aString.Add(strText);
    }
    else {
        m_aString.RemoveAt(iIndex);
        m_aString.Set(iIndex, strText);
    }
}

XString XListElement::GetText( int iIndex ) const
{
    if(iIndex >= m_aString.GetSize() || iIndex < 0) return EmptyString;
    return m_aString.Get(iIndex);
}

void XListElement::SetListOwner( IListOwner* pOwner )
{
    ASSERT(pOwner);
    m_pOwner = pOwner;
}

bool XListElement::IsSelected() const
{
    return m_bSelected;
}

bool XListElement::Select( bool bSelect /*= true */ )
{
    if( !IsEnabled() ) return false;
    if( bSelect == m_bSelected ) return true;
    m_bSelected = bSelect;
    if( bSelect && m_pOwner != NULL ) m_pOwner->SelectItem(m_iIndex);
    Invalidate();
    return true;
}

BOOL XListElement::Activate()
{
    if( !XControl::Activate() ) return false;
    if( m_pWindow != NULL ) m_pWindow->SendAsyncNotify(this, (DWORD) _T("ItemActivate"), TRUE);
    return true;
}

XRect XListElement::GetRect() const
{
    XRect rt(m_rcClient);
    rt.right -= ::GetSystemMetrics(SM_CXVSCROLL);
    return rt;
}

void XListElement::Event( TEvent& event )
{
    switch (event.msg.message)
    {
    case WM_LBUTTONDOWN:
        if (m_bEnabled)
        {
            Activate();
            Invalidate();
            return;
        }
    case WM_KEYDOWN:
        if (m_bEnabled && TCHAR(event.msg.wParam) == VK_RETURN)
        {
            Activate();
            Invalidate();
            return;
        }
    }

    if( m_pOwner != NULL ) m_pOwner->ListEvent(event); else XLabel::Event(event);
}

//////////////////////////////////////////////////////////////////////////

XListTextElement::XListTextElement( XObject* pOb /*= NULL*/ ): XListElement(pOb)
{
    m_uTextStyle |= XLIST_TEXT_ELEMENT_DEFAULT_STYLE;
}

void* XListTextElement::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_LIST_TEXT_ELEMENT: return this;
    }
    return XListElement::GetInterface(hi);
}

void XListTextElement::SetTextStyle( UINT uAdd, UINT uRemove /*= 0 */ )
{
    XListElement::SetTextStyle(uAdd, uRemove);
    Invalidate();
}

void XListTextElement::SetFixedWidth( int cxWidth )
{
    IFixedWidthImpl::SetFixedWidth(cxWidth);
    Invalidate();
}

XSize XListTextElement::EstimateSize( const XSize& )
{
    ASSERT_VALID(m_pWindow);
    return XSize(GetFixedWidth(), 9 + m_pWindow->GetFontInfoByHash(m_szFontHash)->tm.tmHeight);
}

void XListTextElement::Event( TEvent& event )
{
    switch( event.msg.message )
    {
    case WM_LBUTTONDOWN:
        if (m_bEnabled)
        {
            Select();
            Invalidate();
        }
        break;
    case WM_MOUSEENTER:
        if (m_bEnabled)
        {
            m_uButtonState |= XSTATE_HOT;
            Invalidate();
        }
        break;
    case WM_MOUSELEAVE:
        if( m_bEnabled && (m_uButtonState & XSTATE_HOT) != 0 ) {
            m_uButtonState &= ~XSTATE_HOT;
            Invalidate();
        }
        break;
    }
    XListElement::Event(event);
}

void XListTextElement::Paint( HDC hDC, const XRect& rcPaint )
{
    if ( !m_rcPaint.IntersectRect(&rcPaint, &m_rcClient) ) return;

    const TListInfo* pInfo = m_pOwner->GetListInfo();
    COLORREF iTextColor = pInfo->Text;
    COLORREF iBackColor = pInfo->Background;
    if( (m_uButtonState & XSTATE_HOT) != 0 ) {
        iTextColor = pInfo->HotText;
        iBackColor = pInfo->HotBackground;
    }
    if( IsSelected() ) {
        iTextColor = pInfo->SelText;
        iBackColor = pInfo->SelBackground;
    }
    if( !IsEnabled() ) {
        iTextColor = XCOLOR_CONTROL_TEXT_DISABLED;
        iBackColor = MAKE_RGB(XCOLOR_CONTROL_BACKGROUND_DISABLED);
    }

    m_dwBkColor = iBackColor;
    PaintBkColor(hDC);

    ASSERT_VALID(m_pWindow);
//     Rendering::X_DrawText(hDC, m_pWindow, m_rcClient, m_szText, iTextColor, m_pWindow->GetFontByHash(m_szFontHash), m_uTextStyle | DT_SINGLELINE);

    for( int i = 0; i < pInfo->nColumns; i++ )
    {
        XRect rcItem(pInfo->rcColumn[i].left, m_rcClient.top, pInfo->rcColumn[i].right, m_rcClient.bottom);
        LPCTSTR pstrText = (LPCTSTR)m_aString.Get(i);
        rcItem.DeflateRect(4, 0);
        Rendering::X_DrawText(hDC, m_pWindow, rcItem, pstrText, iTextColor, m_pWindow->GetFontByHash(m_szFontHash), m_uTextStyle | DT_SINGLELINE);
    }
//     XRect rcLine(m_rcItem.left, m_rcItem.bottom - 1, m_rcItem.right, m_rcItem.bottom - 1);
//     XRender::XPaintLine(hDC, m_pManager, rcLine, XCOLOR_DIALOG_BACKGROUND);
}

//////////////////////////////////////////////////////////////////////////

XListLabelElement::XListLabelElement( XObject* pOb /*= NULL*/ ): XListTextElement(pOb), m_pCombo(NULL)
{

}

void* XListLabelElement::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_LIST_LABEL: return static_cast<IListLabel*>(this);
    case HI_LIST_LABEL_ELEMENT: return this;
    }
    return XListTextElement::GetInterface(hi);
}

void XListLabelElement::SetCombo( XCombo* pCombo )
{
    ASSERT_VALID(pCombo);
    m_pCombo = pCombo;
}

void XListLabelElement::SetRect( const XRect & rt )
{
    XRect rect(rt);
    rect.DeflateRect(4, 0);
    XListTextElement::SetRect(rect);
}

void XListLabelElement::Event( TEvent& event )
{
    switch( event.msg.message )
    {
    case WM_LBUTTONDOWN:
        if (m_bEnabled) {
            m_pWindow->SendAsyncNotify(this, (DWORD) _T("DropDownSelect"), TRUE, 0, m_iIndex);
        }
        break;
    case WM_KEYDOWN:
        if (m_bEnabled) {
            switch( event.msg.wParam ) {
            case VK_ESCAPE:
            case VK_RETURN:
                m_pWindow->SendAsyncNotify(this, (DWORD) _T("DropDownSelect"), TRUE, 0, m_iIndex);
                break;
            }
        }
        break;
    }
    XListTextElement::Event(event);
}

void XListLabelElement::Paint( HDC hDC, const XRect& rcPaint )
{
    if ( !m_rcPaint.IntersectRect(&rcPaint, &m_rcClient) ) return;

    ASSERT(m_pOwner);
    const TListInfo* pInfo = m_pOwner->GetListInfo();
    COLORREF iTextColor = pInfo->Text;
    COLORREF iBackColor = pInfo->Background;
    if( (m_uButtonState & XSTATE_HOT) != 0 ) {
        iTextColor = pInfo->HotText;
        iBackColor = pInfo->HotBackground;
    }
    if( IsSelected() ) {
        iTextColor = pInfo->SelText;
        iBackColor = pInfo->SelBackground;
    }
    if( !IsEnabled() ) {
        iTextColor = XCOLOR_CONTROL_TEXT_DISABLED;
        iBackColor = MAKE_RGB(XCOLOR_CONTROL_BACKGROUND_DISABLED);
    }

    m_dwBkColor = iBackColor;
    XControl::Paint(hDC, rcPaint);
}

CONTROLS_END_NAMESPACE