#include "StdAfx.h"

UI_BEGIN_NAMESPACE
XClass* _XClassManager::m_pFirstClass;
_XClassManager* _XClassManager::m_pThis;

_IClassAdv* _XAdv_Global_GetClassManager()
{
    static _IClassAdv* g_IClass = _XClassManager::_XAdv_GetInterface();
    return g_IClass;
}

void _XAdv_Global_Release()
{
    static _IClassAdvOp* g_IClassDel = _XClassManager::_XAdv_GetInterface_Del();
    g_IClassDel->_DeleteManager();
}

void _XAdv_Global_InitClass()
{
    static _IClassAdvOp* g_IClassDel = _XClassManager::_XAdv_GetInterface_Del();
    g_IClassDel->_InitClass();
}

//////////////////////////////////////////////////////////////////////////

_XClassManager::_XClassManager(): m_allocSize(0), m_bAllowDumping(false)
{

}

_XClassManager::~_XClassManager()
{
    // Ensure everything has beed deleted
#ifdef XManager_Dumping
    if (m_mapClass.Count() > 0)
    {
        TRACE("######################## Dump Context Begin ########################");
        auto enumerator = m_mapClass.Wrap().CreateEnumerator();
        while (enumerator->Next())
        {
            delete enumerator->Current()._V;
        }
        delete enumerator;
        TRACE("######################## Dump Context End ########################");
    }
#endif // XManager_Dumping
    ASSERT(m_allocSize == 0);
}

_IClassAdv* _XClassManager::_XAdv_GetInterface()
{
    if (m_pThis == NULL) {
        m_pThis = new _XClassManager;
    }

    return m_pThis;
}

_IClassAdvOp* _XClassManager::_XAdv_GetInterface_Del()
{
    if (m_pThis == NULL) {
        m_pThis = new _XClassManager;
    }

    return m_pThis;
}

#ifdef XManager_Dumping
bool _XClassManager::_RegisterObject( XObject* pObj )
{
    ASSERT(m_mapClass.Count() > 0);
    ASSERT(pObj);

    XClass* pClass = pObj->GetClass();
    ASSERT(pClass->m_lpszClassName);

    LPCTSTR lpszClassName = pClass->m_lpszClassName;
    LPVOID ppVoid = NULL;
    if (m_mapClass.Lookup(lpszClassName, ppVoid))
    {
        _XAdvClassInfo* pInfo = static_cast<_XAdvClassInfo*>(ppVoid);
        ASSERT(pInfo);
        pInfo->Add(pObj);
        return true;
    }

    ASSERT(!"Error: Class Not Found.");
    return false;
}

bool _XClassManager::_UnregisterObject( XObject* pObj )
{
    ASSERT(m_mapClass.Count() > 0);
    ASSERT_VALID(pObj);

    XClass* pClass = pObj->GetClass();
    ASSERT(pClass->m_lpszClassName);

    LPCTSTR lpszClassName = pClass->m_lpszClassName;
    LPVOID ppVoid = NULL;
    if (m_mapClass.Lookup(lpszClassName, ppVoid))
    {
        XClass* ppClass = static_cast<XClass*>(ppVoid);
        ASSERT(ppClass);
        static_cast<_XAdvClassInfo*>(m_mapClass[lpszClassName])->Remove(pObj);
        return true;
    }

    ASSERT(!"Error: Class Not Found.");
    return false;
}
#endif // XManager_Dumping

size_t _XClassManager::X_GetAllocatedSize()
{
    return m_allocSize;
}

void _XClassManager::X_CreateObjectFromClass( const TCHAR* _lpszFilename, int _Linenumber, XClass* pClass, XObject** ppObj )
{
    ASSERT(pClass);
    ASSERT(ppObj);
    *ppObj = pClass->CreateObject();
    ASSERT(*ppObj);
#ifdef XManager_Dumping
    _RegisterObject(*ppObj);
#endif // XManager_Dumping
    m_allocSize += pClass->m_nObjectSize;
    TRACE_T(_lpszFilename, _Linenumber, "[%s - 0x%X - %dBytes] has been created. (Total: %dBytes)", (*ppObj)->GetClass()->m_lpszClassName,
        *ppObj, (*ppObj)->GetClass()->m_nObjectSize, m_allocSize);
}

void _XClassManager::X_CreateObjectFromClass( const TCHAR* _lpszFilename, int _Linenumber, XClass* pClass, XObject** ppObj, XObject* pParam )
{
    ASSERT(pClass);
    ASSERT(ppObj);
    *ppObj = pClass->CreateObject(pParam);
    ASSERT(*ppObj);
#ifdef XManager_Dumping
    _RegisterObject(*ppObj);
#endif // XManager_Dumping
    m_allocSize += pClass->m_nObjectSize;
    TRACE_T(_lpszFilename, _Linenumber, "[%s - 0x%X - %dBytes] has been created. (Total: %dBytes)", (*ppObj)->GetClass()->m_lpszClassName,
        *ppObj, (*ppObj)->GetClass()->m_nObjectSize, m_allocSize);
}

bool _XClassManager::X_CreateObjectFromName( const TCHAR* _lpszFilename, int _Linenumber, LPCTSTR lpszClassName, XObject** ppObj )
{
    ASSERT(lpszClassName);
    ASSERT(ppObj);

    LPVOID ppVoid = NULL;
    if (m_mapClass.Lookup(lpszClassName, ppVoid))
    {
#ifdef XManager_Dumping
        XClass* ppClass = static_cast<_XAdvClassInfo*>(ppVoid)->m_pClass;
#else
        XClass* ppClass = static_cast<XClass*>(ppVoid);
#endif // XManager_Dumping
        ASSERT(ppClass);
        X_CreateObjectFromClass(_lpszFilename, _Linenumber, ppClass, ppObj);
        return true;
    }

    TRACE_T(_lpszFilename, _Linenumber, "Error: CreateObjectFromName failed, class < %s > not found.", lpszClassName);
    ASSERT(!"X_CreateObjectFromName: fatal error");
    return false;
}

bool _XClassManager::X_CreateObjectFromName( const TCHAR* _lpszFilename, int _Linenumber, LPCTSTR lpszClassName, XObject** ppObj, XObject* pParam )
{
    ASSERT(lpszClassName);
    ASSERT(ppObj);

    LPVOID ppVoid = NULL;
    if (m_mapClass.Lookup(lpszClassName, ppVoid))
    {
#ifdef XManager_Dumping
        XClass* ppClass = static_cast<_XAdvClassInfo*>(ppVoid)->m_pClass;
#else
        XClass* ppClass = static_cast<XClass*>(ppVoid);
#endif // XManager_Dumping
        ASSERT(ppClass);
        X_CreateObjectFromClass(_lpszFilename, _Linenumber, ppClass, ppObj, pParam);
        return true;
    }

    TRACE_T(_lpszFilename, _Linenumber, "Error: CreateObjectFromName_V2 failed, class < %s > not found.", lpszClassName);
    ASSERT(!"X_CreateObjectFromName: fatal error");
    return false;
}

XClass* _XClassManager::X_GetClassFromName( LPCTSTR lpszClassName )
{
    ASSERT(lpszClassName);
    LPVOID ppVoid = NULL;
    if (m_mapClass.Lookup(lpszClassName, ppVoid))
    {
#ifdef XManager_Dumping
        XClass* ppClass = static_cast<_XAdvClassInfo*>(ppVoid)->m_pClass;
#else
        XClass* ppClass = static_cast<XClass*>(ppVoid);
#endif // XManager_Dumping
        ASSERT(ppClass);
        return ppClass;
    }

    TRACE("Error: X_GetClassFromName failed, class < %s > not found.", lpszClassName);
    ASSERT(!"X_GetClassFromName: fatal error");
    return NULL;
}

void _XClassManager::_DeleteObject( const TCHAR* _lpszFilename, int _Linenumber, XObject* pObj )
{
    ASSERT_VALID(pObj);
#ifdef XManager_Dumping
    _UnregisterObject(pObj);
#endif // XManager_Dumping
    m_allocSize -= pObj->GetClass()->m_nObjectSize;
    TRACE_T(_lpszFilename, _Linenumber, "[%s - 0x%X - %dBytes] has been deleted. (Total: %dBytes)", pObj->GetClass()->m_lpszClassName,
        pObj, pObj->GetClass()->m_nObjectSize, m_allocSize);
    delete pObj;
}

void _XClassManager::_DeleteManager()
{
    delete this;
}

void _XClassManager::_InitClass()
{
    ASSERT(m_pFirstClass != NULL && "Class Not Found.");

    XClass* pClass = m_pFirstClass;
    while (pClass != NULL)
    {
#if XManager_Dumping
        m_mapClass.Set(pClass->m_lpszClassName, new _XAdvClassInfo(pClass));
#else
        m_mapClass.Set(pClass->m_lpszClassName, pClass);
#endif
        pClass = pClass->m_pNextClass;
    }
}
UI_END_NAMESPACE