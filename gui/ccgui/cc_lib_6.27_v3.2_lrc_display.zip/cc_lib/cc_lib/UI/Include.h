#ifndef _CC_UI_INCLUDE_H
#define _CC_UI_INCLUDE_H

#pragma once

#define XManager_Dumping 1

using namespace cc::Strings;
using namespace cc::Debug;
using namespace cc::Gdi;
using namespace cc::Collections;

//////////////////////////////////////////////////////////////////////////

#define UI_BEGIN_NAMESPACE namespace cc { namespace UI {
#define UI_END_NAMESPACE } }
#define CONTROLS_BEGIN_NAMESPACE UI_BEGIN_NAMESPACE namespace Controls {
#define CONTROLS_END_NAMESPACE } } }
#define CONTAINER_BEGIN_NAMESPACE UI_BEGIN_NAMESPACE namespace Containers {
#define CONTAINER_END_NAMESPACE } } }
#define WINDOW_BEGIN_NAMESPACE UI_BEGIN_NAMESPACE namespace Window {
#define WINDOW_END_NAMESPACE } } }
#define RENDERING_BEGIN_NAMESPACE UI_BEGIN_NAMESPACE namespace Rendering {
#define RENDERING_END_NAMESPACE } } }

// Macros
#include "UI_Macros.h"
#include "../core/cc_Debug.h"
#include "UI_Templates.h"

// Delegate
#include "UI_Delegate.h"
#include "UI_DelegateMap.h"
#include "UI_ExitManager.h"

// Base
#include "UI_ClassManager.h"
#include "UI_Object.h"
#include "UI_WindowImpl.h"

// Gdi
#include "../Gdi/Gdi_Base.h"
#include "../Gdi/Gdi_Animation.h"

// Containers
#include "UI_Control.h"
#include "UI_CmdTarget.h"
#include "UI_Container.h"
#include "UI_Window.h"
#include "UI_Canvas.h"
#include "UI_Layout.h"
#include "UI_Render.h"

// Controls
#include "UI_Label.h"
#include "UI_Button.h"
#include "UI_Edit.h"
#include "UI_Text.h"
#include "UI_List.h"
#include "UI_Combo.h"
#include "UI_Title.h"

// Builder
#include "UI_MarkupNode.h"
#include "UI_Markup.h"
#include "UI_Builder.h"

#endif