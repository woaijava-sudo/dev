#include "StdAfx.h"
#include "UI_DelegateMap.h"

UI_BEGIN_NAMESPACE
XDelegateImpl::~XDelegateImpl()
{
    RemoveAllDelegates();
}

bool XDelegateImpl::CreateDelegate( const XString& Name )
{
    XEventSource* ppVoid = NULL;
    bool bFind = m_mapDelegates.Lookup(Name, ppVoid);
    if (!bFind)
    {
        m_mapDelegates.Set(Name, new XEventSource);
        return true;
    }

    return false;
}

bool XDelegateImpl::RunDelegate( const XString& Name, void* Param )
{
    if (m_mapDelegates.IsEmpty())
    {
        return false;
    }

    XEventSource* ppVoid = NULL;
    bool bFind = m_mapDelegates.Lookup(Name, ppVoid);
    if (bFind)
    {
        XEventSource* pDelegate = static_cast<XEventSource*>(ppVoid);
        ASSERT(pDelegate);
        if (*pDelegate)
        {
            return (*pDelegate)(Param);
        }
    }

    return false;
}

bool XDelegateImpl::AddDelegate( const XString& Name, XFunVoid Functor )
{
    XEventSource* ppVoid = NULL;
    bool bFind = m_mapDelegates.Lookup(Name, ppVoid);
    if (bFind)
    {
        XEventSource* pDelegate = static_cast<XEventSource*>(ppVoid);
        ASSERT(pDelegate);
        (*pDelegate) += Functor;
        return true;
    }

    return false;
}

bool XDelegateImpl::RemoveDelegate( const XString& Name )
{
    if (m_mapDelegates.IsEmpty())
    {
        return false;
    }

    XEventSource* ppVoid = NULL;
    bool bFind = m_mapDelegates.Lookup(Name, ppVoid);
    if (bFind)
    {
        delete static_cast<XEventSource*>(ppVoid);
        m_mapDelegates.Remove(Name);
        return true;
    }

    return false;
}

void XDelegateImpl::RemoveAllDelegates()
{
    if (m_mapDelegates.IsEmpty())
    {
        return;
    }

    auto enumerator = m_mapDelegates.Wrap().CreateEnumerator();
    while (enumerator->Next())
    {
        delete enumerator->Current()._V;
    }
    delete enumerator;

    m_mapDelegates.Clear();
}
UI_END_NAMESPACE