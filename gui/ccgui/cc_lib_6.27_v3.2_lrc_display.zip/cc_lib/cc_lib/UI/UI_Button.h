#ifndef _CC_UI_BUTTON_H
#define _CC_UI_BUTTON_H

#pragma once

#define GetIButton(p) ((XButton*)(static_cast<XButton*>((p)->GetInterface(HI_BUTTON))))

//////////////////////////////////////////////////////////////////////////
CONTROLS_BEGIN_NAMESPACE
class CL_API XButton : public XLabel, public IButtonStateImpl
{
    X_DECLARE_CLASS_WITH_PARA(XButton)
public:
    XButton(XObject* pOb = NULL);
    virtual ~XButton();

    virtual void* GetInterface( HINTERFACE hi );
    virtual void Paint( HDC hDC, const XRect& rect );

    virtual BOOL Activate();
    virtual DWORD GetFlags() const;

    virtual void Event( TEvent& event );

    void SetHotTextColor(COLORREF clrColor);
    COLORREF GetHotTextColor() const;

    void SetPushedTextColor(COLORREF clrColor);
    COLORREF GetPushedTextColor() const;

    void SetFocusedTextColor(COLORREF clrColor);
    COLORREF GetFocusedTextColor() const;

    virtual XSize EstimateSize( const XSize& );

protected:
    COLORREF    m_clrHotTextColor;       // ��ɫ��Alphaͨ����Ч
    COLORREF    m_clrPushedTextColor;    // ��ɫ��Alphaͨ����Ч
    COLORREF    m_clrFocusedTextColor;   // ��ɫ��Alphaͨ����Ч
};

CONTROLS_END_NAMESPACE
#endif