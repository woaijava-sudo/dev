#include "StdAfx.h"
#include "UI_Markup.h"

UI_BEGIN_NAMESPACE
XMarkup::XMarkup( LPCTSTR pstrXML /*= NULL */ ): m_bPreserveWhitespace(false), m_pstrText(NULL)
{
    if( pstrXML != NULL )
    {
        m_szXML = pstrXML;
        _Load();
    }
}

XMarkup::~XMarkup()
{
    Release();
}

bool XMarkup::_Load()
{
    Release();
    bool bRes = _Parse();
    if( !bRes ) Release();
    return bRes;
}

void XMarkup::Release()
{
    m_pstrText = NULL;
    m_szXML.Empty();
    m_szXMLSaved.Empty();

    m_szErrorMsg.Empty();
    m_szErrorXML.Empty();
    for (int i = 0; i < m_aElements.Count(); i++)
    {
        delete m_aElements.Get(i);
    }
    m_aElements.Clear();
}

bool XMarkup::IsValid() const
{
    return m_aElements.Count() != 0;
}

BOOL XMarkup::IsNull() const
{
    return m_szXML.IsEmpty();
}

void XMarkup::SetPreserveWhitespace( bool bPreserve /*= true */ )
{
    m_bPreserveWhitespace = bPreserve;
}

XString XMarkup::GetLastErrorMessage() const
{
    return m_szErrorMsg;
}

XMarkupNode XMarkup::GetRoot()
{
    if( !IsValid() ) return XMarkupNode();
    return XMarkupNode(this, 1, &m_aElements, m_pstrText); // Why 1? <TOP>...counts...</TOP>
}

XML_ELEMENT* XMarkup::_GetReservedElement()
{
    XML_ELEMENT* pEle = new XML_ELEMENT;
    ASSERT(pEle);
    m_aElements.Add(pEle); // Saved new ptr, so deleted when XMarkup::Release()
    return pEle;
}

void XMarkup::_SkipWhitespace(LPCTSTR& pstr) const
{
    while( *pstr > _T('\0') && *pstr <= _T(' ') ) pstr = ::CharNext(pstr);
}

void XMarkup::_SkipWhitespace(LPTSTR& pstr) const
{
    while( *pstr > _T('\0') && *pstr <= _T(' ') ) pstr = ::CharNext(pstr);
}

void XMarkup::_SkipIdentifier(LPCTSTR& pstr) const
{
    // ����ֻ����Ӣ�ģ�������������û������
    while( *pstr != _T('\0') && (*pstr == _T('_') || *pstr == _T(':') || _istalnum(*pstr)) ) pstr = ::CharNext(pstr);
}

void XMarkup::_SkipIdentifier(LPTSTR& pstr) const
{
    // ����ֻ����Ӣ�ģ�������������û������
    while( *pstr != _T('\0') && (*pstr == _T('_') || *pstr == _T(':') || _istalnum(*pstr)) ) pstr = ::CharNext(pstr);
}

bool XMarkup::_Failed( LPCTSTR pstrError, LPCTSTR pstrLocation /*= NULL */ )
{
    ASSERT(pstrError);
    m_szErrorMsg = pstrError;
    m_szErrorXML = (pstrLocation != NULL) ? pstrLocation : EmptyString;

    m_szErrorXML = m_szErrorXML.Left(80);
    int nFind = m_szErrorXML.Find(_T("\n"));
    if (nFind != -1) m_szErrorXML = m_szErrorXML.Left(nFind);

    TRACE("#################### XML Parser(Fatal Error) ####################");
    TRACE(":: Message: %s", m_szErrorMsg);
    TRACE(":: Location: %s", m_szErrorXML);

    ASSERT(!"Markup::ParseXml failed (possible reason: Encoding?)");
    return false; // Always return false
}

UI_END_NAMESPACE