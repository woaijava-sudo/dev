#ifndef _CC_UI_WINDOW_DELEGATE_H
#define _CC_UI_WINDOW_DELEGATE_H

#pragma once

UI_BEGIN_NAMESPACE
class CL_API IDelegate
{
public:
    virtual bool RunDelegate( const XString&, void* ) = 0;
    virtual IDelegate* GetIDelegate() = 0;
protected:
    virtual bool CreateDelegate( const XString& ) = 0;
    virtual bool AddDelegate( const XString&, XFunVoid ) = 0;
    virtual bool RemoveDelegate( const XString& ) = 0;
    virtual void RemoveAllDelegates() = 0;
    virtual void InitializeDelegate() = 0;
};

DEF_DICT_TEMPLATE3(XString, XEventSource*, LPCTSTR);
class CL_API XDelegateImpl : public IDelegate
{
public:
    ~XDelegateImpl();
    virtual bool RunDelegate( const XString&, void* );
    virtual IDelegate* GetIDelegate() = 0;
protected:
    virtual bool CreateDelegate( const XString& );
    virtual bool AddDelegate( const XString&, XFunVoid );
    virtual bool RemoveDelegate( const XString& );
    virtual void RemoveAllDelegates();

private:
    Dictionary<XString, XEventSource*, LPCTSTR> m_mapDelegates;
};

UI_END_NAMESPACE
#endif