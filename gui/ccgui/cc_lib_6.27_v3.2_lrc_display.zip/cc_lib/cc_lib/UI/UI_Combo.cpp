#include "StdAfx.h"

CONTROLS_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS_WITH_PARA(XCombo, XContainer)
//////////////////////////////////////////////////////////////////////////

XCombo::XCombo( XObject* pOb /*= NULL*/ ): XContainer(pOb), m_pLayout(NULL), m_iCurSel(-1)
{
    ::ZeroMemory(&m_ListInfo, sizeof(TListInfo));
    m_szDropBox = XSize(0, 150);

    m_ListInfo.Text             = CLR_TLISTINFO_TEXT;
    m_ListInfo.Background       = CLR_TLISTINFO_BK;
    m_ListInfo.SelText          = CLR_TLISTINFO_SELTEXT;
    m_ListInfo.SelBackground    = CLR_TLISTINFO_SELBK;
    m_ListInfo.HotText          = CLR_TLISTINFO_HOTTEXT;
    m_ListInfo.HotBackground    = CLR_TLISTINFO_HOTBK;
    m_ListInfo.nColumns = 1;

    CreateLayout();
}

XCombo::~XCombo()
{
    if (m_pChildWindow2 != NULL)
    {
        m_pChildWindow2->_SendMessage( WM_CLOSE );
        m_pChildWindow2 = NULL;
    }
}

XControl* XCombo::CreateControl( XClass* pClass )
{
    ASSERT(pClass->IsDerivedFrom(X_CLASS(XListTextElement)));
    XControl* pControl = XControl::CreateControl(pClass);
    Combo_Add(pControl);
    pControl->SetEnable(FALSE);
    return pControl;
}

void* XCombo::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_COMBO: return this;
    case HI_COMBO_ARRAY: return static_cast<IComboArray*>(this);
    }
    return XContainer::GetInterface(hi);
}

XVerticalLayout* XCombo::GetLayout()
{
    return m_pLayout;
}

void XCombo::CreateLayout()
{
    XCanvas* pCanvas = GetICanvas(XContainer::XCreateControl(XCanvas));
    m_pLayout = GetIVerticalLayout(pCanvas->XCreateControl(XVerticalLayout));
    m_pLayout->SetBkColor(MAKE_RGB(XCOLOR_CONTROL_BACKGROUND_NORMAL));
}

BOOL XCombo::Activate()
{
    if( !XControl::Activate() ) return false;
    if( m_pChildWindow2 != NULL ) return true;
    X_CreateObject(X_CLASS(XComboWindow), (XObject**)&m_pChildWindow2);
    ASSERT(m_pChildWindow2 != NULL);
    m_pChildWindow2->Init(this);
    m_pWindow->SendAsyncNotify(this, (DWORD) _T("DropDown"), TRUE);
    Invalidate();
    return true;
}

const TListInfo* XCombo::GetListInfo() const
{
    return &m_ListInfo;
}

XSize XCombo::GetDropBoxSize() const
{
    return m_szDropBox;
}

void XCombo::SetDropBoxSize(XSize szDropBox)
{
    m_szDropBox = szDropBox;
}

int XCombo::GetCurSel() const
{
    return m_iCurSel;
}

bool XCombo::SelectItem( int iIndex )
{
    if( m_pChildWindow2 != NULL )
    {
        m_pChildWindow2 = NULL;
    }
    if( iIndex == m_iCurSel ) return true;
    int iOldSel = m_iCurSel;
    if( m_iCurSel >= 0 ) {
        XControl* pControl = Combo_GetData(m_iCurSel);
        if( pControl == NULL ) return false;
        ASSERT_VALID(pControl);
        IListItem* pListItem = GetIListItem(pControl);
        if( pListItem != NULL ) pListItem->Select(false);
        m_iCurSel = -1;
    }
    if( iIndex < 0 ) return false;
    int size = Combo_GetSize();
    if( size == 0 ) return false;
    if( iIndex >= size ) iIndex = size - 1;
    XControl* pControl = Combo_GetData(iIndex);
    if( pControl == NULL || !pControl->IsVisible() ) return false;
    IListItem* pListItem = GetIListItem(pControl);
    if( pListItem == NULL ) return false;
    m_iCurSel = iIndex;
    if( m_pWindow != NULL ) pControl->SetFocus();
    pListItem->Select(true);
    m_pWindow->SendAsyncNotify(this, (DWORD) _T("ItemSelect"), TRUE, m_iCurSel, iOldSel);
    Invalidate();

    EnsureVisible(m_iCurSel);

    return true;
}

void XCombo::ListEvent( TEvent& event )
{
    Event(event);
}

XControl* XCombo::Combo_GetData( int iIndex ) const
{
    return m_pLayout->GetData(iIndex);
}

int XCombo::Combo_Find( XControl* pControl ) const
{
    ASSERT_VALID(pControl);
    return m_pLayout->Find(pControl);
}

bool XCombo::Combo_SetAt( XControl* pControl, int iIndex )
{
    ASSERT_VALID(pControl);
    int iOrginIndex = m_pLayout->Find(pControl);
    if( iOrginIndex < 0 || iOrginIndex >= iIndex ) return false;

    IListItem* pListItem = NULL;
    if( m_iCurSel >= 0 )
    {
        pListItem = GetIListItem(Combo_GetData(m_iCurSel));
        ASSERT(pListItem);
    }

    if( !m_pLayout->SetAt(pControl, iIndex) ) return false;
    int iMinIndex = min(iOrginIndex, iIndex);
    int iMaxIndex = max(iOrginIndex, iIndex);
    for(int i = iMinIndex; i < iMaxIndex + 1; ++i) {
        XControl* p = Combo_GetData(i);
        ASSERT_VALID(p);
        IListItem* pListItem = GetIListItem(p);
        if( pListItem != NULL ) {
            pListItem->SetListOwner(this);
            pListItem->SetIndex(i);
        }
    }

    if( m_iCurSel >= 0 && pListItem != NULL ) m_iCurSel = pListItem->GetIndex();
    return true;
}

int XCombo::Combo_GetSize() const
{
    return m_pLayout->GetSize();
}

int XCombo::Combo_Add( XControl* pControl )
{
    ASSERT_VALID(pControl);
    ASSERT(pControl->GetInterface(HI_LIST_ITEM) != NULL);
    IListItem* pListItem = GetIListItem(pControl);
    if ( pListItem != NULL ) {
        pListItem->SetListOwner(this);
        pListItem->SetIndex(Combo_GetSize());
    }

    IListLabel* pListLabel = GetIListLabel(pControl);
    if ( pListLabel != NULL ) {
        pListLabel->SetCombo(this);
    }

    return m_pLayout->Add(pControl);
}

bool XCombo::Combo_InsertAt( int iIndex, XControl* pControl )
{
    ASSERT_VALID(pControl);
    if (!m_pLayout->InsertAt(iIndex, pControl)) return false;

    // The list items should know about us
    IListItem* pListItem = GetIListItem(pControl);
    if( pListItem != NULL ) {
        pListItem->SetIndex(iIndex);
    }

    for(int i = iIndex + 1; i < Combo_GetSize(); ++i) {
        XControl* pControl = m_pLayout->GetData(i);
        ASSERT_VALID(pControl);
        IListItem* pListItem = GetIListItem(pControl);
        if( pListItem != NULL ) {
            pListItem->SetListOwner(this);
            pListItem->SetIndex(i);
        }
    }

    if( m_iCurSel >= iIndex ) m_iCurSel += 1;
    return true;
}

bool XCombo::Combo_Remove( XControl* pControl )
{
    ASSERT_VALID(pControl);
    int iIndex = m_pLayout->Find(pControl);
    if (iIndex == -1) return false;

    if (!m_pLayout->RemoveAt(iIndex)) return false;

    for(int i = iIndex; i < Combo_GetSize(); ++i) {
        XControl* pControl = m_pLayout->GetData(i);
        ASSERT_VALID(pControl);
        IListItem* pListItem = GetIListItem(pControl);
        if( pListItem != NULL ) {
            pListItem->SetIndex(i);
        }
    }

    if( iIndex == m_iCurSel && m_iCurSel >= 0 ) {
        int iSel = m_iCurSel;
        m_iCurSel = -1;
        SelectItem(FindSelectable(iSel, false));
    }
    else if( iIndex < m_iCurSel ) m_iCurSel -= 1;
    return true;
}

bool XCombo::Combo_RemoveAt( int iIndex )
{
    if (!m_pLayout->RemoveAt(iIndex)) return false;

    for(int i = iIndex; i < Combo_GetSize(); ++i) {
        XControl* pControl = Combo_GetData(i);
        ASSERT_VALID(pControl);
        IListItem* pListItem = GetIListItem(pControl);
        if( pListItem != NULL ) pListItem->SetIndex(i);
    }

    if( iIndex == m_iCurSel && m_iCurSel >= 0 ) {
        int iSel = m_iCurSel;
        m_iCurSel = -1;
        SelectItem(FindSelectable(iSel, false));
    }
    else if( iIndex < m_iCurSel ) m_iCurSel -= 1;
    return true;
}

void XCombo::Combo_RemoveAll()
{
    m_iCurSel = -1;
    m_pLayout->RemoveAll();
}

void XCombo::SetEnable( BOOL bEnabled )
{
    XContainer::SetEnable(bEnabled);
    if( !m_bEnabled ) {
        m_uButtonState = 0;
    }
}

DWORD XCombo::GetFlags() const
{
    return ( m_bEnabled ?  ( m_flags | XFLAG_TABSTOP) : m_flags );
}

void XCombo::Event( TEvent& event )
{
    if (!m_bMouseEnabled)
    {
        if (OnMouseEvent(event.msg.message))
        {
            if ( m_pParent != NULL )
            {
                event.sender = this;
                event.receiver = m_pParent;
                event.dispatcher->PostEvent(event);
            }
            else
            {
                XContainer::Event(event);
            }
        }
    }
    else
    {
        switch (event.msg.message)
        {
        case WM_SETFOCUS:
            if ( m_bEnabled )
            {                
                Invalidate();
            }
            break;
        case WM_KILLFOCUS:
            if ( m_bEnabled && (m_uButtonState & XSTATE_PUSHED) != 0 ) {
                m_uButtonState &= ~XSTATE_PUSHED;
                Invalidate();
            }
            break;
        case WM_LBUTTONUP:
            if( m_bEnabled && (m_uButtonState & XSTATE_CAPTURED) != 0 ) {
                m_uButtonState &= ~XSTATE_CAPTURED;
                Invalidate();
            }
            break;
        case WM_MOUSEENTER:
            if( m_bEnabled )
            {
                m_uButtonState |= XSTATE_HOT;
                Invalidate();
            }
            return;
        case WM_MOUSELEAVE:
            if( m_bEnabled )
            {
                m_uButtonState &= ~XSTATE_HOT;
                Invalidate();
            }
            return;
        case WM_LBUTTONDOWN:
            if( m_bEnabled ) {
                Activate();
                m_uButtonState |= XSTATE_PUSHED | XSTATE_CAPTURED;
            }
            return;
        case WM_KEYDOWN:
            switch( event.msg.wParam ) {
            case VK_F4:
                Activate();
                return;
            case VK_UP:
                SelectItem(FindSelectable(m_iCurSel - 1, false));
                return;
            case VK_DOWN:
                SelectItem(FindSelectable(m_iCurSel + 1, true));
                return;
            case VK_PRIOR:
                SelectItem(FindSelectable(m_iCurSel - 1, false));
                return;
            case VK_NEXT:
                SelectItem(FindSelectable(m_iCurSel + 1, true));
                return;
            case VK_HOME:
                SelectItem(FindSelectable(0, false));
                return;
            case VK_END:
                SelectItem(FindSelectable(Combo_GetSize() - 1, true));
                return;
            }
            return;
        }

        XContainer::Event(event);
    }
}

XSize XCombo::EstimateSize( const XSize& )
{
    ASSERT_VALID(m_pWindow);
    return XSize(GetFixedWidth(), 12 + m_pWindow->GetFontInfoByHash(m_szFontHash)->tm.tmHeight);
}

void XCombo::EnsureVisible( int iIndex )
{
    if (m_pChildWindow2 != NULL && m_pChildWindow2->_IsWindow())
    {
        m_pChildWindow2->EnsureVisible(iIndex);
    }
}

void XCombo::Scroll( int dx, int dy )
{
    if (m_pChildWindow2 != NULL && m_pChildWindow2->_IsWindow())
    {
        m_pChildWindow2->Scroll(dx, dy);
    }
}

int XCombo::FindSelectable( int iIndex, bool bForward /*= true */ )
{
    IComboArray* Combo = GetIComboArray(this);
    ASSERT(Combo);
    int size = Combo->Combo_GetSize();
    if( size == 0 ) return -1;
    iIndex = CLAMP(iIndex, 0, size - 1);
    if( bForward ) {
        for( int i = iIndex; i < size; i++ ) {
            XControl* p = Combo->Combo_GetData(i);
            ASSERT_VALID(p);
            if( p->GetInterface(HI_LIST_ITEM) != NULL && p->IsVisible()) return i;
        }
        ASSERT(!"Index Valid.");
        return -1;
    }
    else {
        for( int i = iIndex; i >= 0; --i ) {
            XControl* p = Combo->Combo_GetData(i);
            ASSERT_VALID(p);
            if( p->GetInterface(HI_LIST_ITEM) != NULL 
                && p->IsVisible()
                && p->IsEnabled() ) return i;
        }
        return FindSelectable(0, true);
    }
}

void XCombo::SetRect( const XRect & rc )
{
    XContainer::SetRect(rc);

    m_ListInfo.rcColumn[0] = m_rcClient;
    if (m_szDropBox.cx == 0)
    {
        m_szDropBox.cx = m_rcClient.Width();
    }
}

void XCombo::Paint( HDC hDC, const XRect& rect )
{
    if ( !m_rcPaint.IntersectRect(&rect, &m_rcClient) ) return;

    XControl::PaintBkColor(hDC);

    int size = Combo_GetSize();
    if (size > 0) {
        m_iCurSel = CLAMP(m_iCurSel, 0, size - 1);

        XListTextElement* pControl = GetIListTextElement(Combo_GetData(m_iCurSel));
        ASSERT_VALID(pControl);
        pControl->SetRect(rect);

        UINT oldState = pControl->GetButtonState();
        pControl->SetEnable(TRUE, FALSE);
        pControl->SetButtonState(m_uButtonState);
        pControl->Select((m_uButtonState & XSTATE_PUSHED) != 0);
        pControl->Paint(hDC, rect);
        pControl->SetButtonState(oldState, m_uButtonState);
        pControl->SetEnable(FALSE, FALSE);
    } else {
        Rendering::X_DrawColor(hDC, m_rcClient, MAKE_RGB(XCOLOR_CONTROL_BACKGROUND_NORMAL));
    }
}

CONTROLS_END_NAMESPACE