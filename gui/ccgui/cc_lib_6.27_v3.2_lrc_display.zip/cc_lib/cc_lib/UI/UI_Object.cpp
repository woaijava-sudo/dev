#include "StdAfx.h"

UI_BEGIN_NAMESPACE
void XClassInit( XClass* pNewClass )
{
    pNewClass->m_pNextClass = _XClassManager::m_pFirstClass;
    _XClassManager::m_pFirstClass = pNewClass;
}

XObject* XClass::CreateObject()
{
    if (m_pfnCreateObject == NULL)
    {
        TRACE("Error: Create object failed. Class: %s ", m_lpszClassName);
        TRACE("Error: Null Pointer");
        ASSERT(0);
        return NULL;
    }

    XObject* pObject = NULL;
    try
    {
        pObject = (*m_pfnCreateObject)();
    }
    catch(XException* e)
    {
        ASSERT(e->XIsKindOf(XException));
        TRACE("Exception: %s  Message: %s", e->GetClass()->m_lpszClassName, e->m_szMessage);
    }

    return pObject;
}

XObject* XClass::CreateObject(XObject* pOb)
{
    if (m_pfnCreateObject_V2 == NULL)
    {
        TRACE("Error: Create object failed. Class: %s ", m_lpszClassName);
        TRACE("Error: Null Pointer  Possible reason: forget to declare as 'X_DECLARE_CLASS_WITH_PARA'?");
        ASSERT(0);
        return NULL;
    }

    XObject* pObject = NULL;
    try
    {
        pObject = (*m_pfnCreateObject_V2)(pOb);
    }
    catch(XException* e)
    {
        ASSERT(e->XIsKindOf(XException));
        TRACE("Exception: %s  Message: %s", e->GetClass()->m_lpszClassName, e->m_szMessage);
    }

    return pObject;
}

BOOL XClass::IsDerivedFrom( const XClass* pBaseClass ) const
{
    ASSERT(this != NULL);
    ASSERT(IsValidAddress(this, sizeof(XClass), FALSE));
    ASSERT(pBaseClass != NULL);
    ASSERT(IsValidAddress(pBaseClass, sizeof(XClass), FALSE));

    const XClass* pClassThis = this;
    while (pClassThis != NULL)
    {
        if (pClassThis == pBaseClass)
            return TRUE;
        pClassThis = pClassThis->m_pBaseClass;
    }
    return FALSE;
}

//////////////////////////////////////////////////////////////////////////

XObject::XObject(){}
XObject::~XObject(){}

XClass* XObject::GetClass() const { return X_CLASS(XObject); }

BOOL XObject::IsKindOf( const XClass* pClass ) const
{
    ASSERT(this != NULL);
    ASSERT(IsValidAddress(this, sizeof(XObject)));
    XClass* pClassThis = GetClass();
    return pClassThis->IsDerivedFrom(pClass);
}

void* XObject::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_OBJECT: return this;
    }
    return NULL;
}

XClass XObject::classXObject = { NULL, NULL, _T("XObject"), sizeof(XObject), NULL, NULL };

#ifdef _DEBUG
void XObject::AssertValid() const { ASSERT(this != NULL); }
#endif

//////////////////////////////////////////////////////////////////////////

X_IMPLEMENT_CLASS(XException, XObject)
XException::XException( BOOL bAutoDelete /*= TRUE*/ ):     m_bAutoDelete(bAutoDelete){}
XException::~XException() {}
void XException::Delete() { if (m_bAutoDelete) { delete this;} }

//////////////////////////////////////////////////////////////////////////

UI_END_NAMESPACE