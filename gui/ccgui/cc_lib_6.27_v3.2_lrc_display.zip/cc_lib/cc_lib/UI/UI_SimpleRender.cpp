#include "stdafx.h"

RENDERING_BEGIN_NAMESPACE
void X_DrawLine( HDC hDC, const XPoint& pt1, const XPoint& pt2, int iStyle, int cWidth, COLORREF color )
{
    ASSERT_HDC(hDC);
    HGDIOBJ Pen = ::CreatePen(iStyle, cWidth, color);
    HGDIOBJ Obj = ::SelectObject(hDC, Pen);
    ::MoveToEx(hDC, pt1.x, pt1.y, NULL);
    ::LineTo(hDC, pt2.x, pt2.y);
    ::SelectObject(hDC, Obj);
    ::DeleteObject(Pen);
}

void X_DrawRectangle( HDC hDC, const XRect& rc, int iStyle, int cWidth, COLORREF clrBorder, COLORREF clrFill )
{
    ASSERT_HDC(hDC);
    HGDIOBJ Pen = ::CreatePen(iStyle, cWidth, clrBorder);
    HGDIOBJ Obj = ::SelectObject(hDC, Pen);

    HGDIOBJ Brush = (clrFill == CLR_INVALID) ? ::GetStockObject(NULL_BRUSH) : ::CreateSolidBrush(clrFill);
    HGDIOBJ Obj2 = ::SelectObject(hDC, Brush);

    ::Rectangle(hDC, rc.left, rc.top, rc.right, rc.bottom);
    ::SelectObject(hDC, Obj);
    ::SelectObject(hDC, Obj2);
    ::DeleteObject(Pen);
    if (clrFill != CLR_INVALID) ::DeleteObject(Brush);
}

void X_DrawFrame( HDC hDC, const XRect& rc, int iStyle, int cWidth, COLORREF Light, COLORREF Dark, COLORREF Background, UINT uStyle )
{
    ASSERT_HDC(hDC);
    if( Background != CLR_INVALID ) {
        X_DrawColor(hDC, rc, Background);
    }
    HGDIOBJ Obj = ::SelectObject(hDC, ::GetStockObject(NULL_PEN));
    if( (uStyle & XDF_FRAME_ROUND) != 0 )
    {
        HGDIOBJ HLight = ::CreatePen(iStyle, cWidth, Light);
        HGDIOBJ HDark = ::CreatePen(iStyle, cWidth, Dark);
        ::SelectObject(hDC, HLight);
        ::MoveToEx(hDC, rc.left, rc.bottom - 2, NULL);
        ::LineTo(hDC, rc.left, rc.top + 1);
        ::LineTo(hDC, rc.left + 1, rc.top);
        ::LineTo(hDC, rc.right - 2, rc.top);
        ::SelectObject(hDC, HDark);
        ::LineTo(hDC, rc.right - 1, rc.top + 1);
        ::LineTo(hDC, rc.right - 1, rc.bottom - 2);
        ::LineTo(hDC, rc.right - 2, rc.bottom - 1);
        ::LineTo(hDC, rc.left, rc.bottom - 1);
        ::DeleteObject(HLight);
        ::DeleteObject(HDark);
    }
    if( (uStyle & XDF_FRAME_FOCUS) != 0 )
    {
        HGDIOBJ HPen = ::CreatePen(PS_DOT, 1, XCOLOR_BUTTON_BORDER_FOCUS);
        ::SelectObject(hDC, HPen);
        ::MoveToEx(hDC, rc.left, rc.bottom - 1, NULL);
        ::LineTo(hDC, rc.left, rc.top);
        ::LineTo(hDC, rc.right - 1, rc.top);
        ::LineTo(hDC, rc.right - 1, rc.bottom - 1);
        ::LineTo(hDC, rc.left, rc.bottom - 1);
    }
    if( (uStyle & (XDF_FRAME_ROUND | XDF_FRAME_FOCUS)) == 0)
    {
        HGDIOBJ HLight = ::CreatePen(iStyle, cWidth, Light);
        HGDIOBJ HDark = ::CreatePen(iStyle, cWidth, Dark);
        ::SelectObject(hDC, HLight);
        ::MoveToEx(hDC, rc.left, rc.bottom - 1, NULL);
        ::LineTo(hDC, rc.left, rc.top);
        ::LineTo(hDC, rc.right - 1, rc.top);
        ::SelectObject(hDC, HDark);
        ::LineTo(hDC, rc.right - 1, rc.bottom - 1);
        ::LineTo(hDC, rc.left, rc.bottom - 1);
        ::DeleteObject(HLight);
        ::DeleteObject(HDark);
    }
    ::SelectObject(hDC, Obj);
}

void X_DrawButton( HDC hDC, XWindow* pWindow, const XRect& rc, LPCTSTR pstrText, const XRect& rcPadding, UINT uState, HFONT hFont, UINT uStyle )
{
    ASSERT_HDC(hDC);
    ASSERT(pWindow);
    ASSERT(pstrText);
    XRect rt(rc);
    if( (uState & XSTATE_FOCUSED) != 0 ) {
        X_DrawFrame(hDC, rt, PS_SOLID, 1, XCOLOR_BUTTON_BORDER_FOCUS, XCOLOR_BUTTON_BORDER_FOCUS, CLR_INVALID, XDF_FRAME_ROUND);
        rt.DeflateRect(1, 1);
    }

    COLORREF clrBorder1, clrBorder2, clrText, clrBack1, clrBack2;
    if( (uState & XSTATE_DISABLED) != 0 ) {
        clrBorder1 = XCOLOR_BUTTON_BORDER_DISABLED;
        clrBorder2 = XCOLOR_BUTTON_BORDER_DISABLED;
        clrText = XCOLOR_BUTTON_TEXT_DISABLED;
        clrBack1 = XCOLOR_BUTTON_BACKGROUND_DISABLED;
        clrBack2 = XCOLOR_BUTTON_BACKGROUND_DISABLED_2;
    } else if( (uState & XSTATE_PUSHED) != 0 ) {
        clrBorder1 = XCOLOR_BUTTON_BORDER_DARK;
        clrBorder2 = XCOLOR_BUTTON_BORDER_LIGHT;
        clrText = XCOLOR_BUTTON_TEXT_PUSHED;
        clrBack1 = XCOLOR_BUTTON_BACKGROUND_PUSHED;
        clrBack2 = XCOLOR_BUTTON_BACKGROUND_PUSHED_2;
    } else {
        clrBorder1 = XCOLOR_BUTTON_BORDER_LIGHT;
        clrBorder2 = XCOLOR_BUTTON_BORDER_DARK;
        clrText = XCOLOR_BUTTON_TEXT_NORMAL;
        clrBack1 = XCOLOR_BUTTON_BACKGROUND_NORMAL;
        clrBack2 = XCOLOR_BUTTON_BACKGROUND_NORMAL_2;
    }

    X_DrawFrame(hDC, rt, PS_SOLID, 1, clrBorder1, clrBorder2, CLR_INVALID, XDF_FRAME_ROUND);
    rt.DeflateRect(1, 1);

    if( (uState & XSTATE_PUSHED) != 0 ) {
        X_DrawFrame(hDC, rt, PS_SOLID, 1, XCOLOR_STANDARD_LIGHTGREY, XCOLOR_STANDARD_LIGHTGREY, CLR_INVALID, XDF_FRAME_NORMAL);
        rt.top += 1;
        rt.left += 1;
    }

    X_DrawGradient(hDC, rt, clrBack1, clrBack2, true, 32);

    HGDIOBJ Pen = ::CreatePen(PS_SOLID, 1, XCOLOR_DIALOG_BACKGROUND);
    HGDIOBJ Obj = ::SelectObject(hDC, Pen);
    ::MoveToEx(hDC, rt.left, rt.top, NULL);
    ::LineTo(hDC, rt.left, rt.bottom - 1);
    ::LineTo(hDC, rt.right - 2, rt.bottom - 1);
    ::LineTo(hDC, rt.right - 2, rt.top);
    ::SelectObject(hDC, Obj);
    ::DeleteObject(Pen);

    rt.DeflateRect(1, 1);
    rt.left += rcPadding.left;
    rt.top += rcPadding.top;
    rt.right -= rcPadding.right;
    rt.bottom -= rcPadding.bottom;
    Rendering::X_DrawText(hDC, pWindow, rt, pstrText, clrText, hFont, DT_SINGLELINE | uStyle);
}

RENDERING_END_NAMESPACE