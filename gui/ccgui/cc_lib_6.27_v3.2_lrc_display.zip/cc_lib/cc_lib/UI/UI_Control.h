#ifndef _CC_UI_CONTROL_H
#define _CC_UI_CONTROL_H

#pragma once

CONTROLS_BEGIN_NAMESPACE
class XControl;
typedef XControl* (CALLBACK* X_FIND_CALL)(XControl*, void*);
CONTROLS_END_NAMESPACE
WINDOW_BEGIN_NAMESPACE
class XWindow;
WINDOW_END_NAMESPACE

#include "UI_ControlInterface.h"

#define DEFAULT_CONTROL_NAME _T("EX_CTRL")

#define GetIControl(p) ((XControl*)static_cast<XControl*>((p)->GetInterface(HI_CONTROL)))
#define Force_Control(p) ((XControl*)static_cast<XControl*>(p))

//////////////////////////////////////////////////////////////////////////

#define XFIND_VISIBLE       0x00000001
#define XFIND_ENABLED       0x00000002
#define XFIND_HITTEST       0x00000004
#define XFIND_TOP_FIRST     0x00000008
#define XFIND_ME_FIRST      0x00000010

// Flags for GetFlags()
#define XFLAG_TABSTOP       0x00000001
#define XFLAG_SETCURSOR     0x00000002
#define XFLAG_WANTRETURN    0x00000004
#define XFLAG_STATIC        0x00000008
#define XFLAG_AUTOCLEAR     0x00000010
#define XFLAG_FLEXIABLE     0x00000020

// Draw item style
#define XDRS_INPLACE        0x00000001
#define XDRS_FOCUS          0x00000002

// Flags used for controlling the paint
#define XSTATE_FOCUSED      0x00000001
#define XSTATE_SELECTED     0x00000002
#define XSTATE_DISABLED     0x00000004
#define XSTATE_HOT          0x00000008
#define XSTATE_PUSHED       0x00000010
#define XSTATE_READONLY     0x00000020
#define XSTATE_CAPTURED     0x00000040

// Flags used for calculating its position in the cantainer, and based on the rect width & height of it
#define XPOS_NORMAL         0x0000
#define XPOS_LEFT           0x0001
#define XPOS_TOP            0x0002
#define XPOS_RIGHT          0x0004
#define XPOS_BOTTOM         0x0008
#define XPOS_CENTER         0x0010
#define XPOS_VCENTER        0x0020
#define XPOS_RECALC         0x0100

//////////////////////////////////////////////////////////////////////////

/************************************************************************/
/* ���д� XControl �̳е������ʵ���в� XObject ���캯������ؽӿ�      */
/************************************************************************/
CONTROLS_BEGIN_NAMESPACE
using namespace UI;
using namespace Window;
class CL_API XControl : public XObject, public IEvent, public XDelegateImpl, public IRegisterable,
    public ICalcPosImpl, public IPrintBkImpl, public IFixedWidthImpl, public IFixedHeightImpl, public IShowHtmlImpl
{
    X_DECLARE_CLASS_WITH_PARA(XControl);
public:
    XControl(XObject* pOb = NULL);
    virtual ~XControl();

    virtual void* GetInterface(UI::HINTERFACE hi);
    virtual IDelegate* GetIDelegate();

    virtual void SetParent(XControl* pParent);
    XControl* GetParent() const;

    virtual void SetOwner(XWindow* pWindow);
    XWindow* GetOwner() const;

    void SetName(LPCTSTR);
    XString GetName() const;

    void SetText(LPCTSTR);
    XString GetText() const;

    // �ͻ���С
    virtual void SetRect(const XRect &); // ע�⣡��ָ�ͻ����꣡����ָ������С
    virtual XRect GetRect() const;
    XRect GetOriginRect() const;
    void ResetRect();

    virtual void SetOffset(const XPoint &);
    virtual XPoint GetOffset() const;

    virtual void SetDrag(BOOL bDrag);
    virtual BOOL IsDrag() const;

    virtual void SetBorder(XSize);
    virtual XSize GetBorder() const;

    virtual void SetBkColor(COLORREF dwBkColor); // �ؼ��ı�����ɫ��֧��ARGB
    virtual DWORD GetBkColor() const;

    virtual void SetBkColor1(COLORREF dwBkColor1); // �ؼ��ı�����ɫ������1��
    virtual DWORD GetBkColor1() const;

    virtual void SetBkColor2(COLORREF dwBkColor2); // �ؼ��ı�����ɫ������2��
    virtual DWORD GetBkColor2() const;

    virtual void SetBkImage(LPCTSTR pstrImage); // �ؼ��ı���ͼƬ
    virtual XString GetBkImage() const;

    virtual void SetVisible(BOOL bVisible);
    virtual BOOL IsVisible() const;

    virtual void SetEnable(BOOL bEnabled, BOOL bRedraw = TRUE);
    virtual BOOL IsEnabled() const;

    virtual void SetFocus();
    virtual BOOL IsFocused() const;

    virtual void SetMouseEnable(BOOL bEnabled);
    virtual BOOL IsMouseEnabled() const;

    void SetFlags(DWORD flag);
    virtual DWORD GetFlags() const;

    virtual BOOL SetTextFont(LPCTSTR szName, int nSize, BOOL bBold = FALSE, BOOL bUnderline = FALSE, BOOL bItalic = FALSE);
    virtual void SetTextFont(XControl*);
    virtual HFONT GetTextFont();
    virtual TFont* GetTextFontInfo();

    DWORD GetAdjustColor(DWORD dwColor);
    virtual BOOL Activate();

    void NeedUpdate();
    void NeedParentUpdate();
    BOOL IsNeedUpdate() const;
    XControl* GetParents(int nID = 0); // ID = 0 => this

    void Invalidate();
    virtual XSize EstimateSize( const XSize& ); // ��������VerticalLayout HorizonalLayout�Լ����С
    virtual XSize CalcSize(); // ���ڼ����϶���С��Χ��Ӧ��DT_CALCRECT

    virtual void Paint(HDC hDC, const XRect& rect);
    virtual void PaintBkColor( HDC hDC );
    virtual void PaintText( HDC hDC );
    virtual void PaintBkImage( HDC hDC );
    virtual void PostPaint( HDC m_hDcOffscreen, XRect& rect );

    BOOL PaintImage( HDC hDC, LPCTSTR pstrImage, LPCTSTR pstrModify = NULL, bool bNeedAlpha = FALSE, BYTE bNewFade = 255 );
    void GetRegion(HDC hDC, LPCTSTR pstrImage, COLORREF dwColorKey);

    bool OnMouseEvent(UINT uMsg);

    // �¼�
    virtual void Event( TEvent& event );

    // ����
    virtual XControl* FindControl(X_FIND_CALL Proc, LPVOID pData, UINT uFlags);

    // ע��
    virtual void Register();
    virtual void Unregister();

public:
    /************************************************************************/
    /*_______����ʹ��CreateControl��̬���� �����е�����Ϣ��_________________*/
    /*_______��base:XWindow�д��� X_CreateControl(base:XControl, this)______*/
    /************************************************************************/
    static XControl* CreateControl(UI::XClass* pClass, XWindow* pWindow);
    /************************************************************************/
    /*_______����ʹ��CreateControl��̬���� �����е�����Ϣ��_________________*/
    /*_______��base:XControl�д��� this->XCreateControl(base:XControl)_ ____*/
    /************************************************************************/
    virtual XControl* CreateControl(UI::XClass* pClass);

#ifdef _DEBUG
    virtual void AssertValid() const;
#endif // _DEBUG

protected:
    virtual void InitializeDelegate();

protected:
    XWindow*    m_pWindow;
    XControl*   m_pParent;
    XRect       m_rcClient;
    XRect       m_rcOrigin;
    XRect       m_rcPaint;
    XPoint      m_ptOffset;
    XSize       m_szBorder;
    BOOL        m_bNeedUpdate;
    COLORREF    m_dwBkColor;
    COLORREF    m_dwBkColor1;
    COLORREF    m_dwBkColor2;
    XString     m_szName;
    XString     m_szText;
    XPoint      m_ptTrackOrigin;
    DWORD       m_flags;
    XString     m_szFontHash; // ����ָ��
    XString     m_szBkImage;  // ����ͼƬ
    HRGN        m_hRgn;

    BOOL        m_bVisible;
    BOOL        m_bEnabled;
    BOOL        m_bFocused;
    BOOL        m_bFloat;
    BOOL        m_bDrag;
    BOOL        m_bTrack;
    BOOL        m_bMouseEnabled;
    BOOL        m_bGetRegion;
    BOOL        m_bColorHSL;
};
CONTROLS_END_NAMESPACE

#endif