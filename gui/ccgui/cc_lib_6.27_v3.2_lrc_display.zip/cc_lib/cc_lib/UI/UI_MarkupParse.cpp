#include "stdafx.h"
#include "UI_Markup.h"

UI_BEGIN_NAMESPACE
bool XMarkup::_Parse()
{
    if (m_szXML.IsEmpty()) return _Failed(_T("Error: The input xml string is null (Encoding?)"), NULL);

    m_szXMLSaved = m_szXML; // For security
    LPTSTR pstrText = m_szXMLSaved.GetBuffer(0);
    m_pstrText = pstrText;
    ASSERT(m_pstrText);
    _GetReservedElement(); // For Lv.0
    return _Parse(pstrText, 0); // Parent is Lv.0, equal to <Window>, and first control(container) is Lv.1, which to show
}

bool XMarkup::_Parse( LPTSTR& pstrText, ULONG iParent )
{
    _SkipWhitespace(pstrText);
    ULONG iPrevious = 0;
    for( ; ; ) 
    {
        // Parse completed
        if( *pstrText == _T('\0') && iParent <= 1 ) return true;
        _SkipWhitespace(pstrText);

        // Parse tag
        if( *pstrText != _T('<') ) return _Failed(_T("Expected start-tag start"), pstrText); // Invalid tag
        if( pstrText[1] == _T('/') ) return true; // Closed tag (like "</XXX>")

        *pstrText++ = _T('\0'); // Block
        _SkipWhitespace(pstrText);

        // Skip comment or processing directive
        if( *pstrText == _T('!') || *pstrText == _T('?') ) {
            TCHAR ch = *pstrText;
            if( *pstrText == _T('!') ) ch = _T('-');
            while( *pstrText != _T('\0') && !(*pstrText == ch && *(pstrText + 1) == _T('>')) ) pstrText = ::CharNext(pstrText);
            if( *pstrText != _T('\0') ) pstrText += 2;
            _SkipWhitespace(pstrText);
            continue;
        }
        _SkipWhitespace(pstrText);

        // Fill out element structure
        XML_ELEMENT* pEle = _GetReservedElement();
        ULONG iPos = m_aElements.Count() - 1;
        pEle->iStart = pstrText - m_pstrText;
        pEle->iParent = iParent;
        pEle->iNext = pEle->iChild = 0;
        if( iPrevious != 0 ) m_aElements[iPrevious]->iNext = iPos;
        else if( iParent > 0 ) m_aElements[iParent]->iChild = iPos;
        iPrevious = iPos;

        // Parse name
        LPCTSTR pstrName = pstrText;
        _SkipIdentifier(pstrText);
        LPTSTR pstrNameEnd = pstrText;
        if( *pstrText == _T('\0') ) return _Failed(_T("Error parsing element name"), pstrText);

        // Parse attributes
        if( !_ParseAttributes(pstrText) ) return false;
        _SkipWhitespace(pstrText);

        // Parse start-tag closing
        if( pstrText[0] == _T('/') && pstrText[1] == _T('>') )
        {
            pEle->iData = pstrText - m_pstrText;
            *pstrText = _T('\0');
            pstrText += 2;
        }
        else
        {
            if( *pstrText != _T('>') ) return _Failed(_T("Expected start-tag closing"), pstrText);

            // Parse node data
            pEle->iData = ++pstrText - m_pstrText;
            LPTSTR pstrDest = pstrText;
            if( !_ParseData(pstrText, pstrDest, _T('<')) ) return false;

            // Determine type of next element
            if( *pstrText == _T('\0') && iParent <= 1 ) return true;
            if( *pstrText != _T('<') ) return _Failed(_T("Expected end-tag start"), pstrText);

            // Parse end-tag start
            if( pstrText[0] == _T('<') && pstrText[1] != _T('/') ) 
            {
                if( !_Parse(pstrText, iPos) ) return false;
            }
            if( pstrText[0] == _T('<') && pstrText[1] == _T('/') ) 
            {
                *pstrDest = _T('\0');
                *pstrText = _T('\0');
                pstrText += 2;
                _SkipWhitespace(pstrText);

                // Searching for end-tag closing
                size_t cchName = pstrNameEnd - pstrName;
                if( _tcsncmp(pstrText, pstrName, cchName) != 0 ) return _Failed(_T("Unmatched end-tag closing"), pstrText);
                pstrText += cchName;
                _SkipWhitespace(pstrText);

                if( *pstrText++ != _T('>') ) return _Failed(_T("Unmatched end-tag closing"), pstrText);
            }
        }

        *pstrNameEnd = _T('\0'); // Block
        _SkipWhitespace(pstrText);
    }
}

bool XMarkup::_ParseData( LPTSTR& pstrText, LPTSTR& pstrDest, char cEnd )
{
    while( *pstrText != _T('\0') && *pstrText != cEnd ) {
        if( *pstrText == _T('&') ) {
            while( *pstrText == _T('&') ) {
                _ParseMetaChar(++pstrText, pstrDest);
            }
            if (*pstrText == cEnd)
                break;
        }

        if( *pstrText == _T(' ') ) {
            *pstrDest++ = *pstrText++;
            if( !m_bPreserveWhitespace ) _SkipWhitespace(pstrText);
        }
        else {
            LPTSTR pstrTemp = ::CharNext(pstrText);
            while( pstrText < pstrTemp) {
                *pstrDest++ = *pstrText++;
            }
        }
    }
    // Make sure that _MapAttributes() works correctly when it parses
    // over a value that has been transformed.
    LPTSTR pstrFill = pstrDest + 1;
    while( pstrFill < pstrText ) *pstrFill++ = _T(' ');
    return true;
}

void XMarkup::_ParseMetaChar( LPTSTR& pstrText, LPTSTR& pstrDest )
{
    if( pstrText[0] == _T('a') && pstrText[1] == _T('m') && pstrText[2] == _T('p') && pstrText[3] == _T(';') ) {
        *pstrDest++ = _T('&'); pstrText += 4;
    } else if( pstrText[0] == _T('l') && pstrText[1] == _T('t') && pstrText[2] == _T(';') ) {
        *pstrDest++ = _T('<'); pstrText += 3;
    } else if( pstrText[0] == _T('g') && pstrText[1] == _T('t') && pstrText[2] == _T(';') ) {
        *pstrDest++ = _T('>'); pstrText += 3;
    } else if( pstrText[0] == _T('q') && pstrText[1] == _T('u') && pstrText[2] == _T('o') && pstrText[3] == _T('t') && pstrText[4] == _T(';') ) {
        *pstrDest++ = _T('\"'); pstrText += 5;
    } else if( pstrText[0] == _T('a') && pstrText[1] == _T('p') && pstrText[2] == _T('o') && pstrText[3] == _T('s') && pstrText[4] == _T(';') ) {
        *pstrDest++ = _T('\''); pstrText += 5;
    } else {
        *pstrDest++ = _T('&');
    }
}

bool XMarkup::_ParseAttributes( LPTSTR& pstrText )
{
    if( *pstrText == _T('>') ) return true;
    *pstrText++ = _T('\0');
    _SkipWhitespace(pstrText);
    while( *pstrText != _T('\0') && *pstrText != _T('>') && *pstrText != _T('/') ) {
        _SkipIdentifier(pstrText);
        LPTSTR pstrIdentifierEnd = pstrText;
        _SkipWhitespace(pstrText);
        if( *pstrText != _T('=') ) return _Failed(_T("Attribute tag missing '='"), pstrText);
        *pstrText++ = _T(' ');
        *pstrIdentifierEnd = _T('\0');
        _SkipWhitespace(pstrText);
        if( *pstrText++ != _T('\"') ) return _Failed(_T("Attribute value missing '\"'"), pstrText);
        LPTSTR pstrDest = pstrText;
        if( !_ParseData(pstrText, pstrDest, _T('\"')) ) return false;
        if( *pstrText == _T('\0') ) return _Failed(_T("Error while parsing attribute value"), pstrText);
        *pstrDest = _T('\0');
        if( pstrText != pstrDest ) *pstrText = _T(' ');
        pstrText++;
        _SkipWhitespace(pstrText);
    }
    return true;
}

UI_END_NAMESPACE