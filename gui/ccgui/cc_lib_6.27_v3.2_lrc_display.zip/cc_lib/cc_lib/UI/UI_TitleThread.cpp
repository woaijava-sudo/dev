#include "stdafx.h"

WINDOW_BEGIN_NAMESPACE

XTitleThread::XTitleThread()
{
    stop = set_attr = FALSE;
    attr.t_fade_in = XTITLE_FADE_IN;
    attr.t_hold = XTITLE_HOLD;
    attr.t_fade_out = XTITLE_FADE_OUT;
    attr.t_delay = 10;
    memcpy(&tmp_attr, &attr, sizeof(XTitleAttr));
}

XTitleThread::~XTitleThread()
{
    TRACE("Thread '%s' exit", GetName());
}

BOOL XTitleThread::SetAttr( UINT nType, DWORD dwValue )
{
    set_attr = TRUE;
    BOOL result = TRUE;
    cs_post.Enter();
    switch (nType)
    {
    case XTITLE_WM_SET_TIME_FADE_IN:
        tmp_attr.t_fade_in = dwValue;
        break;
    case XTITLE_WM_SET_TIME_HOLD:
        tmp_attr.t_hold = dwValue;
        break;
    case XTITLE_WM_SET_TIME_FADE_OUT:
        tmp_attr.t_fade_out = dwValue;
        break;
    case XTITLE_WM_SET_MAX_DELAY:
        tmp_attr.t_delay = dwValue;
        break;
    default:
        result = FALSE;
    }
    cs_post.Leave();
    return result;
}

DWORD XTitleThread::GetAttr( UINT nType )
{
    DWORD result = 0;
    cs_post.Enter();
    switch (nType)
    {
    case XTITLE_WM_SET_TIME_FADE_IN:
        result = tmp_attr.t_fade_in;
        break;
    case XTITLE_WM_SET_TIME_HOLD:
        result =  tmp_attr.t_hold;
        break;
    case XTITLE_WM_SET_TIME_FADE_OUT:
        result = tmp_attr.t_fade_out;
        break;
    case XTITLE_WM_SET_MAX_DELAY:
        result = tmp_attr.t_delay;
        break;
    }
    cs_post.Leave();
    return result;
}

void XTitleThread::RemoveStop()
{
    int tasks = task.Count();
    if (tasks > 0)
    {
        List<int> remove_task_id;
        for (int i = tasks - 1; i >= 0; i--)
        {
            int cnt = 0;
            while (i >= 0 && task[i]->state == XTitleTask::STOP)
            {
                i--; cnt++;
            }

            if (cnt > 0)
            {
                task.RemoveRange(i + 1, cnt);
            }
        }
    }
}

void XTitleThread::Run()
{
    using namespace Enumerator;
    using namespace Enumerator::Internal;

    List<XString*> post_copy; // post�ı���
    while (!stop)
    {
        // ���̶�֡�ʵĹ���
        // ...
        Sleep(10);

        // ���post�Լ�����attr
        cs_post.Enter();
        if (post.Count() != 0)
        {
            CopyFrom(post_copy.Wrap(), post.Wrap());
            post.Clear();
       }
        if (set_attr)
        {
            memcpy(&attr, &tmp_attr, sizeof(XTitleAttr));
            set_attr = FALSE;
        }
        cs_post.Leave();

        // insert
        if (post_copy.Count() > 0)
        {
            // post_copy -> task
            auto enumerator = post_copy.Wrap().CreateEnumerator();
            while (enumerator->Next())
            {
                auto pTask = new XTitleTask(enumerator->Current());
                task.Add(pTask);
            }
            delete enumerator;
            post_copy.Clear();
        }

        // ����
        // ...
        {
            auto task_it = task.Wrap().CreateEnumerator();
            int cts = task.Count() - attr.t_delay;
            if (cts < 0)
            {
                cts = 0;
            }
            while (task_it->Next())
            {
                DWORD cur_tick = ::timeGetTime();
                XTitleTask* cur_task = task_it->Current().Obj();
                cur_task->cur_tick = cur_tick;
                DWORD dur = cur_tick - cur_task->ref_tick; // during

                if (task_it->Index() >= cts)
                {
                    // calc state translation & completed
                    switch (cur_task->state)
                    {
                    case XTitleTask::READY:
                        {
                            cur_task->completed = 0.0;
                            cur_task->ref_tick = cur_tick;
                            cur_task->state = XTitleTask::FADE_IN;
                        }
                        break;
                    case XTitleTask::FADE_IN:
                        if (dur > attr.t_fade_in)
                        {
                            cur_task->completed = 0.0;
                            cur_task->ref_tick = cur_tick;
                            cur_task->state = XTitleTask::HOLD;
                        }
                        else
                        {
                            cur_task->completed = 1.0 * dur / tmp_attr.t_fade_in;
                        }
                        break;
                    case XTitleTask::HOLD:
                        if (dur > attr.t_hold)
                        {
                            cur_task->completed = 0.0;
                            cur_task->ref_tick = cur_tick;
                            cur_task->state = XTitleTask::FADE_OUT;
                        }
                        else
                        {
                            cur_task->completed = 1.0 * dur / tmp_attr.t_hold;
                        }
                        break;
                    case XTitleTask::FADE_OUT:
                        if (dur > attr.t_fade_out)
                        {
                            cur_task->completed = 0.0;
                            cur_task->ref_tick = cur_tick;
                            cur_task->state = XTitleTask::STOP;
                        }
                        else
                        {
                            cur_task->completed = 1.0 * dur / tmp_attr.t_fade_out;
                        }
                        break;
                    }
                }
                else
                {
                    if (cur_task->state != XTitleTask::FADE_OUT)
                    {
                        cur_task->completed = 0.0;
                        cur_task->ref_tick = cur_tick;
                        cur_task->state = XTitleTask::FADE_OUT;
                    }
                    else
                    {
                        if (dur > attr.t_fade_out)
                        {
                            cur_task->completed = 0.0;
                            cur_task->ref_tick = cur_tick;
                            cur_task->state = XTitleTask::STOP;
                        }
                        else
                        {
                            cur_task->completed = 1.0 * dur / tmp_attr.t_fade_out;
                        }
                    }
                }
            }
            delete task_it;
        }

        // ���stop
        RemoveStop();
        
        // cache
        if (cs.TryEnter())
        {
            CopyFrom(cache.Wrap(), task.Wrap());
            cs.Leave();
        }

        // ֪ͨ�����ػ�
        m_pOwner->Invalidate();

        Sleep(10);
    }
}
void XTitleThread::Init( XTitleWindow* pOwner )
{
    TRACE("Thread '%s' init", GetName());
    m_pOwner = pOwner;
}

void XTitleThread::Terminate()
{
    TRACE("Thread '%s' terminate", GetName());
    stop = TRUE;
}

void XTitleThread::Post( XString* pstrText )
{
    ASSERT(pstrText);

    CriticalSection::Scope scope(cs_post);
    post.Add(pstrText);
}

const XTitleTaskList* XTitleThread::Lock()
{
    cs.Enter();
    return &cache;
}

void XTitleThread::Unlock()
{
    cs.Leave();
}

WINDOW_END_NAMESPACE