#include "stdafx.h"
#include "UI_ClassManager.h"

UI_BEGIN_NAMESPACE
#ifdef XManager_Dumping
_XAdvClassInfo::_XAdvClassInfo( XClass* pClass ): m_pClass(pClass)
{

}

_XAdvClassInfo::~_XAdvClassInfo()
{
    if (m_aClass.GetSize() == 0) return;
    
    for (int i = 0; i < m_aClass.GetSize(); i++)
    {
        XObject* pObj = static_cast<XObject*>(m_aClass.Get(i));
        ASSERT_VALID(pObj);
        XClass* pClass = pObj->GetClass();
        TRACE("");
        TRACE(":: ======================== Memory Leak ========================");
        TRACE(":: [#%d] Object address: [ 0x%p ] size: [ %dBytes ] class: < %s >", i, pObj, pClass->m_nObjectSize, pClass->m_lpszClassName);
        if (pClass->IsDerivedFrom(X_CLASS(XControl)))
        {
            XControl* pControl = GetIControl(pObj);
            ASSERT_VALID(pControl);
            TRACE(":: ------------------------ < XControl > ------------------------");
            TRACE("::         Name: %s", pControl->GetName());
            TRACE("::         Text: %s", pControl->GetText());
            TRACE("::         Rect: %s", pControl->GetRect().ToString());
        } else if (pClass->IsDerivedFrom(X_CLASS(XWindow))) {
            XWindow* pWindow = GetIWindowEx(pObj);
            ASSERT_VALID(pWindow);
            TRACE(":: ------------------------ < XWindow > ------------------------");
            TRACE("::         HWND: 0x%p", pWindow->GetSafeHwnd());
        }
        TRACE("");
    }
}

void _XAdvClassInfo::Add( XObject* pObj )
{
    ASSERT(pObj);
    m_aClass.Add(pObj);
}

void _XAdvClassInfo::Remove( XObject* pObj )
{
    ASSERT(pObj);
    for (int i = 0; i < m_aClass.GetSize(); i++)
    {
        if (m_aClass.Get(i) == pObj)
        {
            m_aClass.RemoveAt(i);
            return;
        }
    }

    ASSERT(!"Target object has already been deleted!");
}
#endif // XManager_Dumping
UI_END_NAMESPACE