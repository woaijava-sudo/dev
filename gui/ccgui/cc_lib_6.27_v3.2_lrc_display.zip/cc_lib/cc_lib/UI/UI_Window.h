#ifndef _CC_UI_WINDOW_H
#define _CC_UI_WINDOW_H

#pragma once

#define x_msg_call

//////////////////////////////////////////////////////////////////////////

#define XWS_CONTAINER   (0)
#define XWS_FRAME       (WS_VISIBLE | WS_OVERLAPPEDWINDOW)
#define XWS_POPUP       (WS_VISIBLE | WS_POPUPWINDOW)
#define XWS_CHILD       (WS_VISIBLE | WS_CHILD | WS_CLIPSIBLINGS | WS_CLIPCHILDREN)
#define XWS_DIALOG_ANI  (WS_VISIBLE | WS_POPUPWINDOW | WS_CAPTION | WS_DLGFRAME)
#define XWS_DIALOG      (WS_VISIBLE | WS_POPUPWINDOW | WS_CAPTION | WS_DLGFRAME | WS_CLIPSIBLINGS | WS_CLIPCHILDREN)

#define XWSE_FRAME      (WS_EX_WINDOWEDGE)
#define XWSE_DIALOG     (WS_EX_TOOLWINDOW | WS_EX_DLGMODALFRAME)

#define XCS_CONTAINER   (0)
#define XCS_FRAME       (CS_VREDRAW | CS_HREDRAW)
#define XCS_CHILD       (CS_VREDRAW | CS_HREDRAW | CS_DBLCLKS | CS_SAVEBITS)
#define XCS_DIALOG      (CS_VREDRAW | CS_HREDRAW | CS_DBLCLKS | CS_SAVEBITS)

#define WM_MOUSEENTER   0x2A2
#define WM_EFFECT       (WM_USER + 2014)

WINDOW_BEGIN_NAMESPACE
using namespace UI;
using namespace Controls;
using namespace Containers;
// Timer Info
typedef struct tagXTIMERINFO
{
    XControl*   sender;
    HWND        hWnd;
    UINT        nLocalID;
    UINT        uWinTimer;
    UINT        uElapse;
    BOOL        bKilled;
} XTIMERINFO;

// Structure for notifications to the outside world
typedef struct tagTAsyncNotify
{
    XControl*   sender;
    BOOL        bTrans; // �Ƿ�Ϊ�Զ�����Ϣ
    MSG         msg;
} TAsyncNotify;

typedef struct tagTSyncNotify // ͬ���Զ�����Ϣ����Ϊ��ͬ�������Դ�ſ��������ܴ�����ú�ָ��
{
    XString     pstrMessage; // ��Ϣ����
    WPARAM      wParam;
    LPARAM      lParam;
} TSyncNotify;

// Listener interface
class IXNotify
{
public:
    virtual void Notify(TAsyncNotify& notify) = 0;
    virtual void AddSyncNotify(LPCTSTR pstrText, WPARAM wParam = 0, LPARAM lParam = 0) = 0;
};

// MessageFilter interface
class IXMessageFilter
{
public:
    virtual LRESULT MessageFilter(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL* bHandled) = 0;
};

#define SAFE_DELETE_DC(hdc) \
{ \
    if (hdc) { ::DeleteDC(hdc); hdc = NULL; } \
}

#define SAFE_DELETE_BITMAP(hbitmp) \
{ \
    if (hbitmp) { ::DeleteObject(hbitmp); hbitmp = NULL; } \
}

//////////////////////////////////////////////////////////////////////////

DEF_LIST_TEMPLATE2(XString, LPCTSTR);
DEF_LIST_TEMPLATE1(IXMessageFilter*);
DEF_LIST_TEMPLATE1(TAsyncNotify*);
DEF_LIST_TEMPLATE1(TSyncNotify*);
DEF_LIST_TEMPLATE1(IXNotify*);
DEF_LIST_TEMPLATE1(XTIMERINFO*);
DEF_LIST_TEMPLATE1(XWindow*);
DEF_DICT_TEMPLATE3(XString, XControl*, LPCTSTR);
DEF_DICT_TEMPLATE3(XString, TImage*, LPCTSTR);
DEF_DICT_TEMPLATE3(XString, TFont*, LPCTSTR);

//////////////////////////////////////////////////////////////////////////

#define X_CreateWindow(RuntimeClass) XWindow::__Create(X_CLASS(RuntimeClass))

class CL_API XWindow : public XCmdTarget, public IXMessageFilter, public IXNotify, public IXFont, public IXImage
{
    X_DECLARE_CLASS(XWindow)
public:
    XWindow();
    virtual ~XWindow();

    virtual void DeleteComponents();
    virtual void Notify(TAsyncNotify& notify);

    virtual HWND Create( HWND hwndParent, LPCTSTR pstrName, DWORD dwStyle, DWORD dwExStyle, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT, int cx = CW_USEDEFAULT, int cy = CW_USEDEFAULT, HMENU hMenu = NULL );

    WPARAM MessageLoop();
    virtual void InitializeUI( HWND hwndParent = NULL, DWORD dwStyle = XWS_FRAME, DWORD dwExStyle = XWSE_FRAME );

    WPARAM DoModal();
    void Close();

    HDC GetDC() const;
    void SetParentWindow( XWindow* );
    void Dead();

    void ExecAsyncNotify();

    BOOL AddNotifier(IXNotify* pNotifier);
    BOOL RemoveNotifier(IXNotify* pNotifier);
    void SendAsyncNotify(TAsyncNotify& notify, XWindow* pSender = NULL, BOOL bSync = FALSE); // �첽��Ϣ
    void SendAsyncNotify(XControl* pControl, DWORD dwMessage, BOOL bTrans = FALSE, WPARAM wParam = 0, LPARAM lParam = 0,
        XWindow* pSender = NULL, BOOL bAsync = FALSE);
    void SendSyncNotify(LPCTSTR pstrText, WPARAM wParam = 0, LPARAM lParam = 0, IXNotify* _INotify = NULL); // ����ͬ����Ϣ
    void AddSyncNotify(LPCTSTR pstrText, WPARAM wParam = 0, LPARAM lParam = 0);  // ����ͬ����Ϣ
    void ExecSyncNotify(); // ����ͬ����Ϣ

    BOOL AddPreMessageFilter(IXMessageFilter* pFilter);
    BOOL RemovePreMessageFilter(IXMessageFilter* pFilter);

    BOOL AddMessageFilter(IXMessageFilter* pFilter);
    BOOL RemoveMessageFilter(IXMessageFilter* pFilter);

    int  GetPostPaintCount() const;
    BOOL AddPostPaint(XControl* pControl);
    BOOL RemovePostPaint(XControl* pControl);
    void SetPostPaintIndex(XControl* pControl, int iIndex);

    int AddAnimation(XAnimTask& task);

    // Win32 API
    HWND _SetCapture();
    BOOL _ReleaseCapture();
    HDC  _CreateCompatibleDC();
    HBITMAP _CreateCompatibleBitmap(int cx, int cy);
    int  _GetDeviceCaps(int index);

    // Operations
    BOOL AttachControl(XControl* pControl);
    void NeedUpdate(XControl* pControl);
    void Invalidate(XRect& rc);
    void SetFocus(XControl* pControl);
    void PostEvent(TEvent& event); // Dispatcher, pt, time ���Զ�����
    BOOL RegisterControl(XControl* pControl);
    BOOL UnregisterControl(XControl* pControl);

    // ��ʱ
    BOOL _SetTimer(XControl* pControl, UINT nTimerID, UINT uElapse);
    BOOL _KillTimer(XControl* pControl, UINT nTimerID);
    void _KillTimerT(XControl* pControl);
    void _KillAllTimers();

    static BOOL PreTranslateMessage(const LPMSG pMsg);

    virtual LRESULT HandleMessage( UINT uMsg, WPARAM wParam, LPARAM lParam ); // Ĭ��û�� PostQuitMessage
    BOOL MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, LRESULT* lRes);
    BOOL PreMessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, LRESULT* lRes);

    LRESULT MessageFilter( UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL* bHandled );

public:
    // ����ӿ�
    virtual XString     MakeFontHash( LPCTSTR szName, int nSize, BOOL bBold = FALSE, BOOL bUnderline = FALSE, BOOL bItalic = FALSE );
    virtual HFONT       GetFontByHash( XString& szHash ) const;
    virtual TFont*      GetFontInfoByHash( XString& szHash ) const;
    virtual BOOL        SetDefaultFont(LPCTSTR szName, int nSize, BOOL bBold = FALSE, BOOL bUnderline = FALSE, BOOL bItalic = FALSE);
    virtual BOOL        SetDefaultFont(TFont* pFont);
    virtual TFont*      GetDefaultFontInfo() const;
    virtual BOOL        AddFont( LPCTSTR szName, int nSize, BOOL bBold = FALSE, BOOL bUnderline = FALSE, BOOL bItalic = FALSE );
    virtual BOOL        AddFontLink( LPCTSTR szLink, LPCTSTR szName, int nSize, BOOL bBold = FALSE, BOOL bUnderline = FALSE, BOOL bItalic = FALSE );
    virtual HFONT       GetFont(LPCTSTR szName, int nSize, BOOL bBold = FALSE, BOOL bUnderline = FALSE, BOOL bItalic = FALSE);      // �õ���������������򴴽�
    virtual TFont*      GetFontInfo(LPCTSTR szName, int nSize, BOOL bBold = FALSE, BOOL bUnderline = FALSE, BOOL bItalic = FALSE);  // �õ�������Ϣ�����������򴴽�
    virtual TFont*      GetFontLink(LPCTSTR szLink);
    virtual BOOL        RemoveFont( XString& szHash );
    virtual void        RemoveAllFonts();
    virtual int         GetFontCount() const;

    // ͼƬ�ӿ�
    virtual const TImage*   GetImage( LPCTSTR lpszImage );
    virtual const TImage*   GetImageEx( LPCTSTR lpszImage, DWORD dwMask = 0 );
    virtual const TImage*   AddImage( LPCTSTR lpszImage, DWORD dwMask = 0 );
    virtual const TImage*   AddImage( LPCTSTR lpszImage, HBITMAP hBitmap, int iWidth, int iHeight, BOOL bAlpha );
    virtual BOOL            RemoveImage( LPCTSTR lpszImage );
    virtual void            RemoveAllImages();
    virtual void            ReloadAllImages();

protected:
#ifdef _DEBUG
    void TraceDeleteNotify(TAsyncNotify* pNotify);
#endif // _DEBUG

public:
    // ����
    void SetMinSize(XSize& sz);
    void SetMaxSize(XSize& sz);
    void GetMinSize(XSize& sz);
    void GetMaxSize(XSize& sz);

public:
    // ���ҷ���
    XControl* FindControl(XPoint pt); // ����Ϊ��Ļ����
    XControl* FindControl(LPCTSTR lpszCtrlName);

    static UINT         MapState();
    static XPoint       GetMousePos();

protected:
    // ���ҷ���
    static XControl* CALLBACK __FindControlFromPoint(XControl* pControl, LPVOID pData);

public:
    /************************************************************************/
    /*_______����ʹ��X_CreateWindow��̬����/���� �����е�����Ϣ��___________*/
    /************************************************************************/
    static XWindow* __Create(XClass*);

protected:
    x_msg_call BOOL OnCreate();
    x_msg_call BOOL OnPaint();
    x_msg_call BOOL OnMouseMove();
    x_msg_call BOOL OnGetMinMaxInfo();
    x_msg_call BOOL OnSize();
    x_msg_call BOOL OnLButtonDown();
    x_msg_call BOOL OnLButtonUp();
    x_msg_call BOOL OnMouseHover();
    x_msg_call BOOL OnMouseLeave();
    x_msg_call BOOL OnSetCursor();
    x_msg_call BOOL OnKeyUp();
    x_msg_call BOOL OnKeyDown();
    x_msg_call BOOL OnClose();
    x_msg_call BOOL OnChar();
    x_msg_call BOOL OnTimer();
    x_msg_call BOOL OnSysKeyDown();
    x_msg_call BOOL OnMouseWheel();
    x_msg_call BOOL OnPaintClient();
    x_msg_call BOOL OnVScroll();
    x_msg_call BOOL OnEffect();

protected:
    void PostEventT(XControl* pControl, UINT uMsg = WM_NULL, WPARAM wParam = 0U, LPARAM lParam = 0L);

public:
#ifdef _DEBUG
    virtual void AssertValid() const;
#endif // _DEBUG

public:
    virtual BOOL PumpMessage();
    virtual BOOL IsIdleMessage( MSG* pMsg );
    virtual BOOL OnIdle( LONG lCount );

    virtual void* GetInterface( HINTERFACE hi );

protected:
    // ���
    HDC     m_hDC;  // ���豸����
    HDC     m_hDcOffscreen; // ��������DC
    HDC     m_hDcBackground;  // ����DC
    HBITMAP m_hBmpOffscreen;  // ����λͼ
    HBITMAP m_hBmpBackground; // ����λͼ
    MSG     m_msg;
    MSG     m_msgT;
    int     m_nDisablePumpCount;
    UINT    m_nMsgLast;

    XWindow*   m_hwndParent;

    XControl*  m_pEventClick;
    XControl*  m_pFocus;
    XControl*  m_pEventHover;
    XControl*  m_pEventKey;

    UINT    m_uTimerID;
    BOOL    m_bDead; // ���ڼ������٣������ٴ����κ���Ϣ

    List<IXMessageFilter*>  m_preMessageFilters; // Ԥ������Ϣ
    List<IXMessageFilter*>  m_MessageFilters; //������Ҫ������Ϣ���˵Ŀؼ�����(�綯����)
    List<TAsyncNotify*>     m_syncNotify; // �첽ϵͳ��Ϣ��ע�⣡�п��ܴ���ʱ��XControl*��ʧЧ��
    List<TSyncNotify*>      m_syncModifiedNotify; // �첽�Զ�����Ϣ
    List<IXNotify*>         m_Notifiers; // ��¼������Ҫ�¼�֪ͨ�Ĵ���.���ݴ������Ƶ�����Ӧ����Ϣ��������
    List<XControl*>         m_PostPaintCtrls; // �ػ���
    List<XTIMERINFO*>       m_Timers; // ��ʱ��

    XContainer*  m_pRoot;
    BOOL    m_bNeedUpdate;
    BOOL    m_bFirstInit; // ��ʼ��
    BOOL    m_bMouseTracking; // �Ƿ��϶����
    static XPoint m_ptMousePos;

    XSize   m_szMin;
    XSize   m_szMax;

    XAnimation  m_anim;
    BOOL    m_bAutoDestroy;

public:
    COLORREF m_clrDefaultFontColor;
    COLORREF m_clrDefaultDisabledColor;

public:
    static List<XWindow*>   m_preMessages;
    Dictionary<XString, XControl*, LPCTSTR>            m_mapNames;
    Dictionary<XString, TImage*, LPCTSTR>              m_mapImage;
    Dictionary<XString, TFont*, LPCTSTR>               m_mapFonts;
    Dictionary<XString, TFont*, LPCTSTR>               m_mapFontLinks;  // ��������
};

WINDOW_END_NAMESPACE
#endif