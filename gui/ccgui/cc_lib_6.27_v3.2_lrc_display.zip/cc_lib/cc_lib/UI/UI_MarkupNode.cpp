#include "StdAfx.h"
#include "UI_MarkupNode.h"

UI_BEGIN_NAMESPACE
XMarkupNode::XMarkupNode( XMarkup* pOwner /*= NULL*/, pos_t iPos /*= 0*/, List<XML_ELEMENT*>* pList /*= NULL*/, LPTSTR pstrText /*= NULL*/ ):
m_pOwner(pOwner), m_iPos(iPos), m_pElements(pList), m_pstrText(pstrText), m_pEle(NULL)
{
    // m_pOwner == NULL so other parameters are not used
    // m_pOwner != NULL so other parameters are used
    if (pOwner != NULL)
    {
        m_pEle = pList->Get(iPos);
    }
}

XMarkupNode::~XMarkupNode()
{
    Release();
}

bool XMarkupNode::IsValid() const
{
    return m_pOwner != NULL;
}

void XMarkupNode::Release()
{
    for (int i = 0; i < m_aAttributes.Count(); i++)
    {
        delete m_aAttributes.Get(i);
    }
    m_aAttributes.Clear();
}

XMarkupNode& XMarkupNode::operator = ( const XMarkupNode& node )
{
    Release();

    m_iPos              = node.m_iPos;
    m_pElements         = node.m_pElements;
    m_aAttributes       = node.m_aAttributes;
    m_pOwner            = node.m_pOwner;
    m_pstrText          = node.m_pstrText;
    m_pEle              = node.m_pEle;

    return *this;
}

XMarkupNode XMarkupNode::GetParent()
{
    if( m_pOwner == NULL ) return XMarkupNode(NULL);
    pos_t iPos = _GetElement()->iParent;
    if( iPos == 0 ) return XMarkupNode();
    return XMarkupNode(m_pOwner, iPos, m_pElements, m_pstrText);
}

XMarkupNode XMarkupNode::GetSibling()
{
    if( m_pOwner == NULL ) return XMarkupNode();
    pos_t iPos = _GetElement()->iNext;
    if( iPos == 0 ) return XMarkupNode();
    return XMarkupNode(m_pOwner, iPos, m_pElements, m_pstrText);
}

XMarkupNode XMarkupNode::GetChild()
{
    if( m_pOwner == NULL ) return XMarkupNode();
    pos_t iPos = _GetElement()->iChild;
    if( iPos == 0 ) return XMarkupNode();
    return XMarkupNode(m_pOwner, iPos, m_pElements, m_pstrText);
}

XMarkupNode XMarkupNode::GetChild( LPCTSTR pstrName )
{
    if( m_pOwner == NULL ) return XMarkupNode();
    pos_t iPos = _GetElement()->iChild;
    while( iPos != 0 ) {
        if( _tcscmp(m_pstrText + _GetElement(iPos)->iStart, pstrName) == 0 ) {
            return XMarkupNode(m_pOwner, iPos, m_pElements, m_pstrText);
        }
        iPos = _GetElement(iPos)->iNext;
    }
    return XMarkupNode();
}

bool XMarkupNode::HasSiblings()
{
    if( m_pOwner == NULL ) return false;
    pos_t iPos = _GetElement()->iNext;
    return iPos > 0;
}

bool XMarkupNode::HasChildren()
{
    if( m_pOwner == NULL ) return false;
    return _GetElement()->iChild != 0;
}

XString XMarkupNode::GetName()
{
    if( m_pOwner == NULL ) return EmptyString;
    return m_pstrText + _GetElement()->iStart;
}

XString XMarkupNode::GetValue()
{
    if( m_pOwner == NULL ) return EmptyString;
    return m_pstrText + _GetElement()->iData;
}

bool XMarkupNode::HasAttributes()
{
    if( m_pOwner == NULL ) return false;
    if( m_aAttributes.Count() == 0 ) _MapAttributes();
    return m_aAttributes.Count() > 0;
}

bool XMarkupNode::HasAttribute( LPCTSTR pstrName )
{
    if( m_pOwner == NULL ) return false;
    if( m_aAttributes.Count() == 0 ) _MapAttributes();
    for( int i = 0; i < m_aAttributes.Count(); i++ ) {
        if( _tcscmp(m_pstrText + m_aAttributes[i]->iName, pstrName) == 0 ) return true;
    }
    return false;
}

int XMarkupNode::GetAttributeCount()
{
    if( m_pOwner == NULL ) return 0;
    if( m_aAttributes.Count() == 0 ) _MapAttributes();
    return m_aAttributes.Count();
}

XString XMarkupNode::GetAttributeName( int iIndex )
{
    if( m_pOwner == NULL ) return EmptyString;
    if( m_aAttributes.Count() == 0 ) _MapAttributes();
    if( iIndex < 0 || iIndex >= m_aAttributes.Count() ) return EmptyString;
    return m_pstrText + m_aAttributes[iIndex]->iName;
}

XString XMarkupNode::GetAttributeValue( int iIndex )
{
    if( m_pOwner == NULL ) return EmptyString;
    if( m_aAttributes.Count() == 0 ) _MapAttributes();
    if( iIndex < 0 || iIndex >= m_aAttributes.Count() ) return EmptyString;
    return m_pstrText + m_aAttributes[iIndex]->iValue;
}

XString XMarkupNode::GetAttributeValue( LPCTSTR pstrName )
{
    if( m_pOwner == NULL ) return EmptyString;
    if( m_aAttributes.Count() == 0 ) _MapAttributes();
    for( int i = 0; i < m_aAttributes.Count(); i++ ) {
        if( _tcscmp(m_pstrText + m_aAttributes[i]->iName, pstrName) == 0 )
            return m_pstrText + m_aAttributes[i]->iValue;
    }
    return EmptyString;
}

const XML_ELEMENT* XMarkupNode::_GetElement()
{
    ASSERT(m_pEle);
    return m_pEle;
}

const XML_ELEMENT* XMarkupNode::_GetElement( int iIndex )
{
    return m_pElements->Get(iIndex);
}

XML_ATTRIBUTE* XMarkupNode::_GetNewAttribute()
{
    XML_ATTRIBUTE* pAttr = new XML_ATTRIBUTE;
    ASSERT(pAttr);
    m_aAttributes.Add(pAttr);
    return pAttr;
}

void XMarkupNode::_ReleaseNewAttribute()
{
    if (m_aAttributes.Count() > 0)
    {
        int iPos = m_aAttributes.GetSize() - 1;
        delete m_aAttributes.Get(iPos);
        m_aAttributes.RemoveAt(iPos);
    }
}

void XMarkupNode::_MapAttributes()
{
    Release();
    LPCTSTR pstr = m_pstrText + _GetElement()->iStart;
    LPCTSTR pstrEnd = m_pstrText + _GetElement()->iData;
    pstr += _tcslen(pstr) + 1;
    while( pstr < pstrEnd ) {
        XML_ATTRIBUTE* pAttr = _GetNewAttribute();
        /* _SkipWhitespace */ while( *pstr > _T('\0') && *pstr <= _T(' ') ) pstr = ::CharNext(pstr);
        pAttr->iName = pstr - m_pstrText;
        pstr += _tcslen(pstr) + 1;
        /* _SkipWhitespace */ while( *pstr > _T('\0') && *pstr <= _T(' ') ) pstr = ::CharNext(pstr);
        if( *pstr != _T('\"') && *pstr != _T('\'') ) {
            _ReleaseNewAttribute(); // delete temp create
            return;
        }
        pstr++;
        pAttr->iValue = pstr - m_pstrText;
        pstr += _tcslen(pstr) + 1;
    }
}

UI_END_NAMESPACE