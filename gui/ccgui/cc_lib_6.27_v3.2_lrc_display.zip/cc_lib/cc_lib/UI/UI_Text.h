#ifndef _CC_UI_TEXT_H
#define _CC_UI_TEXT_H

#pragma once

#define GetIText(p) ((XText*)(static_cast<XText*>((p)->GetInterface(HI_TEXT))))

CONTROLS_BEGIN_NAMESPACE
class CL_API XText : public XLabel
{
    X_DECLARE_CLASS_WITH_PARA(XText)
public:
    XText(XObject* pOb = NULL);
    virtual ~XText();

    virtual void* GetInterface( HINTERFACE hi );
    virtual void Event( TEvent& event );
    virtual DWORD GetFlags() const;
    virtual void PaintText( HDC hDC );

    XString GetLinkContent( int iIndex );

protected:
    enum _LINK_COUNT { MAX_LINK = 8 };
    int         m_nLinks;
    XRect       m_rcLinks[MAX_LINK];
    XString     m_szLinks[MAX_LINK];
    int         m_nHoverLink;
};

CONTROLS_END_NAMESPACE
#endif