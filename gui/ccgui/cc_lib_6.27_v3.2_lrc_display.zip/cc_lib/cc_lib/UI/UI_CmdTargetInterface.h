#ifndef _CC_UI_CMDTARGET_INTERFACE_H
#define _CC_UI_CMDTARGET_INTERFACE_H

#pragma once

#define XGlobal_SetInstanceAndResPath(instance, path) XCmdTarget::SetInstanceAndResPath(instance, path)
#define XGlobal_GetInstance() XCmdTarget::GetInstance()
#define XGlobal_GetInstancePath() XCmdTarget::GetInstancePath()
#define XGlobal_GetResourcePath() XCmdTarget::GetResourcePath()

UI_BEGIN_NAMESPACE
using namespace Window;
class ICmdTarget
{
public:
    virtual BOOL Subclass(HWND hWnd) = 0;
    virtual BOOL UnSubclass() = 0;
    virtual BOOL IsSubclass() const = 0;

protected:
    virtual LRESULT HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam) = 0;
    virtual void OnFinalMessage(HWND hWnd) = 0;
};

class CL_API ICmdTargetImpl : public XWindowImpl
{
public:
    ICmdTargetImpl();
    virtual BOOL Subclass(HWND hWnd);
    virtual BOOL UnSubclass();
    virtual BOOL IsSubclass() const;

    static LRESULT CALLBACK __WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
    static LRESULT CALLBACK __ControlProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

    static void SetInstanceAndResPath(HINSTANCE hInstance, LPCTSTR lpszResPath);
    static HINSTANCE GetInstance();
    static XString GetInstancePath();
    static XString GetResourcePath();

    static void GetHSL(short& H, short& S, short& L);

protected:
    virtual LRESULT HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam);

    static HINSTANCE m_hInstance;
    static XString m_szInstancePath;
    static XString m_szResPath;

    BOOL m_bSubclassed;
    WNDPROC m_OldWndProc;

    static short m_H;
    static short m_S;
    static short m_L;
};

X_DECLARE_CLASS_ATTR(BkBrush, HBRUSH, hBkBrush)

UI_END_NAMESPACE
#endif
