#ifndef _CC_UI_COMBO_H
#define _CC_UI_COMBO_H

#pragma once

#define GetICombo(p) ((XCombo*)(static_cast<XCombo*>((p)->GetInterface(HI_COMBO))))
#define GetIComboArray(p) ((IComboArray*)(static_cast<IComboArray*>((p)->GetInterface(HI_COMBO_ARRAY))))

CONTROLS_BEGIN_NAMESPACE
class XCombo;
class IComboArray : public X_LIST_NAME_T(Combo)<XControl> {};
CONTROLS_END_NAMESPACE
WINDOW_BEGIN_NAMESPACE
class XComboWindow;
WINDOW_END_NAMESPACE

//////////////////////////////////////////////////////////////////////////
WINDOW_BEGIN_NAMESPACE
class XComboWindow : public XWindow, public IOwner<XCombo>, public IListScroll
{
    X_DECLARE_CLASS(XComboWindow)
public:
    XComboWindow();
    virtual ~XComboWindow();
public:
    void Init( XCombo* pOwner );
    virtual void OnFinalMessage( HWND hWnd );

    void EnsureVisible(int iIndex);
    void Scroll(int dx, int dy);
    void SetCurSel(int);

    void CreateLayout();

    virtual LRESULT HandleMessage( UINT uMsg, WPARAM wParam, LPARAM lParam );

    virtual void Notify( TAsyncNotify& notify );
    virtual void DeleteComponents();

protected:
    XCanvas*            m_pCanvas;
    XVerticalLayout*    m_pLayout;
    XRect m_rcPaint;
    int m_iOldSel;
};
WINDOW_END_NAMESPACE

//////////////////////////////////////////////////////////////////////////
CONTROLS_BEGIN_NAMESPACE
class CL_API XCombo : public XContainer, public IListOwner, public IChildWindow2<XComboWindow>,
    public IComboArray, public IButtonStateImpl
{
    X_DECLARE_CLASS_WITH_PARA(XCombo)
public:
    XCombo(XObject* pOb = NULL);
    virtual ~XCombo();

    virtual void* GetInterface( HINTERFACE hi );
    virtual XControl* CreateControl( XClass* pClass );

    XVerticalLayout* GetLayout();
    void CreateLayout();

    virtual void SetRect( const XRect & );

    virtual BOOL Activate();
    const TListInfo* GetListInfo() const;
    XSize GetDropBoxSize() const;
    void SetDropBoxSize(XSize szDropBox);

    // IListSelect
    int  GetCurSel() const;
    bool SelectItem( int iIndex );
    void ListEvent( TEvent& event );

    // IListScroll
    virtual void EnsureVisible( int iIndex );
    virtual void Scroll( int dx, int dy );

    // IComboArray<>
    XControl* Combo_GetData( int ) const;
    int       Combo_Find( XControl* ) const;
    bool      Combo_SetAt( XControl*, int );
    int       Combo_GetSize() const;
    int       Combo_Add( XControl* );
    bool      Combo_InsertAt( int, XControl* );
    bool      Combo_Remove( XControl* );
    bool      Combo_RemoveAt( int );
    void      Combo_RemoveAll();

    virtual void SetEnable( BOOL bEnabled );
    virtual DWORD GetFlags() const;

    virtual void Event( TEvent& event );

    virtual XSize EstimateSize( const XSize& );
    virtual int FindSelectable( int iIndex, bool bForward = true );

    virtual void Paint( HDC hDC, const XRect& rect );

protected:
    int             m_iCurSel;
    XVerticalLayout* m_pLayout;
    TListInfo       m_ListInfo;
    XSize           m_szDropBox;
};

CONTROLS_END_NAMESPACE

#endif