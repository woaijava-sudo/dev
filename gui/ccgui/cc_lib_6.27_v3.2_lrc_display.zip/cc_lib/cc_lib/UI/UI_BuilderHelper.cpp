#include "stdafx.h"
#include "UI_Builder.h"

UI_BEGIN_NAMESPACE
COLORREF XBuilder::_ParseColor( LPCTSTR pstrValue )
{
    if( *pstrValue == _T('#') ) {
        pstrValue = ::CharNext(pstrValue); // Skip '#'
        LPTSTR pstr = NULL;
        COLORREF clrColor = _tcstoul(pstrValue, &pstr, 16); // Warning: Color is like #RRGGBB or #AARRGGBB
        ASSERT(pstr);
        return clrColor;
    } else if ( *pstrValue == _T('$') ) {
        pstrValue = ::CharNext(pstrValue); // Skip '$', Format: "RGB(255,255,255)" => "$255,255,255" (DEC)
        LPTSTR pstr = NULL;
        BYTE r  = (BYTE)_tcstol(pstrValue, &pstr, 10);      ASSERT(pstr);
        BYTE g  = (BYTE)_tcstol(pstr + 1, &pstr, 10);       ASSERT(pstr);
        BYTE b  = (BYTE)_tcstol(pstr + 1, &pstr, 10);       ASSERT(pstr);
        return RGB(r,g,b);
    } else if ( *pstrValue == _T('@') ) {
        pstrValue = ::CharNext(pstrValue); // Skip '@', Format: "RGB(255,255,255,255)" => "@255,255,255,255" (DEC & Alpha)
        LPTSTR pstr = NULL;
        BYTE a  = (BYTE)_tcstol(pstrValue, &pstr, 10);      ASSERT(pstr);
        BYTE r  = (BYTE)_tcstol(pstr + 1, &pstr, 10);       ASSERT(pstr);
        BYTE g  = (BYTE)_tcstol(pstr + 1, &pstr, 10);       ASSERT(pstr);
        BYTE b  = (BYTE)_tcstol(pstr + 1, &pstr, 10);       ASSERT(pstr);
        return ARGB(a,r,g,b);
    } else {
        TRACE("ParseColor failed: accident formation");
        ASSERT(!"Warning: invalid color input");
        return CLR_INVALID;
    }
}

XRect XBuilder::_ParseRect( LPCTSTR pstrValue )
{
    XRect rc;
    LPTSTR pstr = NULL; // like "left,top,right,bottom"
    rc.left   = _tcstol(pstrValue, &pstr, 10);      ASSERT(pstr);
    rc.top    = _tcstol(pstr + 1, &pstr, 10);       ASSERT(pstr);
    rc.right  = _tcstol(pstr + 1, &pstr, 10);       ASSERT(pstr);
    rc.bottom = _tcstol(pstr + 1, &pstr, 10);       ASSERT(pstr);
    return rc;
}

XSize XBuilder::_ParseSize( LPCTSTR pstrValue )
{
    XSize sz;
    LPTSTR pstr = NULL; // like "cx,cy"
    sz.cx   = _tcstol(pstrValue, &pstr, 10);      ASSERT(pstr);
    sz.cy   = _tcstol(pstr + 1, &pstr, 10);       ASSERT(pstr);
    return sz;
}

BOOL XBuilder::_ParseBool( LPCTSTR pstrValue )
{
    XString Value = pstrValue;
    return Value.CompareNoCase(_T("true")) == 0;
}

UINT XBuilder::_ParseUint( LPCTSTR pstrValue )
{
    LPTSTR pstr = NULL;
    UINT uInt = _tcstoul(pstrValue, &pstr, 16); // Warning: Hex
    ASSERT(pstr);
    return uInt;
}

int XBuilder::_ParseInt( LPCTSTR pstrValue )
{
    return _ttoi(pstrValue);
}

void XBuilder::_ParseFontAdv( LPCTSTR pstrValue, XString& szFontName, int& FontSize, BOOL& bB, BOOL& bU, BOOL& bI )
{
    // Like "..Font.Name..|size,bold,underline,italic"
    // so e.g. "Times New Roman|24,1,1,0"
    XString szFont = pstrValue;

    if (szFont.IsEmpty()) return;

    int iPosSep = szFont.Find(_T('|'));
    if (iPosSep == -1) return; // Font Name & Font Size are necessary

    // Parse name
    szFontName = szFont.Left(iPosSep);
    szFont = szFont.Mid(iPosSep + 1);
    LPTSTR lpszValue = szFont.GetBuffer(0);

    LPTSTR pstr = NULL;
    FontSize = (int) _tcstol(lpszValue, &pstr, 10); ASSERT(pstr);

    long lB = _tcstol(pstr + 1, &pstr, 10); ASSERT(pstr);
    long lU = _tcstol(pstr + 1, &pstr, 10); ASSERT(pstr);
    long lI = _tcstol(pstr + 1, &pstr, 10); ASSERT(pstr);

    bB = (lB == 1) ? 1 : 0;
    bU = (lU == 1) ? 1 : 0;
    bI = (lI == 1) ? 1 : 0;
}

void XBuilder::_ParseFont( XControl* pControl, LPCTSTR pstrValue )
{
    XString szFontName; int FontSize; BOOL bB, bU, bI;
    _ParseFontAdv(pstrValue, szFontName, FontSize, bB, bU, bI);
    pControl->SetTextFont(szFontName, FontSize, bB, bU, bI);
}

void XBuilder::_ParseDefaultFont( XWindow* pWindow, LPCTSTR pstrValue )
{
    XString szFontName; int FontSize; BOOL bB, bU, bI;
    _ParseFontAdv(pstrValue, szFontName, FontSize, bB, bU, bI);
    pWindow->SetDefaultFont(szFontName, FontSize, bB, bU, bI);
}
UI_END_NAMESPACE