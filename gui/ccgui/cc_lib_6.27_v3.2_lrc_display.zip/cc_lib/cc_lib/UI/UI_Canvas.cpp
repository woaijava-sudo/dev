#include "StdAfx.h"

CONTROLS_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS_WITH_PARA(XCanvas, XContainer)

XCanvas::XCanvas( XObject* pOb /*= NULL*/ ): 
    XContainer(pOb),
    m_dwState(0)
{
    m_dwBkColor = MAKE_RGB(XCOLOR_WINDOW_BACKGROUND);
    m_clrForward = MAKE_RGB(XCOLOR_DIALOG_BACKGROUND);
    m_clrOld = m_dwBkColor;
}

XCanvas::~XCanvas()
{

}

#ifdef _DEBUG
void XCanvas::AssertValid() const
{
    XContainer::AssertValid();
}
#endif // _DEBUG

void* XCanvas::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_CANVAS: return this;
    }
    return XContainer::GetInterface(hi);
}

void XCanvas::SetForwardColor( COLORREF color )
{
    m_clrForward = color;
}

COLORREF XCanvas::GetForwardColor() const
{
    return m_clrForward;
}

void XCanvas::Paint( HDC hDC, const XRect& rect )
{
    XRect rcTemp;
    if ( !rcTemp.IntersectRect(&rect, &m_rcClient) ) return;

    XContainer::Paint(hDC, rect);
}

void XCanvas::Event( TEvent& event )
{
    switch (event.msg.message)
    {
    case WM_MOUSEENTER:
        if (m_bEnabled && m_bHotTrack)
        {
            m_dwState |= XSTATE_HOT;
            m_dwBkColor = m_clrForward;
            Invalidate();
        }
        break;
    case WM_MOUSELEAVE:
        if (m_bEnabled && m_bHotTrack)
        {
            m_dwState &= ~XSTATE_HOT;
            m_dwBkColor = m_clrOld;
            Invalidate();
        }
        break;
    case WM_MOUSEHOVER:
        if (m_bEnabled && m_bHotTrack)
        {
            if ((m_dwState & XSTATE_HOT) != 0)
            {
                m_pWindow->SendAsyncNotify(this, (DWORD) _T("CanvasHover"), TRUE);
            }            
            Invalidate();
        }
        break;
    }
    XContainer::Event(event);
}

void XCanvas::SetBkColor( COLORREF dwBkColor )
{
    XContainer::SetBkColor(dwBkColor);
    m_clrOld = dwBkColor;
}

CONTROLS_END_NAMESPACE