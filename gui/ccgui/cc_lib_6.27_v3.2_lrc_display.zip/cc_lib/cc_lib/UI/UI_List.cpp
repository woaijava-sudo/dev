#include "StdAfx.h"

CONTROLS_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS_WITH_PARA(XList, XVerticalLayout)
//////////////////////////////////////////////////////////////////////////

XList::XList( XObject* pOb /*= NULL*/ ): XVerticalLayout(pOb), m_iCurSel(-1), m_pList(NULL), m_pHeader(NULL), m_pFooter(NULL), m_bAlwaysShowFocus(TRUE)
{
    ::ZeroMemory(&m_ListInfo, sizeof(TListInfo));

    m_ListInfo.Text             = CLR_TLISTINFO_TEXT;
    m_ListInfo.Background       = CLR_TLISTINFO_BK;
    m_ListInfo.SelText          = CLR_TLISTINFO_SELTEXT;
    m_ListInfo.SelBackground    = CLR_TLISTINFO_SELBK;
    m_ListInfo.HotText          = CLR_TLISTINFO_HOTTEXT;
    m_ListInfo.HotBackground    = CLR_TLISTINFO_HOTBK;

    // Layout
    XCanvas* pCanvas = GetICanvas(XVerticalLayout::XCreateControl(XCanvas));
    m_pList = GetIVerticalLayout(pCanvas->XCreateControl(XVerticalLayout));
    m_pList->SetBkColor(MAKE_RGB(XCOLOR_CONTROL_BACKGROUND_NORMAL));

    m_pHeader = GetIListHeader(XCreateControl(XListHeader));
    m_pFooter = GetIListFooter(XCreateControl(XListFooter));

    m_Items.Swap(0, 1);

    // Colors
    m_pHeader->SetBkColor(MAKE_RGB(XCOLOR_HEADER_BACKGROUND));
    m_pFooter->SetBkColor(MAKE_RGB(XCOLOR_HEADER_BACKGROUND));

    m_pList->EnableScrollBar();
}

UINT XList::GetControlFlags() const
{
    return XFLAG_TABSTOP;
}

void* XList::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_LIST_EX: return static_cast<XList*>(this);
    case HI_LIST: return static_cast<IListAdv*>(this);
    case HI_LIST_ARRAY: return static_cast<IListArray*>(this);
    }
    return XVerticalLayout::GetInterface(hi);
}

XControl* XList::CreateControl( XClass* pClass )
{
    XControl* pControl = XControl::CreateControl(pClass);
    List_Add(pControl);
    return pControl;
}

int XList::GetCurSel() const
{
    return m_iCurSel;
}

bool XList::SelectItem( int iIndex )
{
    if( iIndex == m_iCurSel ) return true;

    if( m_iCurSel >= 0 ) {
        XControl* pControl = List_GetData(m_iCurSel);
        if( pControl != NULL ) {
            IListItem* pListItem = GetIListItem(pControl);
            if( pListItem != NULL ) pListItem->Select(false);
        }
    }

    XControl* pControl = List_GetData(iIndex);
    if( pControl == NULL )       return false;
    if( !pControl->IsVisible() ) return false;
    if( !pControl->IsEnabled() ) return false;
    IListItem* pListItem = GetIListItem(pControl);
    if( pListItem == NULL ) return false;
    m_iCurSel = iIndex;
    if( !pListItem->Select(true) ) {
        m_iCurSel = -1;
        return false;
    }
    pControl->SetFocus();
    if( m_pWindow != NULL ) {
        m_pWindow->SendAsyncNotify(pControl, (DWORD) _T("ItemClick"), TRUE);
        m_pWindow->SendAsyncNotify(this, (DWORD) _T("ItemSelect"), TRUE);
    }
    Invalidate();
    return true;
}

void XList::ListEvent( TEvent& event )
{
    Event(event);
}

void XList::Event( TEvent& event )
{
    switch( event.msg.message ) {
    case WM_KEYDOWN:
        switch( TCHAR(event.msg.wParam) ) {
        case VK_UP:
            SelectItem(FindSelectable(m_iCurSel - 1, false));
            EnsureVisible(m_iCurSel);
            return;
        case VK_DOWN:
            SelectItem(FindSelectable(m_iCurSel + 1, true));
            EnsureVisible(m_iCurSel);
            return;
        case VK_PRIOR:
            SelectItem(FindSelectable(m_iCurSel - 10, false));
            EnsureVisible(m_iCurSel);
            return;
        case VK_NEXT:
            SelectItem(FindSelectable(m_iCurSel + 10, true));
            EnsureVisible(m_iCurSel);
            return;
        case VK_HOME:
            SelectItem(FindSelectable(0, false));
            EnsureVisible(m_iCurSel);
            return;
        case VK_END:
            SelectItem(FindSelectable(List_GetSize() - 1, true));
            EnsureVisible(m_iCurSel);
            return;
        case VK_RETURN:
            if( m_iCurSel != -1 ) List_GetData(m_iCurSel)->Activate();
            return;
        }
        break;
    case WM_MOUSEWHEEL:
        {
            if (m_pList->AllowScrollBar() && m_pList->GetChildWnd() != NULL)
            {
                switch( LOWORD(event.msg.wParam) ) {
                case SB_LINEUP:
                    m_pList->SetScrollPos(m_pList->GetScrollPos() - 30);
                    return;
                case SB_LINEDOWN:
                    m_pList->SetScrollPos(m_pList->GetScrollPos() + 30);
                    return;
                }
            }
        }
        break;
    case WM_KILLFOCUS:
        {
            if (!m_bAlwaysShowFocus)
            {
                ASSERT(m_iCurSel >= 0 && m_iCurSel < m_pList->GetSize());
                GetIListItem(List_GetData(m_iCurSel))->Select(false);
                m_iCurSel = -1;
            }
        }
        break;
    }
    XVerticalLayout::Event(event);
}

void XList::Paint( HDC hDC, const XRect& rect )
{
    if ( !m_rcPaint.IntersectRect(&rect, &m_rcClient) ) return;

    XControl::Paint(hDC, m_rcPaint);
    m_pList->Paint(hDC, m_rcPaint);
    m_pHeader->Paint(hDC, m_rcPaint);
    m_pFooter->Paint(hDC, m_rcPaint);
}

XListHeader* XList::GetHeader() const
{
    return m_pHeader;
}

XListFooter* XList::GetFooter() const
{
    return m_pFooter;
}

XContainer* XList::GetList() const
{
    return m_pList;
}

const TListInfo* XList::GetListInfo() const
{
    return &m_ListInfo;
}

XControl* XList::List_GetData( int iIndex ) const
{
    return m_pList->GetData(iIndex);
}

int XList::List_Find( XControl* pControl ) const
{
    ASSERT_VALID(pControl);
    if( pControl->GetInterface(HI_LIST_HEADER) != NULL ) return XContainer::Find(pControl);
    if( pControl->GetInterface(HI_LIST_HEADER_ITEM) != NULL ) return m_pHeader->Find(pControl);
    return m_pList->Find(pControl);
}

bool XList::List_SetAt( XControl* pControl, int iIndex )
{
    ASSERT_VALID(pControl);
    if( pControl->GetInterface(HI_LIST_HEADER) != NULL ) return XContainer::SetAt(pControl, iIndex);
    if( pControl->GetInterface(HI_LIST_HEADER_ITEM) != NULL ) return m_pHeader->SetAt(pControl, iIndex);

    ASSERT( pControl->GetInterface(HI_LIST_ITEM) != NULL );

    int iOrginIndex = m_pList->Find(pControl);
    if( iOrginIndex < 0 || iOrginIndex >= iIndex ) return false;

    IListItem* pSelectedListItem = NULL;
    if( m_iCurSel >= 0 )
    {
        pSelectedListItem = GetIListItem(List_GetData(m_iCurSel));
        ASSERT(pSelectedListItem);
    }
    if( !m_pList->SetAt(pControl, iIndex) ) return false;
    int iMinIndex = min(iOrginIndex, iIndex);
    int iMaxIndex = max(iOrginIndex, iIndex);
    for(int i = iMinIndex; i < iMaxIndex + 1; ++i) {
        XControl* p = m_pList->GetData(i);
        ASSERT_VALID(p);
        IListItem* pListItem = GetIListItem(p);
        if( pListItem != NULL ) {
            pListItem->SetIndex(i);
        }
    }
    if( m_iCurSel >= 0 && pSelectedListItem != NULL ) m_iCurSel = pSelectedListItem->GetIndex();
    return true;
}

int XList::List_GetSize() const
{
    return m_pList->GetSize();
}

int XList::List_Add( XControl* pControl )
{
    ASSERT_VALID(pControl);
    if( pControl->GetInterface(HI_LIST_HEADER) != NULL ) return Add(pControl);
    if( pControl->GetInterface(HI_LIST_FOOTER) != NULL ) return Add(pControl);

    if( pControl->GetInterface(HI_LIST_HEADER_ITEM) != NULL ) return m_pHeader->Add(pControl);
    if( pControl->GetInterface(HI_LIST_FOOTER_ITEM) != NULL ) return m_pFooter->Add(pControl);

    ASSERT(pControl->GetInterface(HI_LIST_ITEM) != NULL);
    IListItem* pListItem = GetIListItem(pControl);
    if( pListItem != NULL ) {
        pListItem->SetListOwner(this);
        pListItem->SetIndex(List_GetSize());
        for (int i = 0; i < m_ListInfo.nColumns; i++) pListItem->SetText(i, _T(""));
    }

    return m_pList->Add(pControl);
}

bool XList::List_InsertAt( int iIndex, XControl* pControl )
{
    ASSERT_VALID(pControl);
    if( pControl->GetInterface(HI_LIST_HEADER) != NULL ) {
        if( m_pHeader != pControl && m_pHeader->GetSize() == 0 ) {
            Remove(m_pHeader);
            m_pHeader = static_cast<XListHeader*>(pControl);
        }
//         m_ListInfo.nColumns = min(m_pHeader->GetSize(), XLIST_MAX_COLUMNS);
        return InsertAt(0, pControl);
    }

    if( pControl->GetInterface(HI_LIST_HEADER_ITEM) != NULL ) {
        bool ret = m_pHeader->InsertAt(iIndex, pControl);
//         m_ListInfo.nColumns = min(m_pHeader->GetSize(), XLIST_MAX_COLUMNS);
        return ret;
    }

    if (!m_pList->InsertAt(iIndex, pControl)) return false;

    IListItem* pListItem = GetIListItem(pControl);
    if( pListItem != NULL ) {
        pListItem->SetListOwner(this);
        pListItem->SetIndex(iIndex);
    }

    for(int i = iIndex + 1; i < m_pList->GetSize(); ++i) {
        XControl* p = m_pList->GetData(i);
        ASSERT_VALID(p);
        pListItem = GetIListItem(p);
        if( pListItem != NULL ) {
            pListItem->SetIndex(i);
        }
    }
    if( m_iCurSel >= iIndex ) m_iCurSel += 1;
    return true;
}

bool XList::List_Remove( XControl* pControl )
{
    ASSERT_VALID(pControl);
    if( pControl->GetInterface(HI_LIST_HEADER) != NULL ) return Remove(pControl);
    if( pControl->GetInterface(HI_LIST_HEADER_ITEM) != NULL ) return m_pHeader->Remove(pControl);

    int iIndex = m_pList->Find(pControl);
    if (iIndex == -1) return false;

    if (!m_pList->RemoveAt(iIndex)) return false;

    for(int i = iIndex; i < m_pList->GetSize(); ++i) {
        XControl* p = m_pList->GetData(i);
        ASSERT_VALID(p);
        IListItem* pListItem = GetIListItem(p);
        if( pListItem != NULL ) {
            pListItem->SetIndex(i);
        }
    }

    if( iIndex == m_iCurSel && m_iCurSel >= 0 ) {
        int iSel = m_iCurSel;
        m_iCurSel = -1;
        SelectItem(FindSelectable(iSel, false));
    }
    else if( iIndex < m_iCurSel ) m_iCurSel -= 1;
    return true;
}

bool XList::List_RemoveAt( int iIndex )
{
    if ( !m_pList->RemoveAt(iIndex) ) return false;

    for(int i = iIndex; i < m_pList->GetSize(); ++i) {
        XControl* p = m_pList->GetData(i);
        ASSERT_VALID(p);
        IListItem* pListItem = GetIListItem(p);
        if( pListItem != NULL ) pListItem->SetIndex(i);
    }

    if( iIndex == m_iCurSel && m_iCurSel >= 0 ) {
        int iSel = m_iCurSel;
        m_iCurSel = -1;
        SelectItem(FindSelectable(iSel, false));
    }
    else if( iIndex < m_iCurSel ) m_iCurSel -= 1;
    return true;
}

void XList::List_RemoveAll()
{
    m_iCurSel = -1;
    m_pList->RemoveAll();
}

void XList::EnsureVisible( int iIndex )
{
    if( m_iCurSel < 0 ) return;
    if (m_pList->GetChildWnd() == NULL || !m_pList->GetChildWnd()->_IsWindow()) return;
    XRect rcItem = m_pList->GetData(iIndex)->GetRect();
    XRect rcList = m_pList->GetRect();
    if( rcItem.top >= rcList.top && rcItem.bottom < rcList.bottom ) return;
    int dx = 0;
    if( rcItem.top < rcList.top ) dx = rcItem.top - rcList.top;
    if( rcItem.bottom > rcList.bottom ) dx = rcItem.bottom - rcList.bottom;
    Scroll(0, dx);
}

void XList::Scroll( int dx, int dy )
{
    if( dx == 0 && dy == 0 ) return;
    m_pList->SetScrollPos(m_pList->GetScrollPos() + dy);
}

void XList::SetRect( const XRect & rc )
{
    XVerticalLayout::SetRect(rc);
    if( m_pHeader == NULL ) return;

    m_ListInfo.nColumns = min(m_pHeader->GetSize(), XLIST_MAX_COLUMNS);

    if( m_pHeader->IsVisible() ) {
        for( int i = 0; i < m_ListInfo.nColumns; i++ ) m_ListInfo.rcColumn[i] = m_pHeader->GetData(i)->GetRect();
    }
    else {
        XRect rcCol(rc.left, 0, rc.left, 0);
        for( int i = 0; i < m_ListInfo.nColumns; i++ ) {
            XSize sz = m_pHeader->GetData(i)->GetRect().Size();
            rcCol.right += sz.cx;
            m_ListInfo.rcColumn[i] = rcCol;
            rcCol.OffsetRect(sz.cx, 0);
        }
    }
}

void XList::SetOwner( XWindow* pWindow )
{
    m_pHeader->SetOwner(pWindow);
    m_pFooter->SetOwner(pWindow);
    XContainer::SetOwner(pWindow);
}

void XList::SetParent( XControl* pControl )
{
    m_pHeader->SetParent(this);
    m_pFooter->SetParent(this);
    XContainer::SetParent(pControl);
}

BOOL XList::IsAlwaysFocus() const
{
    return m_bAlwaysShowFocus;
}

void XList::EnableAlwaysFocus( BOOL bEnable )
{
    m_bAlwaysShowFocus = bEnable;
}

void XList::RollingToEnd()
{
    if (List_GetSize() == 0) return;
    SetRect(m_rcClient);
    SelectItem(List_GetSize() - 1);
    if (m_pList->GetChildWnd() != NULL && m_pList->GetChildWnd()->_IsWindow())
        EnsureVisible(m_iCurSel);
    NeedUpdate();
}

void XList::RollingToTop()
{
    if (List_GetSize() == 0) return;
    SetRect(m_rcClient);
    SelectItem(0);
    if (m_pList->GetChildWnd() != NULL && m_pList->GetChildWnd()->_IsWindow())
        EnsureVisible(m_iCurSel);
    NeedUpdate();
}

CONTROLS_END_NAMESPACE