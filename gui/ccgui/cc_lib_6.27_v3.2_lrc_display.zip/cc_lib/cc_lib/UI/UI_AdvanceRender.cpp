#include "stdafx.h"
#include "../Gdi/stb_image.h"

//////////////////////////////////////////////////////////////////////////

RENDERING_BEGIN_NAMESPACE
TImage* X_LoadImage( LPCTSTR lpszImage, DWORD dwMask /*= 0*/ )
{
    ASSERT(lpszImage);

    LPBYTE pData = NULL;
    DWORD dwSize = 0;

    do
    {
        XString pstrFile = XGlobal_GetResourcePath();
        pstrFile += lpszImage;

        HANDLE hFile = ::CreateFile(pstrFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
        if( hFile == INVALID_HANDLE_VALUE ) break;
        DWORD dwHighSize = 0;
        dwSize = ::GetFileSize(hFile, &dwHighSize);
        ASSERT(dwHighSize == 0);
        if( dwSize == 0 ) break;

        DWORD dwRead = 0;
        pData = new BYTE[ dwSize ];
        ::ReadFile( hFile, pData, dwSize, &dwRead, NULL );
        ::CloseHandle( hFile );

        if( dwRead != dwSize ) {
            SAFE_DELETE_ARRAY(pData);
        }

    } while (0);

    if (pData == NULL)
    {
        TRACE("Load image failed. Image: %s", lpszImage);
        return NULL;
    }

    LPBYTE img = NULL;
    int x, y, n;
    img = stbi_load_from_memory(pData, dwSize, &x, &y, &n, 4);
    SAFE_DELETE_ARRAY(pData);

    if( img == NULL ) {
        TRACE("Resolve image failed. Image: %s", lpszImage);
        return NULL;
    }

#pragma region BITMAPINFO
    BITMAPINFO bmi;
    ::ZeroMemory(&bmi, sizeof(BITMAPINFO));
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = x;
    bmi.bmiHeader.biHeight = -y;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;
    bmi.bmiHeader.biSizeImage = x * y * 4;
#pragma endregion

    BOOL bAlphaChannel = FALSE;
    LPBYTE pDest = NULL;

    HBITMAP hBitmap = ::CreateDIBSection(NULL, &bmi, DIB_RGB_COLORS, (void**)&pDest, NULL, 0);

    if( hBitmap == NULL ) {
        TRACE("CreateDIBSection failed. Image: %s", lpszImage);
        return NULL;
    }

#pragma region RESOLVE
    for( int i = 0; i < x * y; i++ ) 
    {
        pDest[i*4 + 3] = img[i*4 + 3];
        if( pDest[i*4 + 3] < 255 )
        {
            pDest[i*4] = (BYTE)(DWORD(img[i*4 + 2])*img[i*4 + 3]/255);
            pDest[i*4 + 1] = (BYTE)(DWORD(img[i*4 + 1])*img[i*4 + 3]/255);
            pDest[i*4 + 2] = (BYTE)(DWORD(img[i*4])*img[i*4 + 3]/255); 
            bAlphaChannel = TRUE;
        }
        else
        {
            pDest[i*4] = img[i*4 + 2];
            pDest[i*4 + 1] = img[i*4 + 1];
            pDest[i*4 + 2] = img[i*4]; 
        }

        if( *(DWORD*)(&pDest[i*4]) == dwMask ) {
            pDest[i*4] = (BYTE)0;
            pDest[i*4 + 1] = (BYTE)0;
            pDest[i*4 + 2] = (BYTE)0; 
            pDest[i*4 + 3] = (BYTE)0;
            bAlphaChannel = TRUE;
        }
    }
#pragma endregion

    stbi_image_free(img);
    img = NULL;

    TImage* pImage = new TImage;
    pImage->hBitmap = hBitmap;
    pImage->nX = x;
    pImage->nY = y;
    pImage->alphaChannel = bAlphaChannel;
    return pImage;
}

BOOL X_DrawImage( HDC hDC, XWindow* pWindow, const XRect& rc, const XRect& rcPaint, const XString& szImageName,
    XRect rcItem, XRect rcBmpPart, XRect rcCorner, DWORD dwMask, BYTE bFade,
    BOOL bHole, BOOL bTiledX, BOOL bTiledY, BOOL bNeedAlpha /*= FALSE */ )
{
    ASSERT(pWindow);

    if (szImageName.IsEmpty()) {
        return FALSE;
    }
    const TImage* pImage = pWindow->GetImageEx(szImageName, dwMask);

    if( !pImage ) return FALSE;  

    if( rcBmpPart.left == 0 && rcBmpPart.right == 0 && rcBmpPart.top == 0 && rcBmpPart.bottom == 0 ) {
        rcBmpPart.right = pImage->nX;
        rcBmpPart.bottom = pImage->nY;
    }

    if (rcBmpPart.right > pImage->nX) rcBmpPart.right = pImage->nX;
    if (rcBmpPart.bottom > pImage->nY) rcBmpPart.bottom = pImage->nY;

    XRect rcTemp;
    if( !rcTemp.IntersectRect(&rcItem, &rc) ) return TRUE;
    if( !rcTemp.IntersectRect(&rcItem, &rcPaint) ) return TRUE;

    if( !bNeedAlpha )
        X_DrawImage(hDC, pImage->hBitmap, rcItem, rcPaint, rcBmpPart, rcCorner, TRUE, bFade, bHole, bTiledX, bTiledY);
    else
        X_DrawImage(hDC, pImage->hBitmap, rcItem, rcPaint, rcBmpPart, rcCorner, pImage->alphaChannel, bFade, bHole, bTiledX, bTiledY);

    return TRUE;
}

void X_DrawImage( HDC hDC, HBITMAP hBitmap, const XRect& rc, const XRect& rcPaint, const XRect& rcBmpPart,
    const XRect& rcCorners, BOOL alphaChannel, BYTE uFade /*= 255*/, BOOL hole /*= FALSE*/,
    BOOL xtiled /*= FALSE*/, BOOL ytiled /*= FALSE*/ )
{
    ASSERT_HDC(hDC);

    if( hBitmap == NULL ) return;

    HDC hCloneDC = ::CreateCompatibleDC(hDC);
    HBITMAP hOldBitmap = (HBITMAP) ::SelectObject(hCloneDC, hBitmap);
    ::SetStretchBltMode(hDC, HALFTONE);

    XRect rcTemp;
    XRect rcDest;


#pragma region ALPHA_BLEND
    if( (alphaChannel || uFade < 255) ) {
        BLENDFUNCTION bf = { AC_SRC_OVER, 0, uFade, AC_SRC_ALPHA };
        // middle
        if( !hole ) {
            rcDest.left = rc.left + rcCorners.left;
            rcDest.top = rc.top + rcCorners.top;
            rcDest.right = rc.right - rc.left - rcCorners.left - rcCorners.right;
            rcDest.bottom = rc.bottom - rc.top - rcCorners.top - rcCorners.bottom;
            rcDest.right += rcDest.left;
            rcDest.bottom += rcDest.top;
            if( rcTemp.IntersectRect(&rcPaint, &rcDest) ) {
                if( !xtiled && !ytiled ) {
                    rcDest.right -= rcDest.left;
                    rcDest.bottom -= rcDest.top;
                    ::AlphaBlend(hDC, rcDest.left, rcDest.top, rcDest.right, rcDest.bottom, hCloneDC, \
                        rcBmpPart.left + rcCorners.left, rcBmpPart.top + rcCorners.top, \
                        rcBmpPart.right - rcBmpPart.left - rcCorners.left - rcCorners.right, \
                        rcBmpPart.bottom - rcBmpPart.top - rcCorners.top - rcCorners.bottom, bf);
                }
                else if( xtiled && ytiled ) {
                    LONG lWidth = rcBmpPart.right - rcBmpPart.left - rcCorners.left - rcCorners.right;
                    LONG lHeight = rcBmpPart.bottom - rcBmpPart.top - rcCorners.top - rcCorners.bottom;
                    int iTimesX = (rcDest.right - rcDest.left + lWidth - 1) / lWidth;
                    int iTimesY = (rcDest.bottom - rcDest.top + lHeight - 1) / lHeight;
                    for( int j = 0; j < iTimesY; ++j ) {
                        LONG lDestTop = rcDest.top + lHeight * j;
                        LONG lDestBottom = rcDest.top + lHeight * (j + 1);
                        LONG lDrawHeight = lHeight;
                        if( lDestBottom > rcDest.bottom ) {
                            lDrawHeight -= lDestBottom - rcDest.bottom;
                            lDestBottom = rcDest.bottom;
                        }
                        for( int i = 0; i < iTimesX; ++i ) {
                            LONG lDestLeft = rcDest.left + lWidth * i;
                            LONG lDestRight = rcDest.left + lWidth * (i + 1);
                            LONG lDrawWidth = lWidth;
                            if( lDestRight > rcDest.right ) {
                                lDrawWidth -= lDestRight - rcDest.right;
                                lDestRight = rcDest.right;
                            }
                            ::AlphaBlend(hDC, rcDest.left + lWidth * i, rcDest.top + lHeight * j, 
                                lDestRight - lDestLeft, lDestBottom - lDestTop, hCloneDC, 
                                rcBmpPart.left + rcCorners.left, rcBmpPart.top + rcCorners.top, lDrawWidth, lDrawHeight, bf);
                        }
                    }
                }
                else if( xtiled ) {
                    LONG lWidth = rcBmpPart.right - rcBmpPart.left - rcCorners.left - rcCorners.right;
                    int iTimes = (rcDest.right - rcDest.left + lWidth - 1) / lWidth;
                    for( int i = 0; i < iTimes; ++i ) {
                        LONG lDestLeft = rcDest.left + lWidth * i;
                        LONG lDestRight = rcDest.left + lWidth * (i + 1);
                        LONG lDrawWidth = lWidth;
                        if( lDestRight > rcDest.right ) {
                            lDrawWidth -= lDestRight - rcDest.right;
                            lDestRight = rcDest.right;
                        }
                        ::AlphaBlend(hDC, lDestLeft, rcDest.top, lDestRight - lDestLeft, rcDest.bottom, 
                            hCloneDC, rcBmpPart.left + rcCorners.left, rcBmpPart.top + rcCorners.top, \
                            lDrawWidth, rcBmpPart.bottom - rcBmpPart.top - rcCorners.top - rcCorners.bottom, bf);
                    }
                }
                else { // ytiled
                    LONG lHeight = rcBmpPart.bottom - rcBmpPart.top - rcCorners.top - rcCorners.bottom;
                    int iTimes = (rcDest.bottom - rcDest.top + lHeight - 1) / lHeight;
                    for( int i = 0; i < iTimes; ++i ) {
                        LONG lDestTop = rcDest.top + lHeight * i;
                        LONG lDestBottom = rcDest.top + lHeight * (i + 1);
                        LONG lDrawHeight = lHeight;
                        if( lDestBottom > rcDest.bottom ) {
                            lDrawHeight -= lDestBottom - rcDest.bottom;
                            lDestBottom = rcDest.bottom;
                        }
                        ::AlphaBlend(hDC, rcDest.left, rcDest.top + lHeight * i, rcDest.right, lDestBottom - lDestTop, 
                            hCloneDC, rcBmpPart.left + rcCorners.left, rcBmpPart.top + rcCorners.top, \
                            rcBmpPart.right - rcBmpPart.left - rcCorners.left - rcCorners.right, lDrawHeight, bf);                    
                    }
                }
            }
        }

        // left-top
        if( rcCorners.left > 0 && rcCorners.top > 0 ) {
            rcDest.left = rc.left;
            rcDest.top = rc.top;
            rcDest.right = rcCorners.left;
            rcDest.bottom = rcCorners.top;
            rcDest.right += rcDest.left;
            rcDest.bottom += rcDest.top;
            if( rcTemp.IntersectRect(&rcPaint, &rcDest) ) {
                rcDest.right -= rcDest.left;
                rcDest.bottom -= rcDest.top;
                ::AlphaBlend(hDC, rcDest.left, rcDest.top, rcDest.right, rcDest.bottom, hCloneDC, \
                    rcBmpPart.left, rcBmpPart.top, rcCorners.left, rcCorners.top, bf);
            }
        }
        // top
        if( rcCorners.top > 0 ) {
            rcDest.left = rc.left + rcCorners.left;
            rcDest.top = rc.top;
            rcDest.right = rc.right - rc.left - rcCorners.left - rcCorners.right;
            rcDest.bottom = rcCorners.top;
            rcDest.right += rcDest.left;
            rcDest.bottom += rcDest.top;
            if( rcTemp.IntersectRect(&rcPaint, &rcDest) ) {
                rcDest.right -= rcDest.left;
                rcDest.bottom -= rcDest.top;
                ::AlphaBlend(hDC, rcDest.left, rcDest.top, rcDest.right, rcDest.bottom, hCloneDC, \
                    rcBmpPart.left + rcCorners.left, rcBmpPart.top, rcBmpPart.right - rcBmpPart.left - \
                    rcCorners.left - rcCorners.right, rcCorners.top, bf);
            }
        }
        // right-top
        if( rcCorners.right > 0 && rcCorners.top > 0 ) {
            rcDest.left = rc.right - rcCorners.right;
            rcDest.top = rc.top;
            rcDest.right = rcCorners.right;
            rcDest.bottom = rcCorners.top;
            rcDest.right += rcDest.left;
            rcDest.bottom += rcDest.top;
            if( rcTemp.IntersectRect(&rcPaint, &rcDest) ) {
                rcDest.right -= rcDest.left;
                rcDest.bottom -= rcDest.top;
                ::AlphaBlend(hDC, rcDest.left, rcDest.top, rcDest.right, rcDest.bottom, hCloneDC, \
                    rcBmpPart.right - rcCorners.right, rcBmpPart.top, rcCorners.right, rcCorners.top, bf);
            }
        }
        // left
        if( rcCorners.left > 0 ) {
            rcDest.left = rc.left;
            rcDest.top = rc.top + rcCorners.top;
            rcDest.right = rcCorners.left;
            rcDest.bottom = rc.bottom - rc.top - rcCorners.top - rcCorners.bottom;
            rcDest.right += rcDest.left;
            rcDest.bottom += rcDest.top;
            if( rcTemp.IntersectRect(&rcPaint, &rcDest) ) {
                rcDest.right -= rcDest.left;
                rcDest.bottom -= rcDest.top;
                ::AlphaBlend(hDC, rcDest.left, rcDest.top, rcDest.right, rcDest.bottom, hCloneDC, \
                    rcBmpPart.left, rcBmpPart.top + rcCorners.top, rcCorners.left, rcBmpPart.bottom - \
                    rcBmpPart.top - rcCorners.top - rcCorners.bottom, bf);
            }
        }
        // right
        if( rcCorners.right > 0 ) {
            rcDest.left = rc.right - rcCorners.right;
            rcDest.top = rc.top + rcCorners.top;
            rcDest.right = rcCorners.right;
            rcDest.bottom = rc.bottom - rc.top - rcCorners.top - rcCorners.bottom;
            rcDest.right += rcDest.left;
            rcDest.bottom += rcDest.top;
            if( rcTemp.IntersectRect(&rcPaint, &rcDest) ) {
                rcDest.right -= rcDest.left;
                rcDest.bottom -= rcDest.top;
                ::AlphaBlend(hDC, rcDest.left, rcDest.top, rcDest.right, rcDest.bottom, hCloneDC, \
                    rcBmpPart.right - rcCorners.right, rcBmpPart.top + rcCorners.top, rcCorners.right, \
                    rcBmpPart.bottom - rcBmpPart.top - rcCorners.top - rcCorners.bottom, bf);
            }
        }
        // left-bottom
        if( rcCorners.left > 0 && rcCorners.bottom > 0 ) {
            rcDest.left = rc.left;
            rcDest.top = rc.bottom - rcCorners.bottom;
            rcDest.right = rcCorners.left;
            rcDest.bottom = rcCorners.bottom;
            rcDest.right += rcDest.left;
            rcDest.bottom += rcDest.top;
            if( rcTemp.IntersectRect(&rcPaint, &rcDest) ) {
                rcDest.right -= rcDest.left;
                rcDest.bottom -= rcDest.top;
                ::AlphaBlend(hDC, rcDest.left, rcDest.top, rcDest.right, rcDest.bottom, hCloneDC, \
                    rcBmpPart.left, rcBmpPart.bottom - rcCorners.bottom, rcCorners.left, rcCorners.bottom, bf);
            }
        }
        // bottom
        if( rcCorners.bottom > 0 ) {
            rcDest.left = rc.left + rcCorners.left;
            rcDest.top = rc.bottom - rcCorners.bottom;
            rcDest.right = rc.right - rc.left - rcCorners.left - rcCorners.right;
            rcDest.bottom = rcCorners.bottom;
            rcDest.right += rcDest.left;
            rcDest.bottom += rcDest.top;
            if( rcTemp.IntersectRect(&rcPaint, &rcDest) ) {
                rcDest.right -= rcDest.left;
                rcDest.bottom -= rcDest.top;
                ::AlphaBlend(hDC, rcDest.left, rcDest.top, rcDest.right, rcDest.bottom, hCloneDC, \
                    rcBmpPart.left + rcCorners.left, rcBmpPart.bottom - rcCorners.bottom, \
                    rcBmpPart.right - rcBmpPart.left - rcCorners.left - rcCorners.right, rcCorners.bottom, bf);
            }
        }
        // right-bottom
        if( rcCorners.right > 0 && rcCorners.bottom > 0 ) {
            rcDest.left = rc.right - rcCorners.right;
            rcDest.top = rc.bottom - rcCorners.bottom;
            rcDest.right = rcCorners.right;
            rcDest.bottom = rcCorners.bottom;
            rcDest.right += rcDest.left;
            rcDest.bottom += rcDest.top;
            if( rcTemp.IntersectRect(&rcPaint, &rcDest) ) {
                rcDest.right -= rcDest.left;
                rcDest.bottom -= rcDest.top;
                ::AlphaBlend(hDC, rcDest.left, rcDest.top, rcDest.right, rcDest.bottom, hCloneDC, \
                    rcBmpPart.right - rcCorners.right, rcBmpPart.bottom - rcCorners.bottom, rcCorners.right, \
                    rcCorners.bottom, bf);
            }
        }
    }
#pragma endregion 

    ::SelectObject(hCloneDC, hOldBitmap);
    ::DeleteDC(hCloneDC);
}

BOOL X_DrawImageString( HDC hDC, XWindow* pWindow, const XRect& rc, const XRect& rcPaint, LPCTSTR pstrImage,
    LPCTSTR pstrModify /*= NULL*/, BOOL bNeedAlpha /*= FALSE*/, BYTE bNewFade /*= 255*/ )
{
    if ((pWindow == NULL) || (hDC == NULL)) return FALSE;

    // Format (pstrModify)
    // 1. xxx.jpg ...
    // 2. file='xxx.jpg' res='' dest='0,0,0,0' source='0,0,0,0' corner='0,0,0,0' 
    //    mask='#FF0000' fade='255' hole='FALSE' xtiled='FALSE' ytiled='FALSE'

    XString sImageName = pstrImage;
    XString sImageResType;
    XRect rcItem = rc;
    XRect rcBmpPart;
    XRect rcCorner;
    DWORD dwMask = 0;
    BYTE bFade = 0xFF;
    BOOL bHole = FALSE;
    BOOL bTiledX = FALSE;
    BOOL bTiledY = FALSE;

    int image_count = 0;

    XString szItem;
    XString szValue;
    LPTSTR pstr = NULL;

#pragma region RESOLVE_ATTRIBUTIONS
    for( int i = 0; i < 2; ++i, image_count = 0 )
    {
        if( i == 1)
            pstrImage = pstrModify;

        if( !pstrImage ) continue;

        while( *pstrImage != _T('\0') ) {
            szItem.Empty();
            szValue.Empty();
            while( *pstrImage > _T('\0') && *pstrImage <= _T(' ') ) pstrImage = ::CharNext(pstrImage);
            while( *pstrImage != _T('\0') && *pstrImage != _T('=') && *pstrImage > _T(' ') ) {
                LPTSTR pstrTemp = ::CharNext(pstrImage);
                while( pstrImage < pstrTemp) {
                    szItem += *pstrImage++;
                }
            }

            while( *pstrImage > _T('\0') && *pstrImage <= _T(' ') ) pstrImage = ::CharNext(pstrImage);
            if( *pstrImage++ != _T('=') ) break;
            while( *pstrImage > _T('\0') && *pstrImage <= _T(' ') ) pstrImage = ::CharNext(pstrImage);
            if( *pstrImage++ != _T('\'') ) break;
            while( *pstrImage != _T('\0') && *pstrImage != _T('\'') ) {
                LPTSTR pstrTemp = ::CharNext(pstrImage);
                while( pstrImage < pstrTemp) {
                    szValue += *pstrImage++;
                }
            }

            if( *pstrImage++ != _T('\'') ) break;
            if( !szValue.IsEmpty() ) {
                if( szItem == _T("file") || szItem == _T("res") ) {
                    if( image_count > 0 )
                    {
                        if( bNeedAlpha )
                            X_DrawImage(hDC, pWindow, rc, rcPaint, sImageName, rcItem, rcBmpPart, rcCorner, dwMask, bNewFade, bHole, bTiledX, bTiledY, bNeedAlpha);
                        else
                            X_DrawImage(hDC, pWindow, rc, rcPaint, sImageName, rcItem, rcBmpPart, rcCorner, dwMask, bFade, bHole, bTiledX, bTiledY);
                    }

                    sImageName = szValue;
                    if( szItem == _T("file") )
                        ++image_count;
                } else if( szItem == _T("dest") ) {
                    rcItem.left         = rc.left + _tcstol(szValue, &pstr, 10);    ASSERT(pstr);    
                    rcItem.top          = rc.top + _tcstol(pstr + 1, &pstr, 10);    ASSERT(pstr);
                    rcItem.right        = rc.left + _tcstol(pstr + 1, &pstr, 10);   ASSERT(pstr);
                    if (rcItem.right > rc.right) rcItem.right = rc.right;
                    rcItem.bottom = rc.top + _tcstol(pstr + 1, &pstr, 10);          ASSERT(pstr);
                    if (rcItem.bottom > rc.bottom) rcItem.bottom = rc.bottom;
                } else if( szItem == _T("source") ) {
                    rcBmpPart.left      = _tcstol(szValue, &pstr, 10);              ASSERT(pstr);
                    rcBmpPart.top       = _tcstol(pstr + 1, &pstr, 10);             ASSERT(pstr);
                    rcBmpPart.right     = _tcstol(pstr + 1, &pstr, 10);             ASSERT(pstr);
                    rcBmpPart.bottom    = _tcstol(pstr + 1, &pstr, 10);             ASSERT(pstr);
                } else if( szItem == _T("corner") ) {
                    rcCorner.left       = _tcstol(szValue, &pstr, 10);              ASSERT(pstr);
                    rcCorner.top        = _tcstol(pstr + 1, &pstr, 10);             ASSERT(pstr);
                    rcCorner.right      = _tcstol(pstr + 1, &pstr, 10);             ASSERT(pstr);
                    rcCorner.bottom     = _tcstol(pstr + 1, &pstr, 10);             ASSERT(pstr);
                } else if( szItem == _T("mask") ) {
                    if( szValue[0] == _T('#')) dwMask = _tcstoul(szValue.GetBuffer(0) + 1, &pstr, 16);
                    else dwMask = _tcstoul(szValue, &pstr, 16);
                } else if( szItem == _T("fade") ) {
                    bFade = (BYTE)_tcstoul(szValue, &pstr, 10);
                } else if( szItem == _T("hole") ) {
                    bHole = szValue.CompareNoCase(_T("TRUE")) == 0;
                } else if( szItem == _T("xtiled") ) {
                    bTiledX = szValue.CompareNoCase(_T("TRUE")) == 0;
                } else if( szItem == _T("ytiled") ) {
                    bTiledY = szValue.CompareNoCase(_T("TRUE")) == 0;
                }
            }
            if( *pstrImage++ != _T(' ') ) break;
        }
    }
#pragma endregion 

    X_DrawImage(hDC, pWindow, rc, rcPaint, sImageName, rcItem, rcBmpPart, rcCorner, dwMask, bNewFade, bHole, bTiledX, bTiledY, bNeedAlpha);

    return TRUE;
}

#define CC_TOP_INDENT (aPIndentList.Count() == 0 ? 0 : aPIndentList.Get(aPIndentList.GetSize() - 1))
#define CC_TOP_FONT (aFontList.Count() == 0 ? pWindow->GetDefaultFontInfo() : aFontList.Get(aFontList.GetSize() - 1))
#define CC_TOP_CLR (aColorList.GetSize() == 0 ? dwTextColor : aColorList.Get(aColorList.GetSize() - 1))
void X_DrawHtmlText( HDC hDC, XWindow* pWindow, XRect& rc, LPCTSTR pstrText, DWORD dwTextColor, XRect* pLinks, XString* sLinks,
    int& nLinkRects, UINT uStyle )
{
    ASSERT_HDC(hDC);
    ASSERT(pWindow);
    ASSERT(pstrText);

    if (rc.IsRectEmpty()) return;

    // ֧�ֱ�ǩǶ�ף�Ҫ��ֹ����Ƕ��
    // The string formatter supports a kind of "mini-html" that consists of various short tags:
    //
    //   ����         Bold:             <b>text</b>
    //   ��ɫ         Color:            <c #rrggbb>text</c>  where rgb = RGB in hex(base=16)
    //                               OR <c $r,g,b>text</c>   where rgb = RGB in dec(base=10)
    //   ����         Font:             <f x>text</f>        where x = font id or name
    //   б��         Italic:           <i>text</i>
    //   ͼƬ         Image:            <m x>                where x = image id or name
    //   ����         Link:             <a x>text</a>        where x(optional) = link content, normal like "app:notepad" or "http:www.xxx.com"
    //   ����         NewLine           <n>
    //   ����         Paragraph:        <p x>text</p>        where x = extra pixels indent in p
    //   ���ı�       Raw Text:         <r>text</r>
    //   ѡ��         Selected:         <s>text</s>
    //   �»���       Underline:        <u>text</u>
    //   ˮƽ����     X Indent:         <x i>                where i = hor indent in pixels
    //   ��ֱ����     Y Indent:         <y i>                where i = ver indent in pixels

#pragma region RESOLVE_HTML_TEXT

    BOOL bDraw = (uStyle & DT_CALCRECT) == 0;

    List<TFont*>   aFontList;
    List<COLORREF> aColorList;
    List<int>      aPIndentList;

    XRect rcClip;
    ::GetClipBox(hDC, &rcClip);

    HRGN hOldRgn = ::CreateRectRgnIndirect(&rcClip);
    HRGN hRgn = ::CreateRectRgnIndirect(&rc);
    if( bDraw ) ::ExtSelectClipRgn(hDC, hRgn, RGN_AND);

    const TEXTMETRIC* pTm = &pWindow->GetDefaultFontInfo()->tm;
    HFONT hOldFont = (HFONT) ::SelectObject(hDC, pWindow->GetDefaultFontInfo()->hFont);
    ::SetBkMode(hDC, TRANSPARENT);
    ::SetTextColor(hDC, RGB(GetBValue(dwTextColor), GetGValue(dwTextColor), GetRValue(dwTextColor)));
    DWORD dwBkColor = XCOLOR_CONTROL_BACKGROUND_SELECTED;
    ::SetBkColor(hDC, RGB(GetBValue(dwBkColor), GetGValue(dwBkColor), GetRValue(dwBkColor)));

    // If the drawstyle include a alignment, we'll need to first determine the text-size so
    // we can draw it at the correct position...
    if( ((uStyle & DT_CENTER) != 0 || (uStyle & DT_RIGHT) != 0 || (uStyle & DT_VCENTER) != 0 || (uStyle & DT_BOTTOM) != 0) && (uStyle & DT_CALCRECT) == 0 ) {
        XRect rcText(0, 0, 9999, 100);
        int nLinks = 0;
        X_DrawHtmlText(hDC, pWindow, rcText, pstrText, dwTextColor, NULL, NULL, nLinks, uStyle | DT_CALCRECT);
        if( (uStyle & DT_SINGLELINE) != 0 ){
            if( (uStyle & DT_CENTER) != 0 ) {
                rc.left = rc.left + (rc.Width() / 2) - (rcText.Width() / 2);
                rc.right = rc.left + rcText.Width();
            }
            if( (uStyle & DT_RIGHT) != 0 ) {
                rc.left = rc.right - rcText.Width();
            }
        }
        if( (uStyle & DT_VCENTER) != 0 ) {
            rc.top = rc.top + (rc.Height() / 2) - (rcText.Height() / 2);
            rc.bottom = rc.top + rcText.Height();
        }
        if( (uStyle & DT_BOTTOM) != 0 ) {
            rc.top = rc.bottom - rcText.Height();
        }
    }

    BOOL bHoverLink = FALSE;
    XString sHoverLink;
    XPoint ptMouse = pWindow->GetMousePos();
    for( int i = 0; !bHoverLink && i < nLinkRects; i++ ) {
        if( pLinks[i].PtInRect(ptMouse) ) {
            sHoverLink = *(XString*)(sLinks + i);
            bHoverLink = TRUE;
        }
    }

    XPoint pt = rc.TopLeft();
    int iLinkIndex = 0;
    int cyLine = pTm->tmHeight + pTm->tmExternalLeading + CC_TOP_INDENT;
    int cyMinHeight = 0;
    int cxMaxWidth = 0;
    XPoint ptLinkStart;
    BOOL bLineEnd = FALSE;
    BOOL bInRaw = FALSE;
    BOOL bInLink = FALSE;
    BOOL bInSelected = FALSE;
    int iLineLinkIndex = 0;

    // �Ű�ϰ����ͼ�ĵײ����룬����ÿ�л��ƶ�Ҫ���������ȼ���߶ȣ��ٻ���
    List<TFont*>   aLineFontList;
    List<COLORREF> aLineColorList;
    List<int>      aLinePIndentList;
    LPCTSTR pstrLineBegin = pstrText;
    BOOL bLineInRaw = FALSE;
    BOOL bLineInLink = FALSE;
    BOOL bLineInSelected = FALSE;
    int cyLineHeight = 0;
    BOOL bLineDraw = FALSE; // �еĵڶ��׶Σ�����
    while( *pstrText != _T('\0') ) {
#pragma region LINE_END
        if( pt.x >= rc.right || *pstrText == _T('\n') || bLineEnd ) {
            if( *pstrText == _T('\n') ) pstrText++;
            if( bLineEnd ) bLineEnd = FALSE;
            if( !bLineDraw ) {
                if( bInLink && iLinkIndex < nLinkRects ) {
                    pLinks[iLinkIndex++].SetRect(ptLinkStart.x, ptLinkStart.y, min(pt.x, rc.right), pt.y + cyLine);
                    XString *pStr1 = (XString*)(sLinks + iLinkIndex - 1);
                    XString *pStr2 = (XString*)(sLinks + iLinkIndex);
                    *pStr2 = *pStr1;
                }
                for( int i = iLineLinkIndex; i < iLinkIndex; i++ ) {
                    pLinks[i].bottom = pt.y + cyLine;
                }
                if( bDraw ) {
                    bInLink = bLineInLink;
                    iLinkIndex = iLineLinkIndex;
                }
            } else {
                if( bInLink && iLinkIndex < nLinkRects ) iLinkIndex++;
                bLineInLink = bInLink;
                iLineLinkIndex = iLinkIndex;
            }
            if( (uStyle & DT_SINGLELINE) != 0 && (!bDraw || bLineDraw) ) break;
            if( bDraw ) bLineDraw = !bLineDraw; // !
            pt.x = rc.left;
            if( !bLineDraw ) pt.y += cyLine;
            if( pt.y > rc.bottom && bDraw ) break;
            ptLinkStart = pt;
            cyLine = pTm->tmHeight + pTm->tmExternalLeading + CC_TOP_INDENT;
            if( pt.x >= rc.right ) break;
#pragma endregion LINE_END
        } else if( !bInRaw && ( *pstrText == _T('<') || *pstrText == _T('{') )
            && ( pstrText[1] >= _T('a') && pstrText[1] <= _T('z') )
            && ( pstrText[2] == _T(' ') || pstrText[2] == _T('>') || pstrText[2] == _T('}') ) ) {
                pstrText++;
                LPCTSTR pstrNextStart = NULL;
                switch( *pstrText ) {
#pragma region LINK
                case _T('a'):  // Link
                    {
                        pstrText++;
                        while( *pstrText > _T('\0') && *pstrText <= _T(' ') ) pstrText = ::CharNext(pstrText);
                        if( iLinkIndex < nLinkRects && !bLineDraw ) {
                            XString *pStr = (XString*)(sLinks + iLinkIndex);
                            pStr->Empty();
                            while( *pstrText != _T('\0') && *pstrText != _T('>') && *pstrText != _T('}') ) {
                                LPCTSTR pstrTemp = ::CharNext(pstrText);
                                while( pstrText < pstrTemp) {
                                    *pStr += *pstrText++;
                                }
                            }
                        }

                        DWORD clrColor = XCOLOR_LINK_TEXT_NORMAL;
                        if( bHoverLink && iLinkIndex < nLinkRects ) {
                            XString *pStr = (XString*)(sLinks + iLinkIndex);
                            if( sHoverLink == *pStr ) clrColor = XCOLOR_LINK_TEXT_HOVER;
                        }

                        aColorList.Add(clrColor);
                        ::SetTextColor(hDC,  RGB(GetBValue(clrColor), GetGValue(clrColor), GetRValue(clrColor)));
                        TFont* pFont = CC_TOP_FONT;
                        if( pFont->bUnderline == FALSE ) {
                            pFont = pWindow->GetFontInfo(pFont->lpszFontName->GetBuffer(0), pFont->nSize, pFont->bBold, TRUE, pFont->bItalic);
                            aFontList.Add(pFont);
                            pTm = &pFont->tm;
                            ::SelectObject(hDC, pFont->hFont);
                            cyLine = max(cyLine, pTm->tmHeight + pTm->tmExternalLeading + CC_TOP_INDENT);
                        }
                        ptLinkStart = pt;
                        bInLink = TRUE;
                    }
                    break;
#pragma endregion LINK
#pragma region BOLD
                case _T('b'):  // Bold
                    {
                        pstrText++;
                        TFont* pFont = CC_TOP_FONT;
                        if( pFont->bBold == FALSE ) {
                            pFont = pWindow->GetFontInfo(pFont->lpszFontName->GetBuffer(0), pFont->nSize, TRUE, pFont->bUnderline, pFont->bItalic);
                            aFontList.Add(pFont);
                            pTm = &pFont->tm;
                            ::SelectObject(hDC, pFont->hFont);
                            cyLine = max(cyLine, pTm->tmHeight + pTm->tmExternalLeading + CC_TOP_INDENT);
                        }
                    }
                    break;
#pragma endregion BOLD
#pragma region COLOR
                case _T('c'):  // Color
                    {
                        pstrText++;
                        while( *pstrText > _T('\0') && *pstrText <= _T(' ') ) pstrText = ::CharNext(pstrText);
                        DWORD clrColor = 0;
                        if( *pstrText == _T('#')) {
                            pstrText++;
                            clrColor = _tcstol(pstrText, const_cast<LPTSTR*>(&pstrText), 16);
                        } else if (*pstrText == _T('$')) {
                            pstrText++;
                            LPTSTR pstr = NULL;
                            BYTE r  = (BYTE)_tcstol(pstrText, &pstr, 10);       ASSERT(pstr);
                            BYTE g  = (BYTE)_tcstol(pstr + 1, &pstr, 10);       ASSERT(pstr);
                            BYTE b  = (BYTE)_tcstol(pstr + 1, &pstr, 10);       ASSERT(pstr);
                            clrColor = RGB(r,g,b);
                        }
                        aColorList.Add(clrColor);
                        ::SetTextColor(hDC, RGB(GetRValue(clrColor), GetGValue(clrColor), GetBValue(clrColor)));
                    }
                    break;
#pragma endregion COLOR
#pragma region FONT
                case _T('f'):  // Font
                    {
                        pstrText++;
                        while( *pstrText > _T('\0') && *pstrText <= _T(' ') ) pstrText = ::CharNext(pstrText);
                        LPCTSTR pstrTemp = pstrText;
                        if( pstrTemp != pstrText ) {
                            TFont* pFont = pWindow->GetFontLink(pstrTemp);
                            aFontList.Add(pFont);
                            pTm = &pFont->tm;
                            ::SelectObject(hDC, pFont->hFont);
                        }
                        cyLine = max(cyLine, pTm->tmHeight + pTm->tmExternalLeading + CC_TOP_INDENT);
                    }
                    break;
#pragma endregion FONT
#pragma region ITALIC
                case _T('i'):  // Italic or Image
                    {
                        pstrText++;
                        TFont* pFont = CC_TOP_FONT;
                        if( pFont->bItalic == FALSE ) {
                            pFont = pWindow->GetFontInfo(pFont->lpszFontName->GetBuffer(0), pFont->nSize, pFont->bBold, pFont->bUnderline, TRUE);
                            aFontList.Add(pFont);
                            pTm = &pFont->tm;
                            ::SelectObject(hDC, pFont->hFont);
                            cyLine = max(cyLine, pTm->tmHeight + pTm->tmExternalLeading + CC_TOP_INDENT);
                        }
                    }
                    break;
#pragma endregion ITALIC
#pragma region IMAGE
                case 'm':
                    {
                        pstrText++;
                        while( *pstrText > _T('\0') && *pstrText <= _T(' ') ) pstrText = ::CharNext(pstrText);
                        LPCTSTR pstrTemp = pstrText;
                        if( pstrTemp != pstrText ) {
                            const TImage* pImage = pWindow->GetImage(pstrTemp);
                            if (pImage == NULL) break;

                            int iWidth = pImage->nX;
                            int iHeight = pImage->nY;

                            if( pt.x + iWidth > rc.right && pt.x > rc.left && (uStyle & DT_SINGLELINE) == 0 ) {
                                bLineEnd = true;
                            } else {
                                if( bDraw && bLineDraw ) {
                                    XRect rcImage(pt.x, pt.y + cyLineHeight - iHeight, pt.x + iWidth, pt.y + cyLineHeight);
                                    if( iHeight < cyLineHeight ) { 
                                        rcImage.bottom -= (cyLineHeight - iHeight) / 2;
                                        rcImage.top = rcImage.bottom -  iHeight;
                                    }
                                    XRect rcBmpPart(0, 0, iWidth, iHeight);
                                    XRect rcCorner;
                                    X_DrawImage(hDC, pImage->hBitmap, rcImage, rcImage, rcBmpPart, rcCorner, pImage->alphaChannel, 255);
                                }
                                cyLine = max(iHeight, cyLine);
                                pt.x += iWidth;
                                cyMinHeight = pt.y + iHeight;
                                cxMaxWidth = max(cxMaxWidth, pt.x);
                            }
                        }
                    }
                    break;
#pragma endregion IMAGE
#pragma region LINE
                case _T('n'):  // Newline
                    {
                        pstrText++;
                        if( (uStyle & DT_SINGLELINE) != 0 ) break;
                        bLineEnd = TRUE;
                    }
                    break;
#pragma endregion LINE
#pragma region PARAGRAPH
                case _T('p'):  // Paragraph
                    {
                        pstrText++;
                        if( pt.x > rc.left ) bLineEnd = TRUE;
                        while( *pstrText > _T('\0') && *pstrText <= _T(' ') ) pstrText = ::CharNext(pstrText);
                        int cyLineExtra = (int)_tcstol(pstrText, const_cast<LPTSTR*>(&pstrText), 10);
                        aPIndentList.Add(cyLineExtra);
                        cyLine = max(cyLine, pTm->tmHeight + pTm->tmExternalLeading + cyLineExtra);
                    }
                    break;
#pragma endregion PARAGRAPH
#pragma region RAW
                case _T('r'):  // Raw Text
                    {
                        pstrText++;
                        bInRaw = TRUE;
                    }
                    break;
#pragma endregion RAW
#pragma region SELECTED
                case _T('s'):  // Selected text background color
                    {
                        pstrText++;
                        bInSelected = !bInSelected;
                        if( bDraw && bLineDraw ) {
                            if( bInSelected ) ::SetBkMode(hDC, OPAQUE);
                            else ::SetBkMode(hDC, TRANSPARENT);
                        }
                    }
                    break;
#pragma endregion SELECTED
#pragma region UNDERLINE
                case _T('u'):  // Underline text
                    {
                        pstrText++;
                        TFont* pFont = CC_TOP_FONT;
                        if( pFont->bUnderline == FALSE ) {
                            pFont = pWindow->GetFontInfo(pFont->lpszFontName->GetBuffer(0), pFont->nSize, pFont->bBold, TRUE, pFont->bItalic);
                            aFontList.Add(pFont);
                            pTm = &pFont->tm;
                            ::SelectObject(hDC, pFont->hFont);
                            cyLine = max(cyLine, pTm->tmHeight + pTm->tmExternalLeading + CC_TOP_INDENT);
                        }
                    }
                    break;
#pragma endregion UNDERLINE
#pragma region X_INDENT
                case _T('x'):  // X Indent
                    {
                        pstrText++;
                        while( *pstrText > _T('\0') && *pstrText <= _T(' ') ) pstrText = ::CharNext(pstrText);
                        int iWidth = (int) _tcstol(pstrText, const_cast<LPTSTR*>(&pstrText), 10);
                        pt.x += iWidth;
                        cxMaxWidth = max(cxMaxWidth, pt.x);
                    }
                    break;
#pragma endregion X_INDENT
#pragma region Y_INDENT
                case _T('y'):  // Y Indent
                    {
                        pstrText++;
                        while( *pstrText > _T('\0') && *pstrText <= _T(' ') ) pstrText = ::CharNext(pstrText);
                        cyLine = (int) _tcstol(pstrText, const_cast<LPTSTR*>(&pstrText), 10);
                    }
                    break;
                }
#pragma endregion Y_INDENT
                if( pstrNextStart != NULL ) pstrText = pstrNextStart;
                else {
                    while( *pstrText != _T('\0') && *pstrText != _T('>') && *pstrText != _T('}') ) pstrText = ::CharNext(pstrText);
                    pstrText = ::CharNext(pstrText);
                }
        } else if( !bInRaw && ( *pstrText == _T('<') || *pstrText == _T('{') ) && pstrText[1] == _T('/') ) {
            pstrText++;
            pstrText++;
            switch( *pstrText )
            {
#pragma region C
            case _T('c'):
                {
                    if (aColorList.Count() == 0) break;
                    pstrText++;
                    aColorList.RemoveAt(aColorList.GetSize() - 1);
                    DWORD clrColor = dwTextColor;
                    if( aColorList.GetSize() > 0 ) clrColor = (int)aColorList.Get(aColorList.GetSize() - 1);
                    ::SetTextColor(hDC, RGB(GetBValue(clrColor), GetGValue(clrColor), GetRValue(clrColor)));
                }
                break;
#pragma endregion C
#pragma region P
            case _T('p'):
                {
                    if (aPIndentList.Count() == 0) break;
                    pstrText++;
                    if( pt.x > rc.left ) bLineEnd = TRUE;
                    aPIndentList.RemoveAt(aPIndentList.GetSize() - 1);
                    cyLine = max(cyLine, pTm->tmHeight + pTm->tmExternalLeading + CC_TOP_INDENT);
                }
                break;
#pragma endregion P
#pragma region S
            case _T('s'):
                {
                    pstrText++;
                    bInSelected = !bInSelected;
                    if( bDraw && bLineDraw ) {
                        if( bInSelected ) ::SetBkMode(hDC, OPAQUE);
                        else ::SetBkMode(hDC, TRANSPARENT);
                    }
                }
                break;
#pragma endregion S
#pragma region A
            case _T('a'):
                {
                    if (aColorList.Count() == 0) break;
                    if( iLinkIndex < nLinkRects ) {
                        if( !bLineDraw ) pLinks[iLinkIndex].SetRect(ptLinkStart.x, ptLinkStart.y, min(pt.x, rc.right), pt.y + pTm->tmHeight + pTm->tmExternalLeading);
                        iLinkIndex++;
                    }
                    aColorList.RemoveAt(aColorList.GetSize() - 1);
                    DWORD clrColor = CC_TOP_CLR;
                    ::SetTextColor(hDC, RGB(GetBValue(clrColor), GetGValue(clrColor), GetRValue(clrColor)));
                    bInLink = FALSE;
                }
#pragma endregion A
#pragma region BFIU
            case _T('b'):
            case _T('f'):
            case _T('i'):
            case _T('u'):
                {
                    if (aFontList.Count() == 0) break;
                    pstrText++;
                    aFontList.RemoveAt(aFontList.GetSize() - 1);
                    TFont* pFont = CC_TOP_FONT;
                    if( pTm->tmItalic && pFont->bItalic == FALSE ) {
                        ABC abc;
                        ::GetCharABCWidths(hDC, _T(' '), _T(' '), &abc);
                        pt.x += abc.abcC / 2; // ������һ��б����ŵ�����, ��ȷ����Ӧ���� http://support.microsoft.com/kb/244798/en-us
                    }
                    pTm = &pFont->tm;
                    ::SelectObject(hDC, pFont->hFont);
                    cyLine = max(cyLine, pTm->tmHeight + pTm->tmExternalLeading + CC_TOP_INDENT);
                }
                break;
#pragma endregion BFIU
            }
            while( *pstrText != _T('\0') && *pstrText != _T('>') && *pstrText != _T('}') ) pstrText = ::CharNext(pstrText);
            pstrText = ::CharNext(pstrText);
        }
        else if( !bInRaw &&  *pstrText == _T('<') && pstrText[2] == _T('>') && (pstrText[1] == _T('{')  || pstrText[1] == _T('}')) )
        {
            SIZE szSpace = { 0 };
            ::GetTextExtentPoint32(hDC, &pstrText[1], 1, &szSpace);
            if( bDraw && bLineDraw ) ::TextOut(hDC, pt.x, pt.y + cyLineHeight - pTm->tmHeight - pTm->tmExternalLeading, &pstrText[1], 1);
            pt.x += szSpace.cx;
            cxMaxWidth = max(cxMaxWidth, pt.x);
            pstrText++;pstrText++;pstrText++;
        }
        else if( !bInRaw &&  *pstrText == _T('{') && pstrText[2] == _T('}') && (pstrText[1] == _T('<')  || pstrText[1] == _T('>')) )
        {
            SIZE szSpace = { 0 };
            ::GetTextExtentPoint32(hDC, &pstrText[1], 1, &szSpace);
            if( bDraw && bLineDraw ) ::TextOut(hDC, pt.x,  pt.y + cyLineHeight - pTm->tmHeight - pTm->tmExternalLeading, &pstrText[1], 1);
            pt.x += szSpace.cx;
            cxMaxWidth = max(cxMaxWidth, pt.x);
            pstrText++;pstrText++;pstrText++;
        }
        else if( !bInRaw &&  *pstrText == _T(' ') )
        {
            SIZE szSpace = { 0 };
            ::GetTextExtentPoint32(hDC, _T(" "), 1, &szSpace);
            // Still need to paint the space because the font might have
            // underline formatting.
            if( bDraw && bLineDraw ) ::TextOut(hDC, pt.x,  pt.y + cyLineHeight - pTm->tmHeight - pTm->tmExternalLeading, _T(" "), 1);
            pt.x += szSpace.cx;
            cxMaxWidth = max(cxMaxWidth, pt.x);
            pstrText++;
        }
        else
        {
            XPoint ptPos = pt;
            int cchChars = 0;
            int cchSize = 0;
            int cchLastGoodWord = 0;
            int cchLastGoodSize = 0;
            LPCTSTR p = pstrText;
            LPCTSTR pstrNext;
            SIZE szText = { 0 };
            if( !bInRaw && *p == _T('<') || *p == _T('{') ) p++, cchChars++, cchSize++;
            while( *p != _T('\0') && *p != _T('\n') ) {
                // This part makes sure that we're word-wrapping if needed or providing support
                // for DT_END_ELLIPSIS. Unfortunately the GetTextExtentPoint32() call is pretty
                // slow when repeated so often.
                // TODO: Rewrite and use GetTextExtentExPoint() instead!
                if( bInRaw ) {
                    if( ( *p == _T('<') || *p == _T('{') ) && p[1] == _T('/') 
                        && p[2] == _T('r') && ( p[3] == _T('>') || p[3] == _T('}') ) ) {
                            p += 4;
                            bInRaw = FALSE;
                            break;
                    }
                } else {
                    if( *p == _T('<') || *p == _T('{') ) break;
                }
                pstrNext = ::CharNext(p);
                cchChars++;
                cchSize += (int)(pstrNext - p);
                szText.cx = cchChars * pTm->tmMaxCharWidth;
                if( pt.x + szText.cx >= rc.right ) {
                    ::GetTextExtentPoint32(hDC, pstrText, cchSize, &szText);
                }
                if( pt.x + szText.cx > rc.right ) {
                    if( pt.x + szText.cx > rc.right && pt.x != rc.left) {
                        cchChars--;
                        cchSize -= (int)(pstrNext - p);
                    }
                    if( (uStyle & DT_WORDBREAK) != 0 && cchLastGoodWord > 0 ) {
                        cchChars = cchLastGoodWord;
                        cchSize = cchLastGoodSize;                 
                    }
                    if( (uStyle & DT_END_ELLIPSIS) != 0 && cchChars > 0 ) {
                        cchChars -= 1;
                        LPCTSTR pstrPrev = ::CharPrev(pstrText, p);
                        if( cchChars > 0 ) {
                            cchChars -= 1;
                            pstrPrev = ::CharPrev(pstrText, pstrPrev);
                            cchSize -= (int)(p - pstrPrev);
                        }
                        else 
                            cchSize -= (int)(p - pstrPrev);
                        pt.x = rc.right;
                    }
                    bLineEnd = TRUE;
                    cxMaxWidth = max(cxMaxWidth, pt.x);
                    break;
                }
                if (!( ( p[0] >= _T('a') && p[0] <= _T('z') ) || ( p[0] >= _T('A') && p[0] <= _T('Z') ) )) {
                    cchLastGoodWord = cchChars;
                    cchLastGoodSize = cchSize;
                }
                if( *p == _T(' ') ) {
                    cchLastGoodWord = cchChars;
                    cchLastGoodSize = cchSize;
                }
                p = ::CharNext(p);
            }

            ::GetTextExtentPoint32(hDC, pstrText, cchSize, &szText);
            if( bDraw && bLineDraw ) {
                if( (uStyle & DT_SINGLELINE) == 0 && (uStyle & DT_CENTER) != 0 ) {
                    ptPos.x += (rc.Width() - szText.cx)/2;
                    pLinks[iLinkIndex].OffsetRect((rc.Width() - szText.cx)/2, 0);
                }
                else if( (uStyle & DT_SINGLELINE) == 0 && (uStyle & DT_RIGHT) != 0) {
                    ptPos.x += (rc.Width() - szText.cx);
                }
                ::TextOut(hDC, ptPos.x, ptPos.y + cyLineHeight - pTm->tmHeight - pTm->tmExternalLeading, pstrText, cchSize);
                if( pt.x >= rc.right && (uStyle & DT_END_ELLIPSIS) != 0 ) 
                    ::TextOut(hDC, ptPos.x + szText.cx, ptPos.y, _T("..."), 3);
            }
            pt.x += szText.cx;
            cxMaxWidth = max(cxMaxWidth, pt.x);
            pstrText += cchSize;
        }

        if( pt.x >= rc.right || *pstrText == _T('\n') || *pstrText == _T('\0') ) bLineEnd = TRUE;
        if( bDraw && bLineEnd ) {
            if( !bLineDraw ) {
                using namespace cc::Collections::Enumerator::Internal;
                CopyFrom(aFontList.Wrap(), aLineFontList.Wrap());
                CopyFrom(aColorList.Wrap(), aLineColorList.Wrap());
                CopyFrom(aPIndentList.Wrap(), aLinePIndentList.Wrap());

                cyLineHeight = cyLine;
                pstrText = pstrLineBegin;
                bInRaw = bLineInRaw;
                bInSelected = bLineInSelected;

                DWORD clrColor = CC_TOP_CLR;
                ::SetTextColor(hDC, RGB(GetBValue(clrColor), GetGValue(clrColor), GetRValue(clrColor)));
                TFont* pFont = CC_TOP_FONT;
                pTm = &pFont->tm;
                ::SelectObject(hDC, pFont->hFont);
                if( bInSelected ) ::SetBkMode(hDC, OPAQUE);
            } else {
                using namespace cc::Collections::Enumerator::Internal;
                CopyFrom(aLineFontList.Wrap(), aFontList.Wrap());
                CopyFrom(aLineColorList.Wrap(), aColorList.Wrap());
                CopyFrom(aLinePIndentList.Wrap(), aPIndentList.Wrap());
                pstrLineBegin = pstrText;
                bLineInSelected = bInSelected;
                bLineInRaw = bInRaw;
            }
        }

        ASSERT(iLinkIndex <= nLinkRects);
    }

    nLinkRects = iLinkIndex;

    // Return size of text when requested
    if( (uStyle & DT_CALCRECT) != 0 ) {
        rc.bottom = max(cyMinHeight, pt.y + cyLine);
        rc.right = min(rc.right, cxMaxWidth);
    }

    if( bDraw ) ::SelectClipRgn(hDC, hOldRgn);
    ::DeleteObject(hOldRgn);
    ::DeleteObject(hRgn);
    ::SelectObject(hDC, hOldFont);

#pragma endregion
}

#undef CC_TOP_INDENT
#undef CC_TOP_FONT
#undef CC_TOP_CLR
RENDERING_END_NAMESPACE