#include "StdAfx.h"

CONTROLS_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS_WITH_PARA(XText, XLabel)
//////////////////////////////////////////////////////////////////////////

XText::XText( XObject* pOb /*= NULL*/ ): XLabel(pOb), m_nLinks(0), m_nHoverLink(-1)
{
    m_uTextStyle = DT_WORDBREAK;
    m_rcTextPadding.left = 2;
    m_rcTextPadding.right = 2;
}

XText::~XText()
{

}

void* XText::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_TEXT: return this;
    }
    return XLabel::GetInterface(hi);
}

void XText::Event( TEvent& event )
{
    if (!m_bMouseEnabled)
    {
        if (OnMouseEvent(event.msg.message))
        {
            if ( m_pParent != NULL )
            {
                event.sender = this;
                event.receiver = m_pParent;
                event.dispatcher->PostEvent(event);
            }
            else
            {
                XLabel::Event(event);
            }
        }
    }
    else
    {
        switch (event.msg.message)
        {
        case WM_SETCURSOR:
            for( int i = 0; i < m_nLinks; i++ )
            {
                if( m_rcLinks[i].PtInRect(event.msg.pt) )
                {
                    ::SetCursor(::LoadCursor(NULL, MAKEINTRESOURCE(IDC_HAND)));
                    return;
                }
            }
            break;
        case WM_LBUTTONDOWN:
        case WM_LBUTTONDBLCLK:
            if (m_bEnabled)
            {
                for( int i = 0; i < m_nLinks; i++ )
                {
                    if( m_rcLinks[i].PtInRect(event.msg.pt) )
                    {
                        Invalidate();
                        return;
                    }
                }
            }
            break;
        case WM_LBUTTONUP:
            if (m_bEnabled)
            {
                for( int i = 0; i < m_nLinks; i++ )
                {
                    if( m_rcLinks[i].PtInRect(event.msg.pt) )
                    {
                        ASSERT(m_pWindow);
                        m_pWindow->SendAsyncNotify(this, (DWORD) _T("TextLink"), TRUE, (WPARAM) i);
                        return;
                    }
                }
            }
            break;
        case WM_MOUSEMOVE:
            if (m_bEnabled && m_nLinks > 0)
            {
                int nHoverLink = -1;
                for( int i = 0; i < m_nLinks; i++ )
                {
                    if( m_rcLinks[i].PtInRect(event.msg.pt) )
                    {
                        nHoverLink = i;
                        break;
                    }
                }

                if(m_nHoverLink != nHoverLink)
                {
                    m_nHoverLink = nHoverLink;
                    Invalidate();
                    return;
                }
            }
            break;
        case WM_MOUSELEAVE:
            if (m_bEnabled && m_nLinks > 0)
            {
                if(m_nHoverLink != -1)
                {
                    m_nHoverLink = -1;
                    Invalidate();
                    return;
                }
            }
            break;
        }
        XLabel::Event(event);
    }
}

DWORD XText::GetFlags() const
{
    if( m_bEnabled && m_nLinks > 0 ) return XFLAG_SETCURSOR;
    else return 0;
}

void XText::PaintText( HDC hDC )
{
    ASSERT(hDC);
    ASSERT(m_pWindow);

    if( m_szText.IsEmpty() )
    {
        m_nLinks = 0;
        return;
    }

    if( m_clrTextColor == 0 )
        m_clrTextColor = m_pWindow->m_clrDefaultFontColor;
    if( m_clrDisabledTextColor == 0 )
        m_clrDisabledTextColor = m_pWindow->m_clrDefaultDisabledColor;

    if( m_szText.IsEmpty() )
    {
#ifdef _DEBUG
        TRACE("[%s - 0x%X] waring: this control has not text string.", GetClass()->m_lpszClassName, this);
#endif // _DEBUG
        return;
    }

    m_nLinks = MAX_LINK; // ��ǰ���������������
    XRect rc = m_rcClient;
    rc.left     += m_rcTextPadding.left;
    rc.right    -= m_rcTextPadding.right;
    rc.top      += m_rcTextPadding.top;
    rc.bottom   -= m_rcTextPadding.bottom;

    if (!m_bShowHtml)
    {
        Rendering::X_DrawText(hDC, m_pWindow, rc, m_szText, m_bEnabled ? m_clrTextColor : m_clrDisabledTextColor,
            m_pWindow->GetFontByHash(m_szFontHash), m_uTextStyle);
    }
    else
    {
        Rendering::X_DrawHtmlText(hDC, m_pWindow, rc, m_szText, m_bEnabled ? m_clrTextColor : m_clrDisabledTextColor,
            m_rcLinks, m_szLinks, m_nLinks, m_uTextStyle);
    }
}

XString XText::GetLinkContent( int iIndex )
{
    if( iIndex >= 0 && iIndex < m_nLinks ) return m_szLinks[iIndex];
    return EmptyString;
}

CONTROLS_END_NAMESPACE