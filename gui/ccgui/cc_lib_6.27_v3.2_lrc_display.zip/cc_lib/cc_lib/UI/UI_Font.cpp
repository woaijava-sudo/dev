#include "stdafx.h"

#define DEFAULT_FONT_HASH (_T(""))

WINDOW_BEGIN_NAMESPACE
//////////////////////////////////////////////////////////////////////////
XString XWindow::MakeFontHash( LPCTSTR szName, int nSize, BOOL bBold /*= FALSE*/, BOOL bUnderline /*= FALSE*/, BOOL bItalic /*= FALSE */ )
{
    XString szHash;
    szHash.Format(_T("FN%s#%d%d%d%d$"), szName, nSize, bBold, bUnderline, bItalic);
    return szHash;
}

HFONT XWindow::GetFontByHash( XString& szHash ) const
{
    if (m_mapFonts.IsEmpty())
    {
        ASSERT(!"The font map is empty.");
        return NULL;
    }

    TFont* ppVoid = NULL;
    bool bFind = m_mapFonts.Lookup(szHash, ppVoid);
    if (bFind)
    {
        TFont*& pFont = ppVoid;
        ASSERT(pFont);
        return pFont->hFont;
    }

    return NULL;
}

TFont* XWindow::GetFontInfoByHash( XString& szHash ) const
{
    if (m_mapFonts.IsEmpty())
    {
        ASSERT(!"The font map is empty.");
        return NULL;
    }

    TFont* ppVoid = NULL;
    bool bFind = m_mapFonts.Lookup(szHash, ppVoid);
    if (bFind)
    {
        TFont*& pFont = ppVoid;
        ASSERT(pFont);
        return pFont;
    }

    return NULL;
}

BOOL XWindow::SetDefaultFont( LPCTSTR szName, int nSize, BOOL bBold /*= FALSE*/, BOOL bUnderline /*= FALSE*/, BOOL bItalic /*= FALSE */ )
{
    ASSERT(szName);
    ASSERT(IsValidString(szName));
    ASSERT(nSize > 0);

    LOGFONT lf = { 0 };
    ::GetObject(::GetStockObject(DEFAULT_GUI_FONT), sizeof(LOGFONT), &lf);
    _tcscpy_s(lf.lfFaceName, LF_FACESIZE, szName);
    lf.lfCharSet = DEFAULT_CHARSET;
    lf.lfHeight = -nSize;
    if( bBold ) lf.lfWeight += FW_BOLD;
    if( bUnderline ) lf.lfUnderline = TRUE;
    if( bItalic ) lf.lfItalic = TRUE;
    HFONT hFont = ::CreateFontIndirect(&lf);
    if( hFont == NULL ) return FALSE;

    TFont* ppVoid = NULL;
    bool bFind = m_mapFonts.Lookup(XString(DEFAULT_FONT_HASH), ppVoid);

    TFont* pFont = NULL;

    if (bFind)
    {
        pFont = static_cast<TFont*>(ppVoid);
        ASSERT(pFont);
        ::DeleteObject(pFont->hFont);
        pFont->hFont = hFont;
        pFont->lpszFontName[0] = szName;
        pFont->nSize = nSize;
        pFont->bBold = bBold;
        pFont->bUnderline = bUnderline;
        pFont->bItalic = bItalic;
    }
    else
    {
        // �½�
        pFont = new TFont;
        if( !pFont ) return FALSE;
        ::ZeroMemory(pFont, sizeof(TFont));
        pFont->hFont = hFont;
        pFont->lpszFontName = new XString(szName);
        pFont->nSize = nSize;
        pFont->bBold = bBold;
        pFont->bUnderline = bUnderline;
        pFont->bItalic = bItalic;
        m_mapFonts.Set(XString(DEFAULT_FONT_HASH), pFont);
    }

    ASSERT(m_hDC);
    ASSERT(pFont);

    HFONT hOldFont = (HFONT) ::SelectObject(m_hDC, hFont);
    ::GetTextMetrics(m_hDC, &pFont->tm);
    ::SelectObject(m_hDC, hOldFont);

    return TRUE;
}

BOOL XWindow::SetDefaultFont(TFont* pFont)
{
    ASSERT(pFont != NULL);
    if (pFont == NULL) return FALSE;
    return SetDefaultFont(pFont->lpszFontName->GetBuffer(0), pFont->nSize, pFont->bBold, pFont->bUnderline, pFont->bItalic);
}

TFont* XWindow::GetDefaultFontInfo() const
{
    if (m_mapFonts.IsEmpty())
    {
        ASSERT(!"���棺Ĭ������Ϊ��");
        return NULL;
    }

    TFont* ppVoid = NULL;
    bool bFind = m_mapFonts.Lookup(XString(DEFAULT_FONT_HASH), ppVoid);
    if (!bFind)
    {
        ASSERT(!"���棺Ĭ������Ϊ��");
        return NULL;
    }

    return static_cast<TFont*>(ppVoid);
}

BOOL XWindow::AddFont( LPCTSTR szName, int nSize, BOOL bBold /*= FALSE*/, BOOL bUnderline /*= FALSE*/, BOOL bItalic /*= FALSE */ )
{
    ASSERT(szName);
    ASSERT(IsValidString(szName));
    ASSERT(nSize > 0);
    XString szHash = MakeFontHash(szName, nSize, bBold, bUnderline, bItalic);
    TFont* ppVoid = NULL;
    bool bFind = m_mapFonts.Lookup(szHash, ppVoid);
    if (bFind)
    {
        return FALSE;
    }

    LOGFONT lf = { 0 };
    ::GetObject(::GetStockObject(DEFAULT_GUI_FONT), sizeof(LOGFONT), &lf);
    _tcscpy_s(lf.lfFaceName, LF_FACESIZE, szName);
    lf.lfCharSet = DEFAULT_CHARSET;
    lf.lfHeight = -nSize;
    if( bBold ) lf.lfWeight += FW_BOLD;
    if( bUnderline ) lf.lfUnderline = TRUE;
    if( bItalic ) lf.lfItalic = TRUE;
    HFONT hFont = ::CreateFontIndirect(&lf);
    if( hFont == NULL ) return NULL;

    TFont* pFont = new TFont;
    if( !pFont ) return FALSE;
    ::ZeroMemory(pFont, sizeof(TFont));
    pFont->hFont = hFont;
    pFont->lpszFontName = new XString(szName);
    pFont->nSize = nSize;
    pFont->bBold = bBold;
    pFont->bUnderline = bUnderline;
    pFont->bItalic = bItalic;
    ::GetTextMetrics(m_hDC, &pFont->tm);

    m_mapFonts.Set(szHash, pFont);

    return TRUE;
}

BOOL XWindow::AddFontLink( LPCTSTR szLink, LPCTSTR szName, int nSize, BOOL bBold /*= FALSE*/, BOOL bUnderline /*= FALSE*/, BOOL bItalic /*= FALSE */ )
{
    if (!AddFont(szName, nSize, bBold, bUnderline, bItalic))
    {
        // ����������Ѿ�������ֱ�ӷ���
        m_mapFontLinks.Set(szLink, GetFontInfoByHash(MakeFontHash(szName, nSize, bBold, bUnderline, bItalic)));
        return FALSE;
    }

    // ���򴴽������²���
    m_mapFontLinks.Set(szLink, GetFontInfo(szName, nSize, bBold, bUnderline, bItalic));
    return TRUE;
}

HFONT XWindow::GetFont( LPCTSTR szName, int nSize, BOOL bBold /*= FALSE*/, BOOL bUnderline /*= FALSE*/, BOOL bItalic /*= FALSE*/ )
{
    if (!AddFont(szName, nSize, bBold, bUnderline, bItalic))
    {
        // ����������Ѿ�������ֱ�ӷ���
        return GetFontByHash(MakeFontHash(szName, nSize, bBold, bUnderline, bItalic));
    }

    // ���򴴽������²���
    return GetFont(szName, nSize, bBold, bUnderline, bItalic);
}

TFont* XWindow::GetFontInfo( LPCTSTR szName, int nSize, BOOL bBold /*= FALSE*/, BOOL bUnderline /*= FALSE*/, BOOL bItalic /*= FALSE*/ )
{
    if (!AddFont(szName, nSize, bBold, bUnderline, bItalic))
    {
        // ����������Ѿ�������ֱ�ӷ���
        return GetFontInfoByHash(MakeFontHash(szName, nSize, bBold, bUnderline, bItalic));
    }

    // ���򴴽������²���
    return GetFontInfo(szName, nSize, bBold, bUnderline, bItalic);
}

TFont* XWindow::GetFontLink( LPCTSTR szLink )
{
    if (m_mapFontLinks.IsEmpty())
    {
        return NULL;
    }

    XString szHash;
    TFont* ppVoid = NULL;
    bool bFind = m_mapFonts.Lookup(szHash, ppVoid);
    if (!bFind)
    {
        // û���ҵ�
        return NULL;
    }

    ASSERT(ppVoid);

    return static_cast<TFont*>(ppVoid);
}

BOOL XWindow::RemoveFont( XString& szHash )
{
    if (szHash.IsEmpty())
    {
        return FALSE;
    }

    if (m_mapFonts.IsEmpty())
    {
        return FALSE;
    }

    TFont* ppVoid = NULL;
    bool bFind = m_mapFonts.Lookup(szHash, ppVoid);
    if (!bFind)
    {
        // û���ҵ�
        return FALSE;
    }

    ASSERT(ppVoid);

    delete ppVoid;
    ppVoid = NULL;

    m_mapFonts.Remove(szHash);

    return TRUE;
}

void XWindow::RemoveAllFonts()
{
    if (m_mapFonts.IsEmpty())
    {
        return;
    }

    auto enumerator = m_mapFonts.Wrap().CreateEnumerator();
    while (enumerator->Next())
    {
        delete enumerator->Current()._V;
    }
    delete enumerator;

    m_mapFonts.Clear();
    m_mapFontLinks.Clear();
}

int XWindow::GetFontCount() const
{
    return m_mapFonts.Count();
}

WINDOW_END_NAMESPACE