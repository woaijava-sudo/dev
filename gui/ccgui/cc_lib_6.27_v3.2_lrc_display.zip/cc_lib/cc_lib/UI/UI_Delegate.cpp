#include "stdafx.h"

UI_BEGIN_NAMESPACE
XDelegateBase::XDelegateBase( void* pObject, XFunVoid pFn, LPARAM lParam /*= NULL*/, WPARAM wParam /*= NULL*/ )
{
    m_pObject               = pObject;
    m_unionFnType.pFunVoid  = pFn;
    m_iEventType            = WM_NULL;
    m_lParam                = lParam;
    m_wParam                = wParam;
    m_sNotifyTypeName.Empty();
}

XDelegateBase::XDelegateBase( void* pObject, XFunTEvent pFn, UINT _iEventType /*= EVENT__ALL*/, LPARAM lParam /*= NULL*/, WPARAM wParam /*= NULL*/ )
{
    m_pObject                   = pObject;
    m_unionFnType.pFunTEvent    = pFn;
    m_iEventType                = _iEventType;
    m_lParam                    = lParam;
    m_wParam                    = wParam;
    m_sNotifyTypeName.Empty();
}

XDelegateBase::XDelegateBase( void* pObject, XFunTAsyncNotify pFn, LPCTSTR _sNotifyTypeName /*= NULL*/, LPARAM lParam /*= NULL*/, WPARAM wParam /*= NULL*/ )
{
    m_pObject                   = pObject;
    m_unionFnType.pFunTAsyncNotify = pFn;
    m_iEventType                = WM_NULL;
    m_lParam                    = lParam;
    m_wParam                    = wParam;
    if(NULL != _sNotifyTypeName)
        m_sNotifyTypeName = _sNotifyTypeName;
}

XDelegateBase::XDelegateBase( void* pObject, XFunTSyncNotify pFn, LPCTSTR _sNotifyTypeName /*= NULL*/, LPARAM lParam /*= NULL*/, WPARAM wParam /*= NULL*/ )
{
    m_pObject                   = pObject;
    m_unionFnType.pFunTSyncNotify = pFn;
    m_iEventType                = WM_NULL;
    m_lParam                    = lParam;
    m_wParam                    = wParam;
    if(NULL != _sNotifyTypeName)
        m_sNotifyTypeName = _sNotifyTypeName;
}

XDelegateBase::XDelegateBase( const XDelegateBase& rhs )
{
    m_pObject               = rhs.m_pObject;
    m_unionFnType.pFunVoid  = rhs.m_unionFnType.pFunVoid;
    m_iEventType            = rhs.m_iEventType;
    m_lParam                = rhs.m_lParam;
    m_wParam                = rhs.m_wParam;
    m_sNotifyTypeName       = rhs.m_sNotifyTypeName;
}

XDelegateBase::~XDelegateBase()
{
    if(!m_sNotifyTypeName.IsEmpty())
        m_sNotifyTypeName.Empty();
}

bool XDelegateBase::Equals(const XDelegateBase& rhs) const 
{
    return m_pObject == rhs.m_pObject && m_unionFnType.pFunVoid    == rhs.m_unionFnType.pFunVoid && m_iEventType == rhs.m_iEventType && m_sNotifyTypeName == rhs.m_sNotifyTypeName; 
}

XEventSource::XEventSource()
{
    m_aDelegates.Clear();
}

XEventSource::~XEventSource()
{
    for( int i = 0; i < m_aDelegates.GetSize(); i++ ) {
        XDelegateBase* pObject = static_cast<XDelegateBase*>(m_aDelegates.Get(i));
        if( pObject) delete pObject;
        pObject = NULL;
    }
}

XEventSource::operator bool()
{
    return m_aDelegates.GetSize() > 0;
}

void XEventSource::operator+= (const XDelegateBase& d)
{ 
    for( int i = 0; i < m_aDelegates.GetSize(); i++ ) {
        XDelegateBase* pObject = static_cast<XDelegateBase*>(m_aDelegates.Get(i));
        if( pObject && pObject->Equals(d) ) return;
    }

    m_aDelegates.Add(d.Copy());
}

void XEventSource::operator+= (XFunVoid pFunVoid)
{ 
    (*this) += MakeDelegate(pFunVoid);
}

void XEventSource::operator-= (const XDelegateBase& d) 
{
    for( int i = 0; i < m_aDelegates.GetSize(); i++ ) {
        XDelegateBase* pObject = static_cast<XDelegateBase*>(m_aDelegates.Get(i));
        if( pObject && pObject->Equals(d) ) {
            delete pObject;
            m_aDelegates.RemoveAt(i);
            return;
        }
    }
}
void XEventSource::operator-= (XFunVoid pFunVoid)
{ 
    (*this) -= MakeDelegate(pFunVoid);
}

bool XEventSource::operator() (void* param) 
{
    for( int i = 0; i < m_aDelegates.GetSize(); i++ ) {
        XDelegateBase* pObject = static_cast<XDelegateBase*>(m_aDelegates.Get(i));
        if( pObject && !pObject->Invoke(param, pObject->GetLParam(), pObject->GetWParam()) ) return false;
    }
    return true;
}

bool XEventSource::operator() (TEvent* pTEvent) 
{
    for( int i = 0; i < m_aDelegates.GetSize(); i++ ) {
        XDelegateBase* pObject = static_cast<XDelegateBase*>(m_aDelegates.Get(i));
        if( pObject && !pObject->Invoke(pTEvent, pObject->GetLParam(), pObject->GetWParam()) ) return false;
    }
    return true;
}

bool XEventSource::operator() (TAsyncNotify* pTNotify) 
{
    for( int i = 0; i < m_aDelegates.GetSize(); i++ ) {
        XDelegateBase* pObject = static_cast<XDelegateBase*>(m_aDelegates.Get(i));

        if( pObject && !pObject->Invoke(pTNotify, pObject->GetLParam(), pObject->GetWParam()) ) return false;
    }
    return true;
}

bool XEventSource::operator() (TSyncNotify* pTNotify) 
{
    for( int i = 0; i < m_aDelegates.GetSize(); i++ ) {
        XDelegateBase* pObject = static_cast<XDelegateBase*>(m_aDelegates.Get(i));

        if( pObject && !pObject->Invoke(pTNotify, pObject->GetLParam(), pObject->GetWParam()) ) return false;
    }
    return true;
}

//////////////////////////////////////////////////////////////////////////

XString XDelegateBase::GetNotifyTypeName()
{
    return m_sNotifyTypeName;
}

UINT XDelegateBase::GetEventType()
{
    return m_iEventType;
}

void XDelegateBase::SetNotifyTypeName( XString& _sNotifyTypeName )
{
    m_sNotifyTypeName = _sNotifyTypeName;
}

void XDelegateBase::SetEventType( UINT _iEventType )
{
    m_iEventType = _iEventType;
}

bool XDelegateBase::operator()( TSyncNotify* pTNotify, LPCTSTR _sNotifyTypeName, LPARAM lParam /*= NULL*/,  WPARAM wParam /*= NULL*/ )
{
    return Invoke(pTNotify, lParam, wParam);
}

bool XDelegateBase::operator()( TAsyncNotify* pTNotify, LPCTSTR _sNotifyTypeName, LPARAM lParam /*= NULL*/,  WPARAM wParam /*= NULL*/ )
{
    return Invoke(pTNotify, lParam, wParam);
}

bool XDelegateBase::operator()( TEvent* pTEvent, UINT _iEventType, LPARAM lParam /*= NULL*/,  WPARAM wParam /*= NULL*/ )
{
    return Invoke(pTEvent, lParam, wParam);
}

bool XDelegateBase::operator()( void* param, LPARAM lParam /*= NULL*/,  WPARAM wParam /*= NULL*/ )
{
    return Invoke(param, lParam, wParam);
}

void* XDelegateBase::GetObj() const
{
    return m_pObject;
}

WPARAM XDelegateBase::GetWParam() const
{
    return m_wParam;
}

LPARAM XDelegateBase::GetLParam() const
{
    return m_lParam;
}

XFunTSyncNotify XDelegateBase::GetFunTSyncNotify() const
{
    return m_unionFnType.pFunTSyncNotify;
}

XFunTAsyncNotify XDelegateBase::GetFunTAsyncNotify() const
{
    return m_unionFnType.pFunTAsyncNotify;
}

XFunTEvent XDelegateBase::GetFunTEvent() const
{
    return m_unionFnType.pFunTEvent;
}

XFunVoid XDelegateBase::GetFunVoid() const
{
    return m_unionFnType.pFunVoid;
}

//////////////////////////////////////////////////////////////////////////


bool XDelegateStatic::Invoke( TSyncNotify* pTNotify, LPARAM lParam /*= NULL*/,  WPARAM wParam /*= NULL*/ )
{
    XFunTSyncNotify pFunTNotify = GetFunTSyncNotify();
    return pFunTNotify(pTNotify, lParam, wParam);
}

bool XDelegateStatic::Invoke( TAsyncNotify* pTNotify, LPARAM lParam /*= NULL*/,  WPARAM wParam /*= NULL*/ )
{
    XFunTAsyncNotify pFunTNotify = GetFunTAsyncNotify();
    return pFunTNotify(pTNotify, lParam, wParam);
}

bool XDelegateStatic::Invoke( TEvent* pTEvent, LPARAM lParam /*= NULL*/,  WPARAM wParam /*= NULL*/ )
{
    XFunTEvent pFunTEvent = GetFunTEvent();
    return !pFunTEvent(pTEvent, lParam, wParam);
}

bool XDelegateStatic::Invoke( void* param, LPARAM lParam /*= NULL*/,  WPARAM wParam /*= NULL*/ )
{
    XFunVoid pFunVoid = GetFunVoid();
    return pFunVoid(param, lParam, wParam);
}

XDelegateBase* XDelegateStatic::Copy() const
{
    return new XDelegateStatic(*this);
}

XDelegateStatic::XDelegateStatic( const XDelegateStatic& rhs ) : XDelegateBase(rhs)
{

}

XDelegateStatic::XDelegateStatic( XFunTSyncNotify pFunTNotify, LPCTSTR _sNotifyTypeName /*= NULL*/,  LPARAM lParam /*= NULL*/,  WPARAM wParam /*= NULL*/ ) : XDelegateBase(NULL, pFunTNotify, _sNotifyTypeName, lParam, wParam)
{

}

XDelegateStatic::XDelegateStatic( XFunTAsyncNotify pFunTNotify, LPCTSTR _sNotifyTypeName /*= NULL*/,  LPARAM lParam /*= NULL*/,  WPARAM wParam /*= NULL*/ ) : XDelegateBase(NULL, pFunTNotify, _sNotifyTypeName, lParam, wParam)
{

}

XDelegateStatic::XDelegateStatic( XFunTEvent pFunTEvent, UINT _iEventType /*= 0*/,  LPARAM lParam /*= NULL*/,  WPARAM wParam /*= NULL*/ ) : XDelegateBase(NULL, pFunTEvent, _iEventType, lParam, wParam)
{

}

XDelegateStatic::XDelegateStatic( XFunVoid pFunVoid, LPARAM lParam /*= NULL*/,  WPARAM wParam /*= NULL*/ ) : XDelegateBase(NULL, pFunVoid, lParam, wParam)
{

}
UI_END_NAMESPACE