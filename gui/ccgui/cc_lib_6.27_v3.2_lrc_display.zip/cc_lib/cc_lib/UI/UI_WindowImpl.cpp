#include "stdafx.h"

WINDOW_BEGIN_NAMESPACE
XWindowImpl::XWindowImpl(HWND hwnd /*= NULL*/): m_hWnd(hwnd) {}

HWND XWindowImpl::GetSafeHwnd() const
{
    return m_hWnd;
}

HWND XWindowImpl::Attach( HWND hwnd )
{
    HWND hwndOld = m_hWnd;
    m_hWnd = hwnd;
    return hwndOld;
}

int XWindowImpl::_GetClassName(LPTSTR lpClassName, int nMaxCount)
{
    ASSERT(_IsWindow());
    ASSERT(lpClassName);
    ASSERT(IsValidString(lpClassName));
    return ::GetClassName(m_hWnd, lpClassName, nMaxCount);
}

HICON XWindowImpl::_SetIcon(HICON hIcon, BOOL bBigIcon)
{
    ASSERT(_IsWindow());
    return (HICON)_SendMessage(WM_SETICON, bBigIcon, (LPARAM)hIcon);
}

HICON XWindowImpl::_GetIcon(BOOL bBigIcon) const
{
    ASSERT(_IsWindow());
    return (HICON)_SendMessage(WM_GETICON, bBigIcon, 0);
}

BOOL XWindowImpl::_SetProp(LPCTSTR lpString, HANDLE hData)
{
    ASSERT(_IsWindow());
    return ::SetProp(m_hWnd, lpString, hData);
}

HANDLE XWindowImpl::_GetProp(LPCTSTR lpString)
{
    ASSERT(_IsWindow());
    return ::GetProp(m_hWnd, lpString);
}

HANDLE XWindowImpl::_RemoveProp(LPCTSTR lpString)
{
    ASSERT(_IsWindow());
    return ::RemoveProp(m_hWnd, lpString);
}

int XWindowImpl::_EnumProps(PROPENUMPROC lpEnumFunc)
{
    ASSERT(_IsWindow());
    return ::EnumProps(m_hWnd, lpEnumFunc);
}

int XWindowImpl::_EnumPropsEx(PROPENUMPROCEX lpEnumFunc, LPARAM lParam)
{
    ASSERT(_IsWindow());
    return ::EnumPropsEx(m_hWnd, lpEnumFunc, lParam);
}

BOOL XWindowImpl::_ShowWindow( int nCmdShow )
{
    ASSERT(_IsWindow());
    return ::ShowWindow(m_hWnd, nCmdShow);
}

BOOL XWindowImpl::_MoveWindow( int X, int Y, int nWidth, int nHeight, BOOL bRepaint )
{
    ASSERT(_IsWindow());
    return ::MoveWindow(m_hWnd, X, Y, nWidth, nHeight, bRepaint);
}

BOOL XWindowImpl::_EnableWindow( BOOL bEnable )
{
    ASSERT(m_hWnd);
    return ::EnableWindow(m_hWnd, bEnable);
}

BOOL XWindowImpl::_CloseWindow()
{
    ASSERT(_IsWindow());
    return ::CloseWindow(m_hWnd);
}

BOOL XWindowImpl::_CenterWindow()
{
    ASSERT(_IsWindow());
    ASSERT((_GetWindowStyle() & WS_CHILD) == 0);
    XRect rcDlg;
    _GetWindowRect(rcDlg);
    XRect rcArea;
    XRect rcCenter;
    HWND hWndParent = _GetParent();
    HWND hWndCenter = _GetWindowOwner();
    ::SystemParametersInfo(SPI_GETWORKAREA, NULL, &rcArea, NULL);
    if( hWndCenter == NULL ) rcCenter = rcArea; else ::GetWindowRect(hWndCenter, &rcCenter);

    int DlgWidth = rcDlg.Width();
    int DlgHeight = rcDlg.Height();

    // Find dialog's upper left based on rcCenter
    int xLeft = (rcCenter.left + rcCenter.right) / 2 - DlgWidth / 2;
    int yTop = (rcCenter.top + rcCenter.bottom) / 2 - DlgHeight / 2;

    // The dialog is outside the screen, move it inside
    if( xLeft < rcArea.left ) xLeft = rcArea.left;
    else if( xLeft + DlgWidth > rcArea.right ) xLeft = rcArea.right - DlgWidth;
    if( yTop < rcArea.top ) yTop = rcArea.top;
    else if( yTop + DlgHeight > rcArea.bottom ) yTop = rcArea.bottom - DlgHeight;
    return _SetWindowPos(NULL, xLeft, yTop, -1, -1, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
}

BOOL XWindowImpl::_UpdateWindow()
{
    ASSERT(m_hWnd);
    return ::UpdateWindow(m_hWnd);
}

BOOL XWindowImpl::_GetWindowRect( XRect& rc )
{
    ASSERT(m_hWnd);
    return ::GetWindowRect(m_hWnd, &rc);
}

BOOL XWindowImpl::_IsWindow() const
{
    ASSERT(m_hWnd);
    return ::IsWindow(m_hWnd);
}

BOOL XWindowImpl::_IsWindowVisible()
{
    ASSERT(m_hWnd);
    return ::IsWindowVisible(m_hWnd);
}

LONG_PTR XWindowImpl::_SetWindowLongPtr( int nIndex, LONG_PTR dwNewLong )
{
    ASSERT(m_hWnd);
    return ::SetWindowLongPtr(m_hWnd, nIndex, dwNewLong);
}

LONG XWindowImpl::_GetWindowLong( int nIndex )
{
    ASSERT(m_hWnd);
    return ::GetWindowLong(m_hWnd, nIndex);
}

LONG_PTR XWindowImpl::_GetWindowLongPtr( int nIndex )
{
    ASSERT(m_hWnd);
    return ::GetWindowLongPtr(m_hWnd, nIndex);
}

HWND XWindowImpl::_GetDlgItem( int nIDDlgItem )
{
    ASSERT(m_hWnd);
    return ::GetDlgItem(m_hWnd, nIDDlgItem);
}

LONG XWindowImpl::_GetWindowStyle()
{
    return _GetWindowLong(GWL_STYLE);
}

HWND XWindowImpl::_GetParent()
{
    ASSERT(m_hWnd);
    return ::GetParent(m_hWnd);
}

HWND XWindowImpl::_GetWindow( UINT nCmd )
{
    ASSERT(m_hWnd);
    return ::GetWindow(m_hWnd, nCmd);
}

HWND XWindowImpl::_GetWindowOwner()
{
    return GetWindow(m_hWnd, GW_OWNER);
}

HWND XWindowImpl::_SetFocus()
{
    ASSERT(m_hWnd);
    return ::SetFocus(m_hWnd);
}

HWND XWindowImpl::_GetFocus()
{
    return ::GetFocus();
}

BOOL XWindowImpl::_SetWindowPos( HWND hWndInsertAfter, int X, int Y, int cx, int cy, UINT uFlags )
{
    ASSERT(m_hWnd);
    return ::SetWindowPos(m_hWnd, hWndInsertAfter, X, Y, cx, cy, uFlags);
}

BOOL XWindowImpl::_GetUpdateRect( XRect& rc, BOOL bErase /*= FALSE*/ )
{
    ASSERT(m_hWnd);
    return ::GetUpdateRect(m_hWnd, &rc, bErase);
}

BOOL XWindowImpl::_GetCursorPos( LPPOINT lpPoint )
{
    ASSERT(m_hWnd && lpPoint);
    return ::GetCursorPos(lpPoint);
}

BOOL XWindowImpl::_ClientToScreen( LPPOINT lpPoint )
{
    ASSERT(m_hWnd && lpPoint);
    return ::ClientToScreen(m_hWnd, lpPoint);
}

BOOL XWindowImpl::_ScreenToClient( LPPOINT lpPoint )
{
    ASSERT(m_hWnd && lpPoint);
    return ::ScreenToClient(m_hWnd, lpPoint);
}

HDC XWindowImpl::_BeginPaint( PAINTSTRUCT& ps )
{
    ASSERT(m_hWnd);
    return ::BeginPaint(m_hWnd, &ps);
}

BOOL XWindowImpl::_EndPaint( PAINTSTRUCT& ps )
{
    ASSERT(m_hWnd);
    return ::EndPaint(m_hWnd, &ps);
}

HDC XWindowImpl::_GetDC()
{
    ASSERT(m_hWnd);
    return ::GetDC(m_hWnd);
}

int XWindowImpl::_ReleaseDC(HDC hDC)
{
    ASSERT(m_hWnd);
    return ::ReleaseDC(m_hWnd, hDC);
}

BOOL XWindowImpl::_InvalidateRect( XRect* pRect, BOOL bErase /*= FALSE*/ )
{
    ASSERT(m_hWnd);
    return ::InvalidateRect(m_hWnd, pRect, bErase);
}

BOOL XWindowImpl::_GetClientRect( XRect& rc )
{
    ASSERT(m_hWnd);
    return ::GetClientRect(m_hWnd, &rc);
}

void XWindowImpl::_SetWindowFont( HFONT hFont, BOOL bRedraw )
{
    _SendMessage(WM_SETFONT, (WPARAM)hFont, (LPARAM)bRedraw);
}

HFONT XWindowImpl::_GetWindowFont()
{
    return (HFONT) _SendMessage(WM_GETFONT, (WPARAM)0U, (LPARAM)0L);
}

BOOL XWindowImpl::_SetWindowText( LPCTSTR lpString )
{
    ASSERT(m_hWnd);
    ASSERT(lpString);
    return ::SetWindowText(m_hWnd, lpString);
}

int XWindowImpl::_GetWindowText( LPTSTR lpString, int nMaxCount )
{
    ASSERT(m_hWnd);
    ASSERT(lpString);
    ASSERT(nMaxCount > 0);
    return ::GetWindowText(m_hWnd, lpString, nMaxCount);
}

int XWindowImpl::_GetWindowTextLength()
{
    ASSERT(m_hWnd);
    return ::GetWindowTextLength(m_hWnd);
}

BOOL XWindowImpl::_CreateCaret( HBITMAP hBitmap, int nWidth, int nHeight )
{
    ASSERT(m_hWnd);
    return ::CreateCaret(m_hWnd, hBitmap, nWidth, nHeight);
}

BOOL XWindowImpl::_ShowCaret()
{
    ASSERT(m_hWnd);
    return ::ShowCaret(m_hWnd);
}

BOOL XWindowImpl::_HideCaret()
{
    ASSERT(m_hWnd);
    return ::HideCaret(m_hWnd);
}

BOOL XWindowImpl::_SetCaretPos( int X, int Y )
{
    ASSERT(m_hWnd);
    return ::SetCaretPos(X, Y);
}

int XWindowImpl::_MessageBox( LPCTSTR lpText, LPCTSTR lpCaption, UINT uType )
{
    ASSERT(m_hWnd);
    return ::MessageBox(m_hWnd, lpText, lpCaption, uType);
}

LRESULT XWindowImpl::_SendMessage( UINT uMsg, WPARAM wParam /*= 0U*/, LPARAM lParam /*= 0L*/ ) const
{
    ASSERT(m_hWnd);
    return ::SendMessage(m_hWnd, uMsg, wParam, lParam);
}

LRESULT XWindowImpl::_PostMessage( UINT uMsg, WPARAM wParam /*= 0U*/, LPARAM lParam /*= 0L*/ ) const
{
    ASSERT(m_hWnd);
    return ::PostMessage(m_hWnd, uMsg, wParam, lParam);
}

LRESULT XWindowImpl::_DefWindowProc(UINT Msg, WPARAM wParam, LPARAM lParam)
{
    ASSERT(m_hWnd);
    return ::DefWindowProc(m_hWnd, Msg, wParam, lParam);
}

LRESULT XWindowImpl::_CallWindowProc(WNDPROC lpPrevWndFunc, UINT Msg, WPARAM wParam, LPARAM lParam)
{
    ASSERT(m_hWnd);
    return ::CallWindowProc(lpPrevWndFunc, m_hWnd, Msg, wParam, lParam);
}

WINDOW_END_NAMESPACE