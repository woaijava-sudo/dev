#include "stdafx.h"

#ifndef LOWORD
#define LOWORD(l)           ((WORD)(((DWORD_PTR)(l)) & 0xffff))
#endif
#ifndef HIWORD
#define HIWORD(l)           ((WORD)((((DWORD_PTR)(l)) >> 16) & 0xffff))
#endif

WINDOW_BEGIN_NAMESPACE
BOOL XWindow::MessageHandler( UINT uMsg, WPARAM wParam, LPARAM lParam, LRESULT* lRes )
{
    if( m_hWnd == NULL ) return FALSE;

    // ע�⣬���������Ϣ���������У�Ӧ����m_msgT
    m_msgT.hwnd = m_hWnd;
    m_msgT.message = uMsg;
    m_msgT.lParam = lParam;
    m_msgT.wParam = wParam;

    ExecSyncNotify();
    ExecAsyncNotify();

    // Cycle through listeners
    for( int i = 0; i < m_MessageFilters.GetSize(); i++ ) 
    {
        BOOL bHandled = false;
        LRESULT lResult = static_cast<IXMessageFilter*>(m_MessageFilters[i])->MessageFilter(uMsg, wParam, lParam, &bHandled);
        if( bHandled ) {
            *lRes = lResult;
            return TRUE;
        }
    }

    BOOL bRet = FALSE;
    // Custom handling of events
    switch( uMsg ) {
    case WM_CREATE:             bRet = OnCreate(); break;
    case WM_CLOSE:              bRet = OnClose(); break;
    case WM_ERASEBKGND:         bRet = TRUE; *lRes = 1; break;
    case WM_PAINT:              bRet = OnPaint();  break;
    case WM_PRINTCLIENT:        bRet = OnPaintClient();  break;
    case WM_GETMINMAXINFO:      bRet = OnGetMinMaxInfo();  break;
    case WM_SIZE:               bRet = OnSize(); break;
    case WM_TIMER:              bRet = OnTimer(); break;
    case WM_MOUSEHOVER:         bRet = OnMouseHover(); break;
    case WM_MOUSELEAVE:         bRet = OnMouseLeave(); break;
    case WM_MOUSEMOVE:          bRet = OnMouseMove();  break;
    case WM_LBUTTONDOWN:        bRet = OnLButtonDown();  break;
    case WM_LBUTTONDBLCLK:
        break;
    case WM_LBUTTONUP:          bRet = OnLButtonUp();  break;
    case WM_RBUTTONDOWN:
        break;
    case WM_CONTEXTMENU:
        break;
    case WM_MOUSEWHEEL:         bRet = OnMouseWheel(); break;
    case WM_CHAR:               bRet = OnChar(); break;
    case WM_KEYDOWN:            bRet = OnKeyDown(); break;
    case WM_KEYUP:              bRet = OnKeyUp(); break;
    case WM_SETCURSOR:          bRet = OnSetCursor(); break;
    case WM_VSCROLL:            bRet = OnVScroll(); break;
    case WM_EFFECT:             bRet = OnEffect(); break;
    case WM_NOTIFY:
        {
            LPNMHDR lpNMHDR = (LPNMHDR) lParam;
            if( lpNMHDR != NULL ) *lRes = ::SendMessage((HWND) lParam, OCM__BASE + uMsg, wParam, lParam);
            bRet = TRUE;
        }
        break;
    case WM_COMMAND:
    case WM_CTLCOLORMSGBOX:
    case WM_CTLCOLOREDIT:
    case WM_CTLCOLORLISTBOX:
    case WM_CTLCOLORBTN:
    case WM_CTLCOLORDLG:
    case WM_CTLCOLORSCROLLBAR:
    case WM_CTLCOLORSTATIC:
        {
            if( lParam == 0 ) break;
            *lRes = ::SendMessage((HWND) lParam, OCM__BASE + uMsg, wParam, lParam);
            bRet = TRUE;
        }
        break;
    case WM_MEASUREITEM:
        {
            if( wParam == 0 ) break;
            HWND hWndChild = _GetDlgItem(((LPMEASUREITEMSTRUCT) lParam)->CtlID);
            *lRes = ::SendMessage(hWndChild, OCM__BASE + uMsg, wParam, lParam);
            bRet = TRUE;
        }
        break;
    case WM_DRAWITEM:
        {
            if( wParam == 0 ) break;
            HWND hWndChild = ((LPDRAWITEMSTRUCT) lParam)->hwndItem;
            *lRes = ::SendMessage(hWndChild, OCM__BASE + uMsg, wParam, lParam);
            bRet = TRUE;
        }
        break;
    default:
        break;
    }

    if (bRet)
    {
        return TRUE;
    }

    ExecSyncNotify();
    ExecAsyncNotify();

    return FALSE;
}

BOOL XWindow::PreMessageHandler( UINT uMsg, WPARAM wParam, LPARAM lParam, LRESULT* lRes )
{
    for( int i = 0; i < m_preMessageFilters.GetSize(); i++ ) 
    {
        BOOL bHandled = FALSE;
        LRESULT lResult = static_cast<IXMessageFilter*>(m_MessageFilters[i])->MessageFilter(uMsg, wParam, lParam, &bHandled);
        if( bHandled )
        {
            return TRUE;
        }
    }

    BOOL bRet = FALSE;
    switch( uMsg )
    {
    case WM_KEYDOWN:
        if (wParam == VK_ESCAPE)
        {
            _SendMessage(WM_CLOSE);
            return TRUE;
        }
        bRet = FALSE; break;
    case WM_SYSCHAR:            bRet = FALSE; break;
    case WM_SYSKEYDOWN:         bRet = OnSysKeyDown(); break;
    }
    return bRet;
}

BOOL XWindow::OnCreate()
{
    // ��������DC��BITMAP
    AddNotifier(this);
    XRect rcClient;
    _GetClientRect(rcClient);
    m_hDC = ::GetDC(m_hWnd);
    m_hDcOffscreen = _CreateCompatibleDC();
    m_hBmpOffscreen = _CreateCompatibleBitmap(rcClient.Width(), rcClient.Height()); 
    ASSERT(m_hDcOffscreen);
    ASSERT(m_hBmpOffscreen);
    SendAsyncNotify(NULL, WM_CREATE);
    ::SetCursor(::LoadCursor(NULL, MAKEINTRESOURCE(IDC_ARROW)));
    return TRUE;
}

BOOL XWindow::OnPaint()
{
    // Should we paint?
    XRect rcPaint;
    if( !_GetUpdateRect(rcPaint, FALSE) ) return TRUE;
    if( m_pRoot == NULL ) 
    {
        PAINTSTRUCT ps = { 0 };
        _BeginPaint(ps);
#ifdef _DEBUG
        RECT& rc = ps.rcPaint;
        TRACE("[%s - 0x%X] ==> Paint ==> [HDC: 0x%X] (L: %d T: %d R: %d B: %d) (Null)",
            GetClass()->m_lpszClassName, this, ps.hdc, rc.left, rc.top, rc.right, rc.bottom);
#endif // _DEBUG

        _EndPaint(ps);
        return TRUE;
    }

    // Draw the layout and its child container

    // Do we need to resize anything?
    // This is the time where we layout the controls on the form.
    // We delay this even from the WM_SIZE messages since resizing can be
    // a very expensize operation.
    if( m_bNeedUpdate ) {
        m_bNeedUpdate = FALSE;
        XRect rcClient;
        _GetClientRect(rcClient);
        m_pRoot->SetRect(rcClient); // root ������������
        if( !rcClient.IsRectEmpty() )
        {
            if( m_pRoot->IsNeedUpdate() )
            {
                SAFE_DELETE_DC(m_hDcOffscreen);
                SAFE_DELETE_DC(m_hDcBackground);
                SAFE_DELETE_BITMAP(m_hBmpOffscreen);
                SAFE_DELETE_BITMAP(m_hBmpBackground);
            }
            else
            {
                // state = update => control => setrect
            }
            // We'll want to notify the window when it is first initialized
            // with the correct layout. The window form would take the time
            // to submit swipes/animations.
            if( m_bFirstInit )
            {
                m_bFirstInit = FALSE;
                SendAsyncNotify(m_pRoot, (DWORD)_T("WindowInit"), TRUE);
            }
        }
    }

    // ��Ⱦ
    if( m_anim.IsAnimating() || m_anim.IsTaskScheduled() )
    {
        _PostMessage(WM_EFFECT);
    }
    else
    {
        //
        // Render screen
        //
        // Prepare offscreen bitmap?
        if( m_hBmpOffscreen == NULL )
        {
            XRect rcClient;
            _GetClientRect(rcClient);
            m_hDcOffscreen = _CreateCompatibleDC();
            m_hBmpOffscreen = ::CreateCompatibleBitmap(m_hDC, rcClient.Width(), rcClient.Height()); 
            ASSERT(m_hDcOffscreen);
            ASSERT(m_hBmpOffscreen);
        }

        // Begin Windows paint
        PAINTSTRUCT ps = { 0 };
        _BeginPaint(ps);

#ifdef _DEBUG
        RECT& rc = ps.rcPaint;
        TRACE("['%s' - 0x%X] ==> Paint ==> [HDC: 0x%X] (L: %d T: %d R: %d B: %d)",
            GetClass()->m_lpszClassName, this, ps.hdc, rc.left, rc.top, rc.right, rc.bottom);
#endif // _DEBUG

        HBITMAP hOldBitmap = (HBITMAP) ::SelectObject(m_hDcOffscreen, m_hBmpOffscreen);
        int iSaveDC = ::SaveDC(m_hDcOffscreen);
        if( m_hBmpBackground == NULL )
        {
            XRect rcClient;
            _GetClientRect(rcClient);
            m_hDcBackground = _CreateCompatibleDC();
            m_hBmpBackground = _CreateCompatibleBitmap(rcClient.Width(), rcClient.Height()); 
            ASSERT(m_hDcBackground);
            ASSERT(m_hBmpBackground);
            ::SelectObject(m_hDcBackground, m_hBmpBackground);
            ::BitBlt(m_hDcBackground, ps.rcPaint.left, ps.rcPaint.top, ps.rcPaint.right - ps.rcPaint.left,
                ps.rcPaint.bottom - ps.rcPaint.top, ps.hdc, ps.rcPaint.left, ps.rcPaint.top, SRCCOPY);
        }
        else
        {
            ::SelectObject(m_hDcBackground, m_hBmpBackground);
        }

        ::BitBlt(m_hDcOffscreen, ps.rcPaint.left, ps.rcPaint.top, ps.rcPaint.right - ps.rcPaint.left,
            ps.rcPaint.bottom - ps.rcPaint.top, m_hDcBackground, ps.rcPaint.left, ps.rcPaint.top, SRCCOPY);

        // ���ڿ�ʼ��ͼ
        if (!m_mapFonts.IsEmpty()) // �������δ��ʼ���򲻻滭
        {
            m_pRoot->Paint(m_hDcOffscreen, ps.rcPaint);

            for( int i = 0; i < m_PostPaintCtrls.GetSize(); i++ )
            {
                XControl* pPostPaintControl = m_PostPaintCtrls[i];
                pPostPaintControl->PostPaint(m_hDcOffscreen, XRect(ps.rcPaint));
            }
        }

        ::RestoreDC(m_hDcOffscreen, iSaveDC);
        ::BitBlt(ps.hdc, ps.rcPaint.left, ps.rcPaint.top, ps.rcPaint.right - ps.rcPaint.left,
            ps.rcPaint.bottom - ps.rcPaint.top, m_hDcOffscreen, ps.rcPaint.left, ps.rcPaint.top, SRCCOPY);
        ::SelectObject(m_hDcOffscreen, hOldBitmap);

        // All Done!
        _EndPaint(ps);
    }

    if( m_bNeedUpdate )
    {
        _InvalidateRect(NULL, FALSE);
    }

    return TRUE;
}

x_msg_call BOOL XWindow::OnMouseMove()
{
    if( !m_bMouseTracking ) {
        TRACKMOUSEEVENT tme = { 0 };
        tme.cbSize = sizeof(TRACKMOUSEEVENT);
        tme.dwFlags = TME_HOVER | TME_LEAVE;
        tme.hwndTrack = m_hWnd;
        tme.dwHoverTime = 1000UL; // one second
        TrackMouseEvent(&tme);
        m_bMouseTracking = TRUE;
    }

    XControl* pNewHover = FindControl(m_ptMousePos);
    do
    {
        if( pNewHover != NULL && pNewHover->GetOwner() != this )
        {
            break; // �ؼ�������������
        }

        if ( m_msgT.lParam == -1 ) // Mouse Leave
        {
            if (pNewHover != NULL)
            {
                PostEventT(pNewHover, WM_MOUSELEAVE);
            }
            if (m_pEventHover != NULL)
            {
                PostEventT(m_pEventHover, WM_MOUSELEAVE);
                m_pEventHover = NULL;
            }
            break;
        }

        if( pNewHover != m_pEventHover )
        {
            if (m_pEventHover != NULL)
            {
                PostEventT(m_pEventHover, WM_MOUSELEAVE);
                m_pEventHover = NULL;
            }
            else if (pNewHover != NULL)
            {
                PostEventT(pNewHover, WM_MOUSEENTER);
                m_pEventHover = pNewHover;
            }
        }

        if( m_pEventClick != NULL )
        {
            PostEventT(m_pEventClick, WM_MOUSEMOVE);
        }
        else if( pNewHover != NULL )
        {
            PostEventT(pNewHover, WM_MOUSEMOVE);
        }

        break;
    } while (0);

    return FALSE;
}

x_msg_call BOOL XWindow::OnGetMinMaxInfo()
{
    LPMINMAXINFO lpMMI = (LPMINMAXINFO) m_msgT.lParam;

    if( m_szMin.cx > 0 ) lpMMI->ptMinTrackSize.x = m_szMin.cx;
    if( m_szMin.cy > 0 ) lpMMI->ptMinTrackSize.y = m_szMin.cy;
    if( m_szMax.cx > 0 ) lpMMI->ptMaxTrackSize.x = m_szMax.cx;
    if( m_szMax.cy > 0 ) lpMMI->ptMaxTrackSize.y = m_szMax.cy;

    return FALSE;
}

x_msg_call BOOL XWindow::OnSize()
{
    if( m_pFocus != NULL ) PostEventT(m_pFocus, WM_SIZE);
    if( m_pRoot != NULL )
    {
        // ���¼���λ��
        PostEventT(m_pRoot, WM_SIZE);
        m_pRoot->NeedUpdate();
    }
    if( m_anim.IsAnimating() ) m_anim.CancelTasks();
    return TRUE;
}

x_msg_call BOOL XWindow::OnLButtonDown()
{
    _SetFocus();
    do
    {
        if (!m_pRoot)
        {
            break;
        }

        XControl* pControl = FindControl(m_ptMousePos);

        if( pControl == NULL ) break;
        if( pControl->GetOwner() != this ) break;

        pControl->SetFocus();

        m_pEventClick = pControl;

        // ������Ϣ
        PostEventT(pControl);

        _SetCapture();

        break;
    } while (0);

    return FALSE;
}

x_msg_call BOOL XWindow::OnLButtonUp()
{
    do
    {
        if (!m_pRoot)
        {
            break;
        }

        if( m_pEventClick == NULL ) break;

        // ������Ϣ
        PostEventT(m_pEventClick);

        _ReleaseCapture();

        m_pEventClick = NULL;
        break;
    } while (0);

    return FALSE;
}

x_msg_call BOOL XWindow::OnMouseHover()
{
    m_bMouseTracking = FALSE;
    XControl* pHover = FindControl(m_ptMousePos);

    do
    {
        if( pHover == NULL ) break;
        // Generate mouse hover event
        if( m_pEventHover != NULL )
        {
            PostEventT(m_pEventHover, WM_MOUSEHOVER);
        }

        break;
    } while (0);

    return TRUE;
}

x_msg_call BOOL XWindow::OnMouseLeave()
{
    if( m_bMouseTracking ) _SendMessage(WM_MOUSEMOVE, 0, (LPARAM) -1);
    m_bMouseTracking = FALSE;
    return FALSE;
}

x_msg_call BOOL XWindow::OnSetCursor()
{
    do 
    {
        if( LOWORD(m_msgT.lParam) != HTCLIENT ) return FALSE;
        if( m_bMouseCapture ) break;
        XControl* pControl = FindControl(m_ptMousePos);
        if( pControl == NULL || ( (pControl->GetFlags() & XFLAG_SETCURSOR) == 0 ) )
        {
            // Ĭ�����
            ::SetCursor(::LoadCursor(NULL, MAKEINTRESOURCE(IDC_ARROW)));
            break;
        }
        PostEventT(pControl);
        break;
    } while (0);
    return TRUE;
}

x_msg_call BOOL XWindow::OnClose()
{
    // Make sure all matching "closing" events are sent
    if( m_pEventHover != NULL )
    {
        PostEventT(m_pEventHover, WM_MOUSELEAVE);
    }
    if( m_pEventClick != NULL )
    {
        PostEventT(m_pEventClick, WM_LBUTTONUP);
    }

    SetFocus(NULL);

    // Hmmph, the usual Windows tricks to avoid
    // focus loss...
    HWND hwndParent = _GetWindowOwner();
    if( hwndParent != NULL ) ::SetFocus(hwndParent);

    return FALSE;
}

x_msg_call BOOL XWindow::OnKeyUp()
{
    do 
    {
        if( m_pEventKey == NULL ) break;
        PostEventT(m_pEventKey);
        m_pEventKey = NULL;
        break;
    } while (0);
    return FALSE;
}

x_msg_call BOOL XWindow::OnKeyDown()
{
    do 
    {
        if( m_pFocus == NULL ) break;
        PostEventT(m_pFocus);
        m_pEventKey = m_pFocus;
        break;
    } while (0);

    return FALSE;
}

x_msg_call BOOL XWindow::OnChar()
{
    do 
    {
        if( m_pFocus == NULL ) break;
        PostEventT(m_pFocus);
        break;
    } while (0);
    return FALSE;
}

x_msg_call BOOL XWindow::OnTimer()
{
    for( int i = 0; i < m_Timers.GetSize(); i++ )
    {
        const XTIMERINFO* pTimer = static_cast<XTIMERINFO*>(m_Timers[i]);
        if( pTimer->hWnd == m_hWnd && pTimer->uWinTimer == LOWORD(m_msgT.wParam) && pTimer->bKilled == FALSE)
        {
            TEvent event = { 0 };
            event.sender = pTimer->sender;
            event.receiver = pTimer->sender;
            event.msg.hwnd = pTimer->hWnd;
            event.msg.message = WM_TIMER;
            event.msg.wParam = pTimer->nLocalID; // wParam Ϊ ID
            event.msg.lParam = pTimer->uElapse;  // lParam Ϊ Elapse
            PostEvent(event);
            break;
        }
    }
    return FALSE;
}

x_msg_call BOOL XWindow::OnSysKeyDown()
{
    if( m_pFocus != NULL ) PostEventT(m_pFocus);
    return FALSE;
}

x_msg_call BOOL XWindow::OnMouseWheel()
{
    do
    {
        if (m_pFocus == NULL) break;
        if( m_pFocus->GetOwner() != this ) break;
        int zDelta = (int) (short) HIWORD(m_msgT.wParam);
        // Simulate regular scrolling by sending scroll events
        int scrollPage = X_SCROLL_PAGE;
        if (m_pFocus->IsKindOf(X_CLASS(XContainer)))
        {
            scrollPage = GetIScroll(m_pFocus)->GetScrollPage();
        } else if (m_pFocus->GetParent() != NULL) {
            scrollPage = GetIScroll(m_pFocus->GetParent())->GetScrollPage();
        }
        XControl* pFocus = m_pFocus;
        for( int i = 0; i < abs(zDelta); i += scrollPage )
        {
            PostEventT(pFocus, 0, MAKELPARAM((zDelta < 0 ? SB_LINEDOWN : SB_LINEUP), 0));
        }
        m_pFocus = pFocus;
        // Let's make sure that the scroll item below the cursor is the same as before...
        _SendMessage(WM_MOUSEMOVE, 0, (LPARAM) MAKELPARAM(m_ptMousePos.x, m_ptMousePos.y));
    } while (0);
    return FALSE;
}

x_msg_call BOOL XWindow::OnPaintClient()
{
    XRect rcClient;
    _GetClientRect(rcClient);
    HDC hDC = (HDC) m_msgT.wParam;
    int save = ::SaveDC(hDC);
    m_pRoot->Paint(hDC, rcClient);
    // Check for traversing children. The crux is that WM_PRINT will assume
    // that the DC is positioned at frame coordinates and will paint the child
    // control at the wrong position. We'll simulate the entire thing instead.
    if( (m_msgT.lParam & PRF_CHILDREN) != 0 ) {
        HWND hWndChild = _GetWindow(GW_CHILD);
        while( hWndChild != NULL ) {
            XWindowImpl window;
            window.Attach(hWndChild);
            XRect rcPos;
            window._GetWindowRect(rcPos);
            ::MapWindowRect(HWND_DESKTOP, m_hWnd, &rcPos);
            ::SetWindowOrgEx(hDC, -rcPos.left, -rcPos.top, NULL);
            // NOTE: We use WM_PRINT here rather than the expected WM_PRINTCLIENT
            //       since the latter will not print the nonclient correctly for
            //       EDIT controls.
            window._SendMessage(WM_PRINT, m_msgT.wParam, m_msgT.lParam | PRF_NONCLIENT);
            hWndChild = window._GetWindow(GW_HWNDNEXT);
        }
    }
    ::RestoreDC(hDC, save);
    return FALSE;
}

x_msg_call BOOL XWindow::OnVScroll()
{
    do
    {
        HWND hwnd = (HWND) m_msgT.lParam;
        if( hwnd == NULL ) break;
        XWindowImpl window(hwnd);
        XControl* pContainer = Force_Control(window._GetProp(X_SCROLL_PROP));
        if( pContainer == NULL ) break;
        PostEventT(pContainer);
    } while (0);
    return FALSE;
}

x_msg_call BOOL XWindow::OnEffect()
{
    //
    // Render screen
    //
    if( m_anim.IsAnimating() ) {
        // 3D animation in progress
        m_anim.Render();
        // Do a minimum paint loop
        // Keep the client area invalid so we generate lots of
        // WM_PAINT messages. Cross fingers that Windows doesn't
        // batch these somehow in the future.
        PAINTSTRUCT ps = { 0 };
        _BeginPaint(ps);
        _EndPaint(ps);
        _InvalidateRect(NULL, FALSE);
    } else if( m_anim.IsTaskScheduled() ) {
        // Animation system needs to be initialized
        m_anim.Init(m_hWnd);
        // A 3D animation was scheduled; allow the render engine to
        // capture the window content and repaint some other time

        if( !m_anim.PrepareAnimation(m_hWnd) ) m_anim.CancelTasks();
        _InvalidateRect(NULL, FALSE);
    }

    return TRUE;
}

WINDOW_END_NAMESPACE