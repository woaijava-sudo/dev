#ifndef _CC_UI_MARKUP_H
#define _CC_UI_MARKUP_H

#pragma once

#include "UI_MarkupNode.h"

UI_BEGIN_NAMESPACE
class CL_API XMarkup
{
public:
    enum _XMLFILE_ENCODING
    {
        XMLFILE_ENCODING_UTF8 = 0x100,
        XMLFILE_ENCODING_UNICODE,
        XMLFILE_ENCODING_ASNI,
    };

    XMarkup( LPCTSTR pstrXML = NULL );
    ~XMarkup();

    bool LoadFromString( LPCTSTR pstrXml );
    bool LoadFromMem( LPBYTE pByte, DWORD dwSize, int encoding = XMLFILE_ENCODING_UTF8 );
    bool LoadFromFile( LPCTSTR pstrFilename, int encoding = XMLFILE_ENCODING_UTF8 );
    void Release();
    bool IsValid() const;
    BOOL IsNull() const; // has no xml string

    void SetPreserveWhitespace( bool bPreserve = true );
    XString GetLastErrorMessage() const;

    XMarkupNode GetRoot();

private:
    XML_ELEMENT* _GetReservedElement();

    bool _Load();
    bool _Parse();
    bool _Parse( LPTSTR& pstrText, ULONG iParent );
    bool _ParseData( LPTSTR& pstrText, LPTSTR& pstrDest, char cEnd );
    void _ParseMetaChar( LPTSTR& pstrText, LPTSTR& pstrDest );
    bool _ParseAttributes( LPTSTR& pstrText );
    bool _Failed( LPCTSTR pstrError, LPCTSTR pstrLocation = NULL );

    inline void _SkipWhitespace( LPTSTR& pstr ) const;
    inline void _SkipWhitespace( LPCTSTR& pstr ) const;
    inline void _SkipIdentifier( LPTSTR& pstr ) const;
    inline void _SkipIdentifier( LPCTSTR& pstr ) const;

private:
    XString             m_szXML;        // XML String Base
    XString             m_szXMLSaved;   // XML String Backup
    LPTSTR              m_pstrText; // Saved ptr
    List<XML_ELEMENT*>  m_aElements; // Transferred element array (XML_ELEMENT*)
    XString             m_szErrorMsg;
    XString             m_szErrorXML;
    bool                m_bPreserveWhitespace;
};

UI_END_NAMESPACE
#endif