#include "StdAfx.h"

CONTROLS_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS_WITH_PARA(XLabel, XControl)

//////////////////////////////////////////////////////////////////////////

XLabel::XLabel( XObject* pOb /*= NULL*/ ): XControl(pOb),
m_clrTextColor(XCOLOR_EDIT_TEXT_NORMAL),
m_clrDisabledTextColor(XCOLOR_EDIT_TEXT_DISABLED)
{

}

XLabel::~XLabel()
{

}

void* XLabel::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_LABEL: return this;
    case HI_TEXT_STYLE: return static_cast<ITextStyleImpl*>(this);
    }
    return XControl::GetInterface(hi);
}

void XLabel::PaintText( HDC hDC )
{
    ASSERT(hDC);
    ASSERT(m_pWindow);

    if( m_clrTextColor == 0 )
        m_clrTextColor = m_pWindow->m_clrDefaultFontColor;
    if( m_clrDisabledTextColor == 0 )
        m_clrDisabledTextColor = m_pWindow->m_clrDefaultDisabledColor;

    if( m_szText.IsEmpty() )
    {
#ifdef _DEBUG
        TRACE("[%s - 0x%X] waring: this control has not text string.", GetClass()->m_lpszClassName, this);
#endif // _DEBUG
        return;
    }

    XRect rc = m_rcClient;
    m_rcClient.InsetRect(m_rcClient);
     
    if (!m_bShowHtml)
    {
        Rendering::X_DrawText(hDC, m_pWindow, rc, m_szText, m_bEnabled ? m_clrTextColor : m_clrDisabledTextColor,
            m_pWindow->GetFontByHash(m_szFontHash), DT_SINGLELINE | m_uTextStyle);
    }
    else
    {
        int n = 1;
        Rendering::X_DrawHtmlText(hDC, m_pWindow, rc, m_szText, m_bEnabled ? m_clrTextColor : m_clrDisabledTextColor,
            &m_rcClient, &m_szText, n, DT_SINGLELINE | m_uTextStyle);
    }
}

void XLabel::SetTextPadding( XRect& rc )
{
    m_rcTextPadding = rc;
}

XRect XLabel::GetTextPadding() const
{
    return m_rcTextPadding;
}

void XLabel::SetTextColor( COLORREF clrColor )
{
    m_clrTextColor = clrColor;
}

COLORREF XLabel::GetTextColor() const
{
    return m_clrTextColor;
}

void XLabel::SetDisabledTextColor( COLORREF clrDisabledTextColor )
{
    m_clrDisabledTextColor = clrDisabledTextColor;
}

COLORREF XLabel::GetDisabledTextColor() const
{
    return m_clrDisabledTextColor;
}

void XLabel::Event( TEvent& event )
{
    switch (event.msg.message)
    {
    case WM_SETFOCUS:
        m_bFocused = TRUE;
        break;
    case WM_KILLFOCUS:
        m_bFocused = FALSE;
        break;
    case WM_MOUSEENTER:
        break;
    case WM_MOUSELEAVE:
        break;
    default:
        XControl::Event(event);
    }
}

XSize XLabel::EstimateSize( const XSize& )
{
    ASSERT_VALID(m_pWindow);
    return XSize(GetFixedWidth(), max(GetFixedHeight(), 4 + m_pWindow->GetFontInfoByHash(m_szFontHash)->tm.tmHeight));
}

CONTROLS_END_NAMESPACE