#ifndef _CC_UI_MACROS_H
#define _CC_UI_MACROS_H

#pragma once

#include "UI_Colors.h"

#define CLAMP(x,a,b) (__min(b,__max(a,x)))

#define XIsKindOf(RuntimeClass) IsKindOf(X_CLASS(RuntimeClass))

#define X_CreateControl(RuntimeClass, Window) XControl::CreateControl(X_CLASS(RuntimeClass), Window)
/************************************************************************/
/*      XWindow_CreateControl: used for container                       */
/************************************************************************/
#define XWindow_CreateControl(RuntimeClass) X_CreateControl(RuntimeClass, this)
#define XCreateControl(RuntimeClass) CreateControl(X_CLASS(RuntimeClass))

#define Safe_Delete_Object(Object) {if (Object) {X_DeleteObject(Object); }}
#define XDeleteControl(ptr) { if (ptr) { ptr->Unregister(); X_DeleteObject(ptr); } }

#endif