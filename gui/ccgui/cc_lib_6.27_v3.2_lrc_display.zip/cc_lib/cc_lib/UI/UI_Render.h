#ifndef _CC_UI_RENDER_H
#define _CC_UI_RENDER_H

#pragma once

#ifndef ARGB
#define ARGB(a,r,g,b) ( RGB(r,g,b) | (a) << 24 )
#endif // ARGB

#ifndef GetRGB
#define GetRGB(color) ( RGB(GetRValue(color), GetGValue(color), GetBValue(color)) )
#endif // ARGB

#ifndef GetAValue
#define GetAValue(a) (LOBYTE((a)>>24))
#endif // GetAValue

#define BitmapSizeImage(w, h, bit) (((w)*(bit)+31)/32*4*(h))
#define OneThird (1.0f / 3)

#define ASSERT_HDC(hdc) { ASSERT(hdc); ASSERT(::GetObjectType(hDC) == OBJ_DC || ::GetObjectType(hDC) == OBJ_MEMDC); }
#define X_FREE_IMAGE(img) { ASSERT(img); if(img->hBitmap)::DeleteObject(img->hBitmap);delete img; }

/************************************************************************/
/*   �궨����                                                           */
/************************************************************************/

//////////////////////////////////////////////////////////////////////////
// XDrawFrame
#define XDF_FRAME_NORMAL        0
#define XDF_FRAME_ROUND         0x00000001
#define XDF_FRAME_FOCUS         0x00000002

RENDERING_BEGIN_NAMESPACE

DEF_LIST_TEMPLATE1(COLORREF);
DEF_LIST_TEMPLATE1(int);

/************************************************************************/
/*   ��Щ��������ɫֵAlphaͨ����Ч                                      */
/************************************************************************/
void X_DrawColor( HDC hDC, const XRect& rc, COLORREF color );
void X_DrawColorEx( HDC hDC, const XRect& rc, COLORREF color ); // �˺�����X_DrawColor����
void X_DrawGradient( HDC hDC, const XRect& rc, COLORREF clrFirst, COLORREF clrSecond, bool bVertical, int nSteps );

/************************************************************************/
/*   ��Щ��������ɫֵAlphaͨ����Ч (Background��Ч)                     */
/************************************************************************/
int  X_DrawText( HDC hDC, XWindow* pWindow, XRect& rc, LPCTSTR pstrText, COLORREF color, HFONT hFont, UINT uStyle );
void X_DrawLine( HDC hDC, const XPoint& pt1, const XPoint& pt2, int iStyle, int cWidth, COLORREF color );
void X_DrawRectangle( HDC hDC, const XRect& rc, int iStyle, int cWidth, COLORREF clrBorder, COLORREF clrFill );
void X_DrawFrame( HDC hDC, const XRect& rc, int iStyle, int cWidth, COLORREF Light, COLORREF Dark, COLORREF Background, UINT uStyle );

/************************************************************************/
/*   �߼������ı�����                                                   */
/************************************************************************/
void X_DrawHtmlText( HDC hDC, XWindow* pWindow, XRect& rc, LPCTSTR pstrText, DWORD dwTextColor, XRect* pLinks,
    XString* sLinks, int& nLinkRects, UINT uStyle );

/************************************************************************/
/*   �����ؼ����ƺ���                                                   */
/************************************************************************/
void X_DrawButton( HDC hDC, XWindow* pWindow, const XRect& rc, LPCTSTR pstrText, const XRect& rcPadding, UINT uState, HFONT hFont, UINT uStyle );

/************************************************************************/
/*   ��������ı����Σ����ظ߶�                                         */
/************************************************************************/
int X_DrawTextCalcRect( XWindow* pWindow, XRect& rc, LPCTSTR pstrText, HFONT hFont, UINT uStyle );

/************************************************************************/
/*   ͼ��                                                               */
/************************************************************************/
void        X_RGBtoHSL(DWORD ARGB, float& H, float& S, float& L);
void        X_HSLtoRGB(DWORD& ARGB, float H, float S, float L);
DWORD       X_AdjustColor(DWORD dwColor, short H, short S, short L);
TImage*     X_LoadImage(LPCTSTR lpszImage, DWORD dwMask = 0);
BOOL        X_DrawImage(HDC hDC, XWindow* pWindow, const XRect& rc, const XRect& rcPaint, const XString& szImageName,
                XRect rcItem, XRect rcBmpPart, XRect rcCorner, DWORD dwMask, BYTE bFade,
                BOOL bHole, BOOL bTiledX, BOOL bTiledY, BOOL bNeedAlpha = FALSE );
void        X_DrawImage(HDC hDC, HBITMAP hBitmap, const XRect& rc, const XRect& rcPaint,
                const XRect& rcBmpPart, const XRect& rcCorners, BOOL alphaChannel, BYTE uFade = 255, 
                BOOL hole = FALSE, BOOL xtiled = FALSE, BOOL ytiled = FALSE);
BOOL        X_DrawImageString(HDC hDC, XWindow* pWindow, const XRect& rc, const XRect& rcPaint,
                LPCTSTR pstrImage, LPCTSTR pstrModify = NULL, BOOL bNeedAlpha = FALSE, BYTE bNewFade = 255);

RENDERING_END_NAMESPACE
#endif