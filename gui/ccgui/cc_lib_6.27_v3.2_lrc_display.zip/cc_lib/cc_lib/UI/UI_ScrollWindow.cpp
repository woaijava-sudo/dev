#include "stdafx.h"

WINDOW_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS(XScrollWindow, XCmdTarget)
//////////////////////////////////////////////////////////////////////////

XScrollWindow::XScrollWindow()
{
    m_lpszSuperClass = WC_SCROLLBAR;
    m_lpszWindowClass = _T("XScrollWindow");
}

XScrollWindow::~XScrollWindow()
{

}

void XScrollWindow::Init( XScroll* pOwner )
{
    ASSERT_VALID(pOwner);
    m_pOwner = pOwner;
    Create(m_pOwner->GetOwner()->GetSafeHwnd(), NULL, WS_CHILD | SBS_VERT, 0, pOwner->GetRect());
    ASSERT(_IsWindow());
    _SetProp(X_SCROLL_PROP, static_cast<HANDLE>(m_pOwner));
    _SetScrollPos(SB_CTL, 0, TRUE);
    _ShowWindow(SW_SHOWNOACTIVATE);
}

LRESULT XScrollWindow::HandleMessage( UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    LRESULT lRes = 0;
    BOOL bHandled = TRUE;

    switch (uMsg)
    {
    case WM_KEYDOWN:
    case WM_VSCROLL:
        bHandled = FALSE;
        break;
    case OCM_CTLCOLORSCROLLBAR:
        ::SetBkMode((HDC)wParam, TRANSPARENT);
        ASSERT_VALID(m_pOwner);
        if (m_pOwner->EnableScrollColor()) {
            if( GetBkBrush() == NULL ) {
                SetBkBrush(::CreateSolidBrush(m_pOwner->GetScrollColor()));
            }
        } else {
            if( GetBkBrush() != NULL ) {
                ::DeleteObject(GetBkBrush());
                SetBkBrush(NULL);
            }
        }
        return (LRESULT) GetBkBrush();
    default:
        bHandled = FALSE;
    }
    if ( !bHandled )
    {
        return XCmdTarget::HandleMessage(uMsg, wParam, lParam);
    }
    else
    {
        return lRes;
    }
}

void XScrollWindow::OnFinalMessage( HWND hWnd )
{
    if( GetBkBrush() != NULL ) ::DeleteObject(GetBkBrush());
    SetBkBrush(NULL);
    m_pOwner->SetChildWnd(NULL);
    Safe_Delete_Object(this);
}

BOOL XScrollWindow::_SetScrollPos( int nBar, int nPos, BOOL bRedraw )
{
    ASSERT(_IsWindow());
    return ::SetScrollPos(m_hWnd, nBar, nPos, bRedraw);
}

int XScrollWindow::_GetScrollPos( int nBar )
{
    ASSERT(_IsWindow());
    return ::GetScrollPos(m_hWnd, nBar);
}

int XScrollWindow::_SetScrollInfo( int nBar, LPCSCROLLINFO lpsi, BOOL redraw )
{
    ASSERT(_IsWindow());
    return ::SetScrollInfo(m_hWnd, nBar, lpsi, redraw);
}

BOOL XScrollWindow::_GetScrollInfo( int nBar, LPSCROLLINFO lpsi )
{
    ASSERT(_IsWindow());
    return ::GetScrollInfo(m_hWnd, nBar, lpsi);
}

BOOL XScrollWindow::_SetScrollRange( int nBar, int nMinPos, int nMaxPos, BOOL bRedraw )
{
    ASSERT(_IsWindow());
    return ::SetScrollRange(m_hWnd, nBar, nMinPos, nMaxPos, bRedraw);
}

BOOL XScrollWindow::_GetScrollRange( int nBar, LPINT lpMinPos, LPINT lpMaxPos )
{
    ASSERT(_IsWindow());
    return ::GetScrollRange(m_hWnd, nBar, lpMinPos, lpMaxPos);
}

BOOL XScrollWindow::_ShowScrollBar( int wBar, BOOL bShow )
{
    ASSERT(_IsWindow());
    return ::ShowScrollBar(m_hWnd, wBar, bShow);
}

BOOL XScrollWindow::_EnableScrollBar( UINT wSBflags, UINT wArrows )
{
    ASSERT(_IsWindow());
    return ::EnableScrollBar(m_hWnd, wSBflags, wArrows);
}

BOOL XScrollWindow::_GetScrollBarInfo( LONG idObject, PSCROLLBARINFO psbi )
{
    ASSERT(_IsWindow());
    return ::GetScrollBarInfo(m_hWnd, idObject, psbi);
}

WINDOW_END_NAMESPACE
