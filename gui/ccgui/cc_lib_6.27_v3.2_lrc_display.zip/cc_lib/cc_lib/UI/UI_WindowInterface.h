#ifndef _CC_UI_WINDOW_INTERFACE_H
#define _CC_UI_WINDOW_INTERFACE_H

#pragma once

#define     MapWindowRect(hwndFrom, hwndTo, lprc) \
    MapWindowPoints((hwndFrom), (hwndTo), (POINT *)(lprc), 2)

WINDOW_BEGIN_NAMESPACE
class IWindow
{
public:
    virtual HWND GetSafeHwnd() const = 0;
    virtual HWND Attach(HWND hwnd) = 0;
    virtual int  _GetClassName(LPTSTR lpClassName, int nMaxCount) = 0;

    virtual HICON _SetIcon(HICON hIcon, BOOL bBigIcon) = 0;
    virtual HICON _GetIcon(BOOL bBigIcon) const = 0;

    virtual BOOL _SetProp(LPCTSTR lpString, HANDLE hData) = 0;
    virtual HANDLE _GetProp(LPCTSTR lpString) = 0;
    virtual HANDLE _RemoveProp(LPCTSTR lpString) = 0;
    virtual int  _EnumProps(PROPENUMPROC lpEnumFunc) = 0;
    virtual int  _EnumPropsEx(PROPENUMPROCEX lpEnumFunc, LPARAM lParam) = 0;

    virtual BOOL _ShowWindow(int nCmdShow) = 0;
    virtual BOOL _MoveWindow(int X, int Y, int nWidth, int nHeight, BOOL bRepaint) = 0;
    virtual BOOL _EnableWindow(BOOL bEnable) = 0;
    virtual BOOL _CloseWindow() = 0;
    virtual BOOL _CenterWindow() = 0;
    virtual BOOL _UpdateWindow() = 0;

    virtual HDC  _BeginPaint(PAINTSTRUCT& ps) = 0;
    virtual BOOL _EndPaint(PAINTSTRUCT& ps) = 0;
    virtual HDC  _GetDC() = 0;
    virtual int  _ReleaseDC(HDC hDC) = 0;

    virtual BOOL _InvalidateRect(XRect* pRect, BOOL bErase = FALSE) = 0;
    virtual BOOL _GetWindowRect(XRect& rc) = 0;
    virtual BOOL _GetClientRect(XRect& rc) = 0;
    virtual BOOL _GetUpdateRect(XRect& rc, BOOL bErase = FALSE) = 0;
    virtual BOOL _GetCursorPos(LPPOINT lpPoint) = 0;
    virtual BOOL _ClientToScreen(LPPOINT lpPoint) = 0;
    virtual BOOL _ScreenToClient(LPPOINT lpPoint) = 0;
    virtual LONG _GetWindowLong(int nIndex) = 0;
    virtual LONG_PTR _SetWindowLongPtr(int nIndex, LONG_PTR dwNewLong) = 0;
    virtual LONG_PTR _GetWindowLongPtr(int nIndex) = 0;
    virtual HWND _GetDlgItem(int nIDDlgItem) = 0;
    virtual LONG _GetWindowStyle() = 0;
    virtual HWND _GetParent() = 0;
    virtual HWND _GetWindow(UINT nCmd) = 0;
    virtual HWND _GetWindowOwner() = 0;
    virtual HWND _SetFocus() = 0;
    virtual HWND _GetFocus() = 0;
    virtual BOOL _IsWindow() const = 0;
    virtual BOOL _IsWindowVisible() = 0;
    virtual BOOL _SetWindowPos(HWND hWndInsertAfter, int X, int Y, int cx, int cy, UINT uFlags) = 0;
    virtual void _SetWindowFont(HFONT hFont, BOOL bRedraw) = 0;
    virtual HFONT _GetWindowFont() = 0;
    virtual BOOL _SetWindowText(LPCTSTR lpString) = 0;
    virtual int  _GetWindowText(LPTSTR lpString, int nMaxCount) = 0;
    virtual int  _GetWindowTextLength() = 0;
    virtual BOOL _CreateCaret(HBITMAP hBitmap, int nWidth, int nHeight) = 0;
    virtual BOOL _ShowCaret() = 0;
    virtual BOOL _HideCaret() = 0;
    virtual BOOL _SetCaretPos(int X, int Y) = 0;

    virtual int  _MessageBox( LPCTSTR lpText, LPCTSTR lpCaption, UINT uType ) = 0;

    virtual LRESULT _SendMessage(UINT uMsg, WPARAM wParam = 0U, LPARAM lParam = 0L) const = 0;
    virtual LRESULT _PostMessage(UINT uMsg, WPARAM wParam = 0U, LPARAM lParam = 0L) const = 0;

    virtual LRESULT _DefWindowProc(UINT Msg, WPARAM wParam, LPARAM lParam) = 0;
    virtual LRESULT _CallWindowProc(WNDPROC lpPrevWndFunc, UINT Msg, WPARAM wParam, LPARAM lParam) = 0;
};

class IScrollBar
{
public:
    virtual BOOL _SetScrollPos(int nBar, int nPos, BOOL bRedraw) = 0;
    virtual int  _GetScrollPos(int nBar) = 0;
    virtual int  _SetScrollInfo(int nBar, LPCSCROLLINFO lpsi, BOOL redraw) = 0;
    virtual BOOL _GetScrollInfo(int nBar, LPSCROLLINFO lpsi) = 0;
    virtual BOOL _SetScrollRange(int nBar, int nMinPos, int nMaxPos, BOOL bRedraw) = 0;
    virtual BOOL _GetScrollRange(int nBar, LPINT lpMinPos, LPINT lpMaxPos) = 0;
    virtual BOOL _ShowScrollBar(int wBar, BOOL bShow) = 0;
    virtual BOOL _EnableScrollBar(UINT wSBflags, UINT wArrows) = 0;
    virtual BOOL _GetScrollBarInfo(LONG idObject, PSCROLLBARINFO psbi) = 0;
};

class IScrollBarCtrl
{
public:
    virtual int GetScrollPos() = 0;
    virtual int GetScrollPage() = 0;
    virtual XSize GetScrollRange() = 0;
    virtual void SetScrollPos( int iPos ) = 0;
    virtual void EnableScrollBar( bool bEnable = true ) = 0;

protected:
    virtual void ProcessScrollbar( const XRect &, int cyRequired ) = 0;
};

WINDOW_END_NAMESPACE
#endif