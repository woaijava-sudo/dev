#ifndef _CC_UI_TITLE_H
#define _CC_UI_TITLE_H

#pragma once

#define GetITitle(p) ((XTitle*)(static_cast<XTitle*>((p)->GetInterface(HI_TITLE))))

CONTROLS_BEGIN_NAMESPACE
class XTitle;
CONTROLS_END_NAMESPACE
WINDOW_BEGIN_NAMESPACE
class XTitleWindow;
WINDOW_END_NAMESPACE

//////////////////////////////////////////////////////////////////////////
WINDOW_BEGIN_NAMESPACE
using namespace cc::Threading;

// ����ʱ��
#define XTITLE_FADE_IN   500
#define XTITLE_HOLD      5000
#define XTITLE_FADE_OUT  2000

// �Զ��崰����Ϣ
#define XTITLE_WM_POST_TEXT     WM_USER + 0x10
#define XTITLE_WM_SET_ATTR      WM_USER + 0x11
#define XTITLE_WM_GET_ATTR      WM_USER + 0x12

#define XTITLE_WM_SET_TIME_FADE_IN      0x100
#define XTITLE_WM_SET_TIME_HOLD         0x101
#define XTITLE_WM_SET_TIME_FADE_OUT     0x102
#define XTITLE_WM_SET_MAX_DELAY         0x103

struct XTitleAttr
{
    DWORD       t_fade_in;      // ����ʱ��
    DWORD       t_hold;         // ά��ʱ��
    DWORD       t_fade_out;     // ����ʱ��
    DWORD       t_delay;        // ���ͣ����Ŀ
};

struct XTitleTask
{
    enum TitleState
    {
        READY,
        FADE_IN,
        HOLD,
        FADE_OUT,
        STOP,
    };

    AutoPtr<XString>
                message;    // ��Ϣ�ı�
    TitleState  state;       // ����״̬
    DWORD       cur_tick;   // ״̬��ǰʱ��
    DWORD       ref_tick;   // ״̬��ʼʱ��
    DWORD       ori_tick;   // ȫ��ʱ��
    double      completed;  // ����� 0~1

    XTitleTask(): state(READY), completed(0.0)
    {
        cur_tick = ref_tick = ori_tick = ::timeGetTime();
    }

    XTitleTask(XString* pstrText): state(READY), completed(0.0)
    {
        message = pstrText;
        cur_tick = ref_tick = ori_tick = ::timeGetTime();
    }

    XTitleTask& operator = (const XTitleTask& task)
    {
        message = task.message;
        cur_tick = task.cur_tick;
        ref_tick = task.ref_tick;
        ori_tick = task.ori_tick;
        completed = task.completed;
        return *this;
    }

    bool operator == (const XTitleTask& task)
    {
        return message == task.message && ori_tick == task.ori_tick;
    }
};

DEF_AUTO_PTR(XTitleTask*);
DEF_LIST_TEMPLATE2(AutoPtr<XTitleTask>, XTitleTask*);
typedef List<AutoPtr<XTitleTask>, XTitleTask*> XTitleTaskList;

class XTitleWindow;
class XTitleThread : public Thread, public IOwner<XTitleWindow>
{
public:
    XTitleThread();
    ~XTitleThread();

    virtual void Init( XTitleWindow* pOwner );
    virtual void Run();
    void Terminate();
    
    void Post(XString* pstrText);
    const XTitleTaskList* Lock();
    void Unlock();

    void RemoveStop();

    BOOL SetAttr(UINT nType, DWORD dwValue);
    DWORD GetAttr(UINT nType);

public:
    XTitleTaskList              cache;  // ���㻺�棨��UI�̵߳��ã�

private:
    XTitleTaskList              task;   // ��ǰ�������񣨳����߳��ⲻ�ɷ��ʣ�
    List<XString*>              post;   // �ύ���ı��������߳��ⲻ�ɷ��ʣ�
    XTitleAttr                  attr;   // ����
    XTitleAttr                  tmp_attr;
    volatile BOOL               stop;
    volatile BOOL               set_attr;
    CriticalSection             cs;
    CriticalSection             cs_post;
};

class XTitleWindow : public XWindow, public IOwner<XTitle>
{
    X_DECLARE_CLASS(XTitleWindow)
public:
    XTitleWindow();
    virtual ~XTitleWindow();
public:
    void Init( XTitle* pOwner );
    virtual void OnFinalMessage( HWND hWnd );

    virtual LRESULT HandleMessage( UINT uMsg, WPARAM wParam, LPARAM lParam );

    virtual void Notify( TAsyncNotify& notify );
    void PostText(XString* pstrText);
    const XTitleTaskList* Lock();
    void Unlock();

    void Invalidate();

protected:
    XTitleThread thread;
};
WINDOW_END_NAMESPACE

//////////////////////////////////////////////////////////////////////////
CONTROLS_BEGIN_NAMESPACE
class CL_API XTitle : public XText, public IChildWindow2<XTitleWindow>
{
    X_DECLARE_CLASS_WITH_PARA(XTitle)
public:
    XTitle(XObject* pOb = NULL);
    virtual ~XTitle();

    virtual void* GetInterface( HINTERFACE hi );
    virtual XControl* CreateControl( XClass* pClass );

    virtual void SetEnable( BOOL bEnabled );
    virtual void Event( TEvent& event );

    virtual XSize EstimateSize( const XSize& );

    virtual void Paint( HDC hDC, const XRect& rect );

    void Init();

protected:
    XTitleTaskList   task_list;
};

CONTROLS_END_NAMESPACE

#endif