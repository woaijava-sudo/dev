#include "StdAfx.h"

CONTROLS_BEGIN_NAMESPACE
//////////////////////////////////////////////////////////////////////////
X_IMPLEMENT_CLASS_WITH_PARA(XControl, XObject)

XControl::XControl( XObject* pOb /*= NULL*/ ): m_pParent(NULL),
    m_pWindow(NULL),
    m_bNeedUpdate(FALSE),
    m_dwBkColor(MAKE_RGB(XCOLOR_CONTROL_BACKGROUND_NORMAL)),
    m_dwBkColor1(CLR_INVALID),
    m_dwBkColor2(CLR_INVALID),
    m_bVisible(TRUE),
    m_bEnabled(TRUE),
    m_bFocused(FALSE),
    m_bFloat(FALSE),
    m_bDrag(FALSE),
    m_bTrack(FALSE),
    m_bGetRegion(FALSE),
    m_bColorHSL(FALSE),
    m_flags(0),
    m_bMouseEnabled(TRUE)
{
    ASSERT_VALID(pOb);
    ASSERT(pOb->XIsKindOf(XWindow));
    m_szName.Format(_T("%s.%d.%d"), DEFAULT_CONTROL_NAME, this, rand());
    m_pWindow = static_cast<XWindow*>(pOb);
    m_hRgn = ::CreateRectRgn(0, 0, 0, 0);
    ASSERT(m_hRgn);
    InitializeDelegate();
}

XControl::~XControl()
{
    ASSERT(m_hRgn);
    ::DeleteObject(m_hRgn);
    RunDelegate(_T("Destroy"), this);
}

#ifdef _DEBUG
void XControl::AssertValid() const
{
    ASSERT_VALID(m_pWindow);
    XObject::AssertValid();
}
#endif // _DEBUG

XControl* XControl::CreateControl( XClass* pClass, XWindow* pWindow )
{
    ASSERT(pClass);
    ASSERT(pClass->IsDerivedFrom(X_CLASS(XControl)));
    ASSERT_VALID(pWindow);
    ASSERT(pWindow->XIsKindOf(XWindow));
    XControl* pControl = NULL;
    X_CreateObject_V2(pClass, pWindow, (XObject**)&pControl);
    pWindow->RegisterControl(pControl); // Register owner & Unregister by others
    return pControl;
}

XControl* XControl::CreateControl( XClass* pClass )
{
    ASSERT(pClass);
    ASSERT(pClass->IsDerivedFrom(X_CLASS(XControl)));
    ASSERT_VALID(m_pWindow);
    ASSERT(m_pWindow->XIsKindOf(XWindow));
    XControl* pControl = NULL;
    X_CreateObject_V2(pClass, m_pWindow, (XObject**)&pControl);
    m_pWindow->RegisterControl(pControl); // Register owner & Unregister by others
    pControl->SetParent(this);
    return pControl;
}

void* XControl::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_CONTROL: return this;
    }
    return XObject::GetInterface(hi);
}

IDelegate* XControl::GetIDelegate()
{
    return static_cast<IDelegate*>(this);
}

void XControl::SetParent( XControl* pParent )
{
    m_pParent = pParent;
}

void XControl::SetOwner( XWindow* pWindow )
{
    m_pWindow = pWindow;
}

XControl* XControl::GetParent() const
{
    return m_pParent;
}

XWindow* XControl::GetOwner() const
{
    return m_pWindow;
}

void XControl::SetName( LPCTSTR name )
{
    ASSERT(name);
    ASSERT(IsValidString(name));
    ASSERT_VALID(m_pWindow);
#ifdef _DEBUG
    TRACE("['%s' - %s - 0x%X] set name to '%s'", m_szName, GetClass()->m_lpszClassName, this, name);
#endif // _DEBUG
    Unregister();
    m_szName = name;
    Register();
}

XString XControl::GetName() const
{
    return m_szName;
}

void XControl::SetText( LPCTSTR text )
{
    ASSERT(text);
    ASSERT(IsValidString(text));
    m_szText = text;
#ifdef _DEBUG
    TRACE("[%s - 0x%X] set text to '%s'", GetClass()->m_lpszClassName, this, text);
#endif // _DEBUG
}

XString XControl::GetText() const
{
    return m_szText;
}
void XControl::SetRect( const XRect & rect )
{
    m_rcClient = rect;
    m_rcOrigin = rect;
}

XRect XControl::GetRect() const
{
    return m_rcClient;
}

XRect XControl::GetOriginRect() const
{
    return m_rcOrigin;
}

void XControl::ResetRect()
{
    m_rcClient = m_rcOrigin;
}

void XControl::SetOffset( const XPoint & pt )
{
    m_ptOffset = pt;
}

XPoint XControl::GetOffset() const
{
    return m_ptOffset;
}

void XControl::SetDrag( BOOL bDrag )
{
#ifdef _DEBUG
    if (bDrag)
    {
        ASSERT_VALID(m_pParent);
        ASSERT(m_pParent->XIsKindOf(XContainer));
    }
#endif // _DEBUG
    m_bDrag = bDrag;
}

BOOL XControl::IsDrag() const
{
    return m_bDrag;
}

void XControl::SetBorder( XSize size )
{
    m_szBorder = size;
}

XSize XControl::GetBorder() const
{
    return m_szBorder;
}

void XControl::SetBkColor( COLORREF dwBkColor )
{
    m_dwBkColor = dwBkColor;
}

DWORD XControl::GetBkColor() const
{
    return m_dwBkColor;
}

void XControl::SetBkColor1( COLORREF dwBkColor1 )
{
    m_dwBkColor1 = dwBkColor1;
}

DWORD XControl::GetBkColor1() const
{
    return m_dwBkColor1;
}

void XControl::SetBkColor2( COLORREF dwBkColor2 )
{
    m_dwBkColor2 = dwBkColor2;
}

DWORD XControl::GetBkColor2() const
{
    return m_dwBkColor2;
}

void XControl::SetBkImage( LPCTSTR pstrImage )
{
    ASSERT(pstrImage);
    m_szBkImage = pstrImage;
}

XString XControl::GetBkImage() const
{
    return m_szBkImage;
}

void XControl::NeedUpdate()
{
    if( !m_bVisible ) return;
    m_bNeedUpdate = true;
    Invalidate();

    if( m_pWindow != NULL ) m_pWindow->NeedUpdate(this);
}

void XControl::NeedParentUpdate()
{
    if( m_pParent )
    {
        m_pParent->NeedUpdate();
        m_pParent->Invalidate();
    }
    else
    {
        NeedUpdate();
    }

    if( m_pWindow != NULL ) m_pWindow->NeedUpdate(this);
}

BOOL XControl::IsNeedUpdate() const
{
    return m_bNeedUpdate;
}

void XControl::SetVisible( BOOL bVisible )
{
    if( m_bVisible == bVisible ) return;

    m_bVisible = bVisible;
    if (!m_bVisible) // ���ɼ�
    {
        if( m_bFocused ) m_bFocused = FALSE;
    }
    else // �ɼ�
    {
        m_pParent->Invalidate();
    }
}

BOOL XControl::IsVisible() const
{
    return m_bVisible;
}

void XControl::SetEnable( BOOL bEnabled, BOOL bRedraw /*= TRUE*/ )
{
    if( m_bEnabled == bEnabled ) return;
    m_bEnabled = bEnabled;
    if (bRedraw)
    {
        NeedUpdate();
    }
}

BOOL XControl::IsEnabled() const
{
    return m_bEnabled;
}

void XControl::SetFocus()
{
    if( m_pWindow != NULL ) m_pWindow->SetFocus(this);
}

BOOL XControl::IsFocused() const
{
    return m_bFocused;
}

void XControl::SetMouseEnable( BOOL bEnabled )
{
    m_bMouseEnabled = bEnabled;
}

BOOL XControl::IsMouseEnabled() const
{
    return m_bMouseEnabled;
}


void XControl::SetFlags( DWORD flag )
{
    m_flags = flag;
}

DWORD XControl::GetFlags() const
{
    return m_bEnabled ? m_flags : (m_flags & ~XFLAG_SETCURSOR);
}

XSize XControl::EstimateSize( const XSize& )
{
    // һ����ô����غ����������������ӿ�
    XSize sz;
    XSize sz2 = m_rcClient.Size();
    sz.cx = max(GetFixedWidth(), sz2.cx);
    sz.cy = max(GetFixedHeight(), sz2.cy);
    return sz;
}

XSize XControl::CalcSize()
{
    // һ����ô����غ����������������ӿ�
    return m_rcClient.Size();
}

DWORD XControl::GetAdjustColor( DWORD dwColor )
{
    if( !m_bColorHSL ) return dwColor;
    short H, S, L;
    XWindow::GetHSL(H, S, L);
    return Rendering::X_AdjustColor(dwColor, H, S, L);
}

BOOL XControl::Activate()
{
    if( !IsVisible() ) return FALSE;
    if( !IsEnabled() ) return FALSE;
    return TRUE;
}

void XControl::Paint( HDC hDC, const XRect& rect )
{
    if ( !m_rcPaint.IntersectRect(&rect, &m_rcClient) ) return;
    
#ifdef _DEBUG
    TRACE("['%s' - %s - 0x%X] ==> Paint ==> [HDC: 0x%X] (L: %d T: %d R: %d B: %d)",
        m_szName, GetClass()->m_lpszClassName, this, hDC, rect.left, rect.top, rect.right, rect.bottom);
#endif // _DEBUG

    // ����ѭ�򣺱�����ɫ->����ͼ->״̬ͼ->�ı�->�߿�
    if (m_bPrintBk && m_szBkImage.IsEmpty()) PaintBkColor(hDC);
    if (m_bPrintBk) PaintBkImage(hDC);
    PaintText(hDC);
}

void XControl::PaintBkColor( HDC hDC )
{
    if( m_dwBkColor1 != CLR_INVALID ) {
        if( m_dwBkColor2 != CLR_INVALID ) {
            XRect rc = m_rcClient;
            rc.bottom = (rc.bottom + rc.top) / 2;
            Rendering::X_DrawGradient(hDC, rc, m_dwBkColor, m_dwBkColor1, true, 8);
            rc.top = rc.bottom;
            rc.bottom = m_rcClient.bottom;
            Rendering::X_DrawGradient(hDC, rc, m_dwBkColor1, m_dwBkColor2, true, 8);
        } else {
            Rendering::X_DrawGradient(hDC, m_rcClient, m_dwBkColor, m_dwBkColor1, true, 16);
        }
    } else {
        Rendering::X_DrawColor(hDC, m_rcClient, m_dwBkColor);
    }
}

void XControl::PaintText( HDC hDC )
{

}

void XControl::PaintBkImage( HDC hDC )
{
    if( m_szBkImage.IsEmpty() ) return;
    if (m_bGetRegion) GetRegion(hDC, m_szBkImage, RGB(0, 0, 0));
    if( !PaintImage(hDC, (LPCTSTR)m_szBkImage) ) m_szBkImage.Empty();
}

void XControl::GetRegion( HDC hDC, LPCTSTR pstrImage, COLORREF dwColorKey )
{
    ASSERT(hDC);
    ASSERT(pstrImage);

    m_bGetRegion = false;
    HDC memDC = ::CreateCompatibleDC(hDC);

    const TImage* pImage = m_pWindow->GetImageEx((LPCTSTR)pstrImage);
    if( !pImage ) return;

    HBITMAP pOldMemBmp = (HBITMAP)::SelectObject(memDC, pImage->hBitmap);

    BITMAP bit;  
    ::GetObject(pImage->hBitmap, sizeof(BITMAP), &bit); //ȡ��λͼ����������Ҫ�õ�λͼ�ĳ��Ϳ�

    int x, y;
    HRGN rgnTemp; //������ʱregion

    for(x = 0, y = 0; y <= bit.bmHeight; y++)
    {
        do
        {
            // ����͸��ɫ�ҵ���һ����͸��ɫ�ĵ�
            COLORREF res1 = RGB(255, 255, 255);
            COLORREF RES = ::GetPixel(memDC, x, y);
            while (x <= bit.bmWidth && ::GetPixel(memDC, x, y) == dwColorKey) x++;

            // ��ס�����ʼ��
            int iLeftX = x;

            // Ѱ���¸�͸��ɫ�ĵ�
            while (x <= bit.bmWidth && ::GetPixel(memDC, x, y) != dwColorKey) x++;

            // ����һ������������ص���Ϊ1px����ʱregion
            rgnTemp = ::CreateRectRgn(iLeftX, y, x, y+1);

            // �ϲ�����region
            ::CombineRgn(m_hRgn, m_hRgn, rgnTemp, RGN_OR);

            // ɾ����ʱregion�������´δ���ʱ�����
            ::DeleteObject(rgnTemp);

        } while(x < bit.bmWidth );
        x = 0;
    }

    if(pOldMemBmp) ::SelectObject(memDC, pOldMemBmp);
    ::DeleteDC(memDC);
}

BOOL XControl::PaintImage( HDC hDC, LPCTSTR pstrImage, LPCTSTR pstrModify /*= NULL*/, bool bNeedAlpha /*= FALSE*/, BYTE bNewFade /*= 255*/ )
{
    return Rendering::X_DrawImageString(hDC, m_pWindow, m_rcClient, m_rcPaint, pstrImage, pstrModify, bNeedAlpha, bNewFade);
}

void XControl::PostPaint( HDC m_hDcOffscreen, XRect& rect )
{

}

void XControl::Invalidate()
{
    if( !m_bVisible ) return;

    XRect rcInvalid = m_rcClient;

    XControl* pParent = this;
    XRect rcTemp;
    XRect rcParent;
    while( pParent = pParent->m_pParent )
    {
        rcTemp = rcInvalid;
        rcParent = pParent->m_rcClient;
        if( !rcInvalid.IntersectRect(&rcTemp, &rcParent) ) 
        {
            return;
        }
    }

    if( m_pWindow != NULL ) m_pWindow->Invalidate(rcInvalid);
}

XControl* XControl::GetParents(int nID)
{
    if (nID <= 0) {
        return this;
    } else {
        if (m_pParent) {
            return m_pParent->GetParents(nID - 1);
        } else {
            return this;
        }
    }
}

bool XControl::OnMouseEvent( UINT uMsg )
{
    switch ( uMsg )
    {
    case WM_MOUSEMOVE:
    case WM_MOUSELEAVE:
    case WM_MOUSEENTER:
    case WM_MOUSEHOVER:
    case WM_LBUTTONDOWN:
    case WM_LBUTTONUP:
    case WM_RBUTTONDOWN:
    case WM_LBUTTONDBLCLK:
    case WM_CONTEXTMENU:
    case WM_MOUSEWHEEL:
        return true;
    }
    return false;
}

void XControl::Event( TEvent& event )
{
    ASSERT(event.dispatcher && event.sender);

    if( RunDelegate(_T("Event"), &event) ) return; // �ѱ��ص���������

    switch (event.msg.message)
    {
    case WM_SETCURSOR:
        ::SetCursor(::LoadCursor(NULL, MAKEINTRESOURCE(IDC_ARROW)));
        break;
    case WM_SETFOCUS:
        m_bFocused = TRUE;
        Invalidate();
        break;
    case WM_KILLFOCUS:
        m_bFocused = FALSE;
        Invalidate();
        break;
    case WM_TIMER:
        ASSERT(m_pWindow);
        m_pWindow->SendAsyncNotify(this, WM_TIMER, FALSE, event.msg.wParam, event.msg.lParam);
        break;
    case WM_LBUTTONDOWN:
        m_bTrack = TRUE;
        if (m_bDrag)
        {
            m_ptTrackOrigin = event.msg.pt;
        }
        break;
    case WM_LBUTTONUP:
        m_bTrack = FALSE;
        if (m_bDrag)
        { 
            m_ptOffset.x = m_rcClient.left - m_rcOrigin.left;
            m_ptOffset.y = m_rcClient.top - m_rcOrigin.top;
            m_ptTrackOrigin = XPoint();
        }
        break;
    case WM_MOUSEMOVE:
        if (m_bTrack && m_bDrag)
        {
            static XRect rect;
            rect = m_rcOrigin + ( m_ptOffset + event.msg.pt - m_ptTrackOrigin );
            m_bTrack = rect.RestrictRect(m_pParent->GetRect());
            m_rcClient = rect;
            m_pParent->Invalidate();
        }
        break;
    default:
        if ( m_pParent != NULL )
        {
            event.sender = this;
            event.receiver = m_pParent;
            event.dispatcher->PostEvent(event);
        }
    }
}

XControl* XControl::FindControl( X_FIND_CALL Proc, LPVOID pData, UINT uFlags )
{
    ASSERT(pData);
    if( (uFlags & XFIND_VISIBLE) != 0 && !m_bVisible ) return NULL;
    if( (uFlags & XFIND_ENABLED) != 0 && !m_bEnabled ) return NULL;
    if( (uFlags & XFIND_HITTEST) != 0 && !m_rcClient.PtInRect(*static_cast<LPPOINT>(pData)) ) return NULL;
    return Proc(this, pData);
}

BOOL XControl::SetTextFont( LPCTSTR szName, int nSize, BOOL bBold /*= FALSE*/, BOOL bUnderline /*= FALSE*/, BOOL bItalic /*= FALSE*/ )
{
    ASSERT(m_pWindow && "Must initialize the window ptr first!");
    m_szFontHash = m_pWindow->MakeFontHash(szName, nSize, bBold, bUnderline, bItalic);
    return GetIFont(m_pWindow)->AddFont(szName, nSize, bBold, bUnderline, bItalic);
}

void XControl::SetTextFont( XControl* pControl )
{
    ASSERT(m_pWindow && "Must initialize the window ptr first!");
    ASSERT_VALID(pControl);
    m_szFontHash = pControl->m_szFontHash;
}

HFONT XControl::GetTextFont()
{
    ASSERT(m_pWindow);
    if (m_szFontHash.IsEmpty()) return GetIFont(m_pWindow)->GetDefaultFontInfo()->hFont;
    return GetIFont(m_pWindow)->GetFontByHash(m_szFontHash);
}

TFont* XControl::GetTextFontInfo()
{
    ASSERT(m_pWindow);
    if (m_szFontHash.IsEmpty()) return GetIFont(m_pWindow)->GetDefaultFontInfo();
    return GetIFont(m_pWindow)->GetFontInfoByHash(m_szFontHash);
}

void XControl::InitializeDelegate()
{
    CreateDelegate("Init");
    CreateDelegate("Destroy");
    CreateDelegate("Size");
    CreateDelegate("Event");
    CreateDelegate("Notify");
}

void XControl::Register()
{
    ASSERT_VALID(m_pWindow);
    BOOL bRet = m_pWindow->RegisterControl(this);
    ASSERT(bRet);
}

void XControl::Unregister()
{
    ASSERT_VALID(m_pWindow);
    BOOL bRet = m_pWindow->UnregisterControl(this);
    ASSERT(bRet);
}

CONTROLS_END_NAMESPACE