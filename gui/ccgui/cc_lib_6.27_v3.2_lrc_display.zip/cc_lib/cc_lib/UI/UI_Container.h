#ifndef _CC_UI_CONTAINER_H
#define _CC_UI_CONTAINER_H

#pragma once

#include "UI_Scroll.h"

#define GetIContainer(p) ((IContainer*)static_cast<IContainer*>((p)->GetInterface(HI_CONTAINER_INTERFACE)))
#define GetIContainerEx(p) ((XContainer*)static_cast<XContainer*>((p)->GetInterface(HI_CONTAINER)))
#define GetIScrollBar(p) ((IScrollBar*)static_cast<IScrollBar*>((p)->GetInterface(HI_SCROLL)))
#define GetIScrollBarCtrl(p) ((IScrollBarCtrl*)static_cast<IScrollBarCtrl*>((p)->GetInterface(HI_SCROLL_IMPL)))

CONTAINER_BEGIN_NAMESPACE
using namespace UI;
using namespace Controls;
class IContainer : public IArrayAdv<XControl> {};

DEF_LIST_TEMPLATE1(XControl*);

class CL_API XContainer : public XScroll, public IContainer
{
    X_DECLARE_CLASS_WITH_PARA(XContainer)
public:
    XContainer(XObject* pOb = NULL);
    virtual ~XContainer();

    virtual void* GetInterface(HINTERFACE hi);

    // IContainer�ӿ�
    XControl*   GetData( int ) const;
    int         Find( XControl* ) const;
    bool        SetAt( XControl*, int );
    int         GetSize() const;
    int         Add( XControl* );
    bool        InsertAt( int, XControl* );
    bool        Remove( XControl* );
    bool        RemoveAt( int );
    void        RemoveAll();

#ifdef _DEBUG
    virtual void AssertValid() const;
#endif // _DEBUG

    void        SetAutoDestroy( bool );

    virtual void Paint( HDC hDC, const XRect& rect );

    virtual int  FindSelectable( int iIndex, bool bForward = true );

    XRect GetInset() const;
    void  SetInset(XRect& rcInset);

    virtual void SetOwner( XWindow* );
    virtual void SetParent( XControl* );

    virtual XControl* CreateControl(XClass* pClass);

    virtual void Event( TEvent& event );
    virtual XControl* FindControl( X_FIND_CALL Proc, LPVOID pData, UINT uFlags );

    // Scroll Implements
    virtual void SetScrollPos( int iPos );
    virtual void ProcessScrollbar( const XRect &, LONG cyRequired );

    virtual void SetRect( const XRect & );

    virtual XSize EstimateSize( const XSize& );

protected:
    List<XControl*>      m_Items; // �ؼ���Ա��
    XRect       m_rcInset; // �ڱ߾�(�ͻ���)
    bool        m_bAutoDelete;
};

CONTAINER_END_NAMESPACE
#endif