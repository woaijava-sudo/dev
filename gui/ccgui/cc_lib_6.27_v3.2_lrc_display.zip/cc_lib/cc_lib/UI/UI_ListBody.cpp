#include "stdafx.h"

CONTROLS_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS_WITH_PARA(XListHeader, XHorizontalLayout)
X_IMPLEMENT_CLASS_WITH_PARA(XListFooter, XHorizontalLayout)
//////////////////////////////////////////////////////////////////////////

XListHeader::XListHeader( XObject* pOb /*= NULL*/ ): XHorizontalLayout(pOb)
{
    m_bPrintBk = FALSE;
}

void* XListHeader::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_LIST_HEADER: return this;
    }
    return XHorizontalLayout::GetInterface(hi);
}

void XListHeader::Paint( HDC hDC, const XRect& rcPaint )
{
    if ( !m_rcPaint.IntersectRect(&rcPaint, &m_rcClient) ) return;

    Rendering::X_DrawFrame(hDC, m_rcClient, PS_SOLID, 1, XCOLOR_HEADER_BORDER, XCOLOR_HEADER_BORDER, MAKE_RGB(XCOLOR_HEADER_BACKGROUND), 0);
    XRect rcBottom(m_rcClient.left + 1, m_rcClient.bottom - 3, m_rcClient.right - 1, m_rcClient.bottom);
    Rendering::X_DrawGradient(hDC, rcBottom, XCOLOR_HEADER_BACKGROUND, XCOLOR_HEADER_BACKGROUND_2, true, 4);
    XHorizontalLayout::Paint(hDC, rcPaint);
}

bool XListHeader::AllowFixedWidth( LONG iAdd )
{
    if (iAdd <= 0)
    {
        return true;
    }
    XSize sz;
    for (int i = 0; i < m_Items.GetSize(); i++)
    {
        XListHeaderItem* pItem = GetIListHeaderItem(m_Items[i]);
        ASSERT_VALID(pItem);
        iAdd += pItem->EstimateSize(sz).cx;
    }
    return iAdd < m_rcClient.Width();
}

XSize XListHeader::EstimateSize( const XSize& )
{
    ASSERT_VALID(m_pWindow);
    return XSize(0, 6 + m_pWindow->GetFontInfoByHash(m_szFontHash)->tm.tmHeight);
}

//////////////////////////////////////////////////////////////////////////

XListFooter::XListFooter( XObject* pOb /*= NULL*/ ): XHorizontalLayout(pOb)
{
    m_bPrintBk = FALSE;
}

void* XListFooter::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_LIST_FOOTER: return this;
    }
    return XHorizontalLayout::GetInterface(hi);
}

void XListFooter::Paint( HDC hDC, const XRect& rcPaint )
{
    if ( !m_rcPaint.IntersectRect(&rcPaint, &m_rcClient) ) return;

    Rendering::X_DrawFrame(hDC, m_rcClient, PS_SOLID, 1, XCOLOR_HEADER_BORDER, XCOLOR_HEADER_BORDER, MAKE_RGB(XCOLOR_HEADER_BACKGROUND), 0);
    XRect rcTop(m_rcClient.left + 1, m_rcClient.top, m_rcClient.right - 1, m_rcClient.top + 1);
    Rendering::X_DrawGradient(hDC, rcTop, XCOLOR_HEADER_BACKGROUND, XCOLOR_HEADER_BACKGROUND_2, true, 2);
    XRect rcBottom(m_rcClient.left + 1, m_rcClient.bottom - 3, m_rcClient.right - 1, m_rcClient.bottom);
    Rendering::X_DrawGradient(hDC, rcBottom, XCOLOR_HEADER_BACKGROUND_2, XCOLOR_HEADER_BACKGROUND, true, 4);
    XHorizontalLayout::Paint(hDC, rcPaint);
}

XSize XListFooter::EstimateSize( const XSize& )
{
    ASSERT_VALID(m_pWindow);
    return XSize(0, 6 + m_pWindow->GetFontInfoByHash(m_szFontHash)->tm.tmHeight);
}

CONTROLS_END_NAMESPACE