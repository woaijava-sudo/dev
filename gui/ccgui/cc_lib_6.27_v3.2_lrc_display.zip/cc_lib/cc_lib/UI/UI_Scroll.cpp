#include "StdAfx.h"

CONTROLS_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS_WITH_PARA(XScroll, XControl)
//////////////////////////////////////////////////////////////////////////

XScroll::XScroll( XObject* pOb /*= NULL*/ ): XControl(pOb), m_iScrollPos(0), m_bAllowScrollbars(false),
    m_bAllowScrollColor(false), m_clrScroll(0)
{

}

XScroll::~XScroll()
{
    DestroyWindow();
}

void* XScroll::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_SCROLL: return this;
    }
    return XControl::GetInterface(hi);
}

int XScroll::GetScrollPos()
{
    return m_iScrollPos;
}

int XScroll::GetScrollPage()
{
    // ��̬����
    return X_SCROLL_PAGE;
}

XSize XScroll::GetScrollRange()
{
    ASSERT_VALID(m_pChildWindow);
    ASSERT(m_pChildWindow->_IsWindow());
    int cx = 0, cy = 0;
    m_pChildWindow->_GetScrollRange(SB_CTL, &cx, &cy);
    return XSize(cx, cy);
}

void XScroll::SetScrollPos( int iPos )
{
    ASSERT_VALID(m_pChildWindow);
    ASSERT(m_pChildWindow->_IsWindow());
    int iRange1 = 0, iRange2 = 0;
    m_pChildWindow->_GetScrollRange(SB_CTL, &iRange1, &iRange2);
    iPos = CLAMP(iPos, iRange1, iRange2);
    m_pChildWindow->_SetScrollPos(SB_CTL, iPos, TRUE);
    m_iScrollPos = m_pChildWindow->_GetScrollPos(SB_CTL);
}

void XScroll::EnableScrollBar( bool bEnable /*= true */ )
{
    if( m_bAllowScrollbars == bEnable ) return;
    m_iScrollPos = 0;
    m_bAllowScrollbars = bEnable;
}

BOOL XScroll::AllowScrollBar() const
{
    return m_bAllowScrollbars;
}

void XScroll::ProcessScrollbar( const XRect & rect, int cyRequired )
{
    // No scrollbar required
    if( m_pChildWindow == NULL || !m_pChildWindow->_IsWindow() ) return;
    // Move it into place
    int cxScroll = ::GetSystemMetrics(SM_CXVSCROLL);
    m_pChildWindow->_MoveWindow(rect.right - cxScroll, rect.top, cxScroll, rect.Height(), TRUE);
    // Scroll not needed anymore?
    int cyScroll = cyRequired - rect.Height();
    if( cyScroll < 0 ) {
        if( m_iScrollPos != 0 ) SetScrollPos(0);
        cyScroll = 0;
    }
    // Scroll range changed?
    int cyOld1, cyOld2;
    m_pChildWindow->_GetScrollRange(SB_CTL, &cyOld1, &cyOld2);
    if( cyOld2 != cyScroll ) {
        m_pChildWindow->_SetScrollRange(SB_CTL, 0, cyScroll, FALSE);
        m_pChildWindow->_EnableScrollBar(SB_CTL, cyScroll == 0 ? ESB_DISABLE_BOTH : ESB_ENABLE_BOTH);
        m_pChildWindow->_SetScrollPos(SB_CTL, 0, TRUE);
    }
}

void XScroll::Init()
{
    ASSERT_VALID(m_pWindow);
    X_CreateObject(X_CLASS(XScrollWindow), (XObject**)&m_pChildWindow);
    m_pChildWindow->Init(this);
}

void XScroll::DestroyWindow()
{
    if (m_pChildWindow != NULL)
    {
        m_pChildWindow->_ShowWindow( SW_HIDE );
        m_pChildWindow->_PostMessage( WM_CLOSE );
        m_pChildWindow = NULL;
    }
}

void XScroll::EnableScrollColor( bool bEnable )
{
    if (m_pChildWindow == NULL || !m_pChildWindow->_IsWindow()) return;
    m_bAllowScrollColor = bEnable;
    m_pChildWindow->_InvalidateRect(NULL);
}

bool XScroll::EnableScrollColor() const
{
    return m_bAllowScrollColor;
}

void XScroll::SetScrollColor( COLORREF clrColor )
{
    m_clrScroll = clrColor;
}

COLORREF XScroll::GetScrollColor() const
{
    return m_clrScroll;
}

CONTROLS_END_NAMESPACE