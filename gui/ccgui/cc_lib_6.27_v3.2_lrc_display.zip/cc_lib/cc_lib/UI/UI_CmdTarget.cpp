#include "StdAfx.h"

UI_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS(XCmdTarget, XObject)

//////////////////////////////////////////////////////////////////////////

XCmdTarget::XCmdTarget():
    m_pParent(NULL),
    m_uStyle(0U),
    m_bMouseCapture(FALSE)
{
    ASSERT(m_hInstance && "Instance has not initialized! Try X_SetInstance().");
    m_lpszSuperClass = EmptyString;
    m_lpszWindowClass = EmptyString;
}

XCmdTarget::~XCmdTarget()
{

}

void* XCmdTarget::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_CMDTARGET: return this;
    }
    return XObject::GetInterface(hi);
}

#ifdef _DEBUG
void XCmdTarget::AssertValid() const
{
    XObject::AssertValid();
    ASSERT(m_hWnd);
    ASSERT(_IsWindow());
}
#endif // _DEBUG

void XCmdTarget::SetParent( XCmdTarget* pParent )
{
    m_pParent = pParent;
}

XCmdTarget* XCmdTarget::GetParent() const
{
    return m_pParent;
}

void XCmdTarget::SetIcon( UINT nRes )
{
    HICON hIcon = (HICON)::LoadImage(GetInstance(), MAKEINTRESOURCE(nRes), IMAGE_ICON, ::GetSystemMetrics(SM_CXICON), ::GetSystemMetrics(SM_CYICON), LR_DEFAULTCOLOR);
    ASSERT(hIcon);
    _SendMessage(WM_SETICON, (WPARAM) TRUE, (LPARAM) hIcon);
    hIcon = (HICON)::LoadImage(GetInstance(), MAKEINTRESOURCE(nRes), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
    ASSERT(hIcon);
    _SendMessage(WM_SETICON, (WPARAM) FALSE, (LPARAM) hIcon);
}

BOOL XCmdTarget::RegisterWindowClass()
{
    ASSERT(!m_lpszWindowClass.IsEmpty());
    WNDCLASS wc = { 0 };
    wc.style = m_uStyle;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hIcon = NULL;
    wc.lpfnWndProc = __WndProc;
    wc.hInstance = GetInstance();
    wc.hCursor = ::LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH) GetStockObject(BLACK_BRUSH); // Ĭ��Ϊ��
    wc.lpszMenuName  = NULL;
    wc.lpszClassName = m_lpszWindowClass;
    ATOM ret = ::RegisterClass(&wc);
    if (ret == 0)
    {
        if (::GetLastError() == ERROR_CLASS_ALREADY_EXISTS)
        {
            TRACE("Warning: Window class \"%s\" has been registered.", m_lpszWindowClass);
            return TRUE;
        }
        else
        {
            TRACE("Register Window class failed.");
            return FALSE;
        }
    }
    return TRUE;
}

BOOL XCmdTarget::RegisterSuperClass()
{
    // Get the class information from an existing
    // window so we can subclass it later on...
    WNDCLASSEX wc = { 0 };
    wc.cbSize = sizeof(WNDCLASSEX);
    if( !::GetClassInfoEx(NULL, m_lpszSuperClass, &wc) )
    {
        if( !::GetClassInfoEx(GetInstance(), m_lpszWindowClass, &wc) )
        {
            ASSERT(!"Unable to locate window class");
            return FALSE;
        }
    }
    m_OldWndProc = wc.lpfnWndProc;
    wc.lpfnWndProc = __ControlProc;
    wc.hInstance = GetInstance();
    wc.lpszClassName = m_lpszWindowClass;
    ATOM ret = ::RegisterClassEx(&wc);
    if (ret == 0)
    {
        if (::GetLastError() == ERROR_CLASS_ALREADY_EXISTS)
        {
            TRACE("Warning: Superclass \"%s\" has been registered.", m_lpszSuperClass);
            return TRUE;
        }
        else
        {
            TRACE("Register Superclass failed.");
            return FALSE;
        }
    }
    return TRUE;
}

HWND XCmdTarget::Create( HWND hwndParent, LPCTSTR pstrName, DWORD dwStyle, DWORD dwExStyle,
    const XRect rc, HMENU hMenu /*= NULL*/ )
{
    return Create(hwndParent, pstrName, dwStyle, dwExStyle, rc.left, rc.top, rc.Width(), rc.Height(), hMenu);
}

HWND XCmdTarget::Create( HWND hwndParent, LPCTSTR pstrName, DWORD dwStyle, DWORD dwExStyle,
    int x /*= CW_USEDEFAULT*/, int y /*= CW_USEDEFAULT*/, int cx /*= CW_USEDEFAULT*/,
    int cy /*= CW_USEDEFAULT*/, HMENU hMenu /*= NULL*/ )
{
    ASSERT(m_hWnd == NULL);
    if (!m_lpszSuperClass.IsEmpty())
    {
        if (!RegisterSuperClass())
        {
            return NULL;
        }
    }
    else
    {
        if (!RegisterWindowClass())
        {
            return NULL;
        }
    }

    // ���ΪPOPUP����ôĬ��CW_USEDEFAULTΪ������
    if ( (dwStyle & WS_POPUP) != 0 )
    {
        if ( (x == CW_USEDEFAULT) || (y == CW_USEDEFAULT) || (cx == CW_USEDEFAULT) || (cx == CW_USEDEFAULT))
        {
            ASSERT(!"�����ڷ����WS_POPUP������£�CW_USEDEFAULT������Ч��");
        }
    }

    // ����CreateWindowExʧ�ܣ���ô�����Ƿ�����SetDefaultFont������
    m_hWnd = ::CreateWindowEx(dwExStyle, m_lpszWindowClass, pstrName, dwStyle,
        x, y, cx, cy, hwndParent, hMenu, GetInstance(), this);
    ASSERT(m_hWnd);
    return m_hWnd;
}

void XCmdTarget::OnFinalMessage( HWND hWnd )
{

}

LPCTSTR XCmdTarget::GetWindowClassName() const
{
    return m_lpszWindowClass;
}

LPCTSTR XCmdTarget::GetSuperClassName() const
{
    return m_lpszSuperClass;
}

UINT XCmdTarget::GetClassStyle() const
{
    return 0U;
}

UI_END_NAMESPACE