#ifndef _CC_UI_SCROLL_WINDOW
#define _CC_UI_SCROLL_WINDOW

#pragma once

CONTROLS_BEGIN_NAMESPACE
class XList;
class XScroll;
CONTROLS_END_NAMESPACE

#define X_SCROLL_PROP (_T("XWndScroll"))
#define X_SCROLL_PAGE 40

#define GetIScroll(p) ((XScroll*)static_cast<XScroll*>((p)->GetInterface(HI_CONTAINER)))

WINDOW_BEGIN_NAMESPACE
using namespace UI;
using namespace Controls;
using namespace Window;
class XScrollWindow : public XCmdTarget, public IOwner<XScroll>, public IScrollBar, public IBkBrushImpl
{
    X_DECLARE_CLASS(XScrollWindow)
public:
    XScrollWindow();
    virtual ~XScrollWindow();

    virtual void Init( XScroll* pOwner );

    virtual LRESULT HandleMessage( UINT uMsg, WPARAM wParam, LPARAM lParam );
    virtual void OnFinalMessage( HWND hWnd );

    // IScroll
    BOOL _SetScrollPos( int nBar, int nPos, BOOL bRedraw );
    int  _GetScrollPos( int nBar );
    int  _SetScrollInfo( int nBar, LPCSCROLLINFO lpsi, BOOL redraw );
    BOOL _GetScrollInfo( int nBar, LPSCROLLINFO lpsi );
    BOOL _SetScrollRange( int nBar, int nMinPos, int nMaxPos, BOOL bRedraw );
    BOOL _GetScrollRange( int nBar, LPINT lpMinPos, LPINT lpMaxPos );
    BOOL _ShowScrollBar( int wBar, BOOL bShow );
    BOOL _EnableScrollBar( UINT wSBflags, UINT wArrows );
    BOOL _GetScrollBarInfo(LONG idObject, PSCROLLBARINFO psbi);
};
WINDOW_END_NAMESPACE

CONTROLS_BEGIN_NAMESPACE
class CL_API XScroll : public XControl, public IChildWindow<XScrollWindow>, public IScrollBarCtrl
{
    X_DECLARE_CLASS_WITH_PARA(XScroll)
public:
    XScroll(XObject* pOb = NULL);
    virtual ~XScroll();

    virtual void* GetInterface( UI::HINTERFACE hi );
    void Init();
    void DestroyWindow();

    virtual int GetScrollPos();
    virtual int GetScrollPage();
    virtual XSize GetScrollRange();
    virtual void SetScrollPos( int iPos );
    virtual void EnableScrollBar( bool bEnable = true );
    virtual BOOL AllowScrollBar() const;

    void EnableScrollColor( bool bEnable );
    bool EnableScrollColor() const;
    void SetScrollColor( COLORREF clrColor );
    COLORREF GetScrollColor() const;

protected:
    virtual void ProcessScrollbar( const XRect &, int cyRequired );

protected:
    bool m_bAllowScrollbars;
    int  m_iScrollPos;
    bool m_bAllowScrollColor;
    COLORREF m_clrScroll;
};
CONTROLS_END_NAMESPACE

#endif