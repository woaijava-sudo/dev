#include "stdafx.h"

UI_BEGIN_NAMESPACE
bool XExitManager::m_bInitialized;
//////////////////////////////////////////////////////////////////////////

XExitManager::XExitManager()
{
    ASSERT(!m_bInitialized && "Only can be initialized once.");
    m_bInitialized = true;
    m_delegate += MakeDelegate<XExitManager, XExitManager, LPARAM>(this, &XExitManager::DeleteObject);
    m_delegate += MakeDelegate<XExitManager, XExitManager, LPARAM>(this, &XExitManager::DeleteClassManager);
    _XAdv_Global_InitClass();
    XBuilder::_InitAttrMap();
    ::CoInitialize(NULL);
}

XExitManager::~XExitManager()
{
    m_delegate((void*)NULL);
    XBuilder::_ClearAttrMap();
    ::CoUninitialize();
}

void XExitManager::operator+=( XFunVoid lpfn )
{
    m_delegate += lpfn;
}

void XExitManager::operator+=( XDelegateBase& base )
{
    m_delegate += base;
}

bool XExitManager::DeleteClassManager( void*, LPARAM, WPARAM )
{
    _XAdv_Global_Release();
    return true;
}

bool XExitManager::DeleteObject( void*, LPARAM, WPARAM )
{
    for (int i = 0; i < m_delayDeletes.GetSize(); i++)
    {
        Safe_Delete_Object(static_cast<XObject*>(m_delayDeletes.Get(i)));
    }
    return true;
}

void XExitManager::DelayDeleteObject( XObject* pObj )
{
    m_delayDeletes.Add(pObj);
}

UI_END_NAMESPACE