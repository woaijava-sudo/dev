#ifndef _CC_UI_TEMPLATES_H
#define _CC_UI_TEMPLATES_H

#pragma once

#define API_TYPE CL_API

#define X_DECLARE_ConstructElements(name, TYPE)   void API_TYPE name##ConstructElements (TYPE* pElements, int nCount);
#define X_DECLARE_DestructElements(name, TYPE)    void API_TYPE name##DestructElements (TYPE* pElements, int nCount);
#define X_DECLARE_CopyElements(name, TYPE)        void API_TYPE name##CopyElements (TYPE* pDest, const TYPE* pSrc, int nCount);
#define X_DECLARE_CompareElements(name, TYPE, ARG_TYPE)  bool API_TYPE name##CompareElements (const TYPE* pElement1, const ARG_TYPE* pElement2);

#define X_DECLARE_ElementsOperations(name, TYPE) \
    X_DECLARE_ConstructElements(name, TYPE) \
    X_DECLARE_DestructElements(name, TYPE) \
    X_DECLARE_CopyElements(name, TYPE)

#define X_IMPLEMENT_ConstructElements(name, TYPE) \
void name##ConstructElements (TYPE* pElements, int nCount) \
{ \
    ASSERT(nCount == 0 || IsValidAddress(pElements, nCount * sizeof(TYPE))); \
    memset((void*)pElements, 0, nCount * sizeof(TYPE)); \
    for (; nCount--; pElements++) ::new((void*)pElements) TYPE; \
}

#define X_IMPLEMENT_DestructElements(name, TYPE) \
void name##DestructElements (TYPE* pElements, int nCount) \
{ \
    ASSERT(nCount == 0 || IsValidAddress(pElements, nCount * sizeof(TYPE))); \
    for (; nCount--; pElements++) pElements->~TYPE(); \
    }

#define X_IMPLEMENT_CopyElements(name, TYPE) \
void name##CopyElements (TYPE* pDest, const TYPE* pSrc, int nCount) \
{ \
    ASSERT(nCount == 0 || IsValidAddress(pDest, nCount * sizeof(TYPE))); \
    ASSERT(nCount == 0 || IsValidAddress(pSrc, nCount * sizeof(TYPE))); \
    while (nCount--) *pDest++ = *pSrc++; \
    }

#define X_IMPLEMENT_CompareElements(name, TYPE, ARG_TYPE) \
bool name##CompareElements (const TYPE* pElement1, const ARG_TYPE* pElement2) \
{ \
    ASSERT(IsValidAddress(pElement1, sizeof(TYPE), FALSE)); \
    ASSERT(IsValidAddress(pElement2, sizeof(ARG_TYPE), FALSE)); \
    return (TYPE)*pElement1 == (ARG_TYPE)*pElement2; \
    }

#define X_IMPLEMENT_ElementsOperations(name, TYPE) \
    X_IMPLEMENT_ConstructElements(name, TYPE) \
    X_IMPLEMENT_DestructElements(name, TYPE) \
    X_IMPLEMENT_CopyElements(name, TYPE)

#define ConstructElements(name, ...)    name##ConstructElements(__VA_ARGS__)
#define DestructElements(name, ...)     name##DestructElements(__VA_ARGS__)
#define CopyElements(name, ...)         name##CopyElements(__VA_ARGS__)
#define CompareElements(name, ...)         name##CompareElements(__VA_ARGS__)

UI_BEGIN_NAMESPACE
template<class T>
class IArrayAdv
{
public:
    virtual T*   GetData(int) const = 0;
    virtual int  Find(T*) const  = 0;
    virtual bool SetAt(T*, int)  = 0;
    virtual int  GetSize() const = 0;
    virtual int  Add(T*) = 0;
    virtual bool InsertAt(int, T*)  = 0;
    virtual bool Remove(T*) = 0;
    virtual bool RemoveAt(int)  = 0;
    virtual void RemoveAll() = 0;
};

#define X_LIST_NAME_T(name) I##name##Array_
#define X_IMPLEMENT_LIST_T(name) \
template<class T> \
class X_LIST_NAME_T(name) \
{ \
public: \
    virtual T*   name##_GetData(int) const = 0; \
    virtual int  name##_Find(T*) const  = 0;    \
    virtual bool name##_SetAt(T*, int)  = 0;    \
    virtual int  name##_GetSize() const = 0;    \
    virtual int  name##_Add(T*) = 0;            \
    virtual bool name##_InsertAt(int, T*)  = 0; \
    virtual bool name##_Remove(T*) = 0;         \
    virtual bool name##_RemoveAt(int)  = 0;     \
    virtual void name##_RemoveAll() = 0;        \
};

X_IMPLEMENT_LIST_T(List)
X_IMPLEMENT_LIST_T(Combo)

#define SAFE_RELEASE(p) {if(p) {(p)->Release(); (p) = NULL;}}

template< class T >
class XRelease
{
public:
    XRelease( T* p ) : m_p(p){ ASSERT(p); };
    ~XRelease() { Release(); };
    void Release() { SAFE_RELEASE(m_p); }
    T* Detach() { T* t = m_p; m_p = NULL; return t; };

protected:
    T* m_p;
};

template< class T >
class IOwner
{
public:
    IOwner(): m_pOwner(NULL) {}
    virtual void Init(T* pOwner) = 0;
protected:
    T* m_pOwner;
};

template< class T >
class IChildWindow
{
public:
    IChildWindow(): m_pChildWindow(NULL) {}
    T* GetChildWnd() { return m_pChildWindow; }
    void SetChildWnd(T* pWnd) { m_pChildWindow = pWnd; }
protected:
    T* m_pChildWindow;
};

template< class T >
class IChildWindow2
{
public:
    IChildWindow2(): m_pChildWindow2(NULL) {}
    T* GetChildWnd2() { return m_pChildWindow2; }
    void SetChildWnd2(T* pWnd) { m_pChildWindow2 = pWnd; }
protected:
    T* m_pChildWindow2;
};
UI_END_NAMESPACE

//////////////////////////////////////////////////////////////////////////

#define X_DECLARE_CLASS_ATTR(Classname, AttrType, Varible) \
class I##Classname \
{ \
public: \
    virtual void Set##Classname( AttrType Varible ) = 0; \
    virtual AttrType Get##Classname() const = 0; \
}; \
class CL_API I##Classname##Impl \
{ \
public: \
    I##Classname##Impl::I##Classname##Impl(); \
    virtual void Set##Classname( AttrType Varible ); \
    virtual AttrType Get##Classname() const; \
private: \
    AttrType m_##Varible; \
};

#define X_IMPLEMENT_CLASS_ATTR(Classname, AttrType, Varible) X_IMPLEMENT_CLASS_ATTR_VAL(Classname, AttrType, Varible, 0) 
#define X_IMPLEMENT_CLASS_ATTR_VAL(Classname, AttrType, Varible, DefaultVal) \
I##Classname##Impl::I##Classname##Impl(): m_##Varible(DefaultVal) {} \
void I##Classname##Impl::Set##Classname( AttrType Varible ) { m_##Varible = Varible; } \
AttrType I##Classname##Impl::Get##Classname() const { return m_##Varible; }

//////////////////////////////////////////////////////////////////////////

#define X_DECLARE_CLASS_BIN(Classname, AttrType, Varible) \
class I##Classname \
{ \
public: \
    virtual void Set##Classname( AttrType uAdd, AttrType uRemove = 0 ) = 0; \
    virtual AttrType Get##Classname() const = 0; \
}; \
class CL_API I##Classname##Impl \
{ \
public: \
    I##Classname##Impl::I##Classname##Impl(); \
    virtual void Set##Classname( AttrType uAdd, AttrType uRemove = 0 ); \
    virtual AttrType Get##Classname() const; \
protected: \
    AttrType m_##Varible; \
};

#define X_IMPLEMENT_CLASS_BIN(Classname, AttrType, Varible, AlignMask) X_IMPLEMENT_CLASS_BIN_VAL(Classname, AttrType, Varible, AlignMask, 0) 
#define X_IMPLEMENT_CLASS_BIN_VAL(Classname, AttrType, Varible, AlignMask, DefaultVal) \
    I##Classname##Impl::I##Classname##Impl(): m_##Varible(DefaultVal) {} \
    void I##Classname##Impl::Set##Classname( AttrType uAdd, AttrType uRemove ) { \
        static const AttrType uAlignMask = AlignMask; \
        m_##Varible |= (uAdd & uAlignMask); \
        m_##Varible &= ~(uRemove & uAlignMask); } \
    AttrType I##Classname##Impl::Get##Classname() const { return m_##Varible; }

//////////////////////////////////////////////////////////////////////////

#define X_DECLARE_CLASS_ABLE(Classname) \
class I##Classname \
{ \
public: \
    virtual void Enable##Classname( BOOL b##Classname = TRUE ) = 0; \
    virtual BOOL Enable##Classname() const = 0; \
}; \
class CL_API I##Classname##Impl \
{ \
public: \
    I##Classname##Impl::I##Classname##Impl(); \
    virtual void Enable##Classname( BOOL b##Classname = TRUE ); \
    virtual BOOL Enable##Classname() const; \
protected: \
    BOOL m_b##Classname; \
};

#define X_IMPLEMENT_CLASS_ABLE(Classname) X_IMPLEMENT_CLASS_ABLE_VAL(Classname, FALSE)
#define X_IMPLEMENT_CLASS_ABLE_VAL(Classname, InitialVal) \
    I##Classname##Impl::I##Classname##Impl(): m_b##Classname(InitialVal) {} \
    void I##Classname##Impl::Enable##Classname( BOOL b##Classname ) { m_b##Classname = b##Classname; } \
    BOOL I##Classname##Impl::Enable##Classname() const { return m_b##Classname; }

#endif