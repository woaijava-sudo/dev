#ifndef _CC_UI_CONTROL_INTERFACE_H
#define _CC_UI_CONTROL_INTERFACE_H

#pragma once

UI_BEGIN_NAMESPACE
namespace Window
{
    class XWindow;
}
using namespace Window;
using namespace Controls;

// Structure for events
typedef struct tagTEvent
{
    XWindow*    dispatcher;
    XControl*   sender;
    XControl*   receiver;
    MSG         msg;
} TEvent;

// Structure for fonts
typedef struct tagTFont
{
    ~tagTFont() { SAFE_DELETE(lpszFontName); }
    HFONT       hFont;
    XString*    lpszFontName;
    int         nSize;
    BOOL        bBold;
    BOOL        bUnderline;
    BOOL        bItalic;
    TEXTMETRIC  tm;
} TFont;

DEF_LIST_TEMPLATE1(TFont*);

#define GetIFont(p) ((IXFont*)(static_cast<IXFont*>(p)))

// Structure for image
typedef struct tagTImage
{
    HBITMAP        hBitmap;
    int            nX;
    int            nY;
    BOOL        alphaChannel;
    XString        sResType;
    DWORD        dwMask;
} TImage;

#define GetIImage(p) ((IXImage*)(static_cast<IXImage*>(p)))

// Event interface
class IEvent
{
public:
    virtual void Event(TEvent& event) = 0;
};

// Register interface
class IRegisterable
{
public:
    virtual void Register() = 0;
    virtual void Unregister() = 0;
};

// Font related interface
class IXFont
{
public:
    virtual XString         MakeFontHash(LPCTSTR szName, int nSize, BOOL bBold = FALSE, BOOL bUnderline = FALSE, BOOL bItalic = FALSE) = 0;
    virtual HFONT           GetFontByHash(XString& szHash) const = 0;
    virtual TFont*          GetFontInfoByHash(XString& szHash) const = 0;
    virtual BOOL            SetDefaultFont(LPCTSTR szName, int nSize, BOOL bBold = FALSE, BOOL bUnderline = FALSE, BOOL bItalic = FALSE) = 0;
    virtual BOOL            SetDefaultFont(TFont* pFont) = 0;
    virtual TFont*          GetDefaultFontInfo() const = 0;
    virtual BOOL            AddFontLink( LPCTSTR szLink, LPCTSTR szName, int nSize, BOOL bBold = FALSE, BOOL bUnderline = FALSE, BOOL bItalic = FALSE ) = 0;
    virtual BOOL            AddFont(LPCTSTR szName, int nSize, BOOL bBold = FALSE, BOOL bUnderline = FALSE, BOOL bItalic = FALSE) = 0;
    virtual HFONT           GetFont(LPCTSTR szName, int nSize, BOOL bBold = FALSE, BOOL bUnderline = FALSE, BOOL bItalic = FALSE) = 0;
    virtual TFont*          GetFontInfo(LPCTSTR szName, int nSize, BOOL bBold = FALSE, BOOL bUnderline = FALSE, BOOL bItalic = FALSE) = 0;
    virtual TFont*          GetFontLink(LPCTSTR szLink) = 0;
    virtual BOOL            RemoveFont(XString& szHash) = 0;
    virtual void            RemoveAllFonts() = 0;
    virtual int             GetFontCount() const = 0;
};

// Image related interface
class IXImage
{
public:
    virtual const TImage*   GetImage(LPCTSTR lpszImage) = 0;
    virtual const TImage*   GetImageEx(LPCTSTR lpszImage, DWORD dwMask = 0) = 0;
    virtual const TImage*   AddImage(LPCTSTR lpszImage, DWORD dwMask = 0) = 0;
    virtual const TImage*   AddImage(LPCTSTR lpszImage, HBITMAP hBitmap, int iWidth, int iHeight, BOOL bAlpha) = 0;
    virtual BOOL            RemoveImage(LPCTSTR lpszImage) = 0;
    virtual void            RemoveAllImages() = 0;
    virtual void            ReloadAllImages() = 0;
};
UI_END_NAMESPACE
//////////////////////////////////////////////////////////////////////////
CONTROLS_BEGIN_NAMESPACE
X_DECLARE_CLASS_ATTR(FixedWidth, int, cxFixedWidth)
X_DECLARE_CLASS_ATTR(FixedHeight, int, cyFixedHeight)
X_DECLARE_CLASS_BIN(TextStyle, UINT, uTextStyle)
X_DECLARE_CLASS_ABLE(HotTrack)
X_DECLARE_CLASS_ABLE(PrintBk)
X_DECLARE_CLASS_ABLE(ShowHtml)
X_DECLARE_CLASS_BIN(ButtonState, UINT, uButtonState)
X_DECLARE_CLASS_BIN(CalcPos, UINT, uCalcPos) // �Ű�λ��

//////////////////////////////////////////////////////////////////////////

CONTROLS_END_NAMESPACE
#endif

