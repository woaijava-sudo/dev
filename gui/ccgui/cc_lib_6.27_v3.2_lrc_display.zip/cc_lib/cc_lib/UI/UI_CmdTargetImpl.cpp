#include "StdAfx.h"

UI_BEGIN_NAMESPACE
XString ICmdTargetImpl::m_szResPath;
XString ICmdTargetImpl::m_szInstancePath;
HINSTANCE ICmdTargetImpl::m_hInstance;

short ICmdTargetImpl::m_L;
short ICmdTargetImpl::m_S;
short ICmdTargetImpl::m_H;

X_IMPLEMENT_CLASS_ATTR(BkBrush, HBRUSH, hBkBrush)
//////////////////////////////////////////////////////////////////////////

ICmdTargetImpl::ICmdTargetImpl(): m_bSubclassed(FALSE), m_OldWndProc(&::DefWindowProc)
{

}

void ICmdTargetImpl::GetHSL( short& H, short& S, short& L )
{
    H = m_H;
    S = m_S;
    L = m_L;
}

BOOL ICmdTargetImpl::Subclass( HWND hWnd )
{
    ASSERT(_IsWindow());
    m_OldWndProc = ((WNDPROC)::SetWindowLongPtr((hWnd), GWLP_WNDPROC, (LPARAM)(WNDPROC)(__WndProc)));
    if( m_OldWndProc == NULL ) return FALSE;
    m_bSubclassed = TRUE;
    m_hWnd = hWnd;
    return TRUE;
}

BOOL ICmdTargetImpl::UnSubclass()
{
    ASSERT(_IsWindow());
    if( _IsWindow() ) return FALSE;
    if( !m_bSubclassed ) return FALSE;
    ::SetWindowLongPtr((m_hWnd), GWLP_WNDPROC, (LPARAM)(WNDPROC)(m_OldWndProc));
    m_OldWndProc = ::DefWindowProc;
    m_bSubclassed = FALSE;
    return TRUE;
}

BOOL ICmdTargetImpl::IsSubclass() const
{
    return m_bSubclassed;
}

void ICmdTargetImpl::SetInstanceAndResPath( HINSTANCE hInstance, LPCTSTR lpszResPath )
{
    ASSERT(hInstance);
    m_hInstance = hInstance;

    // Set path
    ::GetModuleFileName(m_hInstance, m_szInstancePath.GetBuffer(MAX_PATH), MAX_PATH);
    m_szInstancePath.ReleaseBuffer();

    int iLoc = m_szInstancePath.ReverseFind(_T('\\'));
    ASSERT(iLoc != -1);
    m_szInstancePath = m_szInstancePath.Left(iLoc + 1);

    // res path like "Res\"

    m_szResPath = m_szInstancePath + lpszResPath;
}

XString ICmdTargetImpl::GetInstancePath()
{
    return m_szInstancePath;
}

HINSTANCE ICmdTargetImpl::GetInstance()
{
    ASSERT(m_hInstance);
    return m_hInstance;
}

XString ICmdTargetImpl::GetResourcePath()
{
    return m_szResPath;
}

LRESULT ICmdTargetImpl::HandleMessage( UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    return ::CallWindowProc(m_OldWndProc, m_hWnd, uMsg, wParam, lParam);
}

LRESULT CALLBACK ICmdTargetImpl::__WndProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    static MSG msg;
    msg.hwnd = hWnd;
    msg.message = uMsg;
    msg.lParam = lParam;
    msg.wParam = wParam;

    static XCmdTarget* pThis = NULL;
    static XWindowImpl window;
    window.Attach(hWnd);
    pThis = reinterpret_cast<XCmdTarget*>(window._GetWindowLongPtr(GWLP_USERDATA));

#ifdef _DEBUG
    TraceMsg_T(_T("WndProc"), &msg, pThis);
#endif // _DEBUG

    if( uMsg == WM_NCCREATE )
    {
        LPCREATESTRUCT lpcs = reinterpret_cast<LPCREATESTRUCT>(lParam);
        pThis = static_cast<XCmdTarget*>(lpcs->lpCreateParams);
        pThis->m_hWnd = hWnd;
        window._SetWindowLongPtr(GWLP_USERDATA, reinterpret_cast<LPARAM>(pThis));
    } 
    else
    {
        if( uMsg == WM_NCDESTROY && pThis != NULL )
        {
            LRESULT lRes = window._CallWindowProc(pThis->m_OldWndProc, uMsg, wParam, lParam);
            ::SetWindowLongPtr(pThis->m_hWnd, GWLP_USERDATA, 0L);
            if( pThis->IsSubclass() ) pThis->UnSubclass();
            pThis->OnFinalMessage(hWnd);
            pThis = NULL;
            return lRes;
        }
    }

    if( pThis != NULL )
    {
        return pThis->HandleMessage(uMsg, wParam, lParam);
    } 
    else
    {
        return window._DefWindowProc(uMsg, wParam, lParam);
    }
}

LRESULT CALLBACK ICmdTargetImpl::__ControlProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    static MSG msg;
    msg.hwnd = hWnd;
    msg.message = uMsg;
    msg.lParam = lParam;
    msg.wParam = wParam;

    static XCmdTarget* pThis = NULL;
    static XWindowImpl window;
    window.Attach(hWnd);
    pThis = reinterpret_cast<XCmdTarget*>(window._GetProp(X_CONTROL_WINDOW_PROP));

#ifdef _DEBUG
    TraceMsg_T(_T("CtrlProc"), &msg, pThis);
#endif // _DEBUG

    if( uMsg == WM_NCCREATE )
    {
        LPCREATESTRUCT lpcs = reinterpret_cast<LPCREATESTRUCT>(lParam);
        pThis = static_cast<XCmdTarget*>(lpcs->lpCreateParams);
        window._SetProp(X_CONTROL_WINDOW_PROP, static_cast<HANDLE>(pThis));
        pThis->m_hWnd = hWnd;
    }
    else
    {
        if( uMsg == WM_NCDESTROY && pThis != NULL )
        {
            LRESULT lRes = window._CallWindowProc(pThis->m_OldWndProc, uMsg, wParam, lParam);
            if( pThis->IsSubclass() ) pThis->UnSubclass();
            window._SetProp(X_CONTROL_WINDOW_PROP, NULL);
            pThis->OnFinalMessage(hWnd);
            return lRes;
        }
    }

    if( pThis != NULL )
    {
        return pThis->HandleMessage(uMsg, wParam, lParam);
    }
    else
    {
        return window._DefWindowProc(uMsg, wParam, lParam);
    }
}

UI_END_NAMESPACE