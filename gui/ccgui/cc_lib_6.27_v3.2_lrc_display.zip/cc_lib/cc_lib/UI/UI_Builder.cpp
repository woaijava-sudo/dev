#include "stdafx.h"

UI_BEGIN_NAMESPACE
Dictionary<XString, DWORD, LPCTSTR> XBuilder::m_mapAttributes;

XBuilder::XBuilder(): m_pWindow(NULL)
{
    m_IAdvCreate = _XAdv_Global_GetClassManager();
}

const XMarkup* XBuilder::GetMarkup() const
{
    return &m_Xml;
}

XString XBuilder::GetLastErrorMessage() const
{
    return m_Xml.GetLastErrorMessage();
}

XControl* XBuilder::CreateFromFile( LPCTSTR lpszSrc, XWindow* pWindow, int encoding /*= XMarkup::XMLFILE_ENCODING_UTF8*/, XControl* pParent /*= NULL*/ )
{
    ASSERT(lpszSrc);
    ASSERT_VALID(pWindow);
    m_pWindow = pWindow;
    if( !m_Xml.LoadFromFile(lpszSrc, encoding) ) return NULL;

    return _ParseXml(pParent);
}

XControl* XBuilder::CreateFromString( LPCTSTR lpszXml, XWindow* pWindow, XControl* pParent /*= NULL */ )
{
    ASSERT(lpszXml);
    ASSERT_VALID(pWindow);
    m_pWindow = pWindow;
    if( !m_Xml.LoadFromString(lpszXml) ) return NULL;

    return _ParseXml(pParent);
}

XControl* XBuilder::_ParseXml( XControl* pParent /*= NULL*/ )
{
    ASSERT(!m_Xml.IsNull() && "Error message? Its path? Encoding?");

    XMarkupNode _Root = m_Xml.GetRoot();
    if( !_Root.IsValid() ) return NULL;

    // Work before parse
    // Deal with sth like "<X .../>"
    // 'X...' must be located in the head

    for( XMarkupNode _Node = _Root.GetChild(); _Node.IsValid(); _Node = _Node.GetSibling() )
    {
        XString pstrClass = _Node.GetName();

        if (pstrClass == _T("X"))
        {
            if( _Node.HasAttributes() ) {
                int nAttributes = _Node.GetAttributeCount();
                for( int i = 0; i < nAttributes; i++ ) {
                    XString pstrName = _Node.GetAttributeName(i);
                    XString pstrValue = _Node.GetAttributeValue(i);
                    
                    // Set default settings
                    if (pstrName == _T("Font")) {
                        _ParseDefaultFont(m_pWindow, pstrValue);
                    } else if (pstrName == _T("MinSize")) {
                        m_pWindow->SetMinSize(_ParseSize(pstrValue));
                    } else if (pstrName == _T("MaxSize")) {
                        m_pWindow->SetMaxSize(_ParseSize(pstrValue));
                    }
                }
            }
        }
    }

    return _CreateFromXml(&_Root, pParent);
}
UI_END_NAMESPACE