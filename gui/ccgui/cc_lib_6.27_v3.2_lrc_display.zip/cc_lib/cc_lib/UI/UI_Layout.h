#ifndef _CC_UI_LAYOUT_H
#define _CC_UI_LAYOUT_H

#pragma once

#define GetIHorizontalLayout(p) ((XHorizontalLayout*)static_cast<XHorizontalLayout*>(p->GetInterface(HI_HORIZONTAL_LAYOUT)))
#define GetIVerticalLayout(p) ((XVerticalLayout*)static_cast<XVerticalLayout*>(p->GetInterface(HI_VERTICAL_LAYOUT)))

//////////////////////////////////////////////////////////////////////////
CONTAINER_BEGIN_NAMESPACE
class CL_API XHorizontalLayout : public XContainer
{
    X_DECLARE_CLASS_WITH_PARA(XHorizontalLayout)
public:
    XHorizontalLayout(XObject* pOb = NULL);
    virtual ~XHorizontalLayout();

    virtual void* GetInterface( HINTERFACE hi );
    virtual void SetRect(const XRect &); // �˺����������������Ա�Ĵ�С
};

//////////////////////////////////////////////////////////////////////////

class CL_API XVerticalLayout : public XContainer
{
    X_DECLARE_CLASS_WITH_PARA(XVerticalLayout)
public:
    XVerticalLayout(XObject* pOb = NULL);
    virtual ~XVerticalLayout();

    virtual void* GetInterface( HINTERFACE hi );
    virtual void SetRect(const XRect &); // �˺����������������Ա�Ĵ�С
};

//////////////////////////////////////////////////////////////////////////
CONTAINER_END_NAMESPACE
#endif
