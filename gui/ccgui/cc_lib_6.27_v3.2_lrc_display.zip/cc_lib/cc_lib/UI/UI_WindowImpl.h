#ifndef _CC_UI_WINDOW_IMPL_H
#define _CC_UI_WINDOW_IMPL_H

#pragma once

#include "UI_WindowInterface.h"

#define GetIWindow(p) ((IWindow*)(static_cast<IWindow*>((p)->GetInterface(HI_WINDOW))))
#define GetIWindowEx(p) ((XWindow*)(static_cast<XWindow*>((p)->GetInterface(HI_WINDOW_EX))))
#define X_CONTROL_WINDOW_PROP _T("XCtrlWnd")

WINDOW_BEGIN_NAMESPACE
class CL_API XWindowImpl : public IWindow
{
public:
    XWindowImpl(HWND hwnd = NULL);

    // Window functions
    // ���»��ߵĶ���hwndĬ�ϲ�����ʡ�ԣ�
    HWND GetSafeHwnd() const;
    HWND Attach(HWND hwnd);
    int  _GetClassName(LPTSTR lpClassName, int nMaxCount);

    HICON _SetIcon(HICON hIcon, BOOL bBigIcon);
    HICON _GetIcon(BOOL bBigIcon) const;

    BOOL _SetProp(LPCTSTR lpString, HANDLE hData);
    HANDLE _GetProp(LPCTSTR lpString);
    HANDLE _RemoveProp(LPCTSTR lpString);
    int  _EnumProps(PROPENUMPROC lpEnumFunc);
    int  _EnumPropsEx(PROPENUMPROCEX lpEnumFunc, LPARAM lParam);

    BOOL _ShowWindow(int nCmdShow);
    BOOL _MoveWindow(int X, int Y, int nWidth, int nHeight, BOOL bRepaint);
    BOOL _EnableWindow(BOOL bEnable);
    BOOL _CloseWindow();
    BOOL _CenterWindow();
    BOOL _UpdateWindow();

    HDC  _BeginPaint(PAINTSTRUCT& ps);
    BOOL _EndPaint(PAINTSTRUCT& ps);
    HDC  _GetDC();
    int  _ReleaseDC(HDC hDC);

    BOOL _InvalidateRect(XRect* pRect, BOOL bErase = FALSE);
    BOOL _GetWindowRect(XRect& rc);
    BOOL _GetClientRect(XRect& rc);
    BOOL _GetUpdateRect(XRect& rc, BOOL bErase = FALSE);
    BOOL _GetCursorPos(LPPOINT lpPoint);
    BOOL _ClientToScreen(LPPOINT lpPoint);
    BOOL _ScreenToClient(LPPOINT lpPoint);
    LONG _GetWindowLong(int nIndex);
    LONG_PTR _SetWindowLongPtr(int nIndex, LONG_PTR dwNewLong);
    LONG_PTR _GetWindowLongPtr(int nIndex);
    HWND _GetDlgItem(int nIDDlgItem);
    LONG _GetWindowStyle();
    HWND _GetParent();
    HWND _GetWindow(UINT nCmd);
    HWND _GetWindowOwner();
    HWND _SetFocus();
    HWND _GetFocus();
    BOOL _IsWindow() const;
    BOOL _IsWindowVisible();
    BOOL _SetWindowPos(HWND hWndInsertAfter, int X, int Y, int cx, int cy, UINT uFlags);
    void _SetWindowFont(HFONT hFont, BOOL bRedraw);
    HFONT _GetWindowFont();
    BOOL _SetWindowText(LPCTSTR lpString);
    int  _GetWindowText(LPTSTR lpString, int nMaxCount);
    int  _GetWindowTextLength();
    BOOL _CreateCaret(HBITMAP hBitmap, int nWidth, int nHeight);
    BOOL _ShowCaret();
    BOOL _HideCaret();
    BOOL _SetCaretPos(int X, int Y);

    int  _MessageBox( LPCTSTR lpText, LPCTSTR lpCaption, UINT uType );

    LRESULT _SendMessage(UINT uMsg, WPARAM wParam = 0U, LPARAM lParam = 0L) const;
    LRESULT _PostMessage(UINT uMsg, WPARAM wParam = 0U, LPARAM lParam = 0L) const;

    LRESULT _DefWindowProc(UINT Msg, WPARAM wParam, LPARAM lParam);
    LRESULT _CallWindowProc(WNDPROC lpPrevWndFunc, UINT Msg, WPARAM wParam, LPARAM lParam);

protected:
    HWND m_hWnd; // ������
};

WINDOW_END_NAMESPACE
#endif