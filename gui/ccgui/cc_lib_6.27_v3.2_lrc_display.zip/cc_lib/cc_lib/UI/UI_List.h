#ifndef _CC_UI_LIST_H
#define _CC_UI_LIST_H

#pragma once

#define XLIST_MAX_COLUMNS 12
#define MIN_DRAGSIZE 40

CONTROLS_BEGIN_NAMESPACE
class IListAdv;
class IListItem;
class IListOwner;

class XList;
class XListElement;
class XListTextElement;
class XListLabelElement;
class XListHeader;
class XListHeaderItem;
class XListFooter;
class XListFooterItem;

class XCombo;

#define XLIST_TEXT_ELEMENT_DEFAULT_STYLE ( DT_VCENTER | DT_NOPREFIX | DT_END_ELLIPSIS )

#define GetIList(p) ((IListAdv*)(static_cast<IListAdv*>((p)->GetInterface(HI_LIST))))
#define GetIListEx(p) ((XList*)(static_cast<XList*>((p)->GetInterface(HI_LIST_EX))))
#define GetIListItem(p) ((IListItem*)(static_cast<IListItem*>((p)->GetInterface(HI_LIST_ITEM))))
#define GetIListOwner(p) ((IListOwner*)(static_cast<IListOwner*>((p)->GetInterface(HI_LIST_OWNER))))
#define GetIListArray(p) ((IListArray*)(static_cast<IListArray*>((p)->GetInterface(HI_LIST_ARRAY))))

#define GetIListHeader(p) ((XListHeader*)(static_cast<XListHeader*>((p)->GetInterface(HI_LIST_HEADER))))
#define GetIListHeaderItem(p) ((XListHeaderItem*)(static_cast<XListHeaderItem*>((p)->GetInterface(HI_LIST_HEADER_ITEM))))
#define GetIListFooter(p) ((XListFooter*)(static_cast<XListFooter*>((p)->GetInterface(HI_LIST_FOOTER))))
#define GetIListFooterItem(p) ((XListFooterItem*)(static_cast<XListFooterItem*>((p)->GetInterface(HI_LIST_FOOTER_ITEM))))

#define GetIListTextElement(p) ((XListTextElement*)(static_cast<XListTextElement*>((p)->GetInterface(HI_LIST_TEXT_ELEMENT))))
#define GetIListLabel(p) ((IListLabel*)(static_cast<IListLabel*>((p)->GetInterface(HI_LIST_LABEL))))
#define GetIListLabelElement(p) ((XListLabelElement*)(static_cast<XListLabelElement*>((p)->GetInterface(HI_LIST_LABEL_ELEMENT))))

//////////////////////////////////////////////////////////////////////////

struct TListInfo
{
    int                         nColumns;
    XRect                       rcColumn[XLIST_MAX_COLUMNS];
    COLORREF                    Text;
    COLORREF                    Background;
    COLORREF                    SelText;
    COLORREF                    SelBackground;
    COLORREF                    HotText;
    COLORREF                    HotBackground;
};

//////////////////////////////////////////////////////////////////////////

class IListScroll
{
public:
    virtual void                EnsureVisible( int iIndex ) = 0;
    virtual void                Scroll( int dx, int dy ) = 0;
};

class IListSelect
{
public:
    virtual int                 GetCurSel() const = 0;
    virtual bool                SelectItem( int iIndex ) = 0;
    virtual void                ListEvent( TEvent& event ) = 0;
};

class IListOwner : public IListScroll, public IListSelect
{
public:
    virtual const TListInfo*    GetListInfo() const = 0;
};

class IListLabel
{
public:
    virtual void                SetCombo( XCombo* ) = 0;
};

class IListAdv : public IListOwner
{
public:
    virtual XListHeader*        GetHeader() const = 0;
    virtual XListFooter*        GetFooter() const = 0; 
    virtual XContainer*         GetList() const = 0;
    virtual BOOL                IsAlwaysFocus() const = 0; // �Ƿ�ʼ����ʾѡ����
    virtual void                EnableAlwaysFocus(BOOL) = 0;
};

class IListItem
{
public:
    virtual int                 GetIndex() const = 0;
    virtual void                SetIndex( int iIndex ) = 0;
    virtual void                SetText( int iIndex, XString strText ) = 0;
    virtual XString             GetText( int iIndex ) const = 0;
    virtual void                SetListOwner( IListOwner* pOwner ) = 0;
    virtual bool                IsSelected() const = 0;
    virtual bool                Select( bool bSelect = true ) = 0;
};

class IListArray : public X_LIST_NAME_T(List)<XControl> {};

//////////////////////////////////////////////////////////////////////////

class CL_API XList : public XVerticalLayout, public IListAdv, public IListArray
{
    X_DECLARE_CLASS_WITH_PARA(XList);
public:
    XList(XObject* pOb = NULL);

    virtual UINT                GetControlFlags() const;
    virtual void*               GetInterface( HINTERFACE hi );

    virtual XControl*           CreateControl(XClass* pClass);

    // IListOwner
    int                         GetCurSel() const;
    bool                        SelectItem( int iIndex );
    void                        ListEvent( TEvent& event );
    void                        EnsureVisible( int iIndex );
    void                        Scroll( int dx, int dy );

    // IListAdv
    XListHeader*                GetHeader() const;
    XListFooter*                GetFooter() const;   
    XContainer*                 GetList() const;
    const TListInfo*            GetListInfo() const;
    BOOL                        IsAlwaysFocus() const;
    void                        EnableAlwaysFocus( BOOL );

    // IListArray<>
    XControl*                   List_GetData( int ) const;
    int                         List_Find( XControl* ) const;
    bool                        List_SetAt( XControl*, int );
    int                         List_GetSize() const;
    int                         List_Add( XControl* );
    bool                        List_InsertAt( int, XControl* );
    bool                        List_Remove( XControl* );
    bool                        List_RemoveAt( int );
    void                        List_RemoveAll();

    // Others
    virtual void                SetRect( const XRect & );
    virtual void                SetOwner( XWindow* );
    virtual void                SetParent( XControl* );

    virtual void                Event( TEvent& event );
    virtual void                Paint( HDC hDC, const XRect& rect );

    void                        RollingToEnd(); // �ڴ�������ʱ����Ƶ������
    void                        RollingToTop(); // �ڴ�������ʱ����Ƶ������

protected:
    int                         m_iCurSel;
    XVerticalLayout*            m_pList;
    XListHeader*                m_pHeader;
    XListFooter*                m_pFooter;
    TListInfo                   m_ListInfo;
    BOOL                        m_bAlwaysShowFocus;
};

class CL_API XListElement : public XLabel, public IListItem
{
    X_DECLARE_CLASS_WITH_PARA(XListElement);
public:
    XListElement(XObject* pOb = NULL);
    virtual ~XListElement();

    virtual void*               GetInterface( HINTERFACE hi );

    // IListItem
    virtual int                 GetIndex() const;
    virtual void                SetIndex( int iIndex );
    virtual void                SetText( int iIndex, XString strText );
    virtual XString             GetText( int iIndex ) const;
    virtual void                SetListOwner( IListOwner* pOwner );
    virtual bool                IsSelected() const;
    virtual bool                Select( bool bSelect = true );

    // Others
    virtual BOOL                Activate();
    virtual void                Event( TEvent& event );
    virtual XRect               GetRect() const;

protected:
    int                         m_iIndex;
    List<XString, LPCTSTR>      m_aString;
    bool                        m_bSelected;
    IListOwner*                 m_pOwner;
};

class CL_API XListTextElement : public XListElement, public IButtonStateImpl
{
    X_DECLARE_CLASS_WITH_PARA(XListTextElement);
public:
    XListTextElement(XObject* pOb = NULL);

    virtual void*               GetInterface( HINTERFACE hi );

    virtual void                Event( TEvent& event );
    virtual void                Paint( HDC hDC, const XRect& rcPaint );

    virtual void                SetFixedWidth( int );
    virtual XSize               EstimateSize( const XSize& );

    virtual void                SetTextStyle( UINT uAdd, UINT uRemove = 0 );
};

class CL_API XListLabelElement : public XListTextElement, public IListLabel
{
    X_DECLARE_CLASS_WITH_PARA(XListLabelElement);
public:
    XListLabelElement(XObject* pOb = NULL);

    virtual void*               GetInterface( HINTERFACE hi );
    virtual void                Paint( HDC hDC, const XRect& rcPaint );

    void                        SetCombo( XCombo* );
    virtual void                SetRect( const XRect & );
    virtual void                Event( TEvent& event );

protected:
    XCombo*                     m_pCombo;
};

class CL_API XListHeader : public XHorizontalLayout
{
    X_DECLARE_CLASS_WITH_PARA(XListHeader);
public:
    XListHeader(XObject* pOb = NULL);

    virtual void*               GetInterface( HINTERFACE hi );
    virtual void                Paint( HDC hDC, const XRect& rcPaint );

    bool                        AllowFixedWidth( LONG iAdd );
    virtual XSize               EstimateSize( const XSize& );
};

class CL_API XListHeaderItem : public XLabel
{
    X_DECLARE_CLASS_WITH_PARA(XListHeaderItem);
public:
    XListHeaderItem(XObject* pOb = NULL);

    virtual void*               GetInterface( HINTERFACE hi );

    virtual void                SetText( LPCTSTR pstrText );
    virtual void                Event( TEvent& event );
    virtual void                Paint( HDC hDC, const XRect& rcPaint );
    XRect                       GetThumbRect( const XRect & ) const;

    virtual XSize               EstimateSize( const XSize& );

    XSize                       CalcSize();

    virtual void                SetFixedWidth( int cxFixedWidth );

protected:
    XPoint                      m_ptLastMouse;
    UINT                        m_uDragState;
};

class CL_API XListFooter : public XHorizontalLayout
{
    X_DECLARE_CLASS_WITH_PARA(XListFooter);
public:
    XListFooter(XObject* pOb = NULL);

    virtual void*               GetInterface( HINTERFACE hi );
    virtual void                Paint( HDC hDC, const XRect& rcPaint );

    virtual XSize               EstimateSize( const XSize& );
};

class CL_API XListFooterItem : public XLabel
{
    X_DECLARE_CLASS_WITH_PARA(XListFooterItem);
public:
    XListFooterItem(XObject* pOb = NULL);

    virtual void*               GetInterface( HINTERFACE hi );
    virtual void                SetText( LPCTSTR pstrText );
    virtual XSize               EstimateSize( const XSize& );
};

CONTROLS_END_NAMESPACE

#endif