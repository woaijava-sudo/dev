#ifndef _CC_UI_EXIT_MANAGER_H
#define _CC_UI_EXIT_MANAGER_H

#pragma once

#include "UI_Object.h"

UI_BEGIN_NAMESPACE
using namespace cc::Collections;
using namespace cc::Ptr;

/************************************************************************/
/* No Parameter Exit Delegate                                           */
/************************************************************************/
class CL_API XExitManager
{
public:
    XExitManager();
    ~XExitManager();

    void operator += (XFunVoid);
    void operator += (XDelegateBase&);

    void DelayDeleteObject(XObject*);

protected:
    bool DeleteClassManager(void*, LPARAM, WPARAM);
    bool DeleteObject(void*, LPARAM, WPARAM);

private:
    XEventSource    m_delegate;
    List<XObject*>  m_delayDeletes;
    static bool     m_bInitialized;
};

UI_END_NAMESPACE
#endif