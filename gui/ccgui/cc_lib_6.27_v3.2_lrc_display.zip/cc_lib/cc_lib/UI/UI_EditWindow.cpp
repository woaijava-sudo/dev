#include "stdafx.h"

WINDOW_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS(XEditWindow, XCmdTarget)

//////////////////////////////////////////////////////////////////////////

XEditWindow::XEditWindow()
{
    m_lpszSuperClass = WC_EDIT;
    m_lpszWindowClass = _T("XEditWindow");
}

XEditWindow::~XEditWindow()
{

}

void XEditWindow::Init( XEdit* pOwner )
{
    XWindow* pWnd = pOwner->GetOwner();
    ASSERT_VALID(pWnd);
    m_pOwner = pOwner;
    CalcRect();
    UINT uStyle = WS_CHILD |  pOwner->GetEditStyle();
    Create(pWnd->GetSafeHwnd(), NULL, uStyle, 0, m_rcPos);
    _SetWindowFont(pOwner->GetTextFont(), TRUE);
    SetLimitText(pOwner->GetMaxCharLength());
    if( pOwner->IsPassword() ) SetPasswordChar(pOwner->GetPasswordMask());
    _SetWindowText(GetILabel(pOwner)->GetText());
    SetModify(FALSE);
    if (pOwner->IsEnabled()) _EnableWindow(TRUE);
    if (pOwner->IsReadOnly()) SetReadOnly(TRUE);
    if (pOwner->IsVisible()) _ShowWindow(SW_SHOWNOACTIVATE);
    _SetFocus();
}

void XEditWindow::CalcRect()
{
    XRect rcPos = m_pOwner->GetRect();
//     XRect rcInset = m_pOwner->GetTextPadding();
//     rcPos.InsetRect(rcInset);

    LONG lEditHeight = m_pOwner->GetTextFontInfo()->tm.tmHeight;
    if( lEditHeight < rcPos.Height() )
    {
        rcPos.top += (rcPos.Height() - lEditHeight) / 2;
        rcPos.bottom = rcPos.top + lEditHeight;
    }
    m_rcPos = rcPos;
}

XRect XEditWindow::GetRect() const
{
    return m_rcPos;
}

void XEditWindow::OnFinalMessage( HWND hWnd )
{
    if( GetBkBrush() != NULL ) ::DeleteObject(GetBkBrush());
    m_pOwner->SetChildWnd(NULL);
    Safe_Delete_Object(this);
}

LRESULT XEditWindow::HandleMessage( UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    LRESULT lRes = 0;
    BOOL bHandled = TRUE;
    switch (uMsg)
    {
    case WM_KILLFOCUS:
        return OnKillFocus(uMsg, wParam, lParam);
    case OCM_COMMAND:
        switch ( HIWORD(wParam) )
        {
        case EN_CHANGE:
            return OnEditChanged(uMsg, wParam, lParam);
            break;
        case EN_UPDATE:
            {
                XRect rcClient;
                _GetClientRect(rcClient);
                _InvalidateRect(&rcClient, TRUE);
            }
            break;
        case EN_ERRSPACE:
            _SetWindowText(_T(""));
            break;
        }
        break;
    case WM_CONTEXTMENU:
        break;
    case WM_KEYDOWN:
        {
            UINT uKey = m_pOwner->GetOwner()->MapState();
            switch ( wParam )
            {
            case VK_RETURN:
                m_pOwner->GetOwner()->SendAsyncNotify(m_pOwner, (DWORD) _T("EditReturn"), TRUE);
                if ((m_pOwner->GetFlags() & XFLAG_AUTOCLEAR) != 0)
                    _SetWindowText(_T(""));
                break;
            default:
                bHandled = FALSE;
            }
        }
        break;
    case OCM_CTLCOLOREDIT:
    case OCM_CTLCOLORSTATIC:
        ASSERT_VALID(m_pOwner);
        ::SetTextColor((HDC)wParam, GetRGB(m_pOwner->GetTextColor()));
        ::SetBkColor((HDC)wParam, GetRGB(m_pOwner->GetEditBkColor()));
        if( GetBkBrush() == NULL ) {
            if( m_pOwner->GetEditBkColor() == CLR_INVALID ) {
                SetBkBrush(::CreateSolidBrush(XCOLOR_EDIT_BACKGROUND_NORMAL));
            } else {
                SetBkBrush(::CreateSolidBrush(GetRGB(m_pOwner->GetEditBkColor())));
            }
        }
        return (LRESULT) GetBkBrush();
    default:
        bHandled = FALSE;
    }

    if ( !bHandled )
    {
        return XCmdTarget::HandleMessage(uMsg, wParam, lParam);
    }
    else
    {
        return lRes;
    }
}

LRESULT XEditWindow::OnKillFocus( UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    LRESULT lRes = _DefWindowProc(uMsg, wParam, lParam);
    _PostMessage( WM_CLOSE );
    return lRes;
}

LRESULT XEditWindow::OnEditChanged( UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    if( m_pOwner == NULL ) return 0;
    int cchLen = _GetWindowTextLength() + 1;
    LPTSTR pstr = static_cast<LPTSTR>(malloc(cchLen * sizeof(TCHAR)));
    ASSERT(pstr);
    if( pstr == NULL ) return 0;
    _GetWindowText(pstr, cchLen);
    GetILabel(m_pOwner)->SetText(pstr);
    m_pOwner->GetOwner()->SendAsyncNotify(m_pOwner, (DWORD) _T("EditChanged"), TRUE);
    free(pstr);
    return 0;
}

//////////////////////////////////////////////////////////////////////////

BOOL XEditWindow::CanUndo() const
{ ASSERT(_IsWindow()); return (BOOL)_SendMessage(EM_CANUNDO, 0, 0); }
int XEditWindow::GetLineCount() const
{ ASSERT(_IsWindow()); return (int)_SendMessage(EM_GETLINECOUNT, 0, 0); }
BOOL XEditWindow::GetModify() const
{ ASSERT(_IsWindow()); return (BOOL)_SendMessage(EM_GETMODIFY, 0, 0); }
void XEditWindow::SetModify(BOOL bModified)
{ ASSERT(_IsWindow()); _SendMessage(EM_SETMODIFY, bModified, 0); }
void XEditWindow::GetRect(LPRECT lpRect) const
{ ASSERT(_IsWindow()); _SendMessage(EM_GETRECT, 0, (LPARAM)lpRect); }
void XEditWindow::GetSel(int& nStartChar, int& nEndChar) const
{ ASSERT(_IsWindow()); _SendMessage(EM_GETSEL, (WPARAM)&nStartChar,(LPARAM)&nEndChar); }
DWORD XEditWindow::GetSel() const
{ ASSERT(_IsWindow()); return _SendMessage(EM_GETSEL, 0, 0); }
HLOCAL XEditWindow::GetHandle() const
{ ASSERT(_IsWindow()); return (HLOCAL)_SendMessage(EM_GETHANDLE, 0, 0); }
void XEditWindow::SetHandle(HLOCAL hBuffer)
{ ASSERT(_IsWindow()); _SendMessage(EM_SETHANDLE, (WPARAM)hBuffer, 0); }
int XEditWindow::GetLine(int nIndex, LPTSTR lpszBuffer) const
{ ASSERT(_IsWindow()); return (int)_SendMessage(EM_GETLINE, nIndex, (LPARAM)lpszBuffer); }
int XEditWindow::GetLine(int nIndex, LPTSTR lpszBuffer, int nMaxLength) const
{
    ASSERT(_IsWindow());
    *(LPWORD)lpszBuffer = (WORD)nMaxLength;
    return (int)_SendMessage(EM_GETLINE, nIndex, (LPARAM)lpszBuffer);
}
void XEditWindow::EmptyUndoBuffer()
{ ASSERT(_IsWindow()); _SendMessage(EM_EMPTYUNDOBUFFER, 0, 0); }
BOOL XEditWindow::FmtLines(BOOL bAddEOL)
{ ASSERT(_IsWindow()); return (BOOL)_SendMessage(EM_FMTLINES, bAddEOL, 0); }
void XEditWindow::LimitText(int nChars)
{ ASSERT(_IsWindow()); _SendMessage(EM_LIMITTEXT, nChars, 0); }
int XEditWindow::LineFromChar(int nIndex) const
{ ASSERT(_IsWindow()); return (int)_SendMessage(EM_LINEFROMCHAR, nIndex, 0); }
int XEditWindow::LineIndex(int nLine) const
{ ASSERT(_IsWindow()); return (int)_SendMessage(EM_LINEINDEX, nLine, 0); }
int XEditWindow::LineLength(int nLine) const
{ ASSERT(_IsWindow()); return (int)_SendMessage(EM_LINELENGTH, nLine, 0); }
void XEditWindow::LineScroll(int nLines, int nChars)
{ ASSERT(_IsWindow()); _SendMessage(EM_LINESCROLL, nChars, nLines); }
void XEditWindow::ReplaceSel(LPCTSTR lpszNewText, BOOL bCanUndo)
{ ASSERT(_IsWindow()); _SendMessage(EM_REPLACESEL, (WPARAM) bCanUndo, (LPARAM)lpszNewText); }
void XEditWindow::SetPasswordChar(TCHAR ch)
{ ASSERT(_IsWindow()); _SendMessage(EM_SETPASSWORDCHAR, ch, 0); }
void XEditWindow::SetRect(LPCRECT lpRect)
{ ASSERT(_IsWindow()); _SendMessage(EM_SETRECT, 0, (LPARAM)lpRect); }
void XEditWindow::SetRectNP(LPCRECT lpRect)
{ ASSERT(_IsWindow()); _SendMessage(EM_SETRECTNP, 0, (LPARAM)lpRect); }
void XEditWindow::SetSel(DWORD dwSelection, BOOL bNoScroll)
{ ASSERT(_IsWindow()); _SendMessage(EM_SETSEL,
LOWORD(dwSelection), HIWORD(dwSelection));
if (!bNoScroll)
    _SendMessage(EM_SCROLLCARET, 0, 0); }
void XEditWindow::SetSel(int nStartChar, int nEndChar, BOOL bNoScroll)
{ ASSERT(_IsWindow()); _SendMessage(EM_SETSEL, nStartChar, nEndChar);
if (!bNoScroll)
    _SendMessage(EM_SCROLLCARET, 0, 0); }
BOOL XEditWindow::SetTabStops(int nTabStops, LPINT rgTabStops)
{ ASSERT(_IsWindow()); return (BOOL)_SendMessage(EM_SETTABSTOPS, nTabStops,
(LPARAM)rgTabStops); }
void XEditWindow::SetTabStops()
{ ASSERT(_IsWindow()); VERIFY(_SendMessage(EM_SETTABSTOPS, 0, 0)); }
BOOL XEditWindow::SetTabStops(const int& cxEachStop)
{ ASSERT(_IsWindow()); return (BOOL)_SendMessage(EM_SETTABSTOPS,
1, (LPARAM)(LPINT)&cxEachStop); }
BOOL XEditWindow::Undo()
{ ASSERT(_IsWindow()); return (BOOL)_SendMessage(EM_UNDO, 0, 0); }
void XEditWindow::Clear()
{ ASSERT(_IsWindow()); _SendMessage(WM_CLEAR, 0, 0); }
void XEditWindow::Copy()
{ ASSERT(_IsWindow()); _SendMessage(WM_COPY, 0, 0); }
void XEditWindow::Cut()
{ ASSERT(_IsWindow()); _SendMessage(WM_CUT, 0, 0); }
void XEditWindow::Paste()
{ ASSERT(_IsWindow()); _SendMessage(WM_PASTE, 0, 0); }
BOOL XEditWindow::SetReadOnly(BOOL bReadOnly )
{ ASSERT(_IsWindow()); return (BOOL)_SendMessage(EM_SETREADONLY, bReadOnly, 0L); }
int XEditWindow::GetFirstVisibleLine() const
{ ASSERT(_IsWindow()); return (int)_SendMessage(EM_GETFIRSTVISIBLELINE, 0, 0L); }
TCHAR XEditWindow::GetPasswordChar() const
{ ASSERT(_IsWindow()); return (TCHAR)_SendMessage(EM_GETPASSWORDCHAR, 0, 0L); }
#if (WINVER >= 0x400)
void XEditWindow::SetMargins(UINT nLeft, UINT nRight)
{ ASSERT(_IsWindow()); _SendMessage(EM_SETMARGINS, EC_LEFTMARGIN|EC_RIGHTMARGIN, MAKELONG(nLeft, nRight)); }
DWORD XEditWindow::GetMargins() const
{ ASSERT(_IsWindow()); return (DWORD)_SendMessage(EM_GETMARGINS, 0, 0); }
void XEditWindow::SetLimitText(UINT nMax)
{ ASSERT(_IsWindow()); _SendMessage(EM_SETLIMITTEXT, nMax, 0); }
UINT XEditWindow::GetLimitText() const
{ ASSERT(_IsWindow()); return (UINT)_SendMessage(EM_GETLIMITTEXT, 0, 0); }
XPoint XEditWindow::PosFromChar(UINT nChar) const
{ ASSERT(_IsWindow()); return XPoint( (DWORD)_SendMessage(EM_POSFROMCHAR, nChar, 0)); }
int XEditWindow::CharFromPos(XPoint pt) const
{ ASSERT(_IsWindow()); return (int)_SendMessage(EM_CHARFROMPOS, 0, MAKELPARAM(pt.x, pt.y)); }
#endif

WINDOW_END_NAMESPACE