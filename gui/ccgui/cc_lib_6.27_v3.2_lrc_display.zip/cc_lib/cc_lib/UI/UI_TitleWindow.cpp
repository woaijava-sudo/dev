#include "stdafx.h"

WINDOW_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS(XTitleWindow, XWindow)
//////////////////////////////////////////////////////////////////////////

XTitleWindow::XTitleWindow()
{
    m_lpszSuperClass = EmptyString;
    m_lpszWindowClass = _T("XTitleWindow");
    thread.SetName(_T("TitleWorkingThread"));
}

XTitleWindow::~XTitleWindow()
{

}

void XTitleWindow::Init( XTitle* pOwner )
{
    m_pOwner = pOwner;

    XCmdTarget::Create(pOwner->GetOwner()->GetSafeHwnd(), NULL, WS_CHILD, 0, pOwner->GetRect());
    _ShowWindow(SW_SHOW);

    m_hDC = _GetDC();
}

void XTitleWindow::OnFinalMessage( HWND hWnd )
{
    XWindow::OnFinalMessage(hWnd);
    if (m_hDC != NULL) _ReleaseDC(m_hDC);
    m_pOwner->SetChildWnd2(NULL);
    m_pOwner->Invalidate();
    Safe_Delete_Object(this);
}

void XTitleWindow::Invalidate()
{
    m_pOwner->Invalidate();
}

LRESULT XTitleWindow::HandleMessage( UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    LRESULT lRes = 0;

    switch (uMsg)
    {
    case WM_DESTROY:
        thread.Terminate();
        thread.Wait();
        return 0;
    case XTITLE_WM_POST_TEXT:
        PostText(reinterpret_cast<XString*>(lParam));
        return 0;
    case XTITLE_WM_SET_ATTR:
        return thread.SetAttr((UINT)wParam, (DWORD)lParam);
    case XTITLE_WM_GET_ATTR:
        return thread.GetAttr((UINT)wParam);
    }

    if ( XWindow::MessageHandler(uMsg, wParam, lParam, &lRes) )
    {
        return lRes;
    }
    else
    {
        return XWindow::HandleMessage(uMsg, wParam, lParam);
    }
}

void XTitleWindow::Notify( TAsyncNotify& notify )
{
    if (notify.bTrans)
    {
        XString strMsg = (LPCTSTR) notify.msg.message;
        ASSERT(IsValidString(strMsg));
        int len = strMsg.GetLength();
    }
    else
    {
        switch (notify.msg.message)
        {
        case WM_CREATE:
            thread.Init(this);
            thread.Start();
            break;
        }
    }
}

const XTitleTaskList* XTitleWindow::Lock()
{
    return thread.Lock();
}

void XTitleWindow::Unlock()
{
    thread.Unlock();
}

void XTitleWindow::PostText( XString* pstrText )
{
    ASSERT(pstrText);
    thread.Post(pstrText);
}

WINDOW_END_NAMESPACE