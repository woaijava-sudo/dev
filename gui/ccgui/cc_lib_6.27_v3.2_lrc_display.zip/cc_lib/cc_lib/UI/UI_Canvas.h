#ifndef _CC_UI_CANVAS_H
#define _CC_UI_CANVAS_H

#pragma once

#define GetICanvas(p) ((XCanvas*)(static_cast<XCanvas*>((p)->GetInterface(HI_CANVAS))))

CONTROLS_BEGIN_NAMESPACE
class CL_API XCanvas : public XContainer, public IHotTrackImpl
{
    X_DECLARE_CLASS_WITH_PARA(XCanvas)
public:
    XCanvas(XObject* pOb = NULL);
    virtual ~XCanvas();

public:
#ifdef _DEBUG
    virtual void AssertValid() const;
#endif // _DEBUG

    virtual void* GetInterface( HINTERFACE hi );

    void SetForwardColor(COLORREF color);
    COLORREF GetForwardColor() const;

    virtual void Paint( HDC hDC, const XRect& rect );
    virtual void Event( TEvent& event );

    virtual void SetBkColor( COLORREF dwBkColor );

protected:
    COLORREF    m_clrForward;
    COLORREF    m_clrOld;
    DWORD       m_dwState;
};

CONTROLS_END_NAMESPACE
#endif