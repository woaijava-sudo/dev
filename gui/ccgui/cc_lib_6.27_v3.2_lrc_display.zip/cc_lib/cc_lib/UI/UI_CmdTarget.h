#ifndef _CC_UI_CMDTARGET_H
#define _CC_UI_CMDTARGET_H

#pragma once

#include "UI_CmdTargetInterface.h"

UI_BEGIN_NAMESPACE
class CL_API XCmdTarget : public XObject, public ICmdTargetImpl
{
    X_DECLARE_CLASS(XCmdTarget)
public:
    XCmdTarget();
    virtual ~XCmdTarget();

    void SetParent(XCmdTarget* pParent);
    XCmdTarget* GetParent() const;

    void SetIcon( UINT nRes );

    BOOL RegisterWindowClass();
    BOOL RegisterSuperClass();

    virtual void* GetInterface( HINTERFACE hi );

    HWND Create(HWND hwndParent, LPCTSTR pstrName, DWORD dwStyle, DWORD dwExStyle, const XRect rc, HMENU hMenu = NULL);
    virtual HWND Create(HWND hwndParent, LPCTSTR pstrName, DWORD dwStyle, DWORD dwExStyle, int x = CW_USEDEFAULT, int y = CW_USEDEFAULT, int cx = CW_USEDEFAULT, int cy = CW_USEDEFAULT, HMENU hMenu = NULL);
    
    virtual void OnFinalMessage(HWND hWnd); // �������ز�"Safe_Delete_Object"����Ϊ���Լ�ɾ���͵�����ɾ��

protected:
    virtual LPCTSTR GetWindowClassName() const;
    virtual LPCTSTR GetSuperClassName() const;
    virtual UINT GetClassStyle() const;

#ifdef _DEBUG
    virtual void AssertValid() const;
#endif // _DEBUG

protected:
    UINT    m_uStyle;
    XString m_lpszSuperClass;
    XString m_lpszWindowClass;
    XCmdTarget* m_pParent;
    BOOL    m_bMouseCapture;
};

UI_END_NAMESPACE
#endif