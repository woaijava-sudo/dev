#include "stdafx.h"

WINDOW_BEGIN_NAMESPACE
const TImage* XWindow::AddImage( LPCTSTR lpszImage, DWORD dwMask /*= 0 */ )
{
    ASSERT(lpszImage);

    TImage* ppVoid = NULL;
    bool bFind = m_mapImage.Lookup(lpszImage, ppVoid);

    if (bFind) {
        ASSERT(ppVoid);
        return ppVoid;
    }

    TImage* pImage = Rendering::X_LoadImage(lpszImage, dwMask);

    if( !pImage ) return NULL;
    pImage->dwMask = dwMask;
    m_mapImage.Set(lpszImage, pImage);

    return pImage;
}

const TImage* XWindow::AddImage( LPCTSTR lpszImage, HBITMAP hBitmap, int iWidth, int iHeight, BOOL bAlpha )
{
    if( hBitmap == NULL || iWidth <= 0 || iHeight <= 0 ) return NULL;

    ASSERT(lpszImage);

    TImage* ppVoid = NULL;
    bool bFind = m_mapImage.Lookup(lpszImage, ppVoid);

    if (bFind) {
        ASSERT(ppVoid);
        ::DeleteObject(hBitmap);
        return ppVoid;
    }

    TImage* pImage = new TImage;
    pImage->hBitmap = hBitmap;
    pImage->nX = iWidth;
    pImage->nY = iHeight;
    pImage->alphaChannel = bAlpha;
    pImage->dwMask = 0;

    // Hash name
    m_mapImage.Set(lpszImage, pImage);

    return pImage;
}

const TImage* XWindow::GetImage( LPCTSTR lpszImage )
{
    TImage* ppVoid = NULL;
    bool bFind = m_mapImage.Lookup(lpszImage, ppVoid);

    if (bFind) {
        ASSERT(ppVoid);
        return ppVoid;
    }

    if (m_hwndParent != NULL)
    {
        return m_hwndParent->GetImage(lpszImage);
    }

    return NULL;
}

const TImage* XWindow::GetImageEx( LPCTSTR lpszImage, DWORD dwMask /*= 0 */ )
{
    const TImage* pImage = GetImage(lpszImage);

    if (pImage != NULL)
    {
        return pImage;
    }

    return AddImage(lpszImage, dwMask);
}

BOOL XWindow::RemoveImage( LPCTSTR lpszImage )
{
    const TImage* pImage = GetImage(lpszImage);

    if (pImage == NULL)
    {
        return FALSE;
    }

    X_FREE_IMAGE(pImage);

    return m_mapImage.Remove(lpszImage);
}

void XWindow::RemoveAllImages()
{
    if (m_mapImage.IsEmpty())
    {
        return;
    }

    auto enumerator = m_mapImage.Wrap().CreateEnumerator();
    while (enumerator->Next())
    {
        X_FREE_IMAGE(enumerator->Current()._V);
    }
    delete enumerator;

    m_mapImage.Clear();
}

void XWindow::ReloadAllImages()
{
    if (m_mapImage.IsEmpty())
    {
        return;
    }

    auto enumerator = m_mapImage.Wrap().CreateEnumerator();
    while (enumerator->Next())
    {
        auto current = enumerator->Current();
        auto tmp = current._V;
        current._V = (TImage*)AddImage(current._K, tmp->dwMask);
        X_FREE_IMAGE(tmp);
    }
    delete enumerator;
}

WINDOW_END_NAMESPACE