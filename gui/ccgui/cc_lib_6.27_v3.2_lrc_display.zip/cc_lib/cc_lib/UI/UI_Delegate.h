#ifndef _CC_UI_DELEGATE_H
#define _CC_UI_DELEGATE_H

#pragma once

UI_BEGIN_NAMESPACE
typedef struct tagTEvent        TEvent;
namespace Window
{
    typedef struct tagTAsyncNotify    TAsyncNotify;
    typedef struct tagTSyncNotify     TSyncNotify;
}
using namespace Window;

typedef bool (*XFunVoid)               (void* pParam,                 LPARAM lParam, WPARAM wParam);
typedef bool (*XFunTEvent)             (TEvent* pTEvent,              LPARAM lParam, WPARAM wParam);
typedef bool (*XFunTAsyncNotify)       (TAsyncNotify* pTNotify,       LPARAM lParam, WPARAM wParam);
typedef bool (*XFunTSyncNotify)        (TSyncNotify* pTNotify,        LPARAM lParam, WPARAM wParam);

class XDelegateBase;

class CL_API IDelegateAdv
{
public:
    typedef union _FnType {
        XFunVoid          pFunVoid;
        XFunTEvent        pFunTEvent;
        XFunTAsyncNotify  pFunTAsyncNotify;
        XFunTSyncNotify   pFunTSyncNotify;
    } FnType;

public:
    virtual XFunVoid            GetFunVoid() const = 0;
    virtual XFunTEvent          GetFunTEvent() const = 0;
    virtual XFunTAsyncNotify    GetFunTAsyncNotify() const = 0;
    virtual XFunTSyncNotify     GetFunTSyncNotify() const = 0;
    virtual LPARAM              GetLParam() const = 0;
    virtual WPARAM              GetWParam() const = 0;
public:
    virtual XDelegateBase*      Copy() const = 0;
    virtual bool                Invoke(void* pParam,                   LPARAM lParam = NULL, WPARAM wParam = NULL) = 0;
    virtual bool                Invoke(TEvent* pTEvent,                LPARAM lParam = NULL, WPARAM wParam = NULL) = 0;
    virtual bool                Invoke(TAsyncNotify* pTAsyncNotifyUI,  LPARAM lParam = NULL, WPARAM wParam = NULL) = 0;
    virtual bool                Invoke(TSyncNotify* pTSyncNotifyUI,    LPARAM lParam = NULL, WPARAM wParam = NULL) = 0;
};

class CL_API XDelegateBase : public IDelegateAdv
{
public:
    XDelegateBase(void* pObject, XFunVoid pFn, LPARAM lParam = NULL, WPARAM wParam = NULL);
    XDelegateBase(void* pObject, XFunTEvent pFn, UINT _iEventType,LPARAM lParam = NULL, WPARAM wParam = NULL);
    XDelegateBase(void* pObject, XFunTAsyncNotify pFn, LPCTSTR _sNotifyTypeName, LPARAM lParam = NULL, WPARAM wParam = NULL);
    XDelegateBase(void* pObject, XFunTSyncNotify pFn, LPCTSTR _sNotifyTypeName, LPARAM lParam = NULL, WPARAM wParam = NULL);
    XDelegateBase(const XDelegateBase& rhs);

    virtual ~XDelegateBase();
    XFunVoid                GetFunVoid() const;
    XFunTEvent              GetFunTEvent() const;
    XFunTAsyncNotify        GetFunTAsyncNotify() const;
    XFunTSyncNotify         GetFunTSyncNotify() const;
    LPARAM                  GetLParam() const;
    WPARAM                  GetWParam() const;
    bool                    Equals(const XDelegateBase& rhs) const;
    void*                   GetObj() const;

    bool operator() (void* param, LPARAM lParam = NULL, WPARAM wParam = NULL);
    bool operator() (TEvent* pTEvent, UINT _iEventType, LPARAM lParam = NULL, WPARAM wParam = NULL);
    bool operator() (TAsyncNotify* pTNotify, LPCTSTR _sNotifyTypeName, LPARAM lParam = NULL, WPARAM wParam = NULL);
    bool operator() (TSyncNotify* pTNotify, LPCTSTR _sNotifyTypeName, LPARAM lParam = NULL, WPARAM wParam = NULL);

protected:
    void SetEventType(UINT _iEventType);
    void SetNotifyTypeName(XString& _sNotifyTypeName);
    UINT GetEventType();
    XString GetNotifyTypeName();

private:
    void*  m_pObject;
    FnType m_unionFnType;
    LPARAM m_lParam;
    WPARAM m_wParam;
protected:
    UINT    m_iEventType;
    XString m_sNotifyTypeName;
};

class CL_API XDelegateStatic : public XDelegateBase
{
public:
    XDelegateStatic(XFunVoid pFunVoid, LPARAM lParam = NULL, WPARAM wParam = NULL); 
    XDelegateStatic(XFunTEvent pFunTEvent, UINT _iEventType = 0, LPARAM lParam = NULL, WPARAM wParam = NULL); 
    XDelegateStatic(XFunTAsyncNotify pFunTNotify, LPCTSTR _sNotifyTypeName = NULL, LPARAM lParam = NULL, WPARAM wParam = NULL); 
    XDelegateStatic(XFunTSyncNotify pFunTNotify, LPCTSTR _sNotifyTypeName = NULL, LPARAM lParam = NULL, WPARAM wParam = NULL); 
    XDelegateStatic(const XDelegateStatic& rhs); 
    virtual XDelegateBase* Copy() const;

protected:
    virtual bool Invoke(void* param, LPARAM lParam = NULL, WPARAM wParam = NULL);
    virtual bool Invoke(TEvent* pTEvent, LPARAM lParam = NULL, WPARAM wParam = NULL);
    virtual bool Invoke(TAsyncNotify* pTNotify, LPARAM lParam = NULL, WPARAM wParam = NULL);
    virtual bool Invoke(TSyncNotify* pTNotify, LPARAM lParam = NULL, WPARAM wParam = NULL);
};

template <class O, class T, class P = LPARAM>
class CL_API XDelegate : public XDelegateBase
{
    typedef bool (T::*XMFunVoid)            (void* pParam,             P lParam, WPARAM wParam);
    typedef bool (T::*XMFunTEvent)          (TEvent* pTEvent,          P lParam, WPARAM wParam);
    typedef bool (T::*XMFunTAsyncNotify)    (TAsyncNotify* pTNotify,   P lParam, WPARAM wParam);
    typedef bool (T::*XMFunTSyncNotify)     (TSyncNotify* pTNotify,    P lParam, WPARAM wParam);
public:
    XDelegate(O* pObj, XMFunVoid pXMFunVoid, P lParam = NULL, WPARAM wParam = NULL)
        : XDelegateBase(pObj, *(XFunVoid*)&pXMFunVoid, (LPARAM)lParam,wParam), m_pXMFunVoid(pXMFunVoid),
            m_pXMFunTEvent(NULL), m_pXMFunTAsyncNotify(NULL), m_pXMFunTSyncNotify(NULL) {}
    XDelegate(O* pObj, XMFunTEvent pXMFunTEvent, UINT _iEventType = 0, P lParam = NULL, WPARAM wParam = NULL)
        : XDelegateBase(pObj, *(XFunTEvent*)&pXMFunTEvent,_iEventType, (LPARAM)lParam,wParam), m_pXMFunVoid(NULL), 
            m_pXMFunTEvent(pXMFunTEvent), m_pXMFunTAsyncNotify(NULL), m_pXMFunTSyncNotify(NULL) {}
    XDelegate(O* pObj, XMFunTAsyncNotify pXMFunTNotify, LPCTSTR _sNotifyTypeName = NULL, P lParam = NULL, WPARAM wParam = NULL)
        : XDelegateBase(pObj, *(XFunTSyncNotify*)&pXMFunTNotify, _sNotifyTypeName, (LPARAM)lParam,wParam), m_pXMFunVoid(NULL),
            m_pXMFunTEvent(NULL), m_pXMFunTSyncNotify(pXMFunTNotify), m_pXMFunTSyncNotify(NULL) {}
    XDelegate(O* pObj, XMFunTSyncNotify pXMFunTNotify, LPCTSTR _sNotifyTypeName = NULL, P lParam = NULL, WPARAM wParam = NULL)
        : XDelegateBase(pObj, *(XFunTAsyncNotify*)&pXMFunTNotify, _sNotifyTypeName, (LPARAM)lParam,wParam), m_pXMFunVoid(NULL),
            m_pXMFunTEvent(NULL), m_pXMFunTAsyncNotify(pXMFunTNotify), m_pXMFunTSyncNotify(NULL) {}
    XDelegate( const XDelegate& rhs ) : XDelegateBase(rhs)
    {
        m_pXMFunVoid = rhs.m_pXMFunVoid;
        m_pXMFunTEvent = rhs.m_pXMFunTEvent;
        m_pXMFunTAsyncNotify = rhs.m_pXMFunTAsyncNotify;
        m_pXMFunTSyncNotify = rhs.m_pXMFunTSyncNotify;
    }

    virtual XDelegateBase* Copy() const    { return new XDelegate(*this); }

protected:
    virtual bool Invoke(void* param, LPARAM lParam = NULL, WPARAM wParam = NULL)
    {
        O* pObject = (O*) GetObj();
        if(pObject && m_pXMFunVoid)
            return (pObject->*m_pXMFunVoid)(param, (P)GetLParam(), GetWParam());
        else if(pObject && m_pXMFunTEvent)
            return Invoke((TEvent*)param, GetLParam() ,GetWParam());
        else if(pObject && m_pXMFunTAsyncNotify)
            return Invoke((TAsyncNotify*)param, GetLParam(), GetWParam());
        else if(pObject && m_pXMFunTSyncNotify)
            return Invoke((TSyncNotify*)param, GetLParam(), GetWParam());

        return true;
    }

    virtual bool Invoke(TEvent* pTEvent, LPARAM lParam = NULL, WPARAM wParam = NULL)
    {
        O* pObject = (O*) GetObj();
        if(pObject && pTEvent && GetEventType() == 0)
            return (pObject->*m_pXMFunTEvent)(pTEvent, (P)GetLParam(), GetWParam()); 
        else if(pObject && pTEvent && pTEvent->msg.message == GetEventType())
            return (pObject->*m_pXMFunTEvent)(pTEvent, (P)GetLParam(), GetWParam());

        return true;
    }

    virtual bool Invoke(TAsyncNotify* pTNotify, LPARAM lParam = NULL, WPARAM wParam = NULL)
    {
        O* pObject = (O*) GetObj();
        if(pObject && GetNotifyTypeName().IsEmpty())
            return (pObject->*m_pXMFunTAsyncNotify)(pTNotify, (P)GetLParam(), GetWParam());
        else if(pObject && pTNotify && pTNotify->msg.message == GetNotifyTypeName())
            return (pObject->*m_pXMFunTAsyncNotify)(pTNotify, (P)GetLParam(), GetWParam());

        return true;
    }

    virtual bool Invoke(TSyncNotify* pTNotify, LPARAM lParam = NULL, WPARAM wParam = NULL)
    {
        O* pObject = (O*) GetObj();
        if(pObject && GetNotifyTypeName().IsEmpty())
            return (pObject->*m_pXMFunTSyncNotify)(pTNotify, (P)GetLParam(), GetWParam());
        else if(pObject && pTNotify && pTNotify->pstrMessage == GetNotifyTypeName())
            return (pObject->*m_pXMFunTSyncNotify)(pTNotify, (P)GetLParam(), GetWParam());

        return true;
    }

private:
    XMFunVoid            m_pXMFunVoid;
    XMFunTEvent          m_pXMFunTEvent;
    XMFunTAsyncNotify    m_pXMFunTAsyncNotify;
    XMFunTSyncNotify     m_pXMFunTSyncNotify;
};

template <class O, class T,class P>
XDelegate<O, T, P> MakeDelegate(O* pObject, bool (T::* pFn)(void* pParam, LPARAM lParam, WPARAM wParam),
    P lParam = NULL, WPARAM wParam = NULL)
{
    return XDelegate<O, T, P>(pObject, pFn, lParam, wParam);
}

template <class O, class T,class P>
XDelegate<O, T, P> MakeDelegate(O* pObject, bool (T::* pFn)(TEvent*, P lParam, WPARAM wParam),
    UINT _iEventType, P lParam = NULL, WPARAM wParam = NULL)
{
    return XDelegate<O, T, P>(pObject, pFn, _iEventType, lParam, wParam);
}

template <class O, class T,class P>
XDelegate<O, T, P> MakeDelegate(O* pObject, bool (T::* pFn)(TAsyncNotify*, P lParam, WPARAM wParam),
    LPCTSTR _sNotifyTypeName, P lParam = NULL, WPARAM wParam = NULL)
{
    return XDelegate<O, T, P>(pObject, pFn, (LPCTSTR)_sNotifyTypeName, lParam, wParam);
}

template <class O, class T,class P>
XDelegate<O, T, P> MakeDelegate(O* pObject, bool (T::* pFn)(TSyncNotify*, P lParam, WPARAM wParam),
    LPCTSTR _sNotifyTypeName, P lParam = NULL, WPARAM wParam = NULL)
{
    return XDelegate<O, T, P>(pObject, pFn, (LPCTSTR)_sNotifyTypeName, lParam, wParam);
}

inline XDelegateStatic MakeDelegate(XFunVoid pFunVoid, LPARAM lParam = NULL, WPARAM wParam = NULL)
{
    return XDelegateStatic(pFunVoid, lParam, wParam);
}

inline XDelegateStatic MakeDelegate(XFunTEvent pFunTEvent, UINT _iEventType, LPARAM lParam = NULL, WPARAM wParam = NULL)
{
    return XDelegateStatic(pFunTEvent, _iEventType, lParam, wParam); 
}

inline XDelegateStatic MakeDelegate(XFunTAsyncNotify pFunTNotify, LPCTSTR _sNotifyTypeName, LPARAM lParam = NULL, WPARAM wParam = NULL)
{
    return XDelegateStatic(pFunTNotify, _sNotifyTypeName, lParam, wParam); 
}

inline XDelegateStatic MakeDelegate(XFunTSyncNotify pFunTNotify, LPCTSTR _sNotifyTypeName, LPARAM lParam = NULL, WPARAM wParam = NULL)
{
    return XDelegateStatic(pFunTNotify, _sNotifyTypeName, lParam, wParam); 
}

//////////////////////////////////////////////////////////////////////////

DEF_LIST_TEMPLATE1(XDelegateBase*);
class CL_API XEventSource
{
public:
    XEventSource();
    ~XEventSource();
    operator bool();
    void operator+= (const XDelegateBase& d); // add const for gcc
    void operator+= (XFunVoid pFunVoid);
    void operator-= (const XDelegateBase& d);
    void operator-= (XFunVoid pFunVoid);
    bool operator() (void* param);
    bool operator() (TEvent* pTEvent);
    bool operator() (TAsyncNotify* pTNotify);
    bool operator() (TSyncNotify* pTNotify);

protected:
    List<XDelegateBase*> m_aDelegates;
};

UI_END_NAMESPACE
#endif