#ifndef _CC_UI_EDIT_H
#define _CC_UI_EDIT_H

#pragma once

#define GetIEdit(p) ((XEdit*)(static_cast<XEdit*>((p)->GetInterface(HI_EDIT))))

CONTROLS_BEGIN_NAMESPACE
class XEdit;
CONTROLS_END_NAMESPACE
WINDOW_BEGIN_NAMESPACE
class XEditWindow;
WINDOW_END_NAMESPACE

//////////////////////////////////////////////////////////////////////////
WINDOW_BEGIN_NAMESPACE
class XEditWindow : public XCmdTarget, public IBkBrushImpl, public IOwner<XEdit>
{
    X_DECLARE_CLASS(XEditWindow)
public:
    XEditWindow();
    virtual ~XEditWindow();

    void Init( XEdit* pOwner );
    void CalcRect();
    XRect GetRect() const;

    virtual void OnFinalMessage( HWND hWnd );

    virtual LRESULT HandleMessage( UINT uMsg, WPARAM wParam, LPARAM lParam );
    LRESULT OnKillFocus( UINT uMsg, WPARAM wParam, LPARAM lParam );
    LRESULT OnEditChanged( UINT uMsg, WPARAM wParam, LPARAM lParam );

    //////////////////////////////////////////////////////////////////////////
    // Attributes
    BOOL CanUndo() const;
    int GetLineCount() const;
    BOOL GetModify() const;
    void SetModify(BOOL bModified = TRUE);
    void GetRect(LPRECT lpRect) const;
    DWORD GetSel() const;
    void GetSel(int& nStartChar, int& nEndChar) const;
    HLOCAL GetHandle() const;
    void SetHandle(HLOCAL hBuffer);
#if (WINVER >= 0x400)
    void SetMargins(UINT nLeft, UINT nRight);
    DWORD GetMargins() const;
    void SetLimitText(UINT nMax);
    UINT GetLimitText() const;
    XPoint PosFromChar(UINT nChar) const;
    int CharFromPos(XPoint pt) const;
#endif

    // NOTE: first word in lpszBuffer must contain the size of the buffer!
    int GetLine(int nIndex, LPTSTR lpszBuffer) const;
    int GetLine(int nIndex, LPTSTR lpszBuffer, int nMaxLength) const;

    // Operations
    void EmptyUndoBuffer();
    BOOL FmtLines(BOOL bAddEOL);

    void LimitText(int nChars = 0);
    int LineFromChar(int nIndex = -1) const;
    int LineIndex(int nLine = -1) const;
    int LineLength(int nLine = -1) const;
    void LineScroll(int nLines, int nChars = 0);
    void ReplaceSel(LPCTSTR lpszNewText, BOOL bCanUndo = FALSE);
    void SetPasswordChar(TCHAR ch);
    void SetRect(LPCRECT lpRect);
    void SetRectNP(LPCRECT lpRect);
    void SetSel(DWORD dwSelection, BOOL bNoScroll = FALSE);
    void SetSel(int nStartChar, int nEndChar, BOOL bNoScroll = FALSE);
    BOOL SetTabStops(int nTabStops, LPINT rgTabStops);
    void SetTabStops();
    BOOL SetTabStops(const int& cxEachStop);    // takes an 'int'

    // Clipboard operations
    BOOL Undo();
    void Clear();
    void Copy();
    void Cut();
    void Paste();

    BOOL SetReadOnly(BOOL bReadOnly = TRUE);
    int GetFirstVisibleLine() const;
    TCHAR GetPasswordChar() const;

protected:
    XRect m_rcPos;
};
WINDOW_END_NAMESPACE
//////////////////////////////////////////////////////////////////////////
CONTROLS_BEGIN_NAMESPACE
class CL_API XEdit : public XLabel, public IChildWindow<XEditWindow>
{
    X_DECLARE_CLASS_WITH_PARA(XEdit)
public:
    XEdit(XObject* pOb = NULL);
    virtual ~XEdit();

    virtual void* GetInterface( HINTERFACE hi );
    virtual void Event( TEvent& event );
    virtual void Paint( HDC hDC, const XRect& rect );

    void SetEditStyle( UINT uAdd, UINT uRemove = 0 );
    UINT GetEditStyle() const;

    void SetText(LPCTSTR pstrText);
    int GetText(LPTSTR lpString, int nMaxCount);
    int GetTextLength();

    void SetMaxCharLength(UINT uLength);
    UINT GetMaxCharLength() const;
    void SetReadOnly(BOOL bReadOnly);
    BOOL IsReadOnly() const;
    void SetPassword(BOOL bPassword);
    BOOL IsPassword();
    void SetPasswordMask(TCHAR chPasswordMask);
    TCHAR GetPasswordMask();
    void SetEditBkColor(COLORREF clrBkColor); // �����ı���ѡ��ʱ�ı���ɫ
    COLORREF GetEditBkColor() const;

    virtual void SetEnable( BOOL bEnabled );
    virtual void SetVisible( BOOL bVisible );
    virtual DWORD GetFlags() const;

    virtual XSize EstimateSize( const XSize& );

protected:
    UINT            m_uMaxCharLength;
    TCHAR           m_chPasswordMask; // ��������
    UINT            m_uState;
    UINT            m_uEditStyle;
    COLORREF        m_clrEditBkColor; // Alphaͨ����Ч
};
CONTROLS_END_NAMESPACE
#endif