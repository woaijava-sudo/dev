#include "stdafx.h"

WINDOW_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS(XComboWindow, XWindow)
//////////////////////////////////////////////////////////////////////////

XComboWindow::XComboWindow(): m_iOldSel(-1), m_pCanvas(NULL), m_pLayout(NULL)
{
    m_bAutoDestroy = FALSE;
    m_lpszSuperClass = EmptyString;
    m_lpszWindowClass = _T("XComboWindow");
}

XComboWindow::~XComboWindow()
{
    DeleteComponents();
}

void XComboWindow::DeleteComponents()
{
    TAsyncNotify* pNotify = NULL;
    // Delete the control-tree structures
    for ( int i = 0; i < m_syncNotify.GetSize(); i++ )
    {
        pNotify = static_cast<TAsyncNotify*>(m_syncNotify[i]);
#ifdef _DEBUG
        XWindow::TraceDeleteNotify(pNotify);
#endif // _DEBUG
        delete pNotify;
    }
    XDeleteControl(m_pRoot);
    if (m_hDC != NULL) _ReleaseDC(m_hDC);
    _KillAllTimers();
    m_preMessages.Remove(this);
}

void XComboWindow::CreateLayout()
{
    ASSERT_VALID(m_pOwner);
    SetDefaultFont(m_pOwner->GetOwner()->GetDefaultFontInfo()); // ����Ҫ�������趨���壬���򴰿ڴ���ʧ��
    m_pCanvas = GetICanvas(XWindow_CreateControl(XCanvas));
    m_pCanvas->SetBkColor(MAKE_RGB(XCOLOR_CONTROL_BACKGROUND_NORMAL));
    m_pLayout = GetIVerticalLayout(m_pCanvas->XCreateControl(XVerticalLayout));
    m_pLayout->EnableScrollBar();
    for( int i = 0; i < m_pOwner->Combo_GetSize(); i++ ) {
        XControl* pElement = m_pLayout->XCreateControl(XListLabelElement);
        XControl* pSrc = m_pOwner->Combo_GetData(i);
        ASSERT(pSrc->XIsKindOf(XListTextElement));
        XListTextElement* pSrcEle = GetIListTextElement(pSrc);
        ASSERT(pSrcEle);
        IListLabel* pListLabel = GetIListLabel(pElement);
        IListItem* pListItem = GetIListItem(pElement);

        ASSERT(pListLabel);
        ASSERT(pListItem);
        // XListTextElement Initialization
        pListItem->SetListOwner(m_pOwner);
        pListLabel->SetCombo(m_pOwner);
        pElement->SetText(pSrcEle->GetText(0));
        pListItem->SetIndex(i);
    }

    AttachControl(m_pCanvas);
    _ShowWindow(SW_SHOW);
    _UpdateWindow();
}

void XComboWindow::Init( XCombo* pOwner )
{
    m_pOwner = pOwner;
    m_iOldSel = m_pOwner->GetCurSel();

    // Position the popup window in absolute space
    XSize szDrop = m_pOwner->GetDropBoxSize();
    m_rcPaint.BottomRight().Offset(szDrop);
    XRect rcOwner = pOwner->GetRect();
    XRect rc = rcOwner;
    rc.top = rc.bottom;
    rc.bottom = rc.top + szDrop.cy;
    if( szDrop.cx > 0 ) rc.right = rc.left + szDrop.cx;

    XSize szAvailable = rc.Size();
    int cyFixed = 0;
    for( int it = 0; it < pOwner->Combo_GetSize(); it++ ) {
        XControl* pControl = GetIControl(pOwner->Combo_GetData(it));
        ASSERT_VALID(pControl);
        if( !pControl->IsVisible() ) continue;
        XSize sz = pControl->EstimateSize(szAvailable);
        cyFixed += sz.cy;
    }
    rc.bottom = rc.top + min(cyFixed, szDrop.cy);

    HWND hWndParent = pOwner->GetOwner()->GetSafeHwnd();
    ::MapWindowRect(hWndParent, HWND_DESKTOP, &rc);

    MONITORINFO oMonitor = {};
    oMonitor.cbSize = sizeof(oMonitor);
    ::GetMonitorInfo(::MonitorFromWindow(m_hWnd, MONITOR_DEFAULTTOPRIMARY), &oMonitor);
    XRect rcWork = oMonitor.rcWork;
    if( rc.bottom > rcWork.bottom ) {
        rc.left = rcOwner.left;
        rc.right = rcOwner.right;
        if( szDrop.cx > 0 ) rc.right = rc.left + szDrop.cx;
        rc.top = rcOwner.top - min(cyFixed, szDrop.cy);
        rc.bottom = rcOwner.top;
        ::MapWindowRect(hWndParent, HWND_DESKTOP, &rc);
    }

    XCmdTarget::Create(hWndParent, NULL, WS_POPUP, WS_EX_TOOLWINDOW, rc);
    m_hDC = _GetDC();
    // HACK: Don't deselect the parent's caption
    XWindowImpl hwnd;
    hwnd.Attach(m_hWnd);
    HWND hwnd_ = NULL;
    while( (hwnd_ = hwnd._GetParent()) != NULL ) hwnd.Attach(hwnd_);
    _ShowWindow(SW_SHOW);
    hwnd._SendMessage(WM_NCACTIVATE, TRUE, 0L);
}

void XComboWindow::OnFinalMessage( HWND hWnd )
{
    XWindow::OnFinalMessage(hWnd);
    if (m_hDC != NULL) _ReleaseDC(m_hDC);
    m_pOwner->SetChildWnd2(NULL);
    m_pOwner->SetButtonState(0, XSTATE_PUSHED);
    m_pOwner->Invalidate();
    Safe_Delete_Object(this);
}

void XComboWindow::EnsureVisible( int iIndex )
{
    int iCurSel = m_iOldSel;
    if( iCurSel < 0 ) return;
    m_pLayout->FindSelectable(iCurSel, false);
    XControl* pSelected = m_pLayout->GetData(iIndex);
    IListItem* pEle = GetIListItem(pSelected);
    ASSERT(pEle);
    pEle->Select(true);
    XRect rcItem = pSelected->GetRect();
    XRect rcList = m_pLayout->GetRect();
    int iPos = m_pLayout->GetScrollPos();
    if( rcItem.top >= rcList.top && rcItem.bottom < rcList.bottom ) return;
    int dx = 0;
    if( rcItem.top < rcList.top ) dx = rcItem.top - rcList.top;
    if( rcItem.bottom > rcList.bottom ) dx = rcItem.bottom - rcList.bottom;
    Scroll(0, dx);
}

void XComboWindow::Scroll( int dx, int dy )
{
    if( dx == 0 && dy == 0 ) return;
    m_pLayout->SetScrollPos(m_pLayout->GetScrollPos() + dy);
}

void XComboWindow::SetCurSel( int iSel )
{
    m_iOldSel = iSel;
}

LRESULT XComboWindow::HandleMessage( UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    LRESULT lRes = 0;

    m_pFocus = m_pLayout;

    switch (uMsg)
    {
    case WM_KILLFOCUS:
        _PostMessage( WM_CLOSE );
        break;
    case WM_CLOSE:
        m_pOwner->SetFocus();
        break;
    case WM_MOUSEWHEEL:
        if (m_pLayout != NULL && m_pLayout->GetChildWnd() != NULL)
        {
            UINT sb = ((int) (short) HIWORD(wParam)) < 0 ? SB_LINEDOWN : SB_LINEUP;
            switch( sb ) {
            case SB_LINEUP:
                Scroll(0, 0 - m_pLayout->GetScrollPage());
                break;
            case SB_LINEDOWN:
                Scroll(0, m_pLayout->GetScrollPage());
                break;
            }
        }
        return 0;
    }

    if ( XWindow::MessageHandler(uMsg, wParam, lParam, &lRes) )
    {
        return lRes;
    }
    else
    {
        return XWindow::HandleMessage(uMsg, wParam, lParam);
    }
}

void XComboWindow::Notify( TAsyncNotify& notify )
{
    if (notify.bTrans)
    {
        XString strMsg = (LPCTSTR) notify.msg.message;
        ASSERT(IsValidString(strMsg));
        int len = strMsg.GetLength();
        switch (len)
        {
        case 10:
            if (strMsg == _T("WindowInit")) {
                EnsureVisible(m_iOldSel);
            }
            break;
        case 14:
            if (strMsg == _T("DropDownSelect")) {
                m_iOldSel = notify.msg.lParam;
                m_pOwner->SelectItem(m_iOldSel);
            }
            break;
        }
    }
    else
    {
        switch (notify.msg.message)
        {
        case WM_CREATE:
            CreateLayout();
            break;
        }
    }
}

WINDOW_END_NAMESPACE