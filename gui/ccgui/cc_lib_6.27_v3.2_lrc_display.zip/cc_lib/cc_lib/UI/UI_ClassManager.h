#ifndef _CC_UI_CLASS_MANAGER_H
#define _CC_UI_CLASS_MANAGER_H

#pragma once

/**
* If you don't want to use dumping context, set macro XManager_Dumping to 0
*/

#define X_CreateObject(RuntimeClass, ppOutObject) \
    ::cc::UI::_XAdv_Global_GetClassManager()->X_CreateObjectFromClass(_T(__FILE__), __LINE__, RuntimeClass, ppOutObject)
#define X_CreateObject_V2(RuntimeClass, Param, ppOutObject) \
    ::cc::UI::_XAdv_Global_GetClassManager()->X_CreateObjectFromClass(_T(__FILE__), __LINE__, RuntimeClass, ppOutObject, Param)
#define X_CreateObject_Name(IClassAdv, RuntimeClass, ppOutObject) \
    IClassAdv->X_CreateObjectFromName(_T(__FILE__), __LINE__, RuntimeClass, ppOutObject)
#define X_CreateObject_Name_V2(IClassAdv, RuntimeClass, Param, ppOutObject) \
    IClassAdv->X_CreateObjectFromName(_T(__FILE__), __LINE__, RuntimeClass, ppOutObject, Param)
#define X_GetClass(IClassAdv, RuntimeClass) \
    IClassAdv->X_GetClassFromName(RuntimeClass)
#define X_DeleteObject(Object) \
    ::cc::UI::_XAdv_Global_GetClassManager()->_DeleteObject(_T(__FILE__), __LINE__, Object)


/************************************************************************/
/*  ʹ�õ���ģʽ                                                        */
/************************************************************************/

UI_BEGIN_NAMESPACE
struct XClass;
class XObject;
class XMap;

// �ڲ�ʹ�ýӿ�
class _IClassAdv
{
public:
#ifdef XManager_Dumping
    virtual bool _RegisterObject( XObject* pObj ) = 0;
    virtual bool _UnregisterObject( XObject* pObj ) = 0;
#endif // XManager_Dumping
    virtual void X_CreateObjectFromClass( const TCHAR*, int, XClass* pClass, XObject** ppObj ) = 0;
    virtual void X_CreateObjectFromClass( const TCHAR*, int, XClass* pClass, XObject** ppObj, XObject* pParam ) = 0;
    virtual bool X_CreateObjectFromName( const TCHAR*, int, LPCTSTR lpszClassName, XObject** ppObj ) = 0;
    virtual bool X_CreateObjectFromName( const TCHAR*, int, LPCTSTR lpszClassName, XObject** ppObj, XObject* pParam ) = 0;
    virtual XClass* X_GetClassFromName( LPCTSTR lpszClassName ) = 0;
    virtual size_t X_GetAllocatedSize() = 0;
    virtual void _DeleteObject( const TCHAR*, int, XObject* pObj ) = 0;
};

class _IClassAdvOp
{
public:
    virtual void _DeleteManager() = 0;
    virtual void _InitClass() = 0;
};

#ifdef XManager_Dumping
// Enable dumping context(ones that hadn't been released could be shown in the debug context)
class _XAdvClassInfo
{
public:
    _XAdvClassInfo( XClass* );
    ~_XAdvClassInfo();

    void Add( XObject* );
    void Remove( XObject* );

    XClass* m_pClass;
protected:
    List<XObject*>  m_aClass;
};
#endif // XManager_Dumping

DEF_DICT_TEMPLATE3(XString, void*, LPCTSTR);
class _XClassManager : public _IClassAdv, public _IClassAdvOp
{
public:
    ~_XClassManager();

    // Singleton
    static _IClassAdv* _XAdv_GetInterface();
    static _IClassAdvOp* _XAdv_GetInterface_Del();

    // Operations
#ifdef XManager_Dumping
    bool _RegisterObject( XObject* pObj );
    bool _UnregisterObject( XObject* pObj );
#endif // XManager_Dumping
    void X_CreateObjectFromClass( const TCHAR*, int, XClass* pClass, XObject** ppObj );
    void X_CreateObjectFromClass( const TCHAR*, int, XClass* pClass, XObject** ppObj, XObject* pParam );
    bool X_CreateObjectFromName( const TCHAR*, int, LPCTSTR lpszClassName, XObject** ppObj );
    bool X_CreateObjectFromName( const TCHAR*, int, LPCTSTR lpszClassName, XObject** ppObj, XObject* pParam );
    XClass* X_GetClassFromName( LPCTSTR lpszClassName );
    void _DeleteObject( const TCHAR*, int, XObject* pObj );
    size_t X_GetAllocatedSize();

    // Management
    void _DeleteManager();
    void _InitClass();

public:
    static XClass* m_pFirstClass;

protected:
    _XClassManager();

    static _XClassManager* m_pThis;
    bool   m_bAllowDumping;
    size_t m_allocSize;
    Dictionary<XString, void*, LPCTSTR>   m_mapClass; // Key: Classname, Value: XClass*
};

CL_API _IClassAdv* _XAdv_Global_GetClassManager();
void CL_API _XAdv_Global_Release();
void CL_API _XAdv_Global_InitClass();

UI_END_NAMESPACE
#endif