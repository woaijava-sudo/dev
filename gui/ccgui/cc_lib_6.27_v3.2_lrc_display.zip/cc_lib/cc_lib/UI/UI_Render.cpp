#include "StdAfx.h"

//////////////////////////////////////////////////////////////////////////
RENDERING_BEGIN_NAMESPACE
void X_DrawColor( HDC hDC, const XRect& rc, COLORREF color )
{
    ASSERT_HDC(hDC);
    if (GetAValue(color) == 0xFF) // ��͸���򸲸�
    {
        COLORREF clrOld = ::SetBkColor(hDC, GetRGB(color));
        ::ExtTextOut(hDC, 0, 0, ETO_OPAQUE, &rc, NULL, 0, NULL);
        ::SetBkColor(hDC, clrOld);
        return;
    }

    // Alpha�����Ⱦ
    X_DrawColorEx(hDC, rc, color);
}

void X_DrawColorEx( HDC hDC, const XRect& rc, COLORREF color )
{
    ASSERT_HDC(hDC);

    HDC hCloneDC = ::CreateCompatibleDC(hDC);
    HBITMAP hBitmap = ::CreateCompatibleBitmap(hDC, rc.Width(),rc.Height());

    HBITMAP hOldBitmap = (HBITMAP) ::SelectObject(hCloneDC, hBitmap);

    COLORREF clrOldColor = ::SetBkColor(hCloneDC, GetRGB(color));
    XRect rt(0, 0, rc.Width(), rc.Height());
    ::ExtTextOut(hCloneDC, 0, 0, ETO_OPAQUE, &rt, NULL, 0, NULL);

    static BLENDFUNCTION bf;
    bf.SourceConstantAlpha = GetAValue(color);

    ::AlphaBlend(hDC, rc.left, rc.top, rc.Width(), rc.Height(), hCloneDC, 0, 0, rc.Width(), rc.Height(), bf);
    
    ::SelectObject(hCloneDC, hOldBitmap);
    ::SetBkColor(hCloneDC, clrOldColor);
    ::DeleteDC(hCloneDC);
    ::DeleteObject(hBitmap);
}

void X_DrawGradient( HDC hDC, const XRect& rc, COLORREF clrFirst, COLORREF clrSecond, bool bVertical, int nSteps )
{
    TRIVERTEX triv[2] = 
    {
        { rc.left, rc.top, GetRValue(clrFirst) << 8, GetGValue(clrFirst) << 8, GetBValue(clrFirst) << 8, 0xFF00 },
        { rc.right, rc.bottom, GetRValue(clrSecond) << 8, GetGValue(clrSecond) << 8, GetBValue(clrSecond) << 8, 0xFF00 },
    };
    GRADIENT_RECT grc = { 0, 1 };
    ::GradientFill(hDC, triv, 2, &grc, 1, bVertical ? GRADIENT_FILL_RECT_V : GRADIENT_FILL_RECT_H);
}

int X_DrawTextCalcRect( XWindow* pWindow, XRect& rc, LPCTSTR pstrText, HFONT hFont, UINT uStyle )
{
    ASSERT(pWindow && hFont && pstrText);
    ASSERT(IsValidString(pstrText));
    HDC hDC = pWindow->GetDC();
    HGDIOBJ hOldFont = ::SelectObject(hDC, hFont);
    int iRet = ::DrawText(hDC, pstrText, -1, &rc, uStyle | DT_NOPREFIX | DT_CALCRECT);
    ::SelectObject(hDC, hOldFont);
    return iRet;
}

int X_DrawText( HDC hDC, XWindow* pWindow, XRect& rc, LPCTSTR pstrText, COLORREF color, HFONT hFont, UINT uStyle )
{
    ASSERT_HDC(hDC);
    ASSERT(pWindow);
    ASSERT(pstrText);

    int nOldMode = ::SetBkMode(hDC, TRANSPARENT);
    COLORREF clrOldColor = ::SetTextColor(hDC, GetRGB(color));
    HFONT hOldFont = NULL;
    if ( hFont == NULL )
    {
        TFont* pFont = pWindow->GetDefaultFontInfo();
        if (pFont && pFont->hFont)
        {
            hOldFont = (HFONT)::SelectObject(hDC, (HFONT) pFont->hFont);
        }
        else
        {
            hOldFont = (HFONT)::SelectObject(hDC, (HFONT) ::GetStockObject(DEFAULT_GUI_FONT));
        }
    }
    else
    {
        hOldFont = (HFONT)::SelectObject(hDC, (HFONT) hFont);
    }
    int result = ::DrawText(hDC, pstrText, -1, &rc, uStyle | DT_NOPREFIX);
    ::SetBkMode(hDC, nOldMode);
    ::SetTextColor(hDC, clrOldColor);
    ::SelectObject(hDC, hOldFont);
    return result;
}

DWORD X_AdjustColor( DWORD dwColor, short H, short S, short L )
{
    if( H == 180 && S == 100 && L == 100 ) return dwColor;
    float fH, fS, fL;
    float S1 = S / 100.0f;
    float L1 = L / 100.0f;
    X_RGBtoHSL(dwColor, fH, fS, fL);
    fH += (H - 180);
    fH = fH > 0 ? fH : fH + 360; 
    fS *= S1;
    fL *= L1;
    X_HSLtoRGB(dwColor, fH, fS, fL);
    return dwColor;
}

void X_RGBtoHSL(DWORD ARGB, float& H, float& S, float& L) {
    const float
        R = (float)GetRValue(ARGB),
        G = (float)GetGValue(ARGB),
        B = (float)GetBValue(ARGB),
        nR = (R<0?0:(R>255?255:R))/255,
        nG = (G<0?0:(G>255?255:G))/255,
        nB = (B<0?0:(B>255?255:B))/255,
        m = min(min(nR,nG),nB),
        M = max(max(nR,nG),nB);
    L = (m + M)/2;
    if (M==m) H = S = 0;
    else {
        const float
            f = (nR==m)?(nG-nB):((nG==m)?(nB-nR):(nR-nG)),
            i = (nR==m)?3.0f:((nG==m)?5.0f:1.0f);
        H = (i-f/(M-m));
        if (H>=6) H-=6;
        H=60;
        S = (2*(L)<=1)?((M-m)/(M+m)):((M-m)/(2-M-m));
    }
}
void X_HSLtoRGB(DWORD& ARGB, float H, float S, float L) {
    const float
        q = 2*L<1?L*(1+S):(L+S-L*S),
        p = 2*L-q,
        h = H/360,
        tr = h + OneThird,
        tg = h,
        tb = h - OneThird,
        ntr = tr<0?tr+1:(tr>1?tr-1:tr),
        ntg = tg<0?tg+1:(tg>1?tg-1:tg),
        ntb = tb<0?tb+1:(tb>1?tb-1:tb),
        R = 255*(6*ntr<1?p+(q-p)*6*ntr:(2*ntr<1?q:(3*ntr<2?p+(q-p)*6*(2.0f*OneThird-ntr):p))),
        G = 255*(6*ntg<1?p+(q-p)*6*ntg:(2*ntg<1?q:(3*ntg<2?p+(q-p)*6*(2.0f*OneThird-ntg):p))),
        B = 255*(6*ntb<1?p+(q-p)*6*ntb:(2*ntb<1?q:(3*ntb<2?p+(q-p)*6*(2.0f*OneThird-ntb):p)));
    ARGB &= 0xFF000000;
    ARGB |= RGB( (BYTE)(R<0?0:(R>255?255:R)), (BYTE)(G<0?0:(G>255?255:G)), (BYTE)(B<0?0:(B>255?255:B)) );
}

RENDERING_END_NAMESPACE