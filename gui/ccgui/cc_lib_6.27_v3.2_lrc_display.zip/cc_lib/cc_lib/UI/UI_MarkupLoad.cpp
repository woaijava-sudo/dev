#include "stdafx.h"
#include "UI_Markup.h"

UI_BEGIN_NAMESPACE
bool XMarkup::LoadFromString( LPCTSTR pstrXml )
{
    ASSERT(pstrXml);
    Release();

    m_szXML = pstrXml;

    bool bRes = _Parse();
    if( !bRes ) Release();
    return bRes;
}

bool XMarkup::LoadFromMem( LPBYTE pByte, DWORD dwSize, int encoding /*= XMLFILE_ENCODING_UTF8 */ )
{
    ASSERT(pByte);
    Release();
    LPTSTR pstrXml = _T('\0');
#ifdef _UNICODE
    if (encoding == XMLFILE_ENCODING_UTF8)
    {
        if( dwSize >= 3 && pByte[0] == 0xEF && pByte[1] == 0xBB && pByte[2] == 0xBF ) 
        {
            pByte += 3; dwSize -= 3;
        }
        DWORD nWide = ::MultiByteToWideChar( CP_UTF8, 0, (LPCSTR)pByte, dwSize, NULL, 0 );

        pstrXml = static_cast<LPTSTR>(malloc((nWide + 1)*sizeof(TCHAR)));
        ::MultiByteToWideChar( CP_UTF8, 0, (LPCSTR)pByte, dwSize, pstrXml, nWide );
        pstrXml[nWide] = _T('\0');
    }
    else if (encoding == XMLFILE_ENCODING_ASNI)
    {
        DWORD nWide = ::MultiByteToWideChar( CP_ACP, 0, (LPCSTR)pByte, dwSize, NULL, 0 );

        pstrXml = static_cast<LPTSTR>(malloc((nWide + 1)*sizeof(TCHAR)));
        ::MultiByteToWideChar( CP_ACP, 0, (LPCSTR)pByte, dwSize, pstrXml, nWide );
        pstrXml[nWide] = _T('\0');
    }
    else
    {
        if ( dwSize >= 2 && ( ( pByte[0] == 0xFE && pByte[1] == 0xFF ) || ( pByte[0] == 0xFF && pByte[1] == 0xFE ) ) )
        {
            dwSize = dwSize / 2 - 1;

            if ( pByte[0] == 0xFE && pByte[1] == 0xFF )
            {
                pByte += 2;

                for ( DWORD nSwap = 0 ; nSwap < dwSize ; nSwap ++ )
                {
                    register CHAR nTemp = pByte[ ( nSwap << 1 ) + 0 ];
                    pByte[ ( nSwap << 1 ) + 0 ] = pByte[ ( nSwap << 1 ) + 1 ];
                    pByte[ ( nSwap << 1 ) + 1 ] = nTemp;
                }
            }
            else
            {
                pByte += 2;
            }

            pstrXml = static_cast<LPTSTR>(malloc((dwSize + 1)*sizeof(TCHAR)));
            ::CopyMemory( pstrXml, pByte, dwSize * sizeof(TCHAR) );
            pstrXml[dwSize] = _T('\0');

            pByte -= 2;
        }
    }
#else // !_UNICODE
    if (encoding == XMLFILE_ENCODING_UTF8)
    {
        if( dwSize >= 3 && pByte[0] == 0xEF && pByte[1] == 0xBB && pByte[2] == 0xBF ) 
        {
            pByte += 3; dwSize -= 3;
        }
        DWORD nWide = ::MultiByteToWideChar( CP_UTF8, 0, (LPCSTR)pByte, dwSize, NULL, 0 );

        LPWSTR w_str = static_cast<LPWSTR>(malloc((nWide + 1)*sizeof(WCHAR)));
        ::MultiByteToWideChar( CP_UTF8, 0, (LPCSTR)pByte, dwSize, w_str, nWide );
        w_str[nWide] = L'\0';

        DWORD wide = ::WideCharToMultiByte(CP_ACP, 0, (LPCWSTR)w_str, nWide, NULL, 0, NULL, NULL);

        pstrXml = static_cast<LPTSTR>(malloc((wide + 1)*sizeof(TCHAR)));
        ::WideCharToMultiByte( CP_ACP, 0, (LPCWSTR)w_str, nWide, pstrXml, wide, NULL, NULL);
        pstrXml[wide] = _T('\0');

        free(w_str);
    }
    else if (encoding == XMLFILE_ENCODING_UNICODE)
    {
        if ( dwSize >= 2 && ( ( pByte[0] == 0xFE && pByte[1] == 0xFF ) || ( pByte[0] == 0xFF && pByte[1] == 0xFE ) ) )
        {
            dwSize = dwSize / 2 - 1;

            if ( pByte[0] == 0xFE && pByte[1] == 0xFF )
            {
                pByte += 2;

                for ( DWORD nSwap = 0 ; nSwap < dwSize ; nSwap ++ )
                {
                    register CHAR nTemp = pByte[ ( nSwap << 1 ) + 0 ];
                    pByte[ ( nSwap << 1 ) + 0 ] = pByte[ ( nSwap << 1 ) + 1 ];
                    pByte[ ( nSwap << 1 ) + 1 ] = nTemp;
                }
            }
            else
            {
                pByte += 2;
            }

            DWORD nWide = ::WideCharToMultiByte(CP_ACP, 0, (LPCWSTR)pByte, dwSize, NULL, 0, NULL, NULL);
            pstrXml = static_cast<LPTSTR>(malloc((nWide + 1)*sizeof(TCHAR)));
            ::WideCharToMultiByte( CP_ACP, 0, (LPCWSTR)pByte, dwSize, pstrXml, nWide, NULL, NULL);
            pstrXml[nWide] = _T('\0');

            pByte -= 2;
        }
    }
    else
    {
        pstrXml = static_cast<LPTSTR>(malloc((dwSize + 1)*sizeof(TCHAR)));
        ::CopyMemory( pstrXml, pByte, dwSize * sizeof(TCHAR) );
        pstrXml[dwSize] = _T('\0');
    }
#endif // _UNICODE

    m_szXML = pstrXml;
    free(pstrXml);

    bool bRes = _Parse();
    if( !bRes ) Release();
    return bRes;
}

bool XMarkup::LoadFromFile( LPCTSTR pstrFilename, int encoding /*= XMLFILE_ENCODING_UTF8 */ )
{
    // pstrFilename = path(local or absolute)
    // So far, not supporting zip

    ASSERT(pstrFilename);
    Release();
    XString srcFile = XGlobal_GetResourcePath();
    srcFile += pstrFilename;
    HANDLE hFile = ::CreateFile(srcFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if( hFile == INVALID_HANDLE_VALUE ) return _Failed(_T("Error opening file"));
    DWORD dwHignSize = 0;
    DWORD dwSize = ::GetFileSize(hFile, &dwHignSize);
    ASSERT(dwHignSize == 0);
    if( dwSize == 0 ) return _Failed(_T("File is empty"));
    if ( dwSize > (2 << 22) ) return _Failed(_T("File is too large")); // Support below 4MB

    DWORD dwRead = 0;
    LPBYTE pByte = new BYTE[ dwSize ];
    ::ReadFile( hFile, pByte, dwSize, &dwRead, NULL ); // Sync
    ::CloseHandle( hFile ); // Close File

    if( dwRead != dwSize ) {
        delete[] pByte;
        Release();
        return _Failed(_T("Could not read file"));
    }

    // Succeeded
    bool ret = LoadFromMem(pByte, dwSize, encoding);
    delete[] pByte;

    return ret;
}

UI_END_NAMESPACE