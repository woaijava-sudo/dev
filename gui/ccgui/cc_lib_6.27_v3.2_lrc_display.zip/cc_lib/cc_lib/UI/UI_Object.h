#ifndef _CC_UI_OBJECT_H
#define _CC_UI_OBJECT_H

#pragma once

#include "UI_ObjectInterface.h"

UI_BEGIN_NAMESPACE
struct XClass;

class XObject;
class XException;

//////////////////////////////////////////////////////////////////////////

void CL_API XClassInit( XClass* pNewClass );
struct X_CLASSINIT { X_CLASSINIT( XClass* pNewClass ) { XClassInit(pNewClass); } };

struct CL_API XClass
{
    XObject*        CreateObject(); // �����ڲ�ʹ��
    XObject*        CreateObject(XObject*); // �����ڲ�ʹ��
    BOOL            IsDerivedFrom(const XClass* pBaseClass) const;

    XObject* (PASCAL* m_pfnCreateObject)();
    XObject* (PASCAL* m_pfnCreateObject_V2)(XObject*);

    LPCTSTR         m_lpszClassName;
    size_t          m_nObjectSize;
    XClass*         m_pBaseClass;
    XClass*         m_pNextClass;
};

#define X_CLASS(class_name) ((XClass*)(&class_name::class##class_name))
#define X_KINDOF(class_name, object) ASSERT((object)->IsKindOf(X_CLASS(class_name)))

/************************************************************************/
/*  WITH_PARA macros made specially to fit XControl                     */
/************************************************************************/
#define XUI ::cc::UI::
#define X_DECLARE_CLASS(class_name) \
public: \
    static XUI XClass class##class_name; \
    virtual XUI XClass* GetClass() const; \
    static XUI XObject* PASCAL CreateObject();

#define X_IMPLEMENT_CLASS(class_name, base_class_name) \
    XUI XObject* PASCAL class_name::CreateObject() { return new class_name; } \
    XUI XClass class_name::class##class_name = { class_name::CreateObject, NULL, \
        _T(#class_name), sizeof(class class_name), X_CLASS(base_class_name), NULL }; \
    static XUI X_CLASSINIT _x_init_##class_name(&class_name::class##class_name); \
    XUI XClass* class_name::GetClass() const { return X_CLASS(class_name); }

#define X_DECLARE_CLASS_WITH_PARA(class_name) \
public: \
    X_DECLARE_CLASS(class_name) \
    static XUI XObject* PASCAL CreateObject(XObject*);

#define X_IMPLEMENT_CLASS_WITH_PARA(class_name, base_class_name) \
    XUI XObject* PASCAL class_name::CreateObject() { return new class_name; } \
    XUI XClass class_name::class##class_name = { class_name::CreateObject, class_name::CreateObject, \
        _T(#class_name), sizeof(class class_name), X_CLASS(base_class_name), NULL }; \
    static XUI X_CLASSINIT _x_init_##class_name(&class_name::class##class_name); \
    XUI XClass* class_name::GetClass() const { return X_CLASS(class_name); } \
    XUI XObject* PASCAL class_name::CreateObject(XUI XObject* pOb) { return new class_name(pOb); }

//////////////////////////////////////////////////////////////////////////

class CL_API XObject
{
    X_DECLARE_CLASS(XObject)
public:
    virtual ~XObject();
    BOOL IsKindOf(const XClass* pClass) const;

    virtual void* GetInterface(HINTERFACE hi);

#ifdef _DEBUG
    virtual void AssertValid() const;
#endif

protected:
    XObject();

private:
    XObject(const XObject& objectSrc);
    void operator=(const XObject& objectSrc);
};

DEF_LIST_TEMPLATE1(XObject*);

//////////////////////////////////////////////////////////////////////////

class CL_API XException : public XObject
{
    X_DECLARE_CLASS(XException)
public:
    XException(BOOL bAutoDelete = TRUE);
    virtual ~XException();

    void Delete();

public:
    XString m_szMessage;
    BOOL    m_bAutoDelete;
};

//////////////////////////////////////////////////////////////////////////

UI_END_NAMESPACE
#endif