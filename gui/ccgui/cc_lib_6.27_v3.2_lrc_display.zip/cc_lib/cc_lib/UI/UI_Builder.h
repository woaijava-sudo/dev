#ifndef _CC_UI_BUILDER_H
#define _CC_UI_BUILDER_H

#include "UI_MarkupNode.h"
#include "UI_Markup.h"

#pragma once

UI_BEGIN_NAMESPACE
DEF_DICT_TEMPLATE3(XString, DWORD, LPCTSTR);
class CL_API XBuilder
{
public:
    XBuilder();

    // Create
    XControl* CreateFromFile( LPCTSTR lpszSrc, XWindow* pWindow, int encoding = XMarkup::XMLFILE_ENCODING_UTF8,
        XControl* pParent = NULL ); // Filename like "XX.txt" or "ABC\\XX.txt"
    XControl* CreateFromString( LPCTSTR lpszXml, XWindow* pWindow, XControl* pParent = NULL );

    // Info
    const XMarkup* GetMarkup() const;
    XString GetLastErrorMessage() const;

    static void _InitAttrMap();
    static void _ClearAttrMap();

private:
    XControl* _ParseXml( XControl* pParent = NULL);
    XControl* _CreateFromXml( XMarkupNode* pNode, XControl* pParent = NULL  );
    UINT _GetIdByAttrName( LPCTSTR pstrName );
    bool _SetAttribute( XControl* pControl, UINT uID, LPCTSTR pstrValue ); // Important

private:
    // Helpers
    COLORREF    _ParseColor( LPCTSTR pstrValue ); // start with "#", "$", "@"
    XRect       _ParseRect( LPCTSTR pstrValue );
    XSize       _ParseSize( LPCTSTR pstrValue );
    BOOL        _ParseBool( LPCTSTR pstrValue );
    UINT        _ParseUint( LPCTSTR pstrValue );
    int         _ParseInt( LPCTSTR pstrValue );
    void        _ParseFont( XControl* pControl, LPCTSTR pstrValue ); // Two parameters because of special XControl::SetTextFont(...)
    void        _ParseDefaultFont( XWindow* pWindow, LPCTSTR pstrValue );
    void        _ParseFontAdv( LPCTSTR pstrValue, XString&, int&, BOOL&, BOOL&, BOOL& );

private:
    XWindow*        m_pWindow;
    _IClassAdv*     m_IAdvCreate; // Dynamic create interface
    XMarkup         m_Xml;
    static Dictionary<XString, DWORD, LPCTSTR>     m_mapAttributes; // Map: Name => ID (switch id)
};

UI_END_NAMESPACE
#endif