#include "StdAfx.h"

#define MAX_CHAR_LEN 255
#define DEFAULT_EDIT_STYLE 0

CONTROLS_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS_WITH_PARA(XEdit, XLabel)

//////////////////////////////////////////////////////////////////////////

XEdit::XEdit( XObject* pOb /*= NULL*/ ): XLabel(pOb),
    m_uMaxCharLength(MAX_CHAR_LEN),
    m_chPasswordMask(_T('*')),
    m_uState(0),
    m_clrEditBkColor(CLR_INVALID),
    m_uEditStyle(DEFAULT_EDIT_STYLE)
{
    m_uTextStyle |= DT_VCENTER;
    m_dwBkColor = MAKE_RGB(XCOLOR_EDIT_BACKGROUND_NORMAL);
    m_rcTextPadding = XRect(2, 2, 2, 2);
}

XEdit::~XEdit()
{

}

void* XEdit::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_EDIT: return this;
    }
    return XLabel::GetInterface(hi);
}

void XEdit::Event( TEvent& event )
{
    if (!m_bMouseEnabled)
    {
        if (OnMouseEvent(event.msg.message))
        {
            if ( m_pParent != NULL )
            {
                event.sender = this;
                event.receiver = m_pParent;
                event.dispatcher->PostEvent(event);
            }
            else
            {
                XLabel::Event(event);
            }
        }
    }
    else
    {
        switch (event.msg.message)
        {
        case WM_SETCURSOR:
            if (m_bEnabled)
            {
                ::SetCursor(::LoadCursor(NULL, MAKEINTRESOURCE(IDC_IBEAM)));                
            }
            return;
        case WM_SIZE:
            if ( m_pChildWindow != NULL )
            {
                m_pWindow->SetFocus(this);
            }
            break;
        case WM_MOUSEWHEEL:
            break;
        case WM_SETFOCUS:
            if (m_bEnabled)
            {
                if( m_pChildWindow != NULL ) return;
                X_CreateObject(X_CLASS(XEditWindow), (XObject**)&m_pChildWindow);
                ASSERT(m_pChildWindow);
                m_pChildWindow->Init(this);
                XPoint pt;
                pt.x = event.msg.pt.x - m_pChildWindow->GetRect().left;
                pt.y = event.msg.pt.y - m_pChildWindow->GetRect().top;
                int sel = m_pChildWindow->CharFromPos(pt);
                m_pChildWindow->SetSel(sel, sel);
                if ((m_flags & XFLAG_STATIC) == 0)
                {
                    m_uState |= XSTATE_FOCUSED;
                }
                Invalidate();
            }
            break;
        case WM_KILLFOCUS:
            if (m_bEnabled && ((m_flags & XFLAG_STATIC) == 0))
            {
                m_uState &= ~XSTATE_FOCUSED;
            }
            Invalidate();
            break;
        case WM_MOUSEMOVE:
        case WM_LBUTTONUP:
            return;
        case WM_MOUSEENTER:
            if( m_bEnabled && ((m_flags & XFLAG_STATIC) == 0))
            {
                m_uState |= XSTATE_HOT;
                Invalidate();
            }
            return;
        case WM_MOUSELEAVE:
            if( m_bEnabled && ((m_flags & XFLAG_STATIC) == 0))
            {
                m_uState &= ~XSTATE_HOT;
                Invalidate();
            }
            return;
        case WM_LBUTTONDOWN:
        case WM_RBUTTONDOWN:
        case WM_LBUTTONDBLCLK:
            if( m_bEnabled )
            {
                ASSERT(m_pWindow);
                m_pWindow->_ReleaseCapture();
                if( m_bFocused && m_pChildWindow == NULL )
                {
                    X_CreateObject(X_CLASS(XEditWindow), (XObject**)&m_pChildWindow);
                    ASSERT(m_pChildWindow);
                    m_pChildWindow->Init(this);
                }

                if( (m_bFocused && m_pChildWindow == NULL && m_rcClient.PtInRect(event.msg.pt))
                    || m_pChildWindow != NULL )
                {
                    int nSize = m_pChildWindow->_GetWindowTextLength();
                    if( nSize == 0 )
                        nSize = 1;

                    m_pChildWindow->SetSel(0, nSize);
                }
            }
            return;
        }

        XLabel::Event(event);
    }
}

void XEdit::Paint( HDC hDC, const XRect& rect )
{
    if ( !m_rcPaint.IntersectRect(&rect, &m_rcClient) ) return;
    if( m_bFocused ) m_uState |= XSTATE_FOCUSED;
    if( !m_bEnabled ) m_uState |= XSTATE_DISABLED;

    if( m_clrTextColor == CLR_INVALID )
        m_clrTextColor = m_pWindow->m_clrDefaultFontColor;
    if( m_clrDisabledTextColor == CLR_INVALID )
        m_clrDisabledTextColor = m_pWindow->m_clrDefaultDisabledColor;

    if( m_szText.IsEmpty() )
    {
#ifdef _DEBUG
        TRACE("[%s - 0x%X] waring: this control has not text string.", GetClass()->m_lpszClassName, this);
#endif // _DEBUG
    }

    XControl::PaintBkColor(hDC);

    if ((m_flags & XFLAG_STATIC) == 0)
    {
        if( (m_uState & XSTATE_DISABLED) != 0 ) {
            Rendering::X_DrawFrame(hDC, m_rcClient, PS_SOLID, 1, XCOLOR_CONTROL_BORDER_DISABLED, XCOLOR_CONTROL_BORDER_DISABLED,
                MAKE_RGB(XCOLOR_EDIT_BACKGROUND_DISABLED), m_uState);
        } else if( (m_uState & XSTATE_READONLY) != 0 ) {
            Rendering::X_DrawFrame(hDC, m_rcClient, PS_SOLID, 1, XCOLOR_CONTROL_BORDER_DISABLED, XCOLOR_CONTROL_BORDER_DISABLED,
                MAKE_RGB(XCOLOR_EDIT_BACKGROUND_READONLY), m_uState);
        } else if( (m_uState & XSTATE_HOT) != 0  || (m_uState & XSTATE_FOCUSED) != 0 ) {
            Rendering::X_DrawFrame(hDC, m_rcClient, PS_SOLID, 1, XCOLOR_CONTROL_BORDER_SELECTED, XCOLOR_CONTROL_BORDER_SELECTED,
                MAKE_RGB(XCOLOR_EDIT_BACKGROUND_HOVER), m_uState);
        } else {
            Rendering::X_DrawFrame(hDC, m_rcClient, PS_SOLID, 1, XCOLOR_CONTROL_BORDER_NORMAL, XCOLOR_CONTROL_BORDER_NORMAL,
                MAKE_RGB(XCOLOR_EDIT_BACKGROUND_NORMAL), m_uState);
        }
    }

    XString szText = m_szText;
    // ���������룬��Ϊ����
    if( IsPassword() )
    {
        szText.Empty();
        LPCTSTR pch = m_szText.GetBuffer(0);
        while( *pch != _T('\0') )
        {
            szText += m_chPasswordMask;
            pch = ::CharNext(pch);
        }
    }

    XRect rc = m_rcClient;
    rc.InsetRect(m_rcTextPadding);

    Rendering::X_DrawText(hDC, m_pWindow, rc, szText, m_bEnabled ? m_clrTextColor : m_clrDisabledTextColor,
        m_pWindow->GetFontByHash(m_szFontHash), m_uTextStyle);
}

void XEdit::SetMaxCharLength( UINT uLength )
{
    m_uMaxCharLength = uLength;
}

UINT XEdit::GetMaxCharLength() const
{
    return m_uMaxCharLength;
}

void XEdit::SetReadOnly( BOOL bReadOnly )
{
    if (bReadOnly)
    {
        m_uEditStyle |= ES_READONLY;
    }
    else
    {
        m_uEditStyle &= ~ES_READONLY;
    }
}

BOOL XEdit::IsReadOnly() const
{
    return (m_uEditStyle & ES_READONLY) != 0;
}

void XEdit::SetPassword( BOOL bPassword )
{
    if (bPassword)
    {
        m_uEditStyle |= ES_PASSWORD;
    }
    else
    {
        m_uEditStyle &= ~ES_PASSWORD;
    }
}

BOOL XEdit::IsPassword()
{
    return (m_uEditStyle & ES_PASSWORD) != 0;
}

void XEdit::SetPasswordMask( TCHAR chPasswordMask )
{
    m_chPasswordMask = chPasswordMask;
    m_uEditStyle |= ES_PASSWORD;
}

TCHAR XEdit::GetPasswordMask()
{
    return m_chPasswordMask;
}

void XEdit::SetEditBkColor( COLORREF clrBkColor )
{
    m_clrEditBkColor = clrBkColor;
}

COLORREF XEdit::GetEditBkColor() const
{
    return m_clrEditBkColor;
}

void XEdit::SetEnable( BOOL bEnabled )
{
    XControl::SetEnable(bEnabled);
    if( !m_bEnabled ) {
        m_uState = 0;
    }
}

void XEdit::SetText( LPCTSTR pstrText )
{
    m_szText = pstrText;
    if( m_pChildWindow != NULL ) m_pChildWindow->_SetWindowText(m_szText);
    Invalidate();
}

void XEdit::SetVisible( BOOL bVisible )
{
    XControl::SetVisible(bVisible);
    if( !IsVisible() && m_pWindow != NULL ) m_pWindow->SetFocus(NULL);
}

DWORD XEdit::GetFlags() const
{
    return ( m_bEnabled ?  ( m_flags | XFLAG_SETCURSOR | XFLAG_TABSTOP) : m_flags );
}

int XEdit::GetText( LPTSTR lpString, int nMaxCount )
{
    ASSERT_VALID(m_pChildWindow);
    ASSERT(lpString);
    ASSERT(nMaxCount);
    return m_pChildWindow->_GetWindowText(lpString, nMaxCount);
}

int XEdit::GetTextLength()
{
    ASSERT_VALID(m_pChildWindow);
    return m_pChildWindow->_GetWindowTextLength();
}

void XEdit::SetEditStyle( UINT uAdd, UINT uRemove /*= 0*/ )
{
    m_uEditStyle |= uAdd;
    m_uEditStyle &= ~uRemove;
}

UINT XEdit::GetEditStyle() const
{
    return m_uEditStyle;
}

XSize XEdit::EstimateSize( const XSize& )
{
    ASSERT_VALID(m_pWindow);
    return XSize(GetFixedWidth(), 12 + m_pWindow->GetFontInfoByHash(m_szFontHash)->tm.tmHeight);
}

CONTROLS_END_NAMESPACE