#include "StdAfx.h"

CONTROLS_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS_WITH_PARA(XTitle, XText)
//////////////////////////////////////////////////////////////////////////

bool CreateTitleWnd(void* pVoid, LPARAM lParam, WPARAM wParam)
{
    XTitle* pTitle = GetITitle(static_cast<XControl*>(pVoid));
    ASSERT(pTitle);

    // create window
    pTitle->Init();

    return true;
}

XTitle::XTitle( XObject* pOb /*= NULL*/ ): XText(pOb)
{
    AddDelegate(_T("Init"), CreateTitleWnd);
}

XTitle::~XTitle()
{
    if (m_pChildWindow2 != NULL)
    {
        m_pChildWindow2->_SendMessage( WM_CLOSE );
        m_pChildWindow2 = NULL;
    }
}

void XTitle::Init()
{
    X_CreateObject(X_CLASS(XTitleWindow), (XObject**)&m_pChildWindow2);
    ASSERT(m_pChildWindow2 != NULL);
    m_pChildWindow2->Init(this);
}

XControl* XTitle::CreateControl( XClass* pClass )
{
    VERIFY(NULL); // not implemented
    return NULL;
}

void* XTitle::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_TITLE: return this;
    }
    return XText::GetInterface(hi);
}

void XTitle::SetEnable( BOOL bEnabled )
{
    XControl::SetEnable(bEnabled);
}

void XTitle::Event( TEvent& event )
{
    if (!m_bMouseEnabled)
    {
        if (OnMouseEvent(event.msg.message))
        {
            if ( m_pParent != NULL )
            {
                event.sender = this;
                event.receiver = m_pParent;
                event.dispatcher->PostEvent(event);
            }
            else
            {
                XControl::Event(event);
            }
        }
    }
    else
    {
        switch (event.msg.message)
        {
        case WM_LBUTTONDOWN:
            // �첽����
            {
//                 XString* s = new XString;
//                 s->Format(_T("%ld"),::timeGetTime());
//                 m_pChildWindow2->_PostMessage(XTITLE_WM_POST_TEXT, 0, (LPARAM)s);
            }
            break;
        }
        XText::Event(event);
    }
}

XSize XTitle::EstimateSize( const XSize& )
{
    ASSERT_VALID(m_pWindow);
    return XSize(GetFixedWidth(), 20 + m_pWindow->GetFontInfoByHash(m_szFontHash)->tm.tmHeight);
}

void XTitle::Paint( HDC hDC, const XRect& rect )
{
    if ( !m_bEnabled || !m_rcPaint.IntersectRect(&rect, &m_rcClient) ) return;

    // bgcolor = black while textcolor = white
    Rendering::X_DrawColor(hDC, m_rcClient, ARGB(255, 0, 0, 0));
    // XControl::PaintBkColor(hDC);
    // ASSERT(cache)

    auto cache = m_pChildWindow2->Lock();
    Enumerator::Internal::CopyFrom(task_list.Wrap(), cache->Wrap());
    m_pChildWindow2->Unlock();
    
    // preparations
    if( m_clrTextColor == 0 )
        m_clrTextColor = m_pWindow->m_clrDefaultFontColor;
    if( m_clrDisabledTextColor == 0 )
        m_clrDisabledTextColor = m_pWindow->m_clrDefaultDisabledColor;

    HFONT hFont = m_pWindow->GetFontByHash(m_szFontHash);

    // drawing
    XRect center_rt = m_rcClient;
    center_rt.top = center_rt.bottom - (center_rt.Height() / 2);
    center_rt.bottom = center_rt.top + 30;

    int y = center_rt.top;
    int h = 0;

    XRect rc;

    Enumerator::ReverseEnumerator<AutoPtr<XTitleTask>> enumerator(task_list.Wrap());
    while (enumerator.Next() && y > 0)
    {
        XTitleTask* task = enumerator.Current().Obj();
        const XString& text = *(task->message.Obj());

        // color
        double sine = 0.0, cosine = 0.0;
        BYTE rgb = 0;
        COLORREF clr;
        switch (task->state)
        {
        case XTitleTask::FADE_IN:
            sine = sin(task->completed * D3D_PI / 2.0);
            rgb = (BYTE)(255 * sine);
            clr = RGB(rgb, rgb, rgb);
            break;
        case XTitleTask::HOLD:
            clr = RGB(255, 255, 255);
            break;
        case XTitleTask::FADE_OUT:
            cosine = cos(task->completed * D3D_PI / 2.0);
            rgb = (BYTE)(255 * cosine);
            clr = RGB(rgb, rgb, rgb);
            break;
        default:
            clr = RGB(0, 0, 0);
            break;
        }

        rc = m_rcClient;
        // rendering
        if (!m_bShowHtml)
        {
            h = Rendering::X_DrawText(hDC, m_pWindow, rc, text, clr, hFont, DT_CENTER | DT_CALCRECT);
            rc.SetRect(center_rt.left, y - h, center_rt.right, y);
            if (task->state == XTitleTask::FADE_IN)
            {
                rc.OffsetRect(0, (int)((m_rcClient.Height() - h) * (1 - sine)));
            }
            Rendering::X_DrawText(hDC, m_pWindow, rc, text, clr, hFont, DT_CENTER);
        }
        else
        {
            Rendering::X_DrawHtmlText(hDC, m_pWindow, rc, text, clr, m_rcLinks, m_szLinks, m_nLinks, DT_CENTER | DT_CALCRECT);
            h = rc.Height() + 10;
            rc.SetRect(center_rt.left, y - h, center_rt.right, y);
            Rendering::X_DrawHtmlText(hDC, m_pWindow, rc, text, clr, m_rcLinks, m_szLinks, m_nLinks, DT_CENTER);
        }

        if (task->state == XTitleTask::FADE_IN) // ����λ��
        {
            h = (int)(h * sine);
        }

        y -= h;
    }
}


CONTROLS_END_NAMESPACE