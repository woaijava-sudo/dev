#include "StdAfx.h"

WINDOW_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS(XWindow, XCmdTarget)

List<XWindow*> XWindow::m_preMessages;
XPoint XWindow::m_ptMousePos;
//////////////////////////////////////////////////////////////////////////

XWindow::XWindow(): m_pRoot(NULL),
    m_hDC(NULL),
    m_hDcOffscreen(NULL),
    m_hDcBackground(NULL),
    m_hBmpBackground(NULL),
    m_hBmpOffscreen(NULL),
    m_nDisablePumpCount(0),
    m_nMsgLast(WM_NULL),
    m_pEventClick(NULL),
    m_pFocus(NULL),
    m_bFirstInit(TRUE),
    m_bMouseTracking(FALSE),
    m_pEventHover(NULL),
    m_pEventKey(NULL),
    m_uTimerID(0x1000),
    m_clrDefaultFontColor(MAKE_RGB(XCOLOR_CONTROL_TEXT_NORMAL)),
    m_clrDefaultDisabledColor(MAKE_RGB(XCOLOR_CONTROL_TEXT_DISABLED)),
    m_bAutoDestroy(TRUE),
    m_hwndParent(NULL),
    m_bDead(FALSE)
{
    memset(&m_msg, 0, sizeof(MSG));
    memset(&m_msgT, 0, sizeof(MSG));
}

XWindow::~XWindow()
{
    if (m_bAutoDestroy)
    {
        DeleteComponents();
    }
}

void* XWindow::GetInterface( HINTERFACE hi )
{
    switch (hi)
    {
    case HI_WINDOW_EX: return this;
    }
    return XCmdTarget::GetInterface(hi);
}

void XWindow::DeleteComponents()
{
    TAsyncNotify* pNotify = NULL;
    // Delete the control-tree structures
    for ( int i = 0; i < m_syncNotify.Count(); i++ )
    {
        pNotify = m_syncNotify[i];
#ifdef _DEBUG
        TraceDeleteNotify(pNotify);
#endif // _DEBUG
        delete pNotify;
    }
    XDeleteControl(m_pRoot);
    if (m_hDC != NULL) _ReleaseDC(m_hDC);
    _KillAllTimers();
    int nFind = m_preMessages.IndexOf(this);
    if (nFind > -1)
    {
        m_preMessages.RemoveAt(nFind);
    }

    // Remove resources
    RemoveAllFonts();
    RemoveAllImages();
}

#ifdef _DEBUG
void XWindow::TraceDeleteNotify( TAsyncNotify* pNotify )
{
    ASSERT(pNotify);
    ASSERT(pNotify->sender);
    LPCTSTR lpszMsg = GetMsgName(pNotify->msg.message);
    LPCTSTR lpszClassName = NAString;
    if (pNotify->sender)
    {
        lpszClassName = pNotify->sender->GetClass()->m_lpszClassName;
    }
    if (lpszMsg)
    {
        TRACE("[%s - 0x%X] Delete async notification [ %s ] ==> sender [%s - 0x%X]", GetClass()->m_lpszClassName,
            this, lpszMsg, lpszClassName, pNotify->sender);
    }
    else
    {
        TRACE("[%s - 0x%X] Delete async notification [ 0x%04X ] ==> sender [%s - 0x%X]", GetClass()->m_lpszClassName,
            this, pNotify->msg.message, lpszClassName, pNotify->sender);
    }
}
#endif // _DEBUG


void XWindow::Notify( TAsyncNotify& notify )
{
#ifdef _DEBUG
    TRACE("[%s - 0x%X] Notify null ( Probably reason: derived class has not implemented INotify interface )",
        GetClass()->m_lpszClassName, this);
#endif // _DEBUG
}

#ifdef _DEBUG
void XWindow::AssertValid() const
{
    XObject::AssertValid();
}
#endif // _DEBUG

HDC XWindow::GetDC() const
{
    return m_hDC;
}

void XWindow::Dead()
{
    m_bDead = TRUE;
}

void XWindow::SetParentWindow( XWindow* pWindow )
{
    m_hwndParent = pWindow;
}

void XWindow::InitializeUI( HWND hwndParent /*= NULL*/, DWORD dwStyle /*= XWS_FRAME*/, DWORD dwExStyle /*= XWSE_FRAME*/ )
{

}

XWindow* XWindow::__Create( XClass* pClass )
{
    ASSERT(pClass);
    ASSERT(pClass->IsDerivedFrom(X_CLASS(XWindow)));
    XWindow* pWindow = NULL;
    X_CreateObject(pClass, (XObject**)&pWindow);
    return pWindow;
}

WPARAM XWindow::DoModal()
{
    ASSERT(_IsWindow());
    XWindowImpl hWndParent;
    hWndParent.Attach(_GetWindowOwner());
    _ShowWindow(SW_SHOWNORMAL);
    hWndParent._EnableWindow(FALSE);
    _SetFocus();
    WPARAM wp = MessageLoop();
    hWndParent._EnableWindow(TRUE);
    hWndParent._SetFocus();
    return wp;
}

void XWindow::Close()
{
    ASSERT(_IsWindow());
    _PostMessage(WM_CLOSE);
}

WPARAM XWindow::MessageLoop()
{
    ASSERT_VALID(this);

    // for tracking the idle time state
    BOOL bIdle = TRUE;
    LONG lIdleCount = 0;

    // acquire and dispatch messages until a WM_QUIT message is received.
    for (;;)
    {
        // phase1: check to see if we can do idle work
        while (bIdle && !::PeekMessage(&m_msg, NULL, NULL, NULL, PM_NOREMOVE))
        {
            // call OnIdle while in bIdle state
            if (!OnIdle(lIdleCount++))
                bIdle = FALSE; // assume "no idle" state
        }

        // phase2: pump messages while available
        do
        {
            // pump message, but quit on WM_QUIT
            if (!PumpMessage())
                goto End;

            // reset "no idle" state after pumping "normal" message
            if (IsIdleMessage(&m_msg))
            {
                bIdle = TRUE;
                lIdleCount = 0;
            }

        } while (::PeekMessage(&m_msg, NULL, NULL, NULL, PM_NOREMOVE));
    }

End:
    return m_msg.wParam;
}

BOOL XWindow::PumpMessage()
{
    ASSERT_VALID(this);

    if (!::GetMessage(&m_msg, NULL, NULL, NULL))
    {
#ifdef _DEBUG
        TRACE("[%s - 0x%X] ==> PumpMessage ==> WM_QUIT", GetClass()->m_lpszClassName, this);
        m_nDisablePumpCount++; // application must die
        // Note: prevents calling message loop things in 'ExitInstance'
        // will never be decremented
#endif
        return FALSE;
    }

#ifdef _DEBUG
    if (m_nDisablePumpCount != 0)
    {
        TRACE("Error: PumpMessage called when not permitted.");
        ASSERT(FALSE);
    }
    TraceMsg_T(_T("PumpMessage"), &m_msg, this);
#endif

    // process this message

    if (!PreTranslateMessage(&m_msg))
    {
        ::TranslateMessage(&m_msg);
        ::DispatchMessage(&m_msg);
    }

    return TRUE;
}

BOOL XWindow::IsIdleMessage( MSG* pMsg )
{
    // Return FALSE if the message just dispatched should _not_
    // cause OnIdle to be run.  Messages which do not usually
    // affect the state of the user interface and happen very
    // often are checked for.

    // redundant WM_MOUSEMOVE and WM_NCMOUSEMOVE
    if (pMsg->message == WM_MOUSEMOVE || pMsg->message == WM_NCMOUSEMOVE || pMsg->message == WM_MOUSEWHEEL )
    {
        // mouse move at same position as last mouse move?
        if (m_ptMousePos == pMsg->pt && pMsg->message == m_nMsgLast)
            return FALSE;

        m_ptMousePos = pMsg->pt;  // remember for next time
        m_nMsgLast = pMsg->message;
        return TRUE;
    }

    // WM_PAINT and WM_SYSTIMER (caret blink)
    return pMsg->message != WM_PAINT && pMsg->message != 0x0118;
}

BOOL XWindow::OnIdle( LONG lCount )
{
    ASSERT_VALID(this);

    return lCount < 0;  // nothing more to do if lCount >= 0
}

BOOL XWindow::PreTranslateMessage( const LPMSG pMsg )
{
    // Pretranslate Message takes care of system-wide messages, such as
    // tabbing and shortcut key-combos. We'll look for all messages for
    // each window and any child control attached.
    HWND hwndParent = ::GetParent(pMsg->hwnd);
    DWORD uStyle = (DWORD) GetWindowLong(pMsg->hwnd, GWL_STYLE);
    LRESULT lRes = 0;
    for( int i = 0; i < m_preMessages.Count(); i++ )
    {
        XWindow* pWindow = static_cast<XWindow*>(m_preMessages[i]);
        if( pMsg->hwnd == pWindow->GetSafeHwnd() || (hwndParent == pWindow->GetSafeHwnd() && ((uStyle & WS_CHILD) != 0)) )
        {
            if( pWindow->PreMessageHandler(pMsg->message, pMsg->wParam, pMsg->lParam, &lRes) ) return true;
        }
    }
    return false;
}

LRESULT XWindow::HandleMessage( UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    if (m_bDead) return XCmdTarget::HandleMessage(uMsg, wParam, lParam);

    LRESULT lRes = 0;
    if (uMsg == WM_DESTROY) // default don't handle WM_DESTROY, in case of child window destroyed => main window destroyed
    {
        return 0;
    }

    if ( XWindow::MessageHandler(uMsg, wParam, lParam, &lRes) )
    {
        return lRes;
    }
    else
    {
        return XCmdTarget::HandleMessage(uMsg, wParam, lParam);
    }
}

LRESULT XWindow::MessageFilter( UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL* bHandled )
{
    return 0;
}

void XWindow::ExecAsyncNotify()
{
    TAsyncNotify* pNotify = NULL;
    if (m_syncNotify.Count() > 0)
    {
        while( pNotify = static_cast<TAsyncNotify*>(m_syncNotify[0]) )
        {
            m_syncNotify.Remove(0);
            if( pNotify->sender != NULL ) {
                pNotify->sender->GetIDelegate()->RunDelegate(_T("Notify"), pNotify);
            }
            for( int j = 0; j < m_Notifiers.Count(); j++ ) {
                static_cast<IXNotify*>(m_Notifiers[j])->Notify(*pNotify);
            }
#ifdef _DEBUG
            TraceDeleteNotify(pNotify);
#endif // _DEBUG
            delete pNotify;
        }
    }
}

BOOL XWindow::AttachControl( XControl* pControl )
{
    ASSERT_VALID(pControl);
    ASSERT(pControl->XIsKindOf(XContainer)); // Only container
    ASSERT(_IsWindow());
    XDeleteControl(m_pRoot);

    m_pEventHover = NULL;
    m_pEventClick = NULL;

    m_pRoot = GetIContainerEx(pControl);
    m_pRoot->SetParent(NULL);
    m_pRoot->SetOwner(this);
    m_pRoot->SetDrag(FALSE); // ��ֹ�϶�

    m_bNeedUpdate = TRUE;
    m_bFirstInit = TRUE;

    return TRUE;
}

BOOL XWindow::RegisterControl( XControl* pControl )
{
    ASSERT(pControl);
    if (pControl->GetName().IsEmpty()) return FALSE;
    m_mapNames.Set(pControl->GetName(), pControl);
    return TRUE;
}

BOOL XWindow::UnregisterControl( XControl* pControl )
{
    ASSERT(pControl);
    if (pControl->GetName().IsEmpty()) return FALSE;
    return m_mapNames.Remove(pControl->GetName());
}

HWND XWindow::_SetCapture()
{
    ASSERT(m_hWnd);
    m_bMouseCapture = TRUE;
    return ::SetCapture(m_hWnd);
}

BOOL XWindow::_ReleaseCapture()
{
    m_bMouseCapture = FALSE;
    return ::ReleaseCapture();
}

HDC XWindow::_CreateCompatibleDC()
{
    ASSERT(m_hDC);
    return ::CreateCompatibleDC(m_hDC);
}

HBITMAP XWindow::_CreateCompatibleBitmap( int cx, int cy )
{
    ASSERT(m_hDC);
    return ::CreateCompatibleBitmap(m_hDC, cx, cy);
}

int XWindow::_GetDeviceCaps( int index )
{
    ASSERT(m_hDC);
    return ::GetDeviceCaps(m_hDC, index);
}

BOOL XWindow::AddNotifier( IXNotify* pNotifier )
{
    if (!m_Notifiers.Contains(pNotifier))
    {
        m_Notifiers.Add(pNotifier);
        return TRUE;
    }
    return FALSE;
}

BOOL XWindow::RemoveNotifier( IXNotify* pNotifier )
{
    int nFind = m_Notifiers.IndexOf(pNotifier);
    if (nFind > -1)
    {
        m_Notifiers.RemoveAt(nFind);
        return TRUE;
    }
    return FALSE;
}

void XWindow::SendAsyncNotify( TAsyncNotify& notify, XWindow* pSender /*= NULL*/, BOOL bSync /*= FALSE*/ )
{
    notify.msg.pt = m_ptMousePos;
    notify.msg.time = ::GetTickCount();

    LPCTSTR lpszMsg = NAString;
    LPCTSTR lpszObjectName = NAString;
    LPCTSTR lpszClassName = NAString;

    if (notify.bTrans)
    {
        lpszMsg = (LPCTSTR)notify.msg.message;
    }
    else
    {
        lpszMsg = GetMsgName(notify.msg.message);
    }

    if (notify.sender != NULL)
    {
        lpszClassName = notify.sender->GetClass()->m_lpszClassName;
        lpszObjectName = notify.sender->GetName();
    }

    if( !bSync )
    {
        // Send to all listeners
        if( notify.sender != NULL )
        {
            notify.sender->GetIDelegate()->RunDelegate(_T("Notify"), &notify);
        }
        if (pSender == NULL) // Send to all notifier
        {
            for( int i = 0; i < m_Notifiers.Count(); i++ )
            {
#ifdef _DEBUG
                TRACE("['%s' - 0x%X] Send asynchronous notification [ %s ] ==> sender ['%s' - %s - 0x%X]", GetClass()->m_lpszClassName,
                    this, lpszMsg, lpszObjectName, lpszClassName, notify.sender);
#endif // _DEBUG
                static_cast<IXNotify*>(m_Notifiers[i])->Notify(notify);
            }
        } else { // Send to sender
            static_cast<IXNotify*>(pSender)->Notify(notify);
        }
    }
    else if ( !notify.bTrans )
    {
        TAsyncNotify *pNotify   = new TAsyncNotify;
        pNotify->bTrans         = FALSE;
        pNotify->sender         = notify.sender;
        pNotify->msg.hwnd       = notify.msg.hwnd;
        pNotify->msg.message    = notify.msg.message;
        pNotify->msg.wParam     = notify.msg.wParam;
        pNotify->msg.lParam     = notify.msg.lParam;
        pNotify->msg.pt.x       = notify.msg.pt.x;
        pNotify->msg.pt.y       = notify.msg.pt.y;
        pNotify->msg.time       = notify.msg.time;
#ifdef _DEBUG
        if (lpszMsg)
        {
            TRACE("[%s - 0x%X] Create sync notification [ %s ] ==> sender ['%s' - %s - 0x%X]", GetClass()->m_lpszClassName,
                this, lpszMsg, lpszObjectName, lpszClassName, notify.sender);
        }
        else
        {
            TRACE("[%s - 0x%X] Create sync notification [ 0x%04X ] ==> sender ['%s' - %s - 0x%X]", GetClass()->m_lpszClassName,
                this, notify.msg.message, lpszObjectName, lpszClassName, notify.sender);
        }
#endif // _DEBUG
        m_syncNotify.Add(pNotify);
    }
    else
    {
        // Warning: �첽��Ϣ������Ϊ�Զ�����Ϣ
        // ��Ҫʹ�ã�����SendAsyncNotify(�Զ����첽��Ϣ)
        ASSERT(!"Send notify error. �첽��Ϣ������Ϊ�Զ�����Ϣ��");
    }
}

void XWindow::SendAsyncNotify( XControl* pControl, DWORD dwMessage, BOOL bTrans /*= FALSE*/, WPARAM wParam /*= 0*/,
    LPARAM lParam /*= 0*/, XWindow* pSender /*= NULL*/, BOOL bAsync /*= FALSE*/ )
{
    TAsyncNotify notify;
    notify.bTrans = bTrans;
    notify.sender = pControl;
    notify.msg.hwnd = m_hWnd;
    notify.msg.message = dwMessage;
    notify.msg.wParam = wParam;
    notify.msg.lParam = lParam;
    notify.msg.pt.x = 0; // �ȴ�ˢ��
    notify.msg.pt.y = 0;
    notify.msg.time = 0;
    SendAsyncNotify(notify, pSender, bAsync);
}

void XWindow::SendSyncNotify( LPCTSTR pstrText, WPARAM wParam /*= 0*/, LPARAM lParam /*= 0*/, IXNotify* _INotify /*= NULL*/ )
{
    ASSERT(pstrText);
#ifdef _DEBUG
    TRACE("['%s' - 0x%X] Send synchronous modified notification [ %s ]", GetClass()->m_lpszClassName, this, pstrText);
#endif // _DEBUG
    if (_INotify == NULL)
    {
        for( int i = 0; i < m_Notifiers.Count(); i++ )
        {
            static_cast<IXNotify*>(m_Notifiers[i])->AddSyncNotify(pstrText, wParam, lParam);
        }
    } else {
        _INotify->AddSyncNotify(pstrText, wParam, lParam);
    }
}

void XWindow::AddSyncNotify( LPCTSTR pstrText, WPARAM wParam /*= 0*/, LPARAM lParam /*= 0*/ )
{
    ASSERT(pstrText);
    TSyncNotify* pNotify = new TSyncNotify;
    pNotify->pstrMessage = pstrText;
    pNotify->wParam = wParam;
    pNotify->lParam = lParam;
    m_syncModifiedNotify.Add(pNotify);
}

void XWindow::ExecSyncNotify()
{
    List<TSyncNotify*> syncNotify;
    Enumerator::Internal::CopyFrom(syncNotify.Wrap(), m_syncModifiedNotify.Wrap());
    m_syncModifiedNotify.Clear(); // First clear

    for (int i = 0; i < syncNotify.Count(); i++)
    {
        TSyncNotify* pNotify = static_cast<TSyncNotify*>(syncNotify[i]);
        ASSERT(pNotify);
        // Only send to this
        SendAsyncNotify(NULL, (DWORD)(LPCTSTR) pNotify->pstrMessage, TRUE, pNotify->wParam, pNotify->lParam, this);
        delete pNotify;
    }
}

BOOL XWindow::AddPreMessageFilter( IXMessageFilter* pFilter )
{
    if (!m_preMessageFilters.Contains(pFilter))
    {
        m_preMessageFilters.Add(pFilter);
        return TRUE;
    }
    return FALSE;
}

BOOL XWindow::RemovePreMessageFilter( IXMessageFilter* pFilter )
{
    return m_preMessageFilters.Remove(pFilter);
}

BOOL XWindow::AddMessageFilter( IXMessageFilter* pFilter )
{
    if (!m_MessageFilters.Contains(pFilter))
    {
        m_MessageFilters.Add(pFilter);
        return TRUE;
    }
    return FALSE;
}

BOOL XWindow::RemoveMessageFilter( IXMessageFilter* pFilter )
{
    return m_MessageFilters.Remove(pFilter);
}

int XWindow::GetPostPaintCount() const
{
    return m_PostPaintCtrls.Count();
}

BOOL XWindow::AddPostPaint( XControl* pControl )
{
    if (!m_PostPaintCtrls.Contains(pControl))
    {
        m_PostPaintCtrls.Add(pControl);
        return TRUE;
    }
    return FALSE;
}

BOOL XWindow::RemovePostPaint( XControl* pControl )
{
    return m_PostPaintCtrls.Remove(pControl);
}

void XWindow::SetPostPaintIndex( XControl* pControl, int iIndex )
{
    RemovePostPaint(pControl);
    m_PostPaintCtrls.Set(iIndex, pControl);
}

void XWindow::SetMinSize( XSize& sz )
{
    ASSERT( sz.cx >= 0 && sz.cy >= 0 );
    m_szMin = sz;
}

void XWindow::SetMaxSize( XSize& sz )
{
    ASSERT( sz.cx >= 0 && sz.cy >= 0 );
    m_szMax = sz;
}

void XWindow::GetMinSize( XSize& sz )
{
    sz = m_szMin;
}

void XWindow::GetMaxSize( XSize& sz )
{
    sz = m_szMax;
}

void XWindow::Invalidate( XRect& rc )
{
    _InvalidateRect(&rc);
}

void XWindow::SetFocus( XControl* pControl )
{
    // Paint manager window has focus?
    HWND hFocusWnd = _GetFocus();
    if( hFocusWnd != m_hWnd && pControl != m_pFocus ) _SetFocus();
    // Already has focus?
    if( pControl == m_pFocus ) return;
    // Remove focus from old control
    if( m_pFocus != NULL )
    {
        PostEventT(m_pFocus, WM_KILLFOCUS);
        m_pFocus = NULL;
    }
    if( pControl == NULL ) return;
    // Set focus to new control
    if( pControl != NULL 
        && pControl->GetOwner() == this 
        && pControl->IsVisible() 
        && pControl->IsEnabled() ) 
    {
        m_pFocus = pControl;
        PostEventT(m_pFocus, WM_SETFOCUS);
    }
}

void XWindow::PostEventT( XControl* pControl, UINT uMsg /*= WM_NULL*/, WPARAM wParam /*= 0U*/, LPARAM lParam /*= 0L*/ )
{
    TEvent event = { 0 }; // ���￪ʼ�ṹ�Ĵ���
    event.sender = pControl;
    event.receiver = pControl;
    memcpy_s(&event.msg, sizeof(MSG), &m_msgT, sizeof(MSG));
    if (uMsg != WM_NULL)
    {
        event.msg.message = uMsg;
    }
    if (wParam != 0)
    {
        event.msg.wParam = wParam;
    }
    if (lParam != 0)
    {
        event.msg.lParam = lParam;
    }
    PostEvent(event);
}

void XWindow::PostEvent( TEvent& event )
{
    ASSERT(event.sender && event.receiver);
    event.dispatcher = this;
    XPoint pt(m_ptMousePos);
    _ScreenToClient(&pt);
    event.msg.pt = pt;
    event.msg.time = ::GetTickCount();
#ifdef _DEBUG
    LPCTSTR lpszMsgName = GetMsgName(event.msg.message);
    if (lpszMsgName)
    {
        TRACE("['%s' - 0x%X] Dispatcher: ['%s' - %s - 0x%X] sent [ '%s' ] to ['%s' - %s - 0x%X] ( WP - 0x%04X, LP - 0x%08lX )",
            GetClass()->m_lpszClassName, this, 
            event.sender->GetName(), event.sender->GetClass()->m_lpszClassName, event.sender, lpszMsgName,
            event.receiver->GetName(), event.receiver->GetClass()->m_lpszClassName, event.receiver,
            event.msg.wParam, event.msg.lParam);
    }
    else
    {
        TRACE("['%s' - 0x%X] Dispatcher: ['%s' - %s - 0x%X] sent [ 'MSG: 0x%04X' ] to ['%s' - %s - 0x%X] ( WP - 0x%04X, LP - 0x%08lX )",
            GetClass()->m_lpszClassName, this, 
            event.sender->GetName(), event.sender->GetClass()->m_lpszClassName, event.sender, event.msg.message,
            event.receiver->GetName(), event.receiver->GetClass()->m_lpszClassName, event.receiver,
            event.msg.wParam, event.msg.lParam);
    }
#endif // _DEBUG
    event.receiver->Event(event);
}

void XWindow::NeedUpdate( XControl* pControl )
{
    ASSERT_VALID(pControl);
#ifdef _DEBUG
    TRACE("['%s' - 0x%X] need an update called from ['%s' - %s - 0x%X]", GetClass()->m_lpszClassName, this,
        pControl->GetName(), pControl->GetClass()->m_lpszClassName, pControl);
#endif // _DEBUG
    // add...
    m_bNeedUpdate = true;
}

XControl* CALLBACK XWindow::__FindControlFromPoint( XControl* pControl, LPVOID pData )
{
    ASSERT(pControl && pData);
    LPPOINT pPoint = static_cast<LPPOINT>(pData);
    if (pControl->GetRect().PtInRect(*pPoint))
    {
        return pControl;
    }
    return NULL;
}

XControl* XWindow::FindControl( XPoint pt )
{
    ASSERT(m_pRoot);
    _ScreenToClient(&pt);
    XControl* pResult = m_pRoot->FindControl(__FindControlFromPoint, &pt, XFIND_VISIBLE | XFIND_HITTEST | XFIND_TOP_FIRST);
#ifdef _DEBUG
    if (pResult)
    {
        TRACE("['%s' - 0x%X] Find control ['%s' - %s - 0x%X] by %s", GetClass()->m_lpszClassName, this,
            pResult->GetName(), pResult->GetClass()->m_lpszClassName, pResult, pt.ToString());
    }
    else
    {
        TRACE("['%s' - 0x%X] Can not find control by %s", GetClass()->m_lpszClassName, this, pt.ToString());
    }
#endif // _DEBUG
    return pResult;
}

XControl* XWindow::FindControl( LPCTSTR lpszCtrlName )
{
    ASSERT(lpszCtrlName);
    ASSERT(IsValidString(lpszCtrlName));
    if( m_mapNames.IsEmpty() ) return NULL;
    XString lpszName(lpszCtrlName);
    if (m_mapNames.IsEmpty())
    {
        ASSERT(!"No data");
        return NULL;
    }
    XControl* pRet = NULL;
    bool bRet = m_mapNames.Lookup(lpszName, pRet);
#ifdef _DEBUG
    if (bRet && pRet)
    {
        TRACE("['%s' - 0x%X] Find control ['%s' - %s - 0x%X] by name('%s')", GetClass()->m_lpszClassName, this,
            pRet->GetName(), pRet->GetClass()->m_lpszClassName, pRet, lpszCtrlName);
    }
    else
    {
        TRACE("['%s' - 0x%X] Can not find control by name('%s')", GetClass()->m_lpszClassName, this, lpszCtrlName);
        ASSERT(!"The control to be find does not exist");
    }
#endif // _DEBUG
    return pRet;
}

UINT XWindow::MapState()
{
    static UINT uState;
    uState = 0;
    if( ::GetKeyState(VK_CONTROL) < 0 ) uState |= MK_CONTROL;
    if( ::GetKeyState(VK_RBUTTON) < 0 ) uState |= MK_LBUTTON;
    if( ::GetKeyState(VK_LBUTTON) < 0 ) uState |= MK_RBUTTON;
    if( ::GetKeyState(VK_SHIFT) < 0 )   uState |= MK_SHIFT;
    if( ::GetKeyState(VK_MENU) < 0 )    uState |= MK_ALT;
    return uState;
}

XPoint XWindow::GetMousePos()
{
    return m_ptMousePos;
}

BOOL XWindow::_SetTimer( XControl* pControl, UINT nTimerID, UINT uElapse )
{
    ASSERT(pControl);
    ASSERT(m_hWnd);
    ASSERT(uElapse > 0);
    for( int i = 0; i< m_Timers.Count(); i++ )
    {
        XTIMERINFO* pTimer = static_cast<XTIMERINFO*>(m_Timers[i]);
        if( pTimer->sender == pControl && pTimer->hWnd == m_hWnd && pTimer->nLocalID == nTimerID )
        {
            if( pTimer->bKilled )
            {
                if( ::SetTimer(m_hWnd, pTimer->uWinTimer, uElapse, NULL) ) {
                    pTimer->bKilled = FALSE;
                    return TRUE;
                }
                return FALSE;
            }
            return FALSE;
        }
    }

    m_uTimerID = (++m_uTimerID) % 0xFF;
    if( !::SetTimer(m_hWnd, m_uTimerID, uElapse, NULL) ) return FALSE;
    XTIMERINFO* pTimer = new XTIMERINFO;
    if( pTimer == NULL ) return FALSE;
    pTimer->hWnd = m_hWnd;
    pTimer->sender = pControl;
    pTimer->nLocalID = nTimerID;
    pTimer->uWinTimer = m_uTimerID;
    pTimer->uElapse = uElapse;
    pTimer->bKilled = FALSE;
    int ret = m_Timers.Add(pTimer);
    return ret;
}

BOOL XWindow::_KillTimer( XControl* pControl, UINT nTimerID )
{
    ASSERT(m_hWnd);
    ASSERT(pControl);
    ASSERT(nTimerID > 0);
    for( int i = 0; i< m_Timers.Count(); i++ )
    {
        XTIMERINFO* pTimer = static_cast<XTIMERINFO*>(m_Timers[i]);
        if( pTimer->sender == pControl && pTimer->hWnd == m_hWnd && pTimer->nLocalID == nTimerID )
        {
            if( pTimer->bKilled == FALSE ) {
                if( _IsWindow() ) ::KillTimer(pTimer->hWnd, pTimer->uWinTimer);
                pTimer->bKilled = TRUE;
                return TRUE;
            }
        }
    }
    return FALSE;
}

void XWindow::_KillTimerT( XControl* pControl )
{
    ASSERT(m_hWnd);
    ASSERT(pControl);
    int count = m_Timers.Count();
    for( int i = 0, j = 0; i < count; i++ )
    {
        XTIMERINFO* pTimer = static_cast<XTIMERINFO*>(m_Timers[i - j]);
        if( pTimer->sender == pControl && pTimer->hWnd == m_hWnd )
        {
            if( pTimer->bKilled == FALSE ) ::KillTimer(pTimer->hWnd, pTimer->uWinTimer);
            m_Timers.RemoveAt(i);
            j++;
        }
    }
}

void XWindow::_KillAllTimers()
{
    for( int i = 0; i < m_Timers.Count(); i++ )
    {
        XTIMERINFO* pTimer = static_cast<XTIMERINFO*>(m_Timers[i]);
        if( pTimer->hWnd == m_hWnd )
        {
            if( pTimer->bKilled == FALSE )
            {
                if( _IsWindow() ) ::KillTimer(m_hWnd, pTimer->uWinTimer);
            }
            delete pTimer;
            pTimer = NULL;
        }
    }

    m_Timers.Clear();
}

HWND XWindow::Create( HWND hwndParent, LPCTSTR pstrName, DWORD dwStyle, DWORD dwExStyle, int x /*= CW_USEDEFAULT*/, int y /*= CW_USEDEFAULT*/, int cx /*= CW_USEDEFAULT*/, int cy /*= CW_USEDEFAULT*/, HMENU hMenu /*= NULL */ )
{
    m_preMessages.Add(this);
    HWND hWnd = XCmdTarget::Create(hwndParent, pstrName, dwStyle, dwExStyle, x, y, cx, cy, hMenu);
    ASSERT(hWnd);
    m_hDC = XWindowImpl::_GetDC();
    ASSERT(m_hDC);
    return hWnd;
}

int XWindow::AddAnimation( XAnimTask& task )
{
    XAnimTask* pTask = new XAnimTask(task);
    if( pTask == NULL ) return 0;
    _InvalidateRect(NULL, FALSE);
    return m_anim.AddTask(pTask);
}

WINDOW_END_NAMESPACE