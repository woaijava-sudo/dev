#include "StdAfx.h"

CONTAINER_BEGIN_NAMESPACE
X_IMPLEMENT_CLASS_WITH_PARA(XContainer, XScroll)

XContainer::XContainer( XObject* pOb /*= NULL*/ ): XScroll(pOb), m_bAutoDelete(true)
{
    // ���������������
    m_flags |= XFLAG_SETCURSOR;
}

XContainer::~XContainer()
{
    if (m_bAutoDelete)
    {
        RemoveAll();
    }
}

#ifdef _DEBUG
void XContainer::AssertValid() const
{
    XControl::AssertValid();
}
#endif // _DEBUG

void XContainer::SetAutoDestroy( bool bAuto )
{
    m_bAutoDelete = bAuto;
}

void* XContainer::GetInterface(HINTERFACE hi)
{
    switch (hi)
    {
    case HI_CONTAINER: return this;
    case HI_CONTAINER_INTERFACE: return static_cast<IContainer*>(this);
    }
    return XScroll::GetInterface(hi);
}

XControl* XContainer::GetData( int nIndex ) const
{
    return m_Items.Get(nIndex);
}

int XContainer::Find( XControl* pControl ) const
{
    return m_Items.IndexOf(pControl);
}

bool XContainer::SetAt( XControl* pControl, int nIndex )
{
    for( int i = 0; i < m_Items.GetSize(); i++ )
    {
        if( m_Items[i] == pControl )
        {
            Invalidate();
            XDeleteControl(m_Items[i]);
            m_Items.RemoveAt(i);
            if (nIndex >= 0 && nIndex <= m_Items.GetSize())
            {
                m_Items.Set(nIndex, pControl);
                return true;
            }
            return false;
        }
    }
    return false;
}

int XContainer::GetSize() const
{
    return m_Items.GetSize();
}

int XContainer::Add( XControl* pControl )
{
    if( pControl == NULL) return -1;
    TRACE("['%s' - %s - 0x%X] has its child ['%s' - %s - 0x%p].", m_szName, GetClass()->m_lpszClassName, this,
        pControl->GetName(), pControl->GetClass()->m_lpszClassName, pControl);
    pControl->SetOwner(m_pWindow);
    pControl->SetParent(this);
    if( m_bVisible ) Invalidate();
    pControl->GetIDelegate()->RunDelegate(_T("Init"), pControl);
    return m_Items.Add(pControl);
}

bool XContainer::InsertAt( int nIndex, XControl* pControl )
{
    if( pControl == NULL) return false;
    if( m_bVisible ) Invalidate();
    if (nIndex >= 0 && nIndex <= m_Items.GetSize())
    {
        m_Items.Set(nIndex, pControl);
        return true;
    }
    return false;
}

bool XContainer::Remove( XControl* pControl )
{
    if( pControl == NULL) return false;

    for( int it = 0; it < m_Items.GetSize(); it++ )
    {
        if( m_Items[it] == pControl )
        {
            Invalidate();
            XDeleteControl(pControl);
            m_Items.RemoveAt(it);
            return true;
        }
    }
    return false;
}

bool XContainer::RemoveAt( int nIndex )
{
    return Remove((XControl*)m_Items.Get(nIndex));
}

void XContainer::RemoveAll()
{
    XControl* pControl = NULL;
    for( int i = 0; i < m_Items.GetSize(); i++ )
    {
        XDeleteControl(m_Items[i]);
    }
    m_Items.Clear();
}

void XContainer::Paint( HDC hDC, const XRect& rect )
{
    if ( !m_rcPaint.IntersectRect(&rect, &m_rcClient) ) return;

    XControl::Paint(hDC, m_rcPaint);
    XControl* pControl = NULL;
    for( int i = 0; i < m_Items.GetSize(); i++ )
    {
        pControl = m_Items[i];
        ASSERT_VALID(pControl);
        if (pControl->IsVisible())
        {
            pControl->Paint(hDC, m_rcPaint);
        }
    }
}

int XContainer::FindSelectable( int iIndex, bool bForward /*= true */ )
{
    IListArray* list = GetIListArray(this);
    IContainer* Container = GetIContainer(this);
    if (list != NULL)
    {
        int size = list->List_GetSize();
        if( size == 0 ) return -1;
        iIndex = CLAMP(iIndex, 0, size - 1);
        if( bForward ) {
            for( int i = iIndex; i < size; i++ ) {
                XControl* p = list->List_GetData(i);
                ASSERT_VALID(p);
                if( p->GetInterface(HI_LIST_ITEM) != NULL 
                    && p->IsVisible()
                    && p->IsEnabled() ) return i;
            }
            ASSERT(!"Index Valid.");
            return -1;
        } else {
            for( int i = iIndex; i >= 0; --i ) {
                XControl* p = list->List_GetData(i);
                ASSERT_VALID(p);
                if( p->GetInterface(HI_LIST_ITEM) != NULL 
                    && p->IsVisible()
                    && p->IsEnabled() ) return i;
            }
            return FindSelectable(0, true);
        }
    } else if (Container != NULL) {
        int size = Container->GetSize();
        if( size == 0 ) return -1;
        iIndex = CLAMP(iIndex, 0, size - 1);
        if( bForward ) {
            for( int i = iIndex; i < size; i++ ) {
                XControl* p = Container->GetData(i);
                ASSERT_VALID(p);
                if( p->GetInterface(HI_LIST_ITEM) != NULL 
                    && p->IsVisible()
                    && p->IsEnabled() ) return i;
            }
            ASSERT(!"Index Valid.");
            return -1;
        } else {
            for( int i = iIndex; i >= 0; --i ) {
                XControl* p = Container->GetData(i);
                ASSERT_VALID(p);
                if( p->GetInterface(HI_LIST_ITEM) != NULL 
                    && p->IsVisible()
                    && p->IsEnabled() ) return i;
            }
            return FindSelectable(0, true);
        }
    } else {
        ASSERT(!"No available interface found!");
        return 0;
    }
}

XRect XContainer::GetInset() const
{
    return m_rcInset;
}

void XContainer::SetInset( XRect& rcInset )
{
    m_rcInset = rcInset;
}

void XContainer::SetOwner( XWindow* pWindow )
{
    for (int i = 0; i < GetSize(); i++)
    {
        GetData(i)->SetOwner(pWindow);
    }
    XControl::SetOwner(pWindow);
}

void XContainer::SetParent( XControl* pControl )
{
    for (int i = 0; i < GetSize(); i++)
    {
        GetData(i)->SetParent(this);
    }
    XControl::SetParent(pControl);
}

XControl* XContainer::CreateControl( XClass* pClass )
{
    XControl* pControl = XControl::CreateControl(pClass);
    ASSERT_VALID(pControl);
    Add(pControl);
    pControl->SetBkColor(m_dwBkColor);
    return pControl;
}

void XContainer::Event( TEvent& event )
{
    if (!m_bMouseEnabled)
    {
        if (!m_bMouseEnabled)
        {
            if (OnMouseEvent(event.msg.message))
            {
                if ( m_pParent != NULL )
                {
                    event.sender = this;
                    event.receiver = m_pParent;
                    event.dispatcher->PostEvent(event);
                }
                else
                {
                    XControl::Event(event);
                }
            }
        }
    }
    else
    {
        switch ( event.msg.message ) 
        {
        case WM_VSCROLL:
            if (m_pChildWindow != NULL)
            {
                switch( LOWORD(event.msg.wParam) ) {
                case SB_THUMBPOSITION:
                case SB_THUMBTRACK:
                    {
                        SCROLLINFO si = { 0 };
                        si.cbSize = sizeof(SCROLLINFO);
                        si.fMask = SIF_TRACKPOS;
                        m_pChildWindow->_GetScrollInfo(SB_CTL, &si);
                        SetScrollPos(si.nTrackPos);
                    }
                    return;
                case SB_LINEUP:
                    SetScrollPos(GetScrollPos() - 5);
                    return;
                case SB_LINEDOWN:
                    SetScrollPos(GetScrollPos() + 5);
                    return;
                case SB_PAGEUP:
                    SetScrollPos(GetScrollPos() - GetScrollPage());
                    return;
                case SB_PAGEDOWN:
                    SetScrollPos(GetScrollPos() + GetScrollPage());
                    return;
                case SB_TOP:
                    SetScrollPos(0);
                    return;
                case SB_BOTTOM:
                    SetScrollPos(GetScrollRange().cy);
                    return;
                }
            }
        case WM_KEYDOWN:
            if (m_pChildWindow != NULL)
            {
                switch( event.msg.wParam ) {
                case VK_DOWN:
                    SetScrollPos(GetScrollPos() + 5);
                    return;
                case VK_UP:
                    SetScrollPos(GetScrollPos() - 5);
                    return;
                case VK_NEXT:
                    SetScrollPos(GetScrollPos() + GetScrollPage());
                    return;
                case VK_PRIOR:
                    SetScrollPos(GetScrollPos() - GetScrollPage());
                    return;
                case VK_HOME:
                    SetScrollPos(0);
                    return;
                case VK_END:
                    SetScrollPos(INT_MAX);
                    return;
                }
            }
        case WM_SIZE: // �ı��С
            SetRect(XRect(0, 0, LOWORD(event.msg.lParam), HIWORD(event.msg.lParam)));
            return;
        }
        XControl::Event(event);
    }
}

XControl* XContainer::FindControl( X_FIND_CALL Proc, LPVOID pData, UINT uFlags )
{
    // Check if this guy is valid
    XPoint pt(*static_cast<LPPOINT>(pData));

    if( (uFlags & XFIND_VISIBLE) != 0 && !m_bVisible ) return NULL;
    if( (uFlags & XFIND_ENABLED) != 0 && !m_bEnabled ) return NULL;
    if( (uFlags & XFIND_HITTEST) != 0 ) {
        if( !m_rcClient.PtInRect(pt) ) return NULL;
    }

    if( (uFlags & XFIND_ME_FIRST) != 0 ) {
        XControl* pControl = XControl::FindControl(Proc, pData, uFlags);
        if( pControl != NULL ) return pControl;
    }

    XRect rc = m_rcClient;
    rc.left += m_rcInset.left;
    rc.top += m_rcInset.top;
    rc.right -= m_rcInset.right;
    rc.bottom -= m_rcInset.bottom;

    if( (uFlags & XFIND_TOP_FIRST) != 0 ) // ��������
    {
        for( int i = m_Items.GetSize() - 1; i >= 0; i-- )
        {
            XControl* pControl = m_Items[i]->FindControl(Proc, pData, uFlags);
            if( pControl != NULL )
            {
                if( (uFlags & XFIND_HITTEST) != 0 && !rc.PtInRect(pt) )
                {
                    continue;
                }
                else
                {
                    return pControl;
                }
            }            
        }
    }
    else
    {
        for( int i = 0; i < m_Items.GetSize(); i++ )
        {
            XControl* pControl = m_Items[i]->FindControl(Proc, pData, uFlags);
            if( pControl != NULL )
            {
                if( (uFlags & XFIND_HITTEST) != 0 && !rc.PtInRect(pt) )
                {
                    continue;
                }
                else 
                {
                    return pControl;
                }
            } 
        }
    }

    return XControl::FindControl(Proc, pData, uFlags);
}

void XContainer::SetRect( const XRect & rect )
{
    XScroll::SetRect(rect);
    if( m_Items.GetSize() == 0 ) return;
    XRect rc(rect);
    rc.InsetRect(m_rcInset);
    // We'll position the first child in the entire client area.
    // Do not leave a container empty.
    if (m_Items.GetSize() == 1)
    {
        // Calculate position
        XControl* pControl = GetData(0);
        ASSERT_VALID(pControl);
        XRect rt(m_rcClient);
        UINT uPos = pControl->GetCalcPos();
        if (uPos != XPOS_NORMAL && (uPos & XPOS_RECALC) == 0) {
            XSize sz = pControl->EstimateSize(XSize());
            if (sz.cx != 0) {
                if ((uPos & XPOS_LEFT) != 0) {
                    rt.right = rt.left + sz.cx;
                } else if ((uPos & XPOS_RIGHT) != 0) {
                    rt.left = rt.right - sz.cx;
                } else if ((uPos & XPOS_CENTER) != 0) {
                    rt.DeflateRect(XSize((m_rcClient.Width() - sz.cx) / 2, 0));
                }
            }
            if (sz.cy != 0) {
                if ((uPos & XPOS_TOP) != 0) {
                    rt.bottom = rt.top + sz.cy;
                } else if ((uPos & XPOS_BOTTOM) != 0) {
                    rt.top = rt.bottom - sz.cy;
                } else if ((uPos & XPOS_VCENTER) != 0) {
                    rt.DeflateRect(XSize(0, (m_rcClient.Height() - sz.cy) / 2));
                }
            }
        }
        pControl->SetRect(rt);
    }
}

void XContainer::SetScrollPos( int iPos )
{
    XScroll::SetScrollPos(iPos);
    // Reposition children to the new viewport.
    SetRect(m_rcClient);
    Invalidate();
}

void XContainer::ProcessScrollbar( const XRect & rect, LONG cyRequired )
{
    // Need the scrollbar control, but it's been created already?
    if( cyRequired > rect.Height() && m_pChildWindow == NULL && m_bAllowScrollbars ) {
        XScroll::Init();
        SetRect(m_rcClient);
        return;
    }

    XScroll::ProcessScrollbar(rect, cyRequired);
}

XSize XContainer::EstimateSize( const XSize& sz )
{
    if ((m_flags & XFLAG_FLEXIABLE) != 0)
    {
        return XSize(0, 0); // ��̬����
    }
    return XScroll::EstimateSize(sz);
}

CONTAINER_END_NAMESPACE