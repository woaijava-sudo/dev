#include "stdafx.h"
#include "LoginWnd.h"

using namespace cc::Debug;
using namespace cc::UI::Window;
using namespace cc::UI::Controls;
using namespace cc::UI::Containers;

X_IMPLEMENT_CLASS(LoginWnd, XWindow)
LoginWnd::LoginWnd()
{
    m_lpszWindowClass = _T("LoginWnd");
    m_uStyle = XCS_FRAME;
    title = NULL;
}

LoginWnd::~LoginWnd()
{

}

LRESULT LoginWnd::HandleMessage( UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    if (uMsg == WM_DESTROY)
    {
        PostQuitMessage(0);
        return 0;
    }

    return XWindow::HandleMessage(uMsg, wParam, lParam);
}

void LoginWnd::OnFinalMessage( HWND hWnd )
{
    if (mm)
    {
        timeKillEvent(mm);
    }
    timeEndPeriod(timer_accuracy);

    XWindow::OnFinalMessage(hWnd);
}

void LoginWnd::Notify( TAsyncNotify& notify )
{
    if (notify.bTrans)
    {
        XString strMsg = (LPCTSTR) notify.msg.message;
        IsValidString(strMsg);
        int len = strMsg.GetLength();
        switch (len)
        {
        case 10:
            if (strMsg == _T("WindowInit"))
                OnWindowInit(notify);
            if (strMsg == _T("EditReturn"))
                OnEditReturn(notify);
            break;
        }
    }
    else
    {
        switch (notify.msg.message)
        {
        case WM_CREATE:
            OnCreate(notify);
            break;
        case WM_TIMER:
            OnTimer(notify);
            break;
        }
    }
}

x_msg_call void LoginWnd::OnCreate( TAsyncNotify& notify )
{
#ifdef _DEBUG
    TRACE("['%s' - 0x%X] OnCreate", GetClass()->m_lpszClassName, this);
#endif // _DEBUG
}

void PASCAL PostProc(UINT wTimerID, UINT msg, DWORD dwUser, DWORD dwl, DWORD dw2)
{ 
    LoginWnd* wnd = (LoginWnd*)dwUser;

    int index = wnd->index;
    if (index < wnd->counts)
    {
        DWORD now = timeGetTime();
        const Titles& tt = wnd->titles.Get(index);
        if (now>tt.tick)
        {
            wnd->index++;
            if (index+1 < wnd->counts)
            {
                wnd->edit->SetText(wnd->titles.Get(index+1).lrcs);
            }
            XString* newstring = new XString;
            *newstring = tt.lrcs;
            if (newstring->IsEmpty())
            {
                *newstring=_T("Music...");
            }
            ::PostMessage(wnd->host, XTITLE_WM_POST_TEXT, 0, (LPARAM)newstring);
        }
    }
    else
    {
        ::PostMessage(wnd->host, XTITLE_WM_POST_TEXT, 0, (LPARAM)new XString(_T("End")));
        ::PostMessage(wnd->host, XTITLE_WM_POST_TEXT, 0, (LPARAM)new XString(_T("\n")));
        wnd->edit->SetText(_T(""));
        timeKillEvent(wnd->mm);
        wnd->mm=0;
    }
}

x_msg_call void LoginWnd::OnWindowInit( TAsyncNotify& notify )
{
#ifdef _DEBUG
    TRACE("['%s' - 0x%X] OnWindowInit", GetClass()->m_lpszClassName, this);
#endif // _DEBUG
// 	_SetTimer(FindControl(_T("Time")), 0x10, 1000);
    //AddAnimation(XAnimTask(XANIMTYPE_FLAT, 0, 400, CLR_INVALID, CLR_INVALID, m_pRoot->GetRect(), 0, 30, 0, 255, 0.0f));

    //settings
    host = title->GetChildWnd2()->GetSafeHwnd();
    title->GetChildWnd2()->_PostMessage(XTITLE_WM_SET_ATTR, XTITLE_WM_SET_MAX_DELAY, 2);
    title->GetChildWnd2()->_PostMessage(XTITLE_WM_SET_ATTR, XTITLE_WM_SET_TIME_HOLD, 20000);

    using namespace cc::Stream;
    using namespace cc::Regex;
    FileStream fs(L"F:\\Projects\\cc_class_lib\\1.txt",FileStream::ReadOnly);
    if (!fs.IsAvailable())
    {
        return;
    }
    fpos_t size = fs.Size();
    char* buffer = new char[(pos_t)size];
    fs.Read(buffer,(pos_t)size);
    String str(buffer);
    delete[] buffer;

    index = 0;
    DWORD tk = timeGetTime() + 3000;

    try
    {
	    Regex regex(L"/[(<a>/d{2}):(<b>/d{2})/.(<c>/d{2})/](<d>/.*?)/n", true);
	    RegexMatch::MatchList result;
	    regex.Search(str, result);
	    if (result.Count() > 0)
	    {
	        auto enumerator = result.Wrap().CreateEnumerator();
	        while(enumerator->Next())
	        {
	            const RegexMatch::CaptureGroup& group = enumerator->Current()->Groups();
	            Titles ti;
	            ti.tick =
                    tk + 
	                _ttoi(group[_T("a")].Get(0).Value().Buffer()) * 60000 +
	                _ttoi(group[_T("b")].Get(0).Value().Buffer()) * 1000 +
	                _ttoi(group[_T("c")].Get(0).Value().Buffer()) * 10;
	            ti.lrcs = group[_T("d")].Get(0).Value();
	            titles.Add(ti);
	        }
	        delete enumerator;
	    }
    }
    catch (cc::Exception& e)
    {
    	TRACE("Exception: %s", e.GetMessage());
    }

    counts = titles.Count();

    TIMECAPS tc;
    if(timeGetDevCaps(&tc,sizeof(TIMECAPS))==TIMERR_NOERROR) 
    {
        timer_accuracy = CLAMP(timer_accuracy, tc.wPeriodMin, tc.wPeriodMax);
        timeBeginPeriod(timer_accuracy);
    }
    mm = timeSetEvent(10, timer_accuracy, (LPTIMECALLBACK)PostProc, (DWORD_PTR)this, TIME_PERIODIC);
    ASSERT(mm);
}

x_msg_call void LoginWnd::OnTimer( TAsyncNotify& notify )
{
#ifdef _DEBUG
    TRACE("['%s' - 0x%X] OnTimer ==> ['%s' - %s - 0x%X]", GetClass()->m_lpszClassName, this, notify.sender->GetName(), notify.sender->GetClass()->m_lpszClassName, notify.sender);
#endif // _DEBUG
    // ��ʱ��
    // TNotify.sender - ������Ϣ�Ŀؼ����
    // TNotify.wParam - ��ʱ��ID
    // TNotify.lParam - ��ʱ�����
    switch (notify.msg.wParam)
    {
    case 0x10:
        {
            XString szTime;
            szTime.FormatTime(time(NULL), _T("%c"));
            XRect rt = notify.sender->GetRect();
            rt.DeflateRect(XSize(50, 20));
            //             AddAnimation(XAnimTask(XANIMTYPE_FLAT, 0, 200, CLR_INVALID, CLR_INVALID, rt, 0, -5, 0, 200, 0.0f));
            notify.sender->SetText(szTime);
            notify.sender->NeedUpdate();
        }
        break;
    }
}

x_msg_call void LoginWnd::OnButtonClick( TAsyncNotify& notify )
{
#ifdef _DEBUG
    TRACE("['%s' - 0x%X] OnButtonClick ==> ['%s' - %s - 0x%X]", GetClass()->m_lpszClassName, this, notify.sender->GetName(), notify.sender->GetClass()->m_lpszClassName, notify.sender);
#endif // _DEBUG
}

void LoginWnd::OnEditReturn( TAsyncNotify& notify )
{
    XString* text = new XString;
    *text = notify.sender->GetText();
    if (!text->IsEmpty())
    {
        title->GetChildWnd2()->_PostMessage(XTITLE_WM_POST_TEXT, (WPARAM)0, (LPARAM)text);
    }
}

void LoginWnd::InitializeUI( HWND hwndParent /*= NULL*/, DWORD dwStyle /*= XWS_FRAME*/, DWORD dwExStyle /*= XWSE_FRAME*/ )
{
//     SetMinSize(XSize(300, 300));
// 	Create(hwndParent, _T("ʾ������"), XWS_POPUP, XWSE_FRAME, 0, 0, 800, 600);
// 	SetDefaultFont(_T("����"), 16);

    /*
    // Create Layout
    XCanvas* root = GetICanvas(XWindow_CreateControl(XCanvas));
    XVerticalLayout* pV = GetIVerticalLayout(root->XCreateControl(XVerticalLayout));

    XCanvas* child = GetICanvas(pV->XCreateControl(XCanvas));
    child->SetFixedHeight(200);
    XLabel* label = GetILabel(child->XCreateControl(XLabel));
    label->SetName(_T("Label"));
    label->SetText(_T("�yԇ���"));
    label->SetFixedHeight(180);
    label->SetCalcPos(XPOS_CENTER | XPOS_BOTTOM);
    label->SetTextColor(XCOLOR_STANDARD_GREY);
    label->SetTextFont(_T("DFPNewChuan-B5"), 72);
    label->SetTextStyle(DT_VCENTER | DT_CENTER);

    child = GetICanvas(pV->XCreateControl(XCanvas));
    label->SetFixedHeight(80);
    label = GetILabel(child->XCreateControl(XLabel));
    label->SetName(_T("Time"));
    label->SetTextColor(XCOLOR_STANDARD_GREY);
    label->SetTextFont(_T("Times New Roman"), 24);
    label->SetTextStyle(DT_VCENTER | DT_CENTER);

    XHorizontalLayout* pH = GetIHorizontalLayout(pV->XCreateControl(XHorizontalLayout));
    pH->SetFixedHeight(60);
    label = GetILabel(pH->XCreateControl(XLabel));
    label->SetFixedWidth(360);
    label->SetName(_T("Label1"));
    label->SetText(_T("�ʻ���"));
    label->SetTextColor(XCOLOR_STANDARD_DARKGREY);
    label->SetTextPadding(XRect(0, 0, 20, 0));
    label->SetTextStyle(DT_VCENTER | DT_RIGHT);
    child = GetICanvas(pH->XCreateControl(XCanvas));
    XEdit* edit = GetIEdit(child->XCreateControl(XEdit));
    edit->SetName(_T("Name"));
    edit->SetText(_T("Name"));
    edit->SetFixedHeight(20);
    edit->SetFixedWidth(150);
    edit->SetCalcPos(XPOS_VCENTER | XPOS_LEFT);
    edit->SetTextColor(XCOLOR_STANDARD_DARKGREY);
    edit->SetTextStyle(DT_VCENTER);
    edit->SetMaxCharLength(15);

    pH = GetIHorizontalLayout(pV->XCreateControl(XHorizontalLayout));
    pH->SetFixedHeight(60);
    label = GetILabel(pH->XCreateControl(XLabel));
    label->SetFixedWidth(360);
    label->SetName(_T("Label2"));
    label->SetText(_T("���룺"));
    label->SetTextColor(XCOLOR_STANDARD_DARKGREY);
    label->SetTextPadding(XRect(0, 0, 20, 0));
    label->SetTextStyle(DT_VCENTER | DT_RIGHT);
    child = GetICanvas(pH->XCreateControl(XCanvas));
    edit = GetIEdit(child->XCreateControl(XEdit));
    edit->SetName(_T("Password"));
    edit->SetText(_T("Password"));
    edit->SetFixedHeight(20);
    edit->SetFixedWidth(150);
    edit->SetCalcPos(XPOS_VCENTER | XPOS_LEFT);
    edit->SetTextColor(XCOLOR_STANDARD_DARKGREY);
    edit->SetTextStyle(DT_VCENTER);
    edit->SetPassword(TRUE);
    edit->SetMaxCharLength(15);

    XCanvas* bottom = GetICanvas(pV->XCreateControl(XCanvas));
    bottom->SetRect(XRect(0, 0, 0, 100));
    XButton* button = GetIButton(bottom->XCreateControl(XButton));
    button->SetText(_T("��¼"));
    button->SetFixedHeight(40);
    button->SetFixedWidth(120);
    button->SetCalcPos(XPOS_CENTER | XPOS_VCENTER);
    button->SetTextStyle(DT_VCENTER | DT_CENTER);
    */

    //XBuilder builder;
    //XControl* root = builder.CreateFromFile(_T("Welcome.txt"), this, XMarkup::XMLFILE_ENCODING_ASNI);

    this->SetMinSize(XSize(300, 300));
    Create(hwndParent, _T("ʾ������"), XWS_FRAME, XWSE_FRAME, 0, 0, 800, 600);
    SetDefaultFont(_T("Microsoft Yahei"), 16);

    XHorizontalLayout* root = GetIHorizontalLayout(XWindow_CreateControl(XHorizontalLayout));
    XVerticalLayout* k1 = GetIVerticalLayout(root->XCreateControl(XVerticalLayout));
    k1->SetFlags(k1->GetFlags() | XFLAG_FLEXIABLE);
//     XVerticalLayout* k2 = GetIVerticalLayout(root->XCreateControl(XVerticalLayout));
    XCanvas* father = GetICanvas(k1->XCreateControl(XCanvas)); // For container constructor
    XCanvas* mother = GetICanvas(k1->XCreateControl(XCanvas)); // For container constructor
//     XCanvas* t1 = GetICanvas(k2->XCreateControl(XCanvas)); // For container constructor
//     XCanvas* t2 = GetICanvas(k2->XCreateControl(XCanvas)); // For container constructor

    father->SetName(_T("Father"));
    father->SetBkColor(MAKE_RGB(RGB(106, 213, 111)));
    father->SetForwardColor(MAKE_RGB(RGB(128, 255, 128)));
    father->EnableHotTrack();
    father->SetFlags(father->GetFlags() | XFLAG_FLEXIABLE);

    mother->SetName(_T("Mother"));
    mother->SetBkColor(MAKE_RGB(RGB(206, 113, 111)));
    mother->SetForwardColor(MAKE_RGB(RGB(255, 128, 128)));
    mother->EnableHotTrack();
    mother->SetFixedHeight(50);

// 
//     t1->SetName(_T("t1"));
//     t1->SetBkColor(MAKE_RGB(RGB(111, 113, 206)));
//     t1->SetForwardColor(MAKE_RGB(RGB(128, 128, 255)));
//     t1->EnableHotTrack();
// 
//     t2->SetName(_T("t2"));
//     t2->SetBkColor(MAKE_RGB(RGB(203, 213, 106)));
//     t2->SetForwardColor(MAKE_RGB(RGB(255, 255, 128)));
//     t2->EnableHotTrack();
// 
//     XList* list = GetIListEx(father->XCreateControl(XList));
//     list->SetName(_T("List"));
//     XListHeaderItem* p = GetIListHeaderItem(list->XCreateControl(XListHeaderItem));
//     p->SetText(_T("header"));
//     p->SetFixedWidth(80);
//     p = GetIListHeaderItem(list->XCreateControl(XListHeaderItem));
//     p->SetText(_T("header 2"));
//     p->SetFixedWidth(80);
//     p = GetIListHeaderItem(list->XCreateControl(XListHeaderItem));
//     p->SetText(_T("header 3"));
//     p->SetFixedWidth(80);
//     XListTextElement* t = NULL;
//     for (int i = 0; i < 20; i++)
//     {
//         t = GetIListTextElement(list->XCreateControl(XListTextElement));
//         t->SetText(0, XString::XFormat(_T("1.%d"), i));
//         t->SetText(1, XString::XFormat(_T("2.%d"), i));
//         t->SetText(2, XString::XFormat(_T("3.%d"), i));
//     }

    title = GetITitle(father->XCreateControl(XTitle));
    title->SetName(_T("Title"));
    title->SetText(_T("Title"));
    title->SetTextStyle(DT_VCENTER | DT_CENTER);

	edit = GetIEdit(mother->XCreateControl(XEdit));
	edit->SetName(_T("Edit"));
	edit->SetBkColor(ARGB(255, 0, 0, 0));
	edit->SetText(_T("����������"));
	edit->SetTextColor(RGB(255, 255, 255));
	edit->SetEditBkColor(RGB(0, 0, 0));
	edit->SetTextStyle(DT_SINGLELINE | DT_CENTER);
    edit->SetEditStyle(ES_CENTER);
    edit->SetFlags(edit->GetFlags() | XFLAG_STATIC | XFLAG_AUTOCLEAR); // ����hottrack
    edit->SetReadOnly(TRUE);

//     edit->SetTextStyle(DT_VCENTER | DT_CENTER | DT_EDITCONTROL);
//     edit->SetEditStyle(ES_MULTILINE | ES_WANTRETURN | ES_AUTOVSCROLL);

//      XButton* button = GetIButton(t2->XCreateControl(XButton));
//      button->SetName(_T("Button"));
//      button->SetText(_T("<i>����һ����ť</i>"));
//      button->SetTextFont(_T("����"), 32);
//      button->SetTextStyle(DT_VCENTER | DT_CENTER);
//      button->SetTextColor(RGB(255, 0, 0));
//      button->SetFocusedTextColor(RGB(0, 0, 255));
//      button->SetPushedTextColor(RGB(0, 255, 0));
//      button->SetHotTextColor(RGB(255, 255, 0));
//      button->SetBkColor(ARGB(128, 0x37, 0x49, 0x57));

//     XLabel* label = GetILabel(t2->XCreateControl(XLabel));
//     label->SetName(_T("Label"));
//     label->SetText(_T("����һ����ǩ"));
//     label->SetTextFont(_T("�����п�"), 32);
//     label->SetTextStyle(DT_VCENTER | DT_CENTER);
//     label->SetTextColor(RGB(255, 0, 0));
//     label->SetRect(XRect(0, 100, 300, 200));
//     label->SetBkColor(ARGB(128, 0x66, 0xcc, 0xff));

//     XText* label = GetIText(t2->XCreateControl(XText));
//     label->SetName(_T("Label"));
//     label->SetText(_T("<c #ff0000>abewew</c><n><a>reertert</a><n><u><r>234</r></u><n><a>reertert</a>"));
//     label->SetTextFont(_T("�����п�"), 32);
//     label->SetTextStyle(DT_VCENTER | DT_CENTER);
//     label->SetTextColor(RGB(255, 0, 0));
//     label->SetRect(XRect(0, 100, 300, 200));
//     label->SetBkColor(ARGB(128, 0x66, 0xcc, 0xff));
//     label->EnableShowHtml(TRUE);

//     XCombo* combo = GetICombo(t1->XCreateControl(XCombo));
//     combo->SetName(_T("Combo"));
//     combo->SetTextFont(_T("�����п�"), 32);
//     combo->SetBkColor(ARGB(128, 0x66, 0xcc, 0xff));
// 
//     for (int i = 0; i < 20; i++)
//     {
//         t = GetIListTextElement(combo->XCreateControl(XListTextElement));
//         t->SetText(0, XString::XFormat(_T("1.%d"), i));
//     }

    _SetIcon(LoadIcon(NULL, IDI_WINLOGO), TRUE);
    _SetIcon(LoadIcon(NULL, IDI_WINLOGO), FALSE);
    AttachControl(root);
    _CenterWindow();
}

