#include "stdafx.h"
#include "..\cc_lib\cc_Include.h"

#pragma comment(lib, "WINMM.LIB")

struct Titles
{
    DWORD   tick;
    String  lrcs;

    bool operator == (const Titles& t) const
    {
        return tick == t.tick;
    }
};

using namespace cc::UI::Window;
class LoginWnd : public XWindow
{
	X_DECLARE_CLASS(LoginWnd)
public:
	LoginWnd();
	~LoginWnd();

	virtual LRESULT HandleMessage( UINT uMsg, WPARAM wParam, LPARAM lParam );
	virtual void OnFinalMessage( HWND hWnd );

	virtual void Notify( TAsyncNotify& notify );
	virtual void InitializeUI( HWND hwndParent = NULL, DWORD dwStyle = XWS_FRAME, DWORD dwExStyle = XWSE_FRAME );

	x_msg_call void OnCreate( TAsyncNotify& notify );
	x_msg_call void OnTimer( TAsyncNotify& notify );
	x_msg_call void OnWindowInit( TAsyncNotify& notify );
	x_msg_call void OnButtonClick( TAsyncNotify& notify );
    x_msg_call void OnEditReturn( TAsyncNotify& notify );

public:
    List<Titles> titles;
    int index;
    int counts;
    MMRESULT mm;
    XEdit* edit;
    HWND host;

protected:
    XTitle* title;
    UINT timer_accuracy;
};