#include "stdafx.h"
#include "LoginWnd.h"

int APIENTRY WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd )
{
	XExitManager ex;
	XGlobal_SetInstanceAndResPath(hInstance, _T("/"));

	auto window = X_CreateWindow(LoginWnd);
	ex.DelayDeleteObject(window);

	window->InitializeUI();

	return window->MessageLoop();
}