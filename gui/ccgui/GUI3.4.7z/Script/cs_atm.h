#ifndef CS_ATM
#define CS_ATM

#include "stdafx.h"
#include "cs_inst.h"
#include "cs_pool.h"

using namespace std;
using namespace cc::base;

namespace cc
{
	namespace script
	{
		template<typename _EdgeData>
		class Cs_AtmEdge;
		template<typename _StatusData>
		class Cs_AtmStatus;
		template<typename _EdgeData, typename _StatusData>
		class Cs_AtmIBFSAlgorithm;

		template<typename _EdgeData>
		class Cs_AtmEdge
		{
		public:
			Cs_AtmStatus*				Start;
			Cs_AtmStatus*				End;
			_EdgeData					Data;
		};

		template<typename _StatusData>
		class Cs_AtmStatus
		{
		public:
			typedef vector<Cs_AtmEdge*>	_EdgeList;

			_EdgeList					InEdges;
			_EdgeList					OutEdges;
			_StatusData					Data;

			void Visit(Cs_AtmIBFSAlgorithm* Algorithm)
			{
				/*��ʼ��·������������*/
				auto & Stack = Algorithm->Path;
				Stack.clear();
				Stack.push_back(this);
				/*���п�����������*/
				for (auto & Current : Stack)
				{
					bool VisitConnected = true;
					bool RunEnd = true;
					/*����״̬*/
					Algorithm->VisitBegin(Current, VisitConnected, RunEnd);
					if (VisitConnected)
					{
						/*ȡ����ǰ״̬��ÿһ����*/
						for (auto & CurrentEdge : Current->OutEdges)
						{
							/*����ߵ�Ŀ����δ���ʣ����ұ�ͨ������*/
							if (find(Stack.begin(), Stack.end(), CurrentEdge->End) == Stack.end() && Algorithm->EdgeTest(CurrentEdge))
							{
								/*��·���ϼ���ߵ�Ŀ�꣬�Դ���������*/
								Stack.push_back(CurrentEdge->End);
							}
						}
					}
					if (RunEnd)
					{
						/*��������״̬*/
						Algorithm->VisitEnd(Current);
					}
				}
			}
		};

		/************************************************************************/
		/* ���ڹ�������������Զ����㷨�ӿ�                                     */
		/************************************************************************/
		template<typename _EdgeData, typename _StatusData>
		class Cs_AtmIBFSAlgorithm
		{
		public:
			virtual bool EdgeTest(Cs_AtmEdge* aEdge)
			{
				return true;
			}

			virtual void VisitBegin(Cs_AtmStatus* aStatus, bool& VisitConnected, bool& RunEnd)
			{
			}
			virtual void VisitEnd(Cs_AtmStatus* aStatus)
			{
			}

			vector<Cs_AtmStatus*>		Path;
		};

		template<typename _EdgeData, typename _StatusData>
		class Cs_Automata
		{
		protected:
			class Initer
			{
				friend class Cs_Automata;
			protected:
				Cs_Automata*					Automaton;
			public:
				void Init(Cs_AtmEdge* Data)
				{
					Automaton->Init(Data);
				}
				void Init(Cs_AtmStatus* Data)
				{
					Automaton->Init(Data);
				}
			};

		public:
			Cs_Pool<Cs_AtmEdge, Initer>			EdgePool;
			Cs_Pool<Cs_AtmStatus, Initer>		StatusPool;

			Cs_Automata(size_t PackSize)
				: EdgePool(PackSize)
				, StatusPool(PackSize)
			{
				EdgePool.GetInitializer()->Automaton = this;
				StatusPool.GetInitializer()->Automaton = this;
			}

			virtual void Init(Cs_AtmEdge* Data)
			{
			}

			virtual void Init(Cs_AtmStatus* Data)
			{
			}

			Cs_AtmEdge* Connect(Cs_AtmStatus* Start, Cs_AtmStatus* End)
			{
				Cs_AtmEdge* NewEdge = EdgePool.alloc();
				NewEdge->Start = Start;
				NewEdge->End = End;
				Start->OutEdges.Add(NewEdge);
				End->InEdges.Add(NewEdge);
				return NewEdge;
			}

			void Disconnect(Cs_AtmStatus* Start, Cs_AtmEdge* Edge)
			{
				auto Index = find(Start->OutEdges.begin(), Start->OutEdges.end(), Edge);
				if (Index != Start->OutEdges.end())
				{
					Start->OutEdges.erase(Index);
					Edge->End->InEdges.erase(find(Edge->End->InEdges.begin(), Edge->End->InEdges.end(), Edge));
					EdgePool.free(Edge);
				}
			}

			void Disconnect(Cs_AtmStatus* Start)
			{
				/*ɾ�����״̬���ӵ����б�*/
				for (auto & InEdge : Start->InEdges)
				{
					Disconnect(InEdge->Start, InEdge);
				}
				for (auto & OutEdge : Start->OutEdges)
				{
					Disconnect(Start, OutEdge);
				}
				/*ɾ����״̬*/
				StatusPool.free(Start);
			}
		};
	}
}

#endif